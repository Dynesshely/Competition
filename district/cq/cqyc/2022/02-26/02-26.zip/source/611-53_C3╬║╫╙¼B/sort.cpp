#include<bits/stdc++.h>
using namespace std;
int n,flag,a[100005],vis[10005];
long long k,cnt;
//int num[50005];
void check()
{
	for(int i=1;i<n;i++)
	if(a[i]-1>a[i+1]) return;
//	int bs=1;cnt++;
//	for(int i=n;i>=1;i--)
//	num[cnt]+=bs*a[i],bs*=10;
	cnt++;
	if(cnt==k)
	{
		for(int i=1;i<=n;i++)
		printf("%d ",a[i]);
		flag=1;return;
	}
	
	return;
}
void dfs(int x)
{
	if(flag==1) return;
	if(x==n+1)
	{
		check();
		return;
	}
	for(int i=1;i<=n;i++)
	{
		if(vis[i]) continue;
		a[x]=i,vis[i]=1;
		dfs(x+1);
		vis[i]=0;
	}
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d%lld",&n,&k);
	dfs(1);
	if(flag==0) printf("-1");
//	for(int i=1;i<=cnt;i++)
//	printf("%d\n",num[i]);
}
