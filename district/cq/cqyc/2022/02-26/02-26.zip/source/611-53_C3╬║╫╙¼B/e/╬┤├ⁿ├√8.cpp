#include<bits/stdc++.h>
using namespace std;
struct node{
	int w,id;
}b[10005];
int n,cnt,v[1005];
int a[1005],vis[1005];
void check()
{
	for(int i=1;i<=n;i++)
	a[i]=b[a[i]].w;
	for(int i=1;i<n;i++)
	if(gcd(a[i],a[i+1])==1) 
}
void dfs(int x)
{
	if(x==n+1)
	{check();return;}
	for(int i=1;i<=n;i++)
	{
		if(vis[i]) continue;
		a[x]=i,vis[i]=1;
		dfs(x+1);
		vis[i]=0;
	}
}
bool cmp(node a,node b)
{
	return a.w<b.w;
}
int main()
{
//	freopen("sum.in","r",stdin);
//	freopen("sum.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%d",&b[i].w),b[i].id=i;
    sort(b+1,b+n+1,cmp);
    for(int i=1;i<=n;i++)
    {
    	if(i==1 || b[i].w!=b[i-1].w) cnt++;
    	v[b[i].id]=cnt;
	}	
}
