#include<bits/stdc++.h>
using namespace std;
int T;
long long l,r,k;
int main()
{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%lld%lld%lld",&l,&r,&k);
		long long bs=1,cnt=0;
		if(k==0)
		{
			if(l<=0)
			printf("0"),cnt++;
			if(l<=1 && r>=1)
			printf("1 "),cnt++;
			if(cnt==0) printf("None.\n");
			else printf("\n");
			continue;
		}
		if(k==1)
		{
			if(l<=1 && r>=1) printf("1 "),cnt++;
			if(cnt==0) printf("None.\n");
			else printf("\n");
			continue;
		}
		if(l<=1 && r>=1) printf("1 "),cnt++;
		for(int i=1;i;i++)
		{
			bs*=k;
			if(bs>=l && bs<=r)
			printf("%lld ",bs),cnt++;
			if(bs>=r) break;
		}
		if(cnt==0) printf("None.\n");
		else printf("\n");
	}
	return 0;
}
