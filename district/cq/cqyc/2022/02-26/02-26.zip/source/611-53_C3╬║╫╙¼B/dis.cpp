#include<bits/stdc++.h>
using namespace std;
int n,m,l,r;
int a[100005],p[100005];
int main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		if(a[j]==a[i]) 
		{
			p[i]=j;
			break;
		}
	}
//	printf("P:");
//	for(int i=1;i<=n;i++)
//	printf("%d ",p[i]);printf("\n");
	while(m--)
	{
		scanf("%d%d",&l,&r);
		int ans=1e9;
		for(int i=l;i<=r;i++)
		{
			if(p[i] && p[i]<=r)
			ans=min(ans,p[i]-i);
		}
		if(ans==1e9)printf("-1\n");
		else printf("%d\n",ans);
	}
}
