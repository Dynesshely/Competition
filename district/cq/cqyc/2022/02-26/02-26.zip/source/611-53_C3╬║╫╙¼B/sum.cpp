#include<bits/stdc++.h>
using namespace std;
int n,m,l,r;
int a[1005];
long long sum[1005],p;
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		sum[i]=sum[i-1]+a[i];	
	}
	while(m--)
	{
		scanf("%d%d%lld",&l,&r,&p);
		long long ans=1e9;
		for(int i=l;i<=r;i++)
		for(int len=0;len+i<=r;len++)
		{
			int j=i+len;
			long long s=sum[j]-sum[i-1];
			//printf("i:%d j:%d s:%d\n",i,j,s);
			ans=min(ans,s%p);
		}
		printf("%d\n",ans);
	}
}
