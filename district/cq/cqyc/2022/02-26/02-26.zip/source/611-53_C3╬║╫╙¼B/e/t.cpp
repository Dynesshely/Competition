#include<bits/stdc++.h>
using namespace std;
const int mx=100005;
int n,m,l,r,cnt,h[1005];
int a[mx],p[mx],lst[mx],w[1005];
struct node{
	int w,id;
}b[10005];
bool cmp(node a,node b)
{
	return a.w<b.w;
}
int main()
{
	freopen("dis3.in","r",stdin);
//	freopen("dis.out","w",stdout);
    scanf("%d%d",&n,&m);
    int t=sqrt(n),tt=sqrt(n);
    for(int i=1;i<=n;i++)
    scanf("%d",&b[i].w),b[i].id=i;
    sort(b+1,b+n+1,cmp);
    for(int i=1;i<=n;i++)
    {
    	if(i==1 || b[i].w!=b[i-1].w) cnt++;
    	a[b[i].id]=cnt;
	}
	memset(p,0x3f,sizeof p);
	memset(w,0x3f,sizeof w);
	memset(h,0x3f,sizeof h);
	for(int i=1;i<=n;i++)
	{
		p[lst[a[i]]]=i-lst[a[i]];
		lst[a[i]]=i;
	}
	for(int i=1;i<=n;i++)
	{
		int ks=i/t+1;
		if(i%t==0) ks-=1;
		h[ks]=min(h[ks],i);
		w[ks]=min(w[ks],p[i]);
	}
	if(t*t<n) t+=1;
	while(m--)
	{
		scanf("%d%d",&l,&r);
		
		int ans=1e9;
		int ks=l/tt+1;
		if(l%tt==0) ks-=1;
		//printf("l:%d ks:%d\n",l,ks);
		if(l!=h[ks])
		{
			//printf("%d is not head!\nbaoli:from %d to %d\n",l,l,h[ks+1]-1);
			
			for(int i=l;i<h[ks+1];i++)
			ans=min(ans,p[i]);
			l=h[ks+1],ks+=1;
		}
		for(int i=ks;i<=t;i++)
		{
			if(h[i]+tt-1>r) 
			{l=h[i];break;}
			ans=min(ans,w[i]);
		}
		for(int i=l;i<=r;i++)
		ans=min(ans,p[i]);
		printf("%d\n",ans);
	}
}
/*
10 3
13 5 4 13 8 8 5 33 4 13

20 3
13 5 4 13 8 8 5 33 4 13 13 5 4 13 8 8 5 33 4 13
printf("P:");for(int i=1;i<=n;i++) printf("%d ",p[i]);printf("\n");
for(int i=1;i<=t;i++) printf("%d ",w[i]);	for(int i=1;i<=t;i++) printf("%d ",h[i]);
*/
