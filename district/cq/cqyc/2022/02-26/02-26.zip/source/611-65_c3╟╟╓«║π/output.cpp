#include <bits/stdc++.h>
using namespace std;
int n;
int main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%d",&n);
	long long l,r,k,po;
	bool tur;
	for(int i=1;i<=n;i++) {
		scanf("%lld%lld%lld",&l,&r,&k);
		po=1;tur=true;
		if(k==0&&l==0) printf("0 "),tur=false;
		while(po<=r) {
			if(po>=l) printf("%lld ",po),tur=false;
			po*=k;
		}
		if(tur) printf("None.");
		printf("\n");
	}
	return 0;
}
