#include <bits/stdc++.h>
using namespace std;
long long n,k;
bool boo[200010],bo[200010];
int ans[200010];
int main() {
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%lld%lld",&n,&k);k--;
	for(int i=1;i<=n-1;i++) {
		boo[i]=k&1;k>>=1;
	}
	if(k!=0) {
		printf("-1\n");return 0;
	}
	for(int i=0,j=n;i<n;i++,j--) {
		bo[j]=boo[i];
	}
	for(int i=1;i<=n;i++) ans[i]=i;
	int las=0;
	for(int i=1;i<=n;i++) {
		if(bo[i]==1&&las==0) las=i;
		if(bo[i]==0&&las!=0) {
			for(int j=las,k=i;j<=k;j++,k--) swap(ans[j],ans[k]);
			las=0;
		}
	}
	for(int i=1;i<=n;i++) printf("%d ",ans[i]);
	printf("\n");
	return 0;
}
