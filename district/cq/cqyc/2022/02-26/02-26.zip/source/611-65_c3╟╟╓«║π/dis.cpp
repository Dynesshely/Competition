#include <bits/stdc++.h>
using namespace std;
int n,m,h,a[1000010],nxt[1000010],b[1000010],g[1000010];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int fen(int ind) {
	int l=1,r=h,mid;
	while(r-l>1) {
		mid=(l+r)/2;
		if(g[mid]>ind) r=mid;
		else l=mid;
	}
	if(g[l]==ind) return l;
	else return r;
}
int c[1000010][20],d[1000010][20],po[20];
int init() {
	for(int i=n;i>=1;i--) {
		for(int j=1;i+po[j]<=n;j++) c[i][j]=min(c[i][j-1],c[i+po[j-1]][j-1]);
	}
	for(int i=1;i<=n;i++) {
		for(int j=1;i-po[j]>=1;j++) d[i][j]=min(d[i][j-1],d[i-po[j-1]][j-1]);
	}
	
	for(int i=1;i<=n;i++) {
		g[i]=g[i-1];
		if(po[g[i]+1]<=i) g[i]++;
	}
}
int cha(int l,int r) {
	if(l>r) return 1e9;
	if(l==r) return nxt[l]-l;
	return min(c[l][g[r-l]],d[r][g[r-l]]);
}
int cha2(int l,int r) {
	int ret=1e9;
	for(int i=l;i<=r;i++) ret=min(ret,nxt[i]-i);
	return ret;
}
int main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	po[0]=1;for(int i=1;i<20;i++) po[i]=po[i-1]*2;
	n=read();m=read();
	for(int i=1;i<=n;i++) a[i]=read(),g[i]=a[i];
	sort(g+1,g+1+n);h=unique(g+1,g+1+n)-g-1;
	for(int i=1;i<=n;i++) a[i]=fen(a[i]);
	for(int i=n;i>=1;i--) {
		if(b[a[i]]!=0) nxt[i]=b[a[i]];
		else nxt[i]=n+1;
		b[a[i]]=i;
	}
	for(int i=0;i<=n;i++) b[i]=0;
	for(int i=1;i<=n;i++) b[nxt[i]]=i;
	for(int i=1;i<=n;i++) b[i]=max(b[i-1],b[i]);
	for(int i=1;i<=n;i++) d[i+1][0]=c[i][0]=min(nxt[i]-i,nxt[i+1]-i-1);
	init();
	int l,r,ans;
	for(int i=1;i<=m;i++) {
		l=read();r=read();
		ans=cha(l,b[r]);
		if(ans<=n) printf("%d\n",cha(l,b[r]));
		else printf("-1\n");
	}
	return 0;
}
