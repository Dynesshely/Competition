/*
	T5 game:
	�ò����ۣ���������������ģ�⣬��������
	һ�����TLE&MLE&RE&WA�͸��� 
	
	��Ԥ�Ƶ÷�: 100+100+100+40+0=340 
*/
#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
int main() {
	freopen("game.in","r",stdin);
	srand(time(0));
	int type=rand()%5;
	cout<<"Result Type: ";
	switch(type) {
		case 0:cout<<"Time Limited Exceeded";break;
		case 1:cout<<"Memory Limited Exceeded";break;
		case 2:cout<<"Runtime Error";break;
		case 3:cout<<"Wrong Answer";break;
		case 4:cout<<"File Error";break;
		case 5:cout<<"Unknown Error";break;
	} cout<<endl;
	if (type==0) while(1) ;
	else if (type==1) while(1) char* x=new char;
	else if (type==2) {vector<int> a; cout<<*(a.begin())<<endl;}
	else if (type==3) {
		freopen("game.out","w",stdout);
		cout<<1<<endl;
	}
	else if (type==4) {
		freopen("debug.txt","w",stdout);
		cout<<1<<endl;
	}
	return 0;
}

