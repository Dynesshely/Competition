#include<bits/stdc++.h>
#define min(x,y) ((x)<(y)?(x):(y))
using namespace std;
int n,m,a[500005],l,r,p,ans;
long long sum[500005];
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",a+i);
		sum[i]=sum[i-1]+a[i];
	}
	while(m--)
	{
		scanf("%d%d%d",&l,&r,&p);
		ans=505;
		for(int i=l;i<=r;++i)
		{
			for(int j=i;j<=r;++j)
			{
				ans=min(ans,(sum[j]-sum[i-1])%p);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}

