#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x)
{
	static int stk[30],tp;
	do
		stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)
		putchar(stk[tp--]^48);
}
int n,m,a[1000005],b[1000005],cnt;
int lst[1000005],pre[1000005],nxt[1000005];
int ans[100005],mn;
struct query
{
	int l,r,id;
	inline const bool operator<(const query& A)const
	{
		if(l==A.l) return r>A.r;
		return l<A.l;
	}
}q[100005];
map<int,int> lsh;
int main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i) b[i]=a[i]=read();
	for(int i=1;i<=m;++i) q[i].l=read(),q[i].r=read(),q[i].id=i;
	sort(b+1,b+1+n),b[0]=2000000000;
	for(int i=1;i<=n;++i)
	{
		if(b[i]!=b[i-1]) ++cnt;
		lsh[b[i]]=cnt;
	}
	for(int i=1;i<=n;++i) a[i]=lsh[a[i]];
	for(int i=1;i<=n;++i)
	{
		if(lst[a[i]]) nxt[lst[a[i]]]=i,pre[i]=lst[a[i]];
		lst[a[i]]=i;
	}
	if(n<=1000)
	{
		for(int i=1;i<=m;++i)
		{
			mn=1e9;
			for(int j=q[i].l;j<=q[i].r;++j)
			{
				if(nxt[j] && nxt[j]<=q[i].r) mn=min(mn,nxt[j]-j);
			}
			if(mn==1e9) puts("-1");
			else printf("%d\n",mn);
		}
	}
	return 0;
}
/*
9
1 2 3 1 2 3 1 2 3
*/
