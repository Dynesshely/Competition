#include<bits/stdc++.h>
#define lowbit(x) (x&(-x))
using namespace std;
int n,seq[100005],tot=0,t1[100005],t2[100005],len[100005];
long long k,mx=1,tmp;
bitset<100005> vis,bk,used;
void dfs(int p)
{
	if(p==n+1)
	{
		bool flag=1;
		for(int i=2; i<=n; ++i)
		{
			if(seq[i]<seq[i-1]-1)
			{
				flag=0;
				break;
			}
		}
		if(flag) ++tot;
		if(tot==k)
		{
			for(int i=1; i<=n; ++i)
			{
				printf("%d ",seq[i]);
			}
		}
		return ;
	}
	for(int i=1; i<=n; ++i)
	{
		if(tot>=k) return;
		if(!vis[i])
		{
			seq[p]=i,vis[i]=1;
			dfs(p+1);
			vis[i]=0;
		}

	}
}
int c[100005];
int ask(int i)
{
	int ret=0;
	for(; i; i-=lowbit(i)) ret+=c[i];
	return ret;
}
void update(int i,int k)
{
	for(; i<=n; i+=lowbit(i)) c[i]+=k;
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d%lld",&n,&k);
	for(int i=2; i<=n; ++i)
	{
		mx<<=1;
		if(mx>=k) break;
	}
	if(k>mx)
	{
		printf("-1");
		return 0;
	}
	if(n<10)
	{
		dfs(1);
		return 0;
	}
	k-=1;
	for(int i=1; k; ++i)
	{
		bk[i]=(k&1);
		k>>=1;
	}
	for(int i=1; i<n; ++i)
	{
		bk[i]=(~bk[i]);
		if(bk[i]) len[i]=i;
		else len[i]=len[i-1];
	}
	for(int i=1; i<=n; ++i)
	{
		update(i,1);
	}
	for(int i=n; i>=2; --i)
	{
		//ÿ�����ʣ�µ����е�(n-len)С������len��ĿǰΪֹ���һλ1��λ�á�
		int tt=ask(i-len[i-1]);
		printf("%d ",tt);
		update(i-len[i-1],1);
		used[tt]=1;
	}
	for(int i=1;i<=n;++i)
	{
		if(!used[i])
		{
			printf("%d",i);
			return 0;
		}
	}
	return 0;
}

