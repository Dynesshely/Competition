#include<bits/stdc++.h>
using namespace std;
inline __int128 read()
{
	__int128 x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x;
}
inline void write(__int128 x)
{
	static int stk[64],tp;
	do
		stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)
		putchar(stk[tp--]^48);
}
int T;
__int128 l,r,k;
bool none;
int main()
{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		l=read();
		r=read();
		k=read();
		none=1;
		if(k==0 || k==1)
		{
			if(k==0 && l<=0 && r>=0) printf("0 "),none=0;
			if(l<=1 && r>=1) putchar('1'),none=0;
			if(none) printf("None.");
			putchar('\n');
			continue;
		}
		for(__int128 i=1;i<=r;i*=k)
		{
			if(i>=l)
			{
				none=0;
				write(i);
				putchar(' ');
			}
		}
		if(none) printf("None.");
		putchar('\n');
	}
	return 0;
}
/*
1
0 9223372036854775808 2
*/
