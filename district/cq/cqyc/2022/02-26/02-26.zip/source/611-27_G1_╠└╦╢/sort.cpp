#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,k;
bool vis[1000005];
vector<int> tmp;
string s[1000005];
int sum=0;
bool check(){
	for(register int i=0;i<n-1;i++){
		if(tmp[i]-1>tmp[i+1]) return false;
	}
	return true;
}
void dfs(int now){
	if(now==n+1){
		if(check()){
			sum++;
			for(register int i=0;i<n;i++){
				s[sum]+=(char)(tmp[i]+'0');
				//n<=9
			}
		}
		return;
	}
	for(register int i=1;i<=n;i++){
		if(!vis[i]){
			vis[i]=true;
			tmp.push_back(i);
			dfs(now+1);
			vis[i]=false;
			tmp.pop_back();
		}
	}	
} 
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n=read(),k=read();
	if(n<=9){
		for(register int i=1;i<=n;i++){
			tmp.push_back(i);
			vis[i]=true;
			dfs(2);
			vis[i]=false;
			tmp.pop_back();
		}
		sort(s+1,s+sum+1);
		if(k>sum) puts("-1");
		else {
			for(register int i=0;i<n;i++)
				cout<<s[k][i]<<" ";
		}
	}
	else puts("-1");
	return 0;
}
