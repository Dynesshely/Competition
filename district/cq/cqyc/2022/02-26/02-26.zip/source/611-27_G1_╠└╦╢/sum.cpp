#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0; char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){ sss=sss*10+chh-'0'; chh=getchar(); }
	return sss;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48); puts("");
}
int n,m;
int sum[500005];
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(),m=read(); int l,r,mod,x;
	for(register int i=1;i<=n;i++){
		x=read(); sum[i]=sum[i-1]+x;
	} 
	while(m--){
		int ans=1e9;
		l=read(),r=read(),mod=read();
		for(register int i=l;i<=r;i++){
			for(register int j=i;j<=r;j++){
				ans=min(ans,(sum[j]-sum[i-1])%mod);
			}
		}
		write(ans); 
	}
	return 0;
}
