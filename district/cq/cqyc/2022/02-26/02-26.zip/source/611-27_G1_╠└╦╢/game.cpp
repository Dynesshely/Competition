#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0; char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){ sss=sss*10+chh-'0'; chh=getchar(); }
	return sss;
}
int n;
bool vis[2005];
int num[2005];
int ans[2005];
vector<int> tmp;
bool check(){
	for(register int i=0;i<n-1;i++){
		if(__gcd(tmp[i],tmp[i+1])==1) return false;
	}
	return true;
}
void dfs(int now){
	if(now==n+1){
		for(register int i=n-1;i>=1;i--){
			int j=i;
			while(j>=1&&tmp[j]>tmp[j-1]&&__gcd(tmp[j],tmp[j-1])==1){
				swap(tmp[j],tmp[j-1]);
				j--;
			}
		}
		for(register int i=1;i<=n;i++){
			if(ans[i]>tmp[i-1]){
				for(register int j=0;j<n;j++){
					ans[j+1]=tmp[j];
				}
				break;
			}
			else if(tmp[i-1]>ans[i]) break;
		}
		return;
	}
	for(register int i=1;i<=n;i++){
		if(!vis[i]){
			vis[i]=true;
			tmp.push_back(num[i]);
			dfs(now+1);
			vis[i]=false;
			tmp.pop_back();
		}
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++) num[i]=read();
	if(n<=5){
		memset(ans,0x3f,sizeof ans);
		for(register int i=1;i<=n;i++){
			vis[i]=true;
			tmp.push_back(num[i]);
			dfs(2);
			vis[i]=false;
			tmp.pop_back();
		}
		for(register int i=1;i<=n;i++){
			printf("%d ",ans[i]);
		}
	}
	return 0;
}
