#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) putchar(stk[tp--]^48);printf(" ");
}
int T,l,r,k,num;
signed main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	T=read();
	while(T--){
		l=read(),r=read(),k=read();
		bool flag=false;
		if(!k){
			if(l<=0&&r>=0) puts("0");
			else puts("None.");
		}
		else if(k==1){
			if(l<=1&&r>=1) puts("1");
			else puts("None.");
		}
		else {
			num=1;
			if(l<=num&&num<=r) printf("1 "),flag=true;
			for(register int i=1;i<=63;i++){
				num*=k;
				if(num>r) break;
				if(l<=num&&num<=r) flag=true,write(num);
			}
			if(!flag) puts("None.");
			else puts("");
		}
	}
	return 0;
}
