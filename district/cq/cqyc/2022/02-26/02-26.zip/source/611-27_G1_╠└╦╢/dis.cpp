#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);puts("");
}
int n,m;
int cnt[1000005],tot=0;
map<int,vector<int>> num;
int main(){
	freopen("dis.in","r",stdin);
 	freopen("dis.out","w",stdout);
	n=read(),m=read(); int x;
	for(register int i=1;i<=n;i++){
		x=read();
		num[x].push_back(i);
		if(num[x].size()==2) cnt[++tot]=x;
	}
	int l,r;
	while(m--){
		l=read(),r=read(); int ans=1e9;
		for(register int i=1;i<=tot;i++){
			if(ans==1) break;
			int len=num[cnt[i]].size();
			for(register int j=0;j<len-1;j++){
				if(num[cnt[i]][j]>=l&&num[cnt[i]][j+1]<=r){
					ans=min(ans,num[cnt[i]][j+1]-num[cnt[i]][j]);
				}
				if(ans==1) break;
			}
		}
		if(ans==1e9) puts("-1");
		else write(ans);
	}
	return 0;
}
