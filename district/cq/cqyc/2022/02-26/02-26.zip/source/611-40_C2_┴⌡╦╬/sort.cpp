#include <bits/stdc++.h>
#define ll long long
using namespace std;
int n,a[9],b[9],vis[9],foue;
ll k;
bool u(){
	for(int i=2;i<=n;i++){
		if(a[i-1]-1>a[i]) return 0;
	}
	return 1;
}
void dfs(int now){
	if(foue) return;
	if(now>n){
		if(k&&u()) k--;
		if(!k){
			for(int i=1;i<=n;i++) printf("%d ",a[i]);
			foue=1;
		}
		return;
	}
	for(int i=1;i<=n;i++){
		if(foue) return;
		if(!vis[i]){
			a[now]=i;
			vis[i]=1;
			dfs(now+1);
			vis[i]=0;
			a[now]=0;
		}
	}
}
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cin >> n >> k;
	dfs(1);
	if(!foue) cout << "-1";
	return 0;
}
