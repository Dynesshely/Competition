#include <bits/stdc++.h>
#define ll long long
#define FR 1152921504606846976
using namespace std;
int n,Q;
ll a[500003];
namespace Sub1{
	ll sum[500003];
	void solve(){
		for(int i=1;i<=n;i++) sum[i]=sum[i-1]+a[i];
		for(;Q;Q--){
			int L,R;
			ll p,ans=FR;
			scanf("%d%d%lld",&L,&R,&p);
			for(int l=L;l<=R;l++){
				for(int r=l;r<=R;r++){
					ans=min(ans,(sum[r]-sum[l-1])%p);
				}
			}
			printf("%lld\n",ans);
		}
		return;
	}
}
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&Q);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	if(1ll*n*n*Q<=40000000ll){
		Sub1::solve();
		return 0;
	}
	return 0;
}
