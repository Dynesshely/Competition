#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n,k;
int a[61],ansing[100003],dee[100003];
ll qpow(ll di,ll zhi){
	ll ret=1;
	while(zhi){
		if(zhi&1) ret*=di;
		di*=di;
		zhi>>=1;
	}
	return ret;
}
int find(int x){
	for(int i=1;i<=n;i++){
		if(dee[i]==0) x--;
		if(x==0){
			dee[i]=1;
			return i;
		}
	}
}
int main(){
	cin >> n >> k;
	//2^60>1e18
	if(n<=60&&k>qpow(2ll,n-1)){cout << "-1";return 0;}
	if(n<=3){
		if(n==1) cout << "1";
		if(n==2){
			if(k==1) cout << "1 2";
			else cout << "2 1";
		}
		if(n==3){
			if(k==1) cout << "1 2 3";
			if(k==2) cout << "1 3 2";
			if(k==3) cout << "2 1 3";
			if(k==4) cout << "3 2 1";
		}
		return 0;
	}
	for(int now=1;now<n-1;now++){
		ll l=1,r=qpow(2ll,n-2),y=k,re=0;
		for(ll q=n-2;q>=0;q--){
			ll u=qpow(2,q);
			if(y<=u){
				re=l;
				break;
			}
			l++;y-=u;
		}
		if(y&&re==0) re=l+1;
		int ququ=find(re);cout<<"#"<<now<<' '<<ququ<<endl;
		ansing[now]=ququ;
		if(now<n-2)k>>=1;
		cout<<k<<endl;
	}
	for(int i=1;i<n-1;i++) printf("%d ",ansing[i]);
	if(k==0) cout << find(1) << ' ',cout << find(1);
	else cout << find(2) << ' ',cout << find(1);
	return 0;
}
