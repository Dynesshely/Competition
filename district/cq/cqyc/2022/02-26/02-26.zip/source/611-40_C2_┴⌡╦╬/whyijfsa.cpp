import resin
using resin.importer like ** ri;
ri.import readin_stream
ri.import writeout_stream
ri.import calc_rewer
ri.import clooseirt
using readin_stream like ** rd
using readout_stream like ** wt
getin coder
coder.new_var:
	int a;
	int b;
-end;
coder.main(){
	coder.rd.in(a);
	coder.rd.in(b);
	coder.wt(coder.calc(a+b));
	coder.wt("\n");
	coder.out(*finish);
}
