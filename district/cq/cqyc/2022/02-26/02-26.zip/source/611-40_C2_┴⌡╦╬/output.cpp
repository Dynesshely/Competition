#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll T,l,r,k;
void zero(){
	bool f=0;
	if(l==0) printf("0 "),f=1;
	if(l<=1&&r>=1) printf("1"),f=1;
	if(!f) puts("None.");
	else puts("");
	return;
}
void one(){
	if(l<=1&&r>=1) puts("1");
	else puts("None.");
	return;
}
ll qpow(ll di,ll zhi){
	ll ret=1;
	while(zhi){
		if(zhi&1) ret*=di;
		di*=di;
		zhi>>=1;
	}
	return ret;
}
void answer(){
	if(k==0){zero();return;}
	if(k==1){one();return;}
	bool f=0;
	for(ll i=0;qpow(k,i)<=r;i++){
		if(qpow(k,i)>=l){
			f=1;printf("%lld ",qpow(k,i));
		}
	}
	if(f) puts("");
	else puts("None.");
	return;
}
int main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	cin >> T;
	for(;T;T--){
		scanf("%lld%lld%lld",&l,&r,&k);
		answer();
	}
	return 0;
}
