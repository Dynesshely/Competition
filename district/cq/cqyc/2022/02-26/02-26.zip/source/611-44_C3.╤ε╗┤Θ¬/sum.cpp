#include<bits/stdc++.h>
using namespace std;
long long n,m,a[500005],l,r,p,ans,sum[500005];
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void write(long long x){
	long long stk[30],tp=0;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
	putchar(' ');
}
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++) a[i]=read(),sum[i]=sum[i-1]+a[i];
	for(int i=1;i<=m;i++){
		l=read(),r=read(),p=read();
		ans=1e18; 
		for(int j=l;j<=r;j++){
			for(int g=j;g<=r;g++) ans=min(ans,(sum[g]-sum[j-1])%p);
		}
		write(ans);
		putchar('\n');
	}
	return 0;
}

