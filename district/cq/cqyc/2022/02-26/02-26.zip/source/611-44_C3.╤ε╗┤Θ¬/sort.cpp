#include<bits/stdc++.h>
using namespace std;
long long n,k,b[9],a[50005][9],cnt=0;
bool flag,vis[9];
void dfs(int k){
	if(k==n+1){
		flag=1;
		for(int i=1;i<n;i++) if(b[i]-1>b[i+1]) flag=0;
		if(flag){
			cnt++;
			for(int i=1;i<=n;i++) a[cnt][i]=b[i];
		}
		return;
	}
	for(int i=1;i<=n;i++){
		if(vis[i]) continue;
		vis[i]=1;b[k]=i;
		dfs(k+1);
		vis[i]=0;
	}
}
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	dfs(1);
	if(k>cnt){
		printf("-1");
		return 0;
	}
	for(int i=1;i<=n;i++) printf("%d ",a[k][i]);
	return 0;
}

