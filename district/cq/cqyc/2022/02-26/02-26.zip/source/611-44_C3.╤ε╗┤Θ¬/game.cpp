#include<bits/stdc++.h>
using namespace std;
int n,a[2005];
int gcd(int x,int y){
	if(y==0) return x;
	return gcd(y,x%y);
}
bool cmp(int x,int y){
	return x>y;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	if(n==1) cout<<a[1];
	else if(n==2){
		if(gcd(a[1],a[2])==1) cout<<max(a[1],a[2])<<" "<<min(a[1],a[2]);
		else cout<<min(a[1],a[2])<<" "<<max(a[1],a[2]);
	}
	else{
		sort(a+1,a+1+n,cmp);
		for(int i=1;i<=n;i++) cout<<a[i]<<" ";
	}
	return 0;
}

