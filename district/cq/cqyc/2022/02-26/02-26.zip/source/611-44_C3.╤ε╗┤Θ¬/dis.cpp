#include<bits/stdc++.h>
using namespace std;
int n,m,ans,a[1000005],b[1000005],c[1000005],cnt=0,tnt=0,l,r,t1,t2,mid,s[1000005];
bool flag;
struct ok{
	int x,y,z;
}e[1000005];
bool cmp(ok r1,ok r2){
	return r1.z<r2.z;
}
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void write(int x){
	int stk[30],tp=0;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
	putchar(' ');
}
int main(){
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++) a[i]=b[i]=read();
	sort(b+1,b+1+n);
	b[0]=-2e9;
	for(int i=1;i<=n;i++) if(b[i]!=b[i-1]) b[++cnt]=b[i];
	for(int i=1;i<=n;i++){
		t1=1,t2=cnt;
		while(t1<=t2){
			mid=(t1+t2)>>1;
			if(b[mid]==a[i]){
				a[i]=mid;
				break;
			}
			if(b[mid]>a[i]) t2=mid-1;
			else t1=mid+1;
		}
	}
	for(int i=1;i<=cnt;i++) c[i]=-1e8;
	for(int i=1;i<=n;i++){
		s[i]=i-c[a[i]];
		if(s[i]<=(int)1e9){
			tnt++;
			e[tnt].x=c[a[i]];
			e[tnt].y=i;
			e[tnt].z=s[i];
		}
		c[a[i]]=i;
	}
	sort(e+1,e+1+tnt,cmp);
	for(int i=1;i<=m;i++){
		l=read(),r=read();
		flag=0;
		for(int j=1;j<=tnt;j++){
			if(l<=e[j].x&&e[j].y<=r){
				write(e[j].z);
				putchar('\n');
				flag=1;
				break;
			}
		}
		if(flag==0) puts("-1");
	}
	return 0;
}

