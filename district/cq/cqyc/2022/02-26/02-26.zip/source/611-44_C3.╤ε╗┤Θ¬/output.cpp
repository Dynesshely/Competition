#include<bits/stdc++.h>
using namespace std;
long long t,k,l,r,cnt;
__int128 p;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	} 
	return x*f;
}
void write(long long x){
	long long stk[30],tp=0;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
	putchar(' ');
}
int main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	t=read();
	for(int i=1;i<=t;i++){
		l=read(),r=read(),k=read();
		cnt=0;
		if(k==0){
			if(l<=0&&r>=0) write(0),cnt++;
			if(l<=1&&r>=1) write(1),cnt++;
		}
		else if(k==1){
			if(l<=1&&r>=1) write(1),cnt++;
		}
		else{
			for(int j=0;j<=62;j++){
				if(j==0) p=(__int128)1;
				else p*=(__int128)k;
				if(p>(__int128)r) break;
				if(l<=p&&p<=r){
					write(p);
					cnt++;
				} 
			}	
		}
		if(cnt==0) printf("None.");
		putchar('\n');
	}
	return 0;
}
