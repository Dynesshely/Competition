#include<bits/stdc++.h>
#define int long long
#define N 2000005
#define ls (w<<1)
#define rs (w<<1|1)
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		putchar('-');
		x=-x;
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
	putchar('\n');
}
int n,m,a[N],mn[N<<1],pre[N],ans[N];
inline void push_up(int w){
	if(mn[ls])
		mn[w]=min(mn[w],mn[ls]);
	if(mn[rs])
		mn[w]=min(mn[w],mn[rs]);
}
inline void add(int w,int l,int r,int x,int k){
	if(l==r){
		mn[w]=k;
		return;
	}
	int mid=(l+r)>>1;
	if(x<=mid)
		add(ls,l,mid,x,k);
	else
		add(rs,mid+1,r,x,k);
	push_up(w);
}
inline int query(int w,int l,int r,int L,int R){
	if(L<=l&&R>=r)
		return mn[w];
	int mid=(l+r)>>1,res=1e9;
	if(L<=mid)
		res=query(ls,l,mid,L,R);
	if(R>mid)
		res=min(res,query(rs,mid+1,r,L,R));
	return res;
}
struct node{
	int x,id;
	bool operator<(const node &y)const{
		return x==y.x?id<y.id:x<y.x;
	}
} b[N];
vector<node> P[N>>1];
signed main(){
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;++i){
		a[i]=read();
		b[i]=(node){a[i],i};
	}
	sort(b+1,b+1+n);
	for(int i=2;i<=n;++i)
		if(b[i].x==b[i-1].x)
			pre[b[i].id]=b[i-1].id;
	int l,r;
	for(int i=1;i<=m;++i){
		l=read();r=read();
		P[r].push_back((node){l,i});
	}
	for(int i=1;i<(N<<1);++i)
		mn[i]=1e9;
	for(int i=1;i<=n;++i){
		if(pre[i])
			add(1,1,n,pre[i],i-pre[i]);
		while(!P[i].empty()){
			node y=P[i].back();
			P[i].pop_back();
			ans[y.id]=query(1,1,n,y.x,i);
		}
	}
	for(int i=1;i<=m;++i)
		if(ans[i]!=1e9)
			write(ans[i]);
		else
			puts("-1");
	return 0;
}
