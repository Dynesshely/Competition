#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		putchar('-');
		x=-x;
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
	putchar(' ');
}
int T,l,k,r;
__int128 now;
bool flag;
signed main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	T=read();
	while(T--){
		l=read();r=read();k=read();
		flag=1;now=1;
		if(!k&&!l){
			write(0);
			flag=0;
		}
		while(now&&now<l)
			now*=k;
		while(now&&now<=r){
			write(now);
			flag=0;
			now*=k;
		}
		if(flag)
			printf("None.");
		putchar('\n');
	}
	return 0;
}
