#include<bits/stdc++.h>
#define int long long
#define N 4005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		putchar('-');
		x=-x;
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
	putchar(' ');
}
int n,a[N],t,tmp,ans[N],b[N];
bool vis[N],flag;
inline int gcd(int A,int B){
	if(!B)
		return A;
	return gcd(B,A%B);
}
inline void dfs(int k){
	if(k>n){
		flag=0;
		for(int i=n;i;--i){
			tmp=i;
			while(tmp>1&&gcd(b[i],b[--tmp])==1)
				if(b[i]>b[tmp])
					return;
		}
		for(int i=1;i<=n;++i)
			if(ans[i]>b[i]){
				for(int j=i;j<=n;++j)
					ans[j]=b[j];
				return;
			}
			else
				if(ans[i]<b[i])
					return;
		return;
	}
	for(int i=1;i<=n;++i)
		if(!vis[i]){
			vis[i]=1;
			b[k]=a[i];
			dfs(k+1);
			vis[i]=0;
		}
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	ans[1]=1e9;
	for(int i=1;i<=n;++i){
		a[i]=read();
	}
	dfs(1);
	for(int i=1;i<=n;++i)
		write(ans[i]);
	return 0;
}
