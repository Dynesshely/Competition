#include<bits/stdc++.h>
using namespace std;
int tp[50007][10],n,k,tot=1,flag,rock,vis[10];
void dfs(int n1) {
	if(n1>n) {
		tot++;
		return;
	}
	for(int i=1; i<=n; i++) {
		if(vis[i]==0) {
			vis[i]=1;
			tp[tot][n1]=i;
			dfs(n1+1);
			vis[i]=0;
		}
	}
}
int main() {
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d %d",&n,&k);
	dfs(1);
	for(int j=1; j<=n; j++) {
		for(int i=1; i<tot; i++) {
			if(tp[i][j]==0) tp[i][j]=tp[i-1][j];
		}
	}
	for(int i=1; i<tot; i++) {
		flag=1;
		for(int j=1; j<n; j++) {
			if(tp[i][j]-1>tp[i][j+1]) {
				flag=0;
				break;
			}
		}
		if(flag==1) {
			rock++;
			if(rock==k) {
				for(int j=1; j<=n; j++) printf("%d ",tp[i][j]);
				return 0;
			}
		}
	}
	printf("-1");
	return 0;
}
