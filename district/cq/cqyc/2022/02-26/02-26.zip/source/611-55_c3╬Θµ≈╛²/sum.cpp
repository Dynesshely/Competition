#include<bits/stdc++.h>
using namespace std;
int n,m,a[500007],sum[500007],l,r,p;
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%d %d %d",&l,&r,&p);
		int ans=p;
		for(int st=l;st<=r;st++)
		{
			for(int j=st;j<=r;j++)
			{
				int tmp=sum[j]-sum[st-1];
				ans=min(ans,tmp%p);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
