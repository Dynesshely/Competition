#include<bits/stdc++.h>
using namespace std;
int n,m,a[1000007],tot=1,las[1000007];
int h[1000007],inf=1e7;
struct node
{
	int num,id;
}tmp[1000007];
bool temp(node a1,node a2)
{
	return a1.num<a2.num;
}
struct ccf
{
	int ad,wh;
}tr[1000007];
void build(int id,int l,int r)
{
	int mid=(l+r)>>1;
	if(l==r)
	{
		if(h[l]!=0) tr[id].ad=h[l]-l;
		else tr[id].ad=inf;
		tr[id].wh=l;
		return;
	}
	build(id*2,l,mid),build(id*2+1,mid+1,r);
	if(tr[id*2].ad<=tr[id*2+1].ad) 	tr[id].ad=tr[id*2].ad,tr[id].wh=tr[id*2].wh;
	else tr[id].ad=tr[id*2+1].ad,tr[id].wh=tr[id*2+1].wh;
}
int find(int id,int l,int r,int ls,int rs)
{
	if(ls>r||rs<l) return inf;
	if(ls<=l&&rs>=r&&tr[id].wh+tr[id].ad<=rs) 	return tr[id].ad; 
	if(l==r) return inf;
	int mid=(l+r)>>1,ans=inf;
	if(ls<=mid) ans=min(ans,find(id*2,l,mid,ls,rs));
	if(rs>mid) ans=min(ans,find(id*2+1,mid+1,r,ls,rs));
	return ans;
}
int main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		tmp[i].num=a[i],tmp[i].id=i;
	}
	sort(tmp+1,tmp+1+n,temp);
	a[tmp[1].id]=tot;
	for(int i=2;i<=n;i++)
	{
		if(tmp[i].num!=tmp[i-1].num) tot++;
		a[tmp[i].id]=tot;
	}
	for(int i=1;i<=n;i++)
	{
		if(las[a[i]]!=0) h[las[a[i]]]=i;
		las[a[i]]=i;
	}
	build(1,1,n);
	int l,r;
	for(int i=1;i<=m;i++)
	{
		scanf("%d %d",&l,&r);
		int ans=find(1,1,n,l,r);
		if(ans==inf) printf("-1\n");
		else printf("%d\n",ans);
	}
	return 0;
}
