#include<bits/stdc++.h>
using namespace std;
int t;
long long tmp=1,h;
int main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%d",&t);
	while(t--) {
		long long l,r,k;
		scanf("%lld %lld %lld",&l,&r,&k);
		if(k==0||k==1) {
			if(k==0&&l<=0&&r>=0) printf("0 ");
			if(l<=1&&r>=1) printf("1 ");
			else if(k==1) printf("None.");
			if(k==0&&l>1) printf("None.");
			printf("\n");
			continue;
		}
		h=l,tmp=1;
		if(h>tmp) {
			while(h) {
				tmp=tmp*k,h=h/k;
			}
		}
		if(tmp<l) tmp=tmp*k;
		if(tmp<l||tmp>r) printf("None.");
		while(tmp>=l&&tmp<=r) {
			printf("%lld ",tmp);
			tmp=tmp*k;
		}
		printf("\n");
	}
	return 0;
}
