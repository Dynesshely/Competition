#include<bits/stdc++.h>
using namespace std;
int tp[50007][10],n,tot=1,flag,vis[10],a[10];
int ans[10];
void dfs(int n1) {
	if(n1>n) {
		tot++;
		return;
	}
	for(int i=1; i<=n; i++) {
		if(vis[i]==0) {
			vis[i]=1;
			tp[tot][n1]=a[i];
			dfs(n1+1);
			vis[i]=0;
		}
	}
}
int gdp(int x,int y) {
	if(x>y) swap(x,y);
	if(x==0) return y;
	return gdp(y%x,x);
}
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; i++) scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	dfs(1);
	for(int j=1; j<=n; j++) {
		for(int i=1; i<tot; i++) {
			if(tp[i][j]==0) tp[i][j]=tp[i-1][j];
		}
	}
	for(int i=1; i<tot; i++) {
		flag=1;
		for(int j=1; j<n; j++) {
			if(gdp(tp[i][j],tp[i][j+1])==1) {
				int tmp=j-1;
				if(tp[i][j]<tp[i][j+1]) flag=0;
				while(tmp>=1&&gdp(tp[i][tmp],tp[i][j+1])==1) {
					if(tp[i][tmp]<tp[i][j+1]) {
						flag=0;
						break;
					}
					tmp--;
				}
				tmp=j+2;
				while(tmp<=n&&gdp(tp[i][tmp],tp[i][j])==1) {
					if(tp[i][tmp]>tp[i][j]) {
						flag=0;
						break;
					}
					tmp++;
				}

				if(flag==0) break;
			}
		}
		if(flag==1) {
			for(int j=1; j<=n; j++) printf("%d ",tp[i][j]);
			return 0;
		}
	}
	return 0;
}
