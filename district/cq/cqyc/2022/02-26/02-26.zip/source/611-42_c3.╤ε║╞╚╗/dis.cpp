#include<bits/stdc++.h>
using namespace std;
int n,m,ans,p,q,l,r;
int a[1000001],b[1000001],dl[1000001],dr[1000001],las[1000001],nxt[1000001];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x)
{
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++) b[i]=a[i]=read();
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++) b[i]=lower_bound(a+1,a+1+n,b[i])-a-1;
	while(m--)
	{
		l=read(),r=read(),ans=1000000000;
		memset(las,0,sizeof(las));
		memset(nxt,0,sizeof(nxt));
		for(int i=l;i<=r;i++)
		{
			if(las[b[i]]) ans=min(ans,i-las[b[i]]);
			las[b[i]]=i;
		}
		for(int i=r;i>=l;i--)
		{
			if(nxt[b[i]]) ans=min(ans,nxt[b[i]]-i);
			nxt[b[i]]=i;
		}
		if(ans==1000000000) puts("-1");
		else {write(ans);putchar('\n');}
	}
	return 0;
}

