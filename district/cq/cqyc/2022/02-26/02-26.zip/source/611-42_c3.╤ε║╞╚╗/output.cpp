#include<bits/stdc++.h>
using namespace std;
int t,p;
long long l,r,k,now;
inline long long lread()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[40],tp;
void lwrite(long long x)
{
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
	putchar(' ');
}
int main()
{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		l=lread(),r=lread(),k=lread();
		p=0;
		if(k==0) 
		{
			if(l==0) printf("0 "),p++;
			if(l<=1&&r>=1) printf("1 "),p++;
		}
		else if(k==1)
		{
			if(l<=1&&r>=1) printf("1 "),p++;
		}
		else
		{
			if(l<=1&&r>=1) printf("1 "); 
			now=k;
			while(now<=r&&now>0&&now%k==0)
			{
				if(now>=l&&now<=r) 
				{
					p++;
					lwrite(now);
				}
				now*=k;
			}
		}
		if(!p) puts("None.");
		else puts("");
	}
	return 0;
}
