#include<bits/stdc++.h>
using namespace std;
int n,k,ans;
int a[10];
bool fl;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x)
{
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=n;i++) a[i]=i;
	do{
		fl=0;
		for(int i=1;i<n;i++)
			if(a[i]-1>a[i+1]) {fl=1;break;}	
		if(!fl) ans++;
		if(ans==k) {for(int i=1;i<=n;i++)printf("%d ",a[i]);break;}
	}while(next_permutation(a+1,a+1+n));
	if(ans!=k) printf("-1");
	return 0;
}

