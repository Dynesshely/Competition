#include<bits/stdc++.h>
using namespace std;
int n,p;
bool fl,bo;
int a[21],ans1[21],ans2[21],d[21];
int gcd(int x,int y)
{
	return x?gcd(y%x,x):y;
}
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x)
{
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
bool cmp(int x,int y)
{
	if(gcd(x,y)==1) return x>y; 
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	if(n==1) {
		printf("%d",a[1]);return 0;
	}
	memset(ans1,0x3f,sizeof(ans1));memset(ans2,0x3f,sizeof(ans2));
	sort(a+1,a+1+n);
	do{
		p=a[1];for(int i=2;i<=n;i++) p=gcd(p,a[i]);
		if(p!=1&&!fl) fl=1,memcpy(ans1,a,sizeof(a));
		memcpy(d,a,sizeof(a));sort(d+1,d+1+n,cmp);
		if(!bo) memcpy(ans2,d,sizeof(d)),bo=1;
		else 
		{
			for(int i=1;i<=n;i++) 
			{
				if(ans2[i]!=d[i])
				{
					if(ans2[i]>d[i]) memcpy(ans2,d,sizeof(d));
					break;			
				}
			}
		}
	}while(next_permutation(a+1,a+1+n));
	for(int i=1;i<=n;i++) 
	{
		if(ans1[i]!=ans2[i])
		{
			if(ans1[i]>ans2[i]) for(int j=1;j<=n;j++) printf("%d ",ans2[j]);
			else for(int j=1;j<=n;j++) printf("%d ",ans1[j]);
			break;			
		}
	}
	
	return 0;
}

