#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
#define space pc(' ')
#define enter pc('\n')
using namespace std ;
const int N = 1e5+5 ;
int n,m ;
int a[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
 }
int main()
{
	freopen("sum.in","r",stdin) ;
	freopen("sum.out","w",stdout) ;
	read(n),read(m) ;
	FOR(i,1,n,1) read(a[i]) ;
	while(m--)
	{
		int le,ri,p,ans = 1e9 ;
		read(le),read(ri),read(p) ;
		FOR(i,le,ri,1)
		{
			int sum = 0 ;
			FOR(j,i,ri,1)
			{
				sum += a[j],sum %= p ;
				ans = min(ans,sum) ;
			}
		} 
		print(ans),enter ;
	}
	return 0 ;
}

