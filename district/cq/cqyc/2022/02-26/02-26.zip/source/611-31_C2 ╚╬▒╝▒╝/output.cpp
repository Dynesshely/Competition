#include <bits/stdc++.h>
#define int long long
#define gc getchar
#define pc putchar
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
#define space pc(' ')
#define enter pc('\n')
using namespace std ;
int T,l,r,k,ans,us ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
 }
signed main()
{
	freopen("output.in","r",stdin) ;
	freopen("output.out","w",stdout) ;
	read(T) ;
	while(T--)
	{
		ans = 0 ;
		read(l),read(r),read(k),us = k ;
		if((k == 0 || k == 1) && l > 1) 
		{
			printf("None."),enter ;
			continue ;
		}
		if(!k && !l) print(0),ans++,space ;
		if(l <= 1 && r >= 1) print(1),ans++,space ;
		while(us <= r && k != 0 && k != 1 && us >= 0)
		{
			if(us >= l) print(us),space,ans++ ;
			us *= k ;
		}
		if(!ans) printf("None.") ;
		enter ;
	}
	return 0 ;
}

