#include <bits/stdc++.h>
#define int long long 
#define gc getchar
#define pc putchar
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
#define space pc(' ')
#define enter pc('\n')
#define pb push_back
#define sz size
using namespace std ;
const int N = 1e6+5 ;
int n,q,cnt,ans[N] ;
int us[N],vis[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
 }
struct L{int x,id ;}a[N] ;
struct F{int l,r,id ;}Q[N] ;
vector<F>e[N] ;
struct tree
{
	int sum ;
	struct node
	{
		int mi=1e9+7,l,r ;
	}tr[N<<2] ;
	inline int ls(int x){return x<<1 ;}
	inline int rs(int x){return x<<1|1 ;}
	inline void Build(int x,int le,int ri)
	{
		tr[x].l = le,tr[x].r = ri ;
		if(le == ri) return ;
		int mid = le+ri>>1 ;
		Build(ls(x),le,mid) ;
		Build(rs(x),mid+1,ri) ;
	}
	inline void query(int x,int le,int ri)
	{
		if(tr[x].l >= le && tr[x].r <= ri)
		{
			sum = min(sum,tr[x].mi) ;
			return ;
		}
		int mid = tr[x].l+tr[x].r>>1 ;
		if(le <= mid) query(ls(x),le,ri) ;
		if(mid < ri) query(rs(x),le,ri) ;
	}
	inline int Query(int le,int ri)
	{
		sum = 1e9+7 ; 
		query(1,le,ri) ;
		return sum ;
	}
	inline void Insert(int x,int k,int f)
	{
		if(tr[x].l == tr[x].r)
		{
			tr[x].mi = f ;
			return ;
		}
		int mid = tr[x].l+tr[x].r>>1 ;
		if(k <= mid) Insert(ls(x),k,f) ;
		else Insert(rs(x),k,f) ;
		tr[x].mi = min(tr[ls(x)].mi,tr[rs(x)].mi) ;
	 } 
}T ;

inline int cmp(L x,L y)
{
	return x.x < y.x ;
}
signed main()
{
	freopen("dis.in","r",stdin) ;
	freopen("dis.out","w",stdout) ;
	read(n),read(q) ;
	T.Build(1,1,n) ;
	FOR(i,1,n,1) read(a[i].x),a[i].id = i ;
	sort(a+1,a+1+n,cmp) ;
	a[0].x = 1e9+7 ;
	FOR(i,1,n,1)
	{
		if(a[i].x != a[i-1].x) ++cnt ;
		us[a[i].id] = cnt ;
	}
	FOR(i,1,q,1)
	{
		read(Q[i].l),read(Q[i].r),Q[i].id = i ;
		e[Q[i].r].pb(Q[i]),ans[i] = 1e9+7 ;
	}
	FOR(i,1,n,1)
	{
		if(vis[us[i]]) T.Insert(1,vis[us[i]],i-vis[us[i]]) ;
		vis[us[i]] = i ;
		if(e[i].sz())
			FOR(j,0,e[i].sz()-1,1)
			{
				int id = e[i][j].id ;
				ans[id] = T.Query(e[i][j].l,i) ;
				if(ans[id] == 1e9+7) ans[id] = -1 ;
			}
	}
	FOR(i,1,q,1) print(ans[i]),enter ;
	return 0 ;
}

