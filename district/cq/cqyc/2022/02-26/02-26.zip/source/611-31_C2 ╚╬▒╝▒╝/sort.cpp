#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
#define space pc(' ')
#define enter pc('\n')
using namespace std ;
const int N = 15 ;
int n,k,f,cnt ; 
int ans,vis[N],fan[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
 }
inline void check()
{
	FOR(i,1,n-1,1)
		if(fan[i]-1 > fan[i+1]) return ;
	++cnt ;
	return ;
}
inline void take(int x)
{
	if(x == n+1) 
	{
		check() ;
		return ; 
	}
	FOR(i,1,n,1)
	{
		if(vis[i]) continue ;
		vis[i] = 1 ;
		fan[x] = i ;
		take(x+1) ;
		if(cnt == k) return ;		
		vis[i] = fan[x] = 0 ; 
	}
}
int main()
{
	freopen("sort.in","r",stdin) ;
	freopen("sort.out","w",stdout) ;
	read(n),read(k) ;
	take(1) ;
	if(cnt == k) 
	 FOR(i,1,n,1) print(fan[i]),space ;
	else print(-1) ;
	return 0 ;
}

