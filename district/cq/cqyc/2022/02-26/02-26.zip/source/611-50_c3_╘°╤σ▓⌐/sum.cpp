#include <bits/stdc++.h>
using namespace std;
int read() {
	int f(0),x(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void write(int x) {
	if(x<0) x=-x,putchar('-');
	if(x>=10) write(x/10);
	putchar(x%10+'0');
}
const int N=205;
int n,m,a[N],b[N][N];
signed main() {
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i) a[i]=read();
	while(m--) {
		int l=read(),r=read(),p=read();
		int mi=1e9;
		memset(b,0,sizeof b);
		for(int i=l;i<=r;++i)
			for(int j=i;j<=r;++j)
				b[i][j]=(b[i][j-1]+a[j])%p,mi=min(b[i][j],mi);
		write(mi),putchar('\n');
	}
	return 0;
}
/*
*/
