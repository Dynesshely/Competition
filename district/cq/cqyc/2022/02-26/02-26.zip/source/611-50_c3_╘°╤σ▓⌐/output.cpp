#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int f(0),x(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void write(int x) {
	if(x<0) x=-x,putchar('-');
	if(x>=10) write(x/10);
	putchar(x%10+'0');
}
int t,l,r,k;
signed main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	t=read();
	while(t--) {
		l=read(),r=read(),k=read();
		bool flag=0;
		if(k==0) {
			if(l==0) flag=1,putchar('0'),putchar(' ');
			if(l<=1&&r>=1) flag=1,putchar('1'),putchar(' ');
		}
		else if(k==1) {
			if(l<=1&&r>=1) flag=1,putchar('1'),putchar(' ');
		}
		else {
			int tmp=1;
			while(1) {
				if(tmp>=l) flag=1,write(tmp),putchar(' ');
				if(tmp>r/k) break;
				tmp*=k;
			}
		}
		if(flag) putchar('\n');
		else puts("None.");
	}
	return 0;
}
/*
4
1 10 2
2 4 5
19562 31702689720 17701
3680 37745933600 10

1 2 4 8 
None.
313325401 
10000 100000 1000000 10000000 100000000 1000000000 10000000000 

2
0 0 0
0 0 1

0
None.
*/
