#include <bits/stdc++.h>
#define int long long
using namespace std;
void write(int x) {
	if(x<0) x=-x,putchar('-');
	if(x>=10) write(x/10);
	putchar(x%10+'0');
}
int n=1000000,m=1000000;
signed main() {
	freopen("dis.in","w",stdout);
	cout<<n<<" "<<m<<endl;
	for(int i=1;i<=n;++i) {
		int a=(int)rand()*rand()%1000000001ll;
		a*=rand()&1?1:-1;
		write(a),putchar('\n');
	}
	for(int i=1;i<=m;++i) {
		int a=(int)rand()*rand()%n+1,b=rand()*rand()%(n-a+1);
		write(a),putchar(' '),write(a+b),putchar('\n');
	}
	return 0;
}
/*
*/

