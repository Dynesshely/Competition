#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int f(0),x(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void write(int x) {
	if(x<0) x=-x,putchar('-');
	if(x>=10) write(x/10);
	putchar(x%10+'0');
}
const int N=100005;
int n,m,k,p[N],po[101],tot,mac;
bool vis[N];
bool check() {
	for(int i=1;i<n;++i) if(p[i]-1>p[i+1]) return 0;
	return 1;
}
void funshe() {
	for(n=1;n<=8;++n) {
		for(int i=1;i<=n;++i) p[i]=i;
		tot=0;
		do {
			if(check()) {
				for(int i=1;i<=n;++i) cout<<p[i]<<" ";
				cout<<endl;
				++tot;
			}
		} while(next_permutation(p+1,p+1+n));
		cout<<tot<<endl;
	}
	exit(0);
}
void gs() {
	for(n=1;n<=8;++n) {
		for(int kk=1;kk<=po[n-1];++kk) {
			k=kk;
			cerr<<n<<" "<<k<<endl;
			memset(vis,0,sizeof vis);
//			if(k<=mac&&k==po[n-1]) {
//				for(int i=1;i<=n;++i) write(n-i+1),putchar(' ');
//				putchar('\n');
//				continue;
//			}
			for(int i=1;i<=n;++i) {
				if(n-i-1>mac) {
		//			cerr<<i<<endl;
					write(i),vis[i]=1;
					continue;
				}
				if(k<=mac&&k==po[n-i]) {
					for(int j=n;j>=1;--j) if(!vis[j]) write(j),putchar(' ');
					putchar('\n');
					break;
				}
				int sum=0;
				for(int j=n-i-1;j>=0;--j) {
					sum+=po[j];
		//				cerr<<i<<" "<<j<<" "<<sum<<" "<<po[j]<<" "<<k<<" ";
					if(sum>=k/*||(j>0&&sum+po[j-1]>k)*/) {
						int ii=i;
						for(int kk=n-j-1;kk>=ii;--kk) vis[kk]=1,write(kk),putchar(' '),++i;
						--i;
						if(n-j-2-ii>=0) /*cerr<<"fa "<<n-j-ii-2<<" "<<n-i<<"       ",*/k-=sum-po[j];
		//				cerr<<i<<" "<<k<<" ";
		//				cerr<<endl;
						break;
					}
		//			cerr<<endl;
				}
				if(i==n) for(int i=1;i<=n;++i) if(!vis[i]) {
					write(i);
					break;
				}
			}
			putchar('\n');
		}
		cout<<po[n-1]<<endl;
	}
	exit(0);
}
signed main() {
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
//	funshe();
	n=read(),k=read();
	po[0]=1;
	for(int i=1;;++i) {
		po[i]=(po[i-1]<<1);
		if(po[i]==576460752303423488ll) {
			mac=i;
			break;
		}
	}
//	gs();
	if(n<=mac&&k>po[n-1]) {
		puts("-1");
		return 0;
	}
//	cerr<<mac<<"\n\n";
	for(int i=1;i<=n;++i) {
		if(n-i-1>mac) {
//			cerr<<i<<endl;
			write(i),putchar(' '),vis[i]=1;
			continue;
		}
		if(k<=mac&&k==po[n-i]) {
			for(int j=n;j>=1;--j) if(!vis[j]) write(j),putchar(' ');
			return 0;
		}
		int sum=0;
		for(int j=n-i-1;j>=0;--j) {
			sum+=po[j];
//				cerr<<i<<" "<<j<<" "<<sum<<" "<<po[j]<<" "<<k<<" ";
			if(sum>=k/*||(j>0&&sum+po[j-1]>k)*/) {
				int ii=i;
				for(int kk=n-j-1;kk>=ii;--kk) vis[kk]=1,write(kk),putchar(' '),++i;
				--i;
				if(n-j-2-ii>=0) /*cerr<<"fa "<<n-j-ii-2<<" "<<n-i<<"       ",*/k-=sum-po[j];
//				if(k==0) k=1;
//				cerr<<i<<" "<<k<<" ";
//				cerr<<endl;
				break;
			}
//			cerr<<endl;
		}
		if(i==n) for(int i=1;i<=n;++i) if(!vis[i]) {
			write(i);
			break;
		}
	}
	return 0;
}
/*
1 1

1

1 2

-1

3 3

2 1 3

3 4

3 2 1

6 5

1 2 4 3 5 6

8 117

4 3 2 1 6 5 7 8
*/
