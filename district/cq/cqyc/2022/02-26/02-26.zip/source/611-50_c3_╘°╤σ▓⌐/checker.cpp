#include <bits/stdc++.h>
using namespace std;
signed main() {
	system("fc dis.out dis3.ans");
	return 0;
}
/*
*/

