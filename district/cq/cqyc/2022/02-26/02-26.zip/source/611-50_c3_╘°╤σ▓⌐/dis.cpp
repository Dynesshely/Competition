#include <bits/stdc++.h>
#define pii pair<int,int>
using namespace std;
int read() {
	int f(0),x(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void write(int x) {
	if(x<0) x=-x,putchar('-');
	if(x>=10) write(x/10);
	putchar(x%10+'0');
}
const int N=1000005;
int n,m,a[N],ans[N],nxt[N],c[N],cnt;
pii p[N];
struct node {
	int l,r,id;
	bool operator < (const node &y) const {
		return l==y.l?r<=y.r:l>y.l;
	}
} b[N];
int t[N];
void add(int x,int k) {
	for(;x<=n;x+=(x&-x)) t[x]=min(t[x],k);
}
int ask(int x) {
	int mi=t[0];
	for(;x;x-=(x&-x)) mi=min(t[x],mi);
	return mi;
}
signed main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i) p[i].first=read(),p[i].second=i;
	for(int i=1;i<=m;++i) b[i].l=read(),b[i].r=read(),b[i].id=i;
	sort(p+1,p+1+n);
	sort(b+1,b+1+m);
	p[0].first=(1e9)+1;
	for(int i=1;i<=n;++i) cnt+=p[i].first!=p[i-1].first?1:0,c[p[i].second]=cnt;
//	for(int i=1;i<=n;++i) cerr<<c[i]<<" ";
//	cerr<<endl;
	memset(t,0x3f,sizeof t);
	int tmp=n+1;
	for(int i=1;i<=m;++i) {	
//		cerr<<b[i].l<<" "<<b[i].r<<endl;
		while(tmp>b[i].l) {
			--tmp;
			if(nxt[c[tmp]]) {
				add(nxt[c[tmp]],nxt[c[tmp]]-tmp);
//				cerr<<"fa "<<c[tmp]<<" "<<tmp<<" "<<nxt[c[tmp]]<<" "<<nxt[c[tmp]]-tmp<<endl;
			}
			nxt[c[tmp]]=tmp;
		}
		int mi=ask(b[i].r);
		if(mi==t[0]) ans[b[i].id]=-1;
		else ans[b[i].id]=mi;
	}
	for(int i=1;i<=m;++i) write(ans[i]),putchar('\n');
	return 0;
}
/*
5 3
1 1 2 3 2
1 5
2 4
3 5

1
-1
2

6 5
1 2 1 3 2 3
4 6
1 3
2 5
2 4
1 6

2
2
3
-1
2
*/
