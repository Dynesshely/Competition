#include<bits/stdc++.h>
using namespace std;
long long t,l,r,k,a;
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
void write(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>=10)
	write(x/10);
	putchar(x%10+'0');
}
int main()
	{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	t=read();
	for(int i=1;i<=t;++i)
	{
		l=read(),r=read(),k=read();
		long long p[105]={1},tot=1,sum=k,ans=0,jl=9223372036854775807,num,wz;
		bool pd_1=false,pd_2=false;
		p[0]=1;
		p[1]=k;
		if(k>1)
		{
				while(sum*k-1<jl)
			{
				sum*=k;
				p[++tot]=sum;
			}
		for(num=0;num<=tot;++num)
		{
			if(p[num]>=l)
			{
				pd_1=true;
				break;
			}
		}
		for(wz=num;wz<=tot;++wz)
		{
			if(p[wz]>=r)
			{
				pd_2=true;
				break;
			}
		}
		if(p[wz]>r)
		wz--;
		if(p[wz]<l)
		pd_2=false;
		if(pd_1==false||pd_2==false)
		{
			printf("None.\n");
			continue;
		}
		for(int j=num;j<=wz;++j)
		{
			write(p[j]);
			printf(" ");
		}
		}
		else
		{
			if(l<=k&&r>=k)
			write(k);
			else
			printf("None.");
		}
		printf("\n");
	}
	return 0;
	}
