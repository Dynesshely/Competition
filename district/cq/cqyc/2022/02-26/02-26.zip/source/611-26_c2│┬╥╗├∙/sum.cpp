#include<bits/stdc++.h>
using namespace std;
long long n,m,a[500005],l,r,p,ans,sum,num;
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
void write(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>=10)
	write(x/10);
	putchar(x%10+'0');
}
int main()
	{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i)
	a[i]=read();
	for(int i=1;i<=m;++i)
	{
		ans=0x3f3f3f3f;
		l=read(),r=read(),p=read();
		for(int j=l;j<=r;++j)
		{
		for(int w=j;w<=r;++w)
		{
		sum=0;
		for(int q=j;q<=w;++q)
		sum+=a[q];
		sum=sum%p;
		ans=min(ans,sum);	
		}
		}
		printf("%d\n",ans);
	}
	return 0;
	}
