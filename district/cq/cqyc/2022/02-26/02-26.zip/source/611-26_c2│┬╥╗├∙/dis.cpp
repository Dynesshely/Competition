#include<bits/stdc++.h>
using namespace std;
long long n,m,a[1000005],l,r,sum,num,ans;
bool pd;
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
void write(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>=10)
	write(x/10);
	putchar(x%10+'0');
}
int main()
	{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=m;++i)
	{
		pd=false;
		sum=0,ans=0x3f3f3f3f;
		l=read(),r=read();
		for(long long j=l;j<=r;++j)
			for(long long q=j+1;q<=r;++q)
			if(a[j]==a[q])
				{
				pd=true;
				sum=q-j;
				ans=min(sum,ans);
				}
		if(pd)
			write(ans);
		else
			printf("-1");
		printf("\n");
	}
	return 0;
	}
