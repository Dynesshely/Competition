#include<bits/stdc++.h>
using namespace std;
long long n,k,ans[100005],wz,tot;
char a[100005];
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
void write(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>=10)
	write(x/10);
	putchar(x%10+'0');
}
void zxy(long long sum,long long num)
{
	if(sum==n)
	return;
	if(k>=pow(2,n-sum-1)+pow(2,num))
	{
		for(int i=0;i<strlen(a);++i)
			if(a[i]-'0'==sum)
			{
				wz=i;
				break;
			}
		for(int i=sum+1;i>wz;--i)
			a[i]=a[i-1];
		a[wz]=sum+1+'0';
		zxy(sum+1,num+pow(2,n-sum-1));
	}
	else
	{
		tot=strlen(a);
		a[tot]=sum+1+'0';
		zxy(sum+1,num);
	}
	return;
}
int main()
	{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n=read(),k=read();
	if(k>pow(2,n-1))
	{
		cout<<-1;
		return 0;
	}
	a[0]='1';
	zxy(1,0);
	for(int i=0;i<strlen(a);++i)
	printf("%c ",a[i]);
	return 0;
	}
