#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
#define mid ((l+r)>>1)
const int N=1e6+5;
int ans[N],n,m,r,a[N],b[N],la[N],xd[4*N];
struct aa{
	int i,l,r;
}xw[N];
void add(int g,int l,int r,int v,int v1){
	xd[g]=min(xd[g],v1);
	if(l==r) return;
	if(v<=mid) add(2*g,l,mid,v,v1);
	else add(2*g+1,mid+1,r,v,v1);
}
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[60],tp;
void write(int x){
	do{
		stk[++tp]=x%10;
		x/=10;
	}while(x);
	while(tp) putchar(stk[tp--]^48);
}
bool cmp(aa a,aa b){
	return a.r<b.r;
}
int da(int g,int l,int r,int l1,int r1){
	if(l1<=l && r<=r1) return xd[g];
	int ans=xd[0];
	if(l1<=mid) ans=da(2*g,l,mid,l1,r1);
	if(r1>mid) ans=min(ans,da(2*g+1,mid+1,r,l1,r1));
	return ans;
}
int main(){
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	memset(xd,0x3f,sizeof(xd));
	n=read();
	m=read();
	for(int i=1;i<=n;i++) b[i]=a[i]=read();
	sort(b+1,b+1+n);
	for(int i=1;i<=n;i++) a[i]=lower_bound(b+1,b+1+n,a[i])-b;
	for(int i=1;i<=m;i++){
		xw[i].l=read();
		xw[i].r=read();
		xw[i].i=i;
	}
	sort(xw+1,xw+1+m,cmp);
	int no=0;
	for(int i=1;i<=m;i++){
		while(no<xw[i].r){
			no++;
			if(!la[a[no]]){
				la[a[no]]=no;
				continue; 
			}
			add(1,1,n,la[a[no]],no-la[a[no]]);
			la[a[no]]=no;
		}
		ans[xw[i].i]=da(1,1,n,xw[i].l,n);
	}
	for(int i=1;i<=m;i++){
		if(ans[i]==xd[0]){
			puts("-1");
			continue;
		}
		write(ans[i]);
		putchar('\n');
	}
	return 0;
}
