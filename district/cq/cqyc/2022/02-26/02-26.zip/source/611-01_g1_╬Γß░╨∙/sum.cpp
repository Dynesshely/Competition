#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=5e5+5;
int n,m,a[N];
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	while(m--){
		int l=0,r=0,p=0;
		scanf("%d %d %d",&l,&r,&p);
		int ans=p;
		for(int i=l;i<=r;i++){
			int an=0;
			for(int j=i;j<=r;j++){
				an+=a[j]%p;
				ans=min(ans,an%p);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
