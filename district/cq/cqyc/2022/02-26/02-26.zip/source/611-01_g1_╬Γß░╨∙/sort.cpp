#include<cstdio>
#define int long long
const int N=1e5+5;
int dp[N],n,k,po[N];
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[60],tp;
void write(int x){
	do{
		stk[++tp]=x%10;
		x/=10;
	}while(x);
	while(tp) putchar(stk[tp--]^48);
}
signed main(){
//	freopen("sort.in","r",stdin);
//	freopen("sort.out","w",stdout);
	n=read();
	k=read();
	po[1]=1;
	int cn=2;
	po[0]=1;
	while(1){
		po[cn]=po[cn-1]*2ll;
		if(po[cn]>=1e18) break;
		cn++;
	}
	if(k>po[n] && po[n]){
		printf("-1");
		return 0;
	}
	int i=1;
	while(i<=n){
		int le=n-i;
		if(!po[le]){
			write(i);
			putchar(' ');
			i++;
			continue;
		}
		int v=0;
		while(k>po[le]){
			k-=po[le];
			v++;
			le--;
		}
		for(int j=v;j>=0;j--){
			write(i+j);
			putchar(' ');
		}
		i+=v+1;
	}
	return 0;
}
