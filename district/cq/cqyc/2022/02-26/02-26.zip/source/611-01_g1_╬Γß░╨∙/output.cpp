#include<cstdio>
#define int long long
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[60],tp;
void write(int x){
	do{
		stk[++tp]=x%10;
		x/=10;
	}while(x);
	while(tp) putchar(stk[tp--]^48);
}
signed main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	int t=read();
	while(t--){
		int l=0,r=0,k=0;
		l=read();
		r=read();
		k=read();
		if(k==0){
			if(l==0){
				putchar('0');
				if(r>=1){
					putchar(' ');
					putchar('1');
				}
				putchar('\n');
				continue;
			}
			if(l==1){
				putchar('1');
				putchar('\n');
				continue;
			}
			puts("None.");
			continue;
		}
		if(k==1){
			if(l<=1 && r>=1){
				putchar('1');
				putchar('\n');
			}
			else puts("None.");
			continue;
		}
		int ans=1;
		bool pd=0;
		while(1){
			if(l<=ans && ans<=r){
				pd=1;
				write(ans);
				putchar(' ');
			}
			if(r/ans<k) break;
			ans*=k;
		}
		if(!pd) puts("None.");
		else putchar('\n');
	}
	return 0;
}
