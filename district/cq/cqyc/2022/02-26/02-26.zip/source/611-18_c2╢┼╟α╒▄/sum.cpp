#include<bits/stdc++.h>
#define LL long long
using namespace std;
int N,M,L,R,P;
LL a[500005],sum[500005],Ans;
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;++i){
		scanf("%lld",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=1;i<=M;++i){
		scanf("%d%d%d",&L,&R,&P),Ans=P-1;
		for(int l=L;l<=R;++l){
			for(int r=l;r<=R;++r){
				Ans=min(Ans,(sum[r]-sum[l-1])%P);
			}
		}
		printf("%lld\n",Ans);
	}
}
