#include<bits/stdc++.h>
using namespace std;
int N,a[30005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>N;
	for(int i=1;i<=N;++i){
		scanf("%d",&a[i]);
	}
	sort(a+1,a+N+1);
	for(int i=1;i<=N;++i){
		cout<<a[i]<<" ";
	}
} 
