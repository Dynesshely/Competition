#include<bits/stdc++.h>
using namespace std;
const int Mod=1e7; 
int N,M,L,R,Ans;
struct sn {
	int x,id;
} b[1000005];
int a[1000005],pre[1000005];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline bool cmp(sn a,sn b) {
	if(a.x==b.x)return a.id<b.id;
	else return a.x<b.x;
}
int main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	N=read(),M=read();
	for(int i=1; i<=N; ++i) {
		a[i]=read();
		b[i].x=a[i],b[i].id=i;
	}
	sort(b+1,b+N+1,cmp);
	for(int i=1;i<=N;++i){
		if(b[i].x!=b[i-1].x||i==1)pre[b[i].id]=-1;
		else pre[b[i].id]=b[i-1].id;
	}
	for(int i=1;i<=M;++i){
		L=read(),R=read(),Ans=Mod;
		for(int j=L;j<=R;++j){
			if(pre[j]<L)continue;
			Ans=min(Ans,j-pre[j]);
		}
		if(Ans==Mod)printf("-1\n");
		else printf("%lld\n",Ans);
	}
}
