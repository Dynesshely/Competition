#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL N,L,R,K;
bool f=0;
LL stk[30],tp;
void write(LL x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%lld",&N);
	for(int i=1; i<=N; ++i) {
		scanf("%lld%lld%lld",&L,&R,&K),f=0;
		if(K==0) {
			if(L==0)printf("0 "),f=1;
			if(R>=1)printf("1 "),f=1;
			if(f==0) printf("None.");
			printf("\n");
			continue;
		}
		for(LL j=1; j<=R; j*=K) {
			if(j>=L)f=1,write(j),printf(" ");
		}
		if(f==0)printf("None.");
		printf("\n");
	}
}
