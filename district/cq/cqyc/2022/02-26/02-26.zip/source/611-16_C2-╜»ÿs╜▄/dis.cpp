#include <bits/stdc++.h>
#define inf 0x3f3f3f3f
using namespace std;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){ if(ch=='-')f=-1;ch=getchar(); }
	while(ch>='0'&& ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
void write(int x) {
	int stk[30],tp=0;
	do stk[++tp]=x%10,x/=10; while(x);
	while(tp) putchar(stk[tp--]^48);
}
int n, m, l, r, dis[100005];
struct qwq{
	int x, id;
}a[1000005];
bool comp(qwq A, qwq B) {
	if(A.x == B.x) return A.id < B.id;
	return A.x < B.x;
}
int main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n = read(), m=read();
	for(int i = 1; i <= n; ++i) a[i]=(qwq) {read(), i}, dis[i]=inf;
	sort(a+1, a+1+n, comp);
	for(int i = 2; i <= n; ++i)
		if(a[i].x == a[i-1].x)
			dis[a[i].id]=a[i].id-a[i-1].id;
	for(int i = 1; i <= m; ++i) {
		l=read(), r=read();
		int ans=inf;
		for(int j = r; j >= l; --j)
			if(dis[j] <= j-l)
				ans=min(ans, dis[j]);
		if(ans == inf) printf("-1");
		else write(ans);
		putchar('\n');
	}
	return 0;
}
