#include <bits/stdc++.h>
#define inf 0x3f3f3f3f
using namespace std;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){ if(ch=='-')f=-1;ch=getchar(); }
	while(ch>='0'&& ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
void write(int x) {
	int stk[30],tp=0;
	do stk[++tp]=x%10,x/=10; while(x);
	while(tp) putchar(stk[tp--]^48);
}
int n, m, a[205], s[205], sum[205][205][505], l, r, q;
int main() {
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(), m=read();
	for(int i = 1; i <= n; ++i) a[i]=read(), s[i]+=a[i]+s[i-1];
	for(int p = 1; p <= 500; ++p)
		for(int i = 1; i <= n; ++i) {
			for(int j = i; j <= n; ++j)
				sum[i][j][p]=sum[j][i][p]=0x3f3f3f3f;
		}
	for(int p = 1; p <= 500; ++p)
		for(int o = 1; o <= 2; ++o)
			for(int i = 1; i <= n; ++i)
				for(int k = i; k <= n; ++k)
					for(int j = k; j <= n; ++j)
						sum[i][j][p]=min(sum[i][j][p],
						min(min(sum[i][k][p],sum[k][j][p]), (s[j]-s[i-1])%p));
	for(int i = 1; i <= m; ++i) {
		l=read(), r=read(), q=read();
		write(sum[l][r][q]), putchar('\n');
	}
	return 0;
}
