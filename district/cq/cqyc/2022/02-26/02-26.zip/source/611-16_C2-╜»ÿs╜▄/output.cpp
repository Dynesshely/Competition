#include <bits/stdc++.h>
using namespace std;
inline long long read(){
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){ if(ch=='-')f=-1;ch=getchar(); }
	while(ch>='0'&& ch<='9'){x=1LL*(x<<1)+1LL*(x<<3)+1LL*(ch^48);ch=getchar();}
	return x*f;
}
void write(long long x){
	int stk[30],tp=0;
	do stk[++tp]=x%10,x/=10; while(x);
	while(tp) putchar(stk[tp--]^48);
}
int t, gs;
long long l, r, k, ans[1005]; 
int main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	t=read();
	while(t--) {
		l=read(), r=read(), k=read(), gs=0;
		for(int i = 1; i <= 100; ++i) ans[i]=0;
		if(k == 0 || k == 1) {
			if(l <= 0 && k == 0) ans[++gs]=0;
			if(l <= 1 && 1 <= r) ans[++gs]=1;
		}
		else {
			long long x=1;
			while(x <= r && x > 0) {
				if(l <= x && x <= r) ans[++gs]=x;
				x*=k;
			}
		}
		if(gs == 0) printf("None.");
		else for(int i = 1; i <= gs; ++i)
			write(ans[i]), putchar(' ');
		putchar('\n');
	}
	return 0;
}
