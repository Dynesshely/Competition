#include <bits/stdc++.h>
#define inf 0x3f3f3f3f
using namespace std;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){ if(ch=='-')f=-1;ch=getchar(); }
	while(ch>='0'&& ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
void write(int x) {
	int stk[30],tp=0;
	do stk[++tp]=x%10,x/=10; while(x);
	while(tp) putchar(stk[tp--]^48);
}
int n, k, pd[100005], ans[100005], cnt;
int dfs(int x) {
	if(x == n) {
		++cnt;
		if(cnt == k) {
			for(int i = 1; i <= n; ++i) write(ans[i]), putchar(' ');
			return 0;
		}else return 1;
	}
	for(int i = 1; i <= n; ++i)
		if(ans[x]-1 <= i && !pd[i]) {
			ans[x+1]=i, pd[i]=1;
			if(!dfs(x+1)) return 0;
			pd[i]=0;
		}
	return 1;
}
int main() {
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n = read(), k = read();
	if(dfs(0))
		printf("-1\n");
	return 0;
}
