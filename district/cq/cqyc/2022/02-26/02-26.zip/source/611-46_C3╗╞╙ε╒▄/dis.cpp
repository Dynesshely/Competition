#include<bits/stdc++.h>
using namespace std;
const int MAX = 1e6+10,inf = 1e9;
struct node{
	int v,id;
}b[MAX];
int n,m,l,r,ans;
int a[MAX],pre[MAX],nxt[MAX]; 
bool cmp(node x,node y){return x.v<y.v;}
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
void write(int x)
{
	if(x<0) {putchar('-');x=-x;} 
	if(x>=10) write(x/10);
	putchar(x%10+'0');
}
signed main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n = read(),m = read();
	for(int i = 1;i<=n;i++) b[i] = (node){read(),i},nxt[i] = inf;
	sort(b+1,b+n+1,cmp);
	a[b[1].id] = 1;
	for(int i = 2;i<=n;i++) 
	{
		a[b[i].id] = a[b[i-1].id];
		if(b[i].v!=b[i-1].v) a[b[i].id]++;
	}
	for(int i = 1;i<=n;i++) nxt[pre[a[i]]] = i,pre[a[i]] = i;
	while(m--)
	{
		l = read(),r = read(),ans = inf;
		for(int i = l;i<=r;i++) if(nxt[i]<=r) ans = min(ans,nxt[i]-i);
		if(ans>=n) ans = -1;
		printf("%d\n",ans);
	}
	return 0;	
} 
