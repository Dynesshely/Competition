#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 5e5+10;
int n,m,l,r,p,ans;
int a[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n = read(),m = read();
	for(int i = 1;i<=n;i++) a[i] = read()+a[i-1];
	while(m--)
	{
		l = read(),r = read(),p = read(),ans = 1e9;
		for(int i = l;i<=r;i++)
			for(int j = i;j<=r;j++) 
				ans = min(ans,(a[j]-a[i-1])%p);
		printf("%lld\n",ans);
	}
	return 0;	
} 
