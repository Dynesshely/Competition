#include<bits/stdc++.h>
using namespace std;
const int MAX = 2e3+10;
int n,f;
int a[MAX],b[MAX],d[MAX],vis[MAX][MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n = read();
	for(int i = 1;i<=n;i++) a[i] = read();
	sort(a+1,a+n+1);
	for(int i = 1;i<=n;i++)
		for(int j = i+1;j<=n;j++) 
			if(__gcd(a[i],a[j])>1) vis[i][j]=vis[j][i]=1;
	b[1] = 1;
	for(int i = 2;i<=n;i++)
	{
		for(int j = 2;j<=n;j++)
			if(!d[j] and vis[j][b[i-1]]){b[i] = j,d[j] = 1;break;}
		if(!b[i]) for(int j = 2;j<=n;j++)if(!d[j]){b[i] = j,d[j] = 1;break;}
	}
	for(int i = 2;i<=n;i++)
	{
		for(int j = i-1;j>=1;j--)
			if(!vis[b[j+1]][b[j]] and a[b[j]]<a[b[j+1]]) 
				swap(b[j+1],b[j]);
	}
	for(int i = 1;i<=n;i++) printf("%d ",a[b[i]]);
	return 0;	
} 
