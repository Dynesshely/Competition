#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 1e5+10;
int n,k,cnt,f=-1;
int a[MAX],b[MAX],t[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
bool solve()
{
	if(cnt==f) return true;
	for(int i = 2;i<=n;i++) if(a[i]<a[i-1]-1) return true;
	f = cnt;
	return false; 
}
void update()
{
	cnt++;
	if(cnt>=b[n]) return;
	int c = 0,l = cnt;
	for(int i = n;i>=1;i--) t[++c] = i;
	for(int i = 1;i<=n;i++)
	{
		int r = c;
		while(l>=b[n-i])r--,l-=b[n-i];
		a[i] = t[r],c--;
		for(int j = r;j<=c;j++) t[j] = t[j+1]; 
	}
}
signed main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n = read(),k = read(),b[0] = 1;
	for(int i = 1;i<=n;i++) a[i] = i;
	for(int i = 1;i<=n;i++) b[i] = b[i-1]*i;
	for(int i = 1;i<=k;i++)
		while(solve()) 
		{
			update();
			if(cnt>=b[n]){printf("-1");return 0;}
		}
	for(int i = 1;i<=n;i++) printf("%d ",a[i]);
	return 0;
} 
