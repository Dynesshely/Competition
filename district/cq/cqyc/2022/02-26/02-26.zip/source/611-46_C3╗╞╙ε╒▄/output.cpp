#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,l,r,k,d,lr;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	T = read();
	while(T--)
	{
		l = read(),r = read(),k = read(),d = 1,lr = 1;
		if(k==0) 
		{
			if(l<=0 and r>=0) {d = 0;printf("0 ");}
			if(l<=1 and r>=1) {d = 0;printf("1 ");}
			if(d) printf("None.");
			putchar('\n');
			continue;
		}
		while(lr<l) lr*=k;
		while(lr<=r)
		{
			printf("%lld ",lr);
			lr *= k,d = 0;
		}
		if(d) printf("None.");
		putchar('\n');
	}
	return 0;	
} 
