#include<bits/stdc++.h>
#define int long long
using namespace std;
int t,l,r,k,sum=1;
bool f=1;
signed main()
{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%lld",&t);
	while(t--)
	{
		f=1,scanf("%lld%lld%lld",&l,&r,&k),sum=1;
		if(k==0 && l==0) printf("0 "),f=0;
		while(sum>0 && sum<=r)
		{
			if(sum>=l) printf("%lld ",sum),f=0;
			sum*=k;
		}
		if(f) cout<<"None.";
		cout<<"\n";
	}
	return 0;
}
