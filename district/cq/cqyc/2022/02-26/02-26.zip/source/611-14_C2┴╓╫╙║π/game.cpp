#include<bits/stdc++.h>
using namespace std;
int n,a[2005],ans[2005],b[2005],d[2005];
bool f[2005];
void hanshu(int x)
{
	if(x==n+1)
	{
		for(int i=1; i<=n; ++i) d[i]=b[i];
		int c=1;
		while(c)
		{
			c=0;
			for(int i=1; i<n; ++i) if(__gcd(d[i],d[i+1])==1 && d[i]<d[i+1]) swap(d[i],d[i+1]),c=1;
		}
		int k=0;
		for(int i=1; i<=n && !k; ++i) if(ans[i]>d[i]) k=1;
		if(k) for(int i=1; i<=n; ++i) ans[i]=d[i];
		return;
	}
	for(int i=1; i<=n; ++i) if(f[i]==0) b[x]=a[i],f[i]=1,hanshu(x+1),f[i]=0;
	return;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	memset(ans,0x3f3f3f3f,sizeof ans);
	scanf("%d",&n);
	for(int i=1; i<=n; ++i) cin>>a[i];
	hanshu(1);
	for(int i=1; i<=n; ++i) cout<<ans[i]<<" ";
	return 0;
}
