#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
int n,m,x,y,mi,b[2][1000006];
struct ll
{
	int id,x;
} a[1000006];
int cmp(ll a,ll b)
{
	if(a.x==b.x) return a.id<b.id;
	return a.x<b.x;
}
int main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read(),memset(b,10000009,sizeof b);
	for(int i=1; i<=n; ++i) a[i].x=read(),a[i].id=i;
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;++i)
	{
		if(a[i].x==a[i-1].x) b[0][a[i].id]=a[i-1].id;
		if(a[i].x==a[i+1].x) b[1][a[i].id]=a[i+1].id;
	}
	while(m--)
	{
		mi=10000009,x=read(),y=read();
		for(int i=x;i<=y;++i)
		{
			if(b[0][i]>=x && b[0][i]<=y) mi=min(mi,i-b[0][i]);
			if(b[1][i]<=y && b[1][i]>=x) mi=min(mi,b[1][i]-i);
		}
		cout<<(mi==10000009?-1:mi)<<"\n";
	}
	return 0;
}
