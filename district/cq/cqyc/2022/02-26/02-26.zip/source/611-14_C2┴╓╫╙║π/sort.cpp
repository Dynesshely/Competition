#include<bits/stdc++.h>
using namespace std;
long long n,k,a[10],js;
bool f[10];
void hanshu(int x)
{
	if(x==n+1)
	{
		++js;
		if(js!=k) return;
	}
	if(js==k)
	{
		for(int i=1; i<=n; ++i) cout<<a[i]<<" ";
		exit(0);
	}
	for(int i=1; i<=n; ++i) if(!f[i] && a[x-1]-1<=i) f[i]=1,a[x]=i,hanshu(x+1),f[i]=0;
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	hanshu(1);
	cout<<-1;
	return 0;
}
