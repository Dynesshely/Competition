#include <iostream>
#include <vector>
#include <ctime>
#include <random>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 2005;
int num[N],ans[N],lasans[N];
int a[N],dat[N];
bool b[N];
int n;

int gcd(int a,int b){
	if(!b)
		return a;
	return gcd(b,a%b);
}

inline void upd(){
	if(!ans[1]){
		memcpy(ans,dat,sizeof(int)*(n+1));
		return;
	}
	for(int k=1;k<=n;k++){
		if(ans[k]<dat[k]){
			memcpy(ans,dat,sizeof(int)*(n+1));
			return;
		}
		else if(ans[k]>dat[k])
			return;
	}
}

inline void updlas(){
	if(!lasans[1]){
		memcpy(lasans,ans,sizeof(int)*(n+1));
		return;
	}
	for(int k=1;k<=n;k++){
		if(lasans[k]>ans[k]){
			memcpy(lasans,ans,sizeof(int)*(n+1));
			return;
		}
		else if(lasans[k]<ans[k])
			return;
	}
}
void dfs(int dep){
	if(dep==n+1){
		mt19937 myrand(time(0)^114514);
		memcpy(dat,num,sizeof(int)*(n+1));
		memset(ans,0,sizeof(ans));
		upd();
		for(int k=1;k<=5000;k++){
			int wei = myrand()%(n-1)+1;
			if(gcd(dat[wei],dat[wei+1])==1){
				swap(dat[wei],dat[wei+1]);
				if(dat[wei]>dat[wei+1])
					upd();
			}
		}
		updlas();
	}
	for(int k=1;k<=n;k++)
		if(!b[k]){
			num[dep] = a[k];
			b[k] = true;
			dfs(dep+1); 
			b[k] = false;
		}
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&n);
	for(int k=1;k<=n;k++)
		scanf("%d",a+k);
	dfs(1);
	for(int k=1;k<=n;k++)
		printf("%d ",lasans[k]);
	return 0;
}
