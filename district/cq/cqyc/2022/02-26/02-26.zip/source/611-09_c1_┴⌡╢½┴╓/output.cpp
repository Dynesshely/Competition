#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

typedef __int128 ll;

signed main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	int q;
	scanf("%lld",&q);
	while(q--){
		int l,r,K;
		scanf("%lld%lld%lld",&l,&r,&K);
		if(!K){
			if(!l&&!r){
				puts("0");
				continue;	
			}
			else if(!l&&r>=1){
				puts("0 1");
				continue;
			}
			else if(l>=1&&r>=1){
				puts("1");
				continue;
			}
			else
				puts("None.");
			continue;	
		}
		if(K==1){
			if(l<=1&&r>=1)
				puts("1");
			else
				puts("None.");
			continue; 
		}
		ll ans = 1;
		while(ans<l)
			ans *= K;
		if(ans>r){
			puts("None.");
			continue;
		}
		while(ans<=r){
			printf("%lld ",(int)ans);
			ans *= K;
		}
		putchar('\n');
	}
	return 0;
} 
