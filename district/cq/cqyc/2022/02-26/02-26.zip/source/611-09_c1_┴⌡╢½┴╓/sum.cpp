#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 500005,INF = 0x3f3f3f3f;
int a[N];
int n,m;

int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int k=1;k<=n;k++)
		scanf("%d",a+k);
	while(m--){
		int l,r,p;
		scanf("%d%d%d",&l,&r,&p);
		int ans = INF;
		for(int k=l;k<=r;k++){
			int num = 0;
			for(int j=k;j<=r;j++){
				(num += a[j])%=p;
				ans = min(ans,num);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
