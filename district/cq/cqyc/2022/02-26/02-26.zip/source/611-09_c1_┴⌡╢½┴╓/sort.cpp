#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int INF = 0x3f3f3f3f3f3f3f3fll;
int n,K;

inline int ksm(int b){
	if(b<=0)
		return 1;
	if(b>=63)
		return INF;
	return 1ll<<b;
}

signed main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%lld%lld",&n,&K);
	if(K>ksm(n-1)){
		puts("-1");
		return 0;
	}
	for(int k=1;k<=n;){
		int dat = 1;
		while(K>ksm(n-dat-k)){
			K -= ksm(n-dat-k);
			dat++;
		}
		for(int j=dat;j;j--)
			printf("%lld ",k+j-1);
		k = k+dat;
	}
	return 0;
}
