#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
#include <unordered_map>
using namespace std;

namespace fastio{
	inline int in(){
	    int x=0,f=1;
	    char ch=getchar();
	    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	    return x*f;
	}
	int stk[30],tp;
	inline void out(int x){
	    do stk[++tp]=x%10,x/=10;while(x);
	    while(tp)putchar(stk[tp--]^48);
	}
};
using fastio::out;
using fastio::in;

const int N = 1000005,INF = 0x3f3f3f3f;
unordered_map<int,int> q;
int a[N];
int n,m;

int main(){
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n = in();
	m = in();
	for(int k=1;k<=n;k++)
		a[k] = in();
	while(m--){
		int l = in(),r = in();
		int ans = INF;
		for(int k=l;k<=r;k++){
			if(q[a[k]]<k&&q[a[k]]>=l)
				ans = min(ans,q[a[k]]-a[k]+1);
			q[a[k]] = k;
		}
		printf("%d\n",ans==INF?-1:ans);
	}
	return 0;
}
