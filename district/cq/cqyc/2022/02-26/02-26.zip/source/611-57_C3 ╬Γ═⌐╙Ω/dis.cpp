#include<bits/stdc++.h>
using namespace std;

const int INF=1e9;
const int Maxn=1e6+10;
int N,M,A[Maxn];

inline int read() {
	int x=0,f=1; char ch=getchar();
	while(!isdigit(ch)) { if(ch=='-')f=-1; ch=getchar(); }
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
} 

int stk[30],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}

int main(){
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	N=read(),M=read();
	for(int i=1;i<=N;i++) A[i]=read();
	while(M--){
		int l=read(),r=read(),ans=INF;
		map<int,int> lst;
		for(int j=l;j<=r;j++){
			int now=0;
			if(lst[A[j]]) now=j-lst[A[j]];
			lst[A[j]]=j; 
			if(now) ans=min(ans,now);
		}
		if(ans==INF) puts("-1");
		else write(ans),puts("");
	}
	return 0;
}
