#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e6+10;
const  int INF=1e9;
int N,M,A[Maxn];

inline int read() {
	int x=0,f=1; char ch=getchar();
	while(!isdigit(ch)) { if(ch=='-')f=-1; ch=getchar(); }
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
} 

int stk[30],tp;

void write(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}

int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	N=read(),M=read();
	for(int i=1;i<=N;i++) A[i]=read();
	while(M--){
		int l=read(),r=read(),Mod=read(),ans=INF;
		for(int L=l;L<=r;L++){
			for(int R=L;R<=r;R++){
				int sum=0;
				for(int i=L;i<=R;i++){
					sum+=A[i];
				}
				ans=min(ans,sum%Mod);
			}
		}
		write(ans);puts("");
	}
	return 0;
}
