#include<bits/stdc++.h>
using namespace std;
#define int long long

int T,l,r,k;

inline int read() {
	int x=0,f=1; char ch=getchar();
	while(!isdigit(ch)) { if(ch=='-')f=-1; ch=getchar(); }
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
} 

int stk[30],tp;

void write(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}

signed main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	T=read();
	while(T--){
		l=read(),r=read(),k=read();
		int tmp=1;  bool flag=false;  
		if(k==0){
			if(l<=1&&r>=0) {
				if(l==0) printf("0 ");
				if(r>=1) printf("1 ");
				puts("");
			}
			else puts("None.");
			continue;
		}
		int mx=r/k;
		while(tmp<l) tmp*=k;
		while(tmp<=r){
			write(tmp); putchar(' ');
			flag=true;
			if(tmp>mx) break;
			tmp*=k;
		}
		if(!flag) puts("None.");
		else puts("");
	}
	return 0;
}
