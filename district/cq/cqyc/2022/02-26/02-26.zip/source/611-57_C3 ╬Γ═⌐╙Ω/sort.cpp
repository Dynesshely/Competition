#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e5+10;
int N,K,val[Maxn],ans[Maxn],tot=0;
bool Vis[Maxn]; 

inline int read() {
	int x=0,f=1; char ch=getchar();
	while(!isdigit(ch)) { if(ch=='-')f=-1; ch=getchar(); }
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
} 

int stk[30],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}

bool check(){
	for(int i=1;i<N;i++){
		if(val[i]-1>val[i+1]) return 0;
	}
	return 1;
}

void DFS(int x){
	if(x>=N){
		for(int i=1;i<=N;i++) if(!Vis[i]){ val[x]=i; break; }
		if(check()){
			tot++;
			if(tot==K){
				for(int i=1;i<=N;i++) write(val[i]),putchar(' ');
				exit(0);
			}
		}
		return;
	}
	for(int i=1;i<=N;i++){
		if(Vis[i]) continue;
		Vis[i]=true; val[x]=i;
		DFS(x+1);
		Vis[i]=false; val[x]=0;
	}
}

int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	N=read(),K=read();
	DFS(1); puts("-1");
	return 0;
}
