// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
const ll N=1e5;
bool vis[N+10];
ll stac[N+10],le[N+10],ri[N+10];
ll n,ans=0,k;
//
//void dfs(ll dep){
//	if(dep>n){
//		FOR(i,1,n) printf("%lld",stac[i]);
//		printf("\n");
//		++ans;
//		if(ans>=k) return;
//	}
//	FOR(i,max(stac[dep-1]-1,(ll)1),n){
//		if(!vis[i]&&stac[dep-1]-1<=i){
//			vis[i]=1;
//			stac[dep]=i;
//			dfs(dep+1);	
//			vis[i]=0;
//		}
//	}
//}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n=gt(),k=gt();
	if(n<=62&&(1ll<<(n-1))<k){
		printf("-1");
		return 0;
	}
//	dfs(1);
//	if(ans<k) printf("-1");
	ll tem=1;
	FOR(i,1,n){
		le[i]=i-1;
		ri[i]=i+1;
	}
	ll tans,yans=1;
	FOR(i,1,n){
		ll b=(1ll<<(min((ll)62,max((ll)0,n-i-1)))),tans=yans;
//		printf("%lld %lld\n",tem,b);
		while(tem+b<=k){
			tem+=b;
			b>>=1;
			b=max(b,(ll)1);
			tans=ri[tans];
		} 
		ri[le[tans]]=ri[tans];
		le[ri[tans]]=le[tans];
		if(le[tans]+1>=tans&&le[tans]) yans=le[tans];
		else yans=ri[tans];
		printf("%lld ",tans);
	}
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



