// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
struct node{
	ll x,z;
};
struct node1{
	ll ord,l,r;
};
const ll N=1e6;
ll a[N+10],le[N+10],lea[N+10],T[N*4+10],ans[N+10];
node afs[N+10];
node1 que[N+10];
//
void chan(ll tord,ll l,ll r,ll ql,ll qr,ll z){
//	printf("tord:%lld T:%lld %lld %lld %lld %lld %lld\n",tord,T[tord],l,r,ql,qr,z);
	if(ql<=l&&r<=qr){
		T[tord]=min(T[tord],z);
		return;
	} 
	if(ql<=mid) chan((tord<<1),l,mid,ql,qr,z);
	if(qr>mid) chan(((tord<<1)|1),mid+1,r,ql,qr,z);
}
ll tque(ll tord,ll l,ll r,ll q){
	if(l==r) return T[tord];
	if(q<=mid){
		T[(tord<<1)]=min(T[(tord<<1)],T[tord]);
		return tque((tord<<1),l,mid,q);
	} 
	else{
		T[(tord<<1)|1]=min(T[(tord<<1)|1],T[tord]);
		return tque(((tord<<1)|1),mid+1,r,q);
	} 
}
bool cmp(node a,node b){
	return a.z<b.z;
}
bool cmp1(node1 a,node1 b){
	return a.r<b.r;
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=gc();
	while(!isdigit(v))f|=(v=='-'),v=gc();
	while(isdigit(v))t=(t<<3)+(t<<1)+(v^48),v=gc();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	ll n=gt(),m=gt();
	FOR(i,1,n){
		a[i]=gt();
		afs[i]=(node){i,a[i]};
	}
	FOR(i,1,m){
		que[i]=(node1){i,gt(),gt()};
	}
	sort(afs+1,afs+n+1,cmp);
	ll to=0;
	while(to<n){
		++to;
		a[afs[to].x]=to;
		ll yto=to;
		while(to<n&&afs[to].z==afs[to+1].z){
			++to;
			a[afs[to].x]=yto;
		}
	}
	memset(T,0x3f,sizeof(T));
	memset(lea,0x3f,sizeof(lea));
	FOR(i,1,n){
		if(le[a[i]]){
			lea[i]=le[a[i]];
		}
		le[a[i]]=i;
	}
	sort(que+1,que+m+1,cmp1);
	to=1;
	FOR(i,1,n){
//		printf("%lld ",lea[i]);
		if(lea[i]<T[0]) chan(1,1,n,1,lea[i],i-lea[i]);
		while(to<=m&&que[to].r==i){
			ans[que[to].ord]=tque(1,1,n,que[to].l);
			if(ans[que[to].ord]>=1e9) ans[que[to].ord]=-1;
			++to;
		}
	}
//	printf("\n");
	FOR(i,1,m){
		wr(ans[i]);
		puts("");
	}
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



