// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
struct node{
	ll x,z;
};
const ll N=2e3;
ll a[N+10],stac[N+10],ans[N+10],lans[N+10];
ll n;
node lst[N+10];
bool vis[10],vis2[10];
//
ll gcd(ll a,ll b){
//	printf("%lld %lld\n",a,b);
	if(b) return gcd(b,a%b);
	else return a;
}
bool check(ll dep){
	if(dep>n) return 0;
	if(lans[dep]<ans[dep]) return 1;
	else if(lans[dep]==ans[dep]) return check(dep+1);
	else return 0;
}
void dfs(ll dep){
	if(dep>n){
		memset(vis2,0,sizeof(vis2));
//		stac[1]=2;
//		stac[2]=5;
//		stac[1]=6;
//		stac[1]=15;
//		stac[1]=12;
//		printf("\n");
		FOR(i,1,n){
			ll to=0;
			FOR(j,1,n){
				if(!vis2[j]) lst[++to]=(node){j,stac[j]};
			}
			ll mmax=0,mto=0;
//			FOR(j,1,to) printf("%lld ",lst[j]);
//			printf("\n");
			FOR(j,1,to){
				bool b=0;
				FOR(k,1,j-1){
//					printf("%lld %lld %lld\n",lst[j],lst[k],gcd(lst[j],lst[k]));
					if(gcd(lst[j].z,lst[k].z)!=1){
						b=1;
						break;
					}
				}
				if(!b){
					if(lst[j].z>mmax){
						mmax=lst[j].z;
						mto=lst[j].x;
					}
				} 
			}
//			printf("%lld ",mmax);
			lans[i]=mmax;
			vis2[mto]=1;
		}
//		printf("\n");
		if(check(1)){
			FOR(i,1,n) ans[i]=lans[i];
		}
		return;
	}
	FOR(i,1,n){
		if(!vis[i]){
			vis[i]=1;
			stac[dep]=a[i];
			dfs(dep+1);
			vis[i]=0;
		}
	}
}
//
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=gt();
	FOR(i,1,n) a[i]=gt();
	memset(ans,0x3f,sizeof(ans));
	dfs(1);
	FOR(i,1,n) printf("%lld ",ans[i]);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



