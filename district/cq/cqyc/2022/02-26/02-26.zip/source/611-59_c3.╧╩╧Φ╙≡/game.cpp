#include<bits/stdc++.h>
using namespace std;
const int N=2010;
int n,a[N],b[N],cop[N],ans[N];
bool biao[N];
int gcd(int x,int y)
{
	if(!y) return x;
	return gcd(y,x%y);
}
void ret() {for(int i=1;i<=n;i++) b[i]=cop[i];}
void change(int k[])
{
	for(int i=1;i<=n;i++)
	{
		int id=i;
		for(int j=i-1;j;j--)
		{
			if(gcd(k[i],k[j])!=1) break;
			if(k[j]<k[i]) id=j;
		}
		for(int j=i-1;j>=id;j--) swap(k[j+1],k[j]);
	}
}
void check()
{
	for(int i=1;i<=n;i++) cop[i]=b[i];
	change(b);
	for(int i=1;i<=n;i++)
	{
		if(b[i]>ans[i]) return ret();
		if(b[i]<ans[i]) break;
	}
	for(int i=1;i<=n;i++) ans[i]=b[i];
	ret();
}
void dfs(int x)
{
	if(x>n) return check();
	for(int i=1;i<=n;i++) if(!biao[i])
	{
		b[x]=a[i];
		biao[i]=true;
		dfs(x+1);
		biao[i]=false;
	}
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",a+i),ans[i]=a[i];
	change(ans);
	dfs(1);
	for(int i=1;i<=n;i++) printf("%d ",ans[i]);
	putchar('\n');
	fclose(stdin);fclose(stdout);
	return 0;
}
