#include<bits/stdc++.h>
using namespace std;
int t;
long long l,r,k;
int main()
{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lld%lld%lld",&l,&r,&k);
		bool out=false;
		long long ans=1ll;
		if(!k)
		{
			if(!l) out=true,printf("0 ");
			if(l<=1&&1<=r) out=true,putchar('1');
		}
		else if(k==1) {if(l<=k&&k<=r) out=true,putchar('1');}
		else while(ans>0&&ans<=r)
		{
			if(ans>=l) printf("%lld ",ans),out=true;
			ans*=k;
		}
		if(!out) printf("None.");
		putchar('\n');
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
