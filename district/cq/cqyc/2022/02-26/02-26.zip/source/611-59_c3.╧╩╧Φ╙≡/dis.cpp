#include<bits/stdc++.h>
using namespace std;
const int N=1e6+10;
int n,m,ans,a[N],b[N],lt[N],R[N];
int main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",a+i),b[i]=a[i];
	sort(b+1,b+n+1);
	int t=unique(b+1,b+n+1)-b;
	for(int i=1;i<=n;i++)
	{
		a[i]=lower_bound(b+1,b+t+1,a[i])-b;
		R[lt[a[i]]]=i;
		lt[a[i]]=i;
	}
	int l,r;
	while(m--)
	{
		ans=1e9;
		scanf("%d%d",&l,&r);
		for(;l<=r;l++) if(R[l]&&R[l]<=r) ans=min(ans,R[l]-l);
		printf("%d\n",(ans==1e9)?-1:ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
