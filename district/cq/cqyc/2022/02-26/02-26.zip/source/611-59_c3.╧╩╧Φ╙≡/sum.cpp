#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
int n,m;
long long ans,sum[N];
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,x;i<=n;i++)
	{
		scanf("%d",&x);
		sum[i]=sum[i-1]+x;
	}
	int l,r,p;
	while(m--)
	{
		ans=1e18;
		scanf("%d%d%d",&l,&r,&p);
		for(;l<=r;l++) for(int i=l;i<=r;i++) ans=min(ans,(sum[i]-sum[l-1])%p);
		printf("%lld\n",ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
