#include<bits/stdc++.h>
using namespace std;
const int N=10;
int n,now,ans[N];
bool biao[N];
long long k;
void check()
{
	for(int i=1;i<n;i++) if(ans[i]-1>ans[i+1]) return;
	now++;
	if(now==k)
	{
		for(int i=1;i<=n;i++) printf("%d ",ans[i]);
		putchar('\n');
		exit(0);
	}
}
void dfs(int x)
{
	if(x>n) return check();
	for(int i=1;i<=n;i++) if(!biao[i])
	{
		ans[x]=i;
		biao[i]=true;
		dfs(x+1);
		biao[i]=false;
	}
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d%lld",&n,&k);
	dfs(1);
	printf("-1\n");
	fclose(stdin);fclose(stdout);
	return 0;
}
