#include<bits/stdc++.h>
using namespace std;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
} 
int stk[30],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
struct node{
	long long val,loc;
	bool b;
}a[200050];
map<long long ,int > mp;
int cs[200050];
int main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout); 
     int n,m;
     n=read();m=read();
     for(register int i=1;i<=n;i++){
     	a[i].val=read();
     	a[i].loc=mp[a[i].val];
     	mp[a[i].val]=i;
	 }
	 long long ans=1e17;
	 for(register int i=1;i<=m;i++){
	 	ans=1e8;
	 	int l,r,js=0;
	    l=read();r=read();
	    for(register int j=l;j<=r;j++){
	    	if(a[j].b==1) continue;
	    	if(a[j].loc<l) continue;
	    	ans=min(ans,j-a[j].loc);
	    	a[j].b=1;
	    	cs[++js]=j;
		}
		for(register int i=1;i<=js;i++){
			a[cs[i]].b=0;
		}
		if(ans==1e8){
			puts("-1");
		}
		else{
			write(ans);
		    printf("\n");
	    }
	}	
}
