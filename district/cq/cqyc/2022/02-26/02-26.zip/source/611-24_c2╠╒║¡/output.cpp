#include<bits/stdc++.h>
using namespace std;
inline unsigned long long read() {
	unsigned long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[100],tp;
void write(unsigned long long x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	int t;
	scanf("%d",&t);
    unsigned long long l,r,k;
    for(int i=1;i<=t;i++){
    	l=read();r=read();k=read();
    	unsigned long long now=l,kk=1;
    	if(k==0){
    		if(l<=1&&r>=1){
    			printf("%d %d",0,1);
    			continue;
			}
			if(l>1){
				puts("None.");
				continue;
			} 
			if(l<=1&&r<=1){
				puts("0");
				continue;
			}
		}
		if(k==1){
			if(l<=1&&r>=1||l>=1&&r>=1){
				puts("1");
				continue;
			}
			else{
				puts("None.");
				continue;
			} 
		}
    	for(int j=1;kk*k<=l;j++){
    		kk*=k;
		}
		bool p=0;
		if(kk==l) p=1,write(kk),printf(" ");
		while(kk*k<=r){
			kk*=k;
			p=1;
			write(kk);
			printf(" ");
		}
		if(p==0) puts("None.");
		else
		printf("\n");
	}
}
