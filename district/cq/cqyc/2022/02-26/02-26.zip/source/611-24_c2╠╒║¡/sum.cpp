#include<bits/stdc++.h>
using namespace std;
long long sum[7005][7005],a[200050],ans[7007][7007];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
} 
int stk[30],tp;
void write(long long x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main() {
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout); 
	int n,m;
    n=read();m=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=n;i++){
    	for(int j=1;j<=n;j++){
    		for(int k=i;k<=j;k++){
    		    sum[i][j]=(sum[i][j]+a[k]);
			}
		}
	}
	for(int i=1;i<=m;i++){
		int l,r,p;
		long long aans=1e17;
		l=read();r=read();p=read();
		for(int j=l;j<=r;j++){
			for(int k=j;k<=r;k++){		
				aans=min(aans,sum[j][k]%p);
			}
		}
		write(aans);
		printf("\n");
	}
}
