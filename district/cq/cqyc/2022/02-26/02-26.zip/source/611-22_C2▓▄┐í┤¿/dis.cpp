#include <bits/stdc++.h>
using namespace std;
int n,m;
int a[1000016],b[1000016],c[1000016];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
void hanshu(int id)
{
	for(int j=id+1;j<=n;j++)
	{
		if(a[id]==a[j]) 
		{
			b[id]=j;
			c[id]=j-id;
			return;
		}
	}
}
int main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i) a[i]=read();
	for(int i=1;i<=n;++i)
	{
		hanshu(i);
	}
	while(m--)
	{
		int mi=1000000001;
		int l,r;
		l=read(),r=read();
		for(int i=l;i<=r;i++)
		{
			if(b[i]<=r&&c[i]!=0) mi=min(mi,c[i]);
		}
		if(mi==1000000001) printf("-1\n");
		else write(mi),printf("\n");
	} 
	
}
