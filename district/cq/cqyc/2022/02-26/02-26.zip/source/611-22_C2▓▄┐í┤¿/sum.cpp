#include <bits/stdc++.h>
using namespace std;
int n,m;
int a[500005];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i) a[i]=read();
	while(m--)
	{
		int mi=1000000001;
		int l,r,p,sum=0;
		l=read(),r=read(),p=read();
		for(int i=l;i<=r;i++)
		{
			sum=(sum+a[i])%p;
			mi=min(mi,sum);
		}
		write(mi),printf("\n");
	}
}
