#include <bits/stdc++.h>
using namespace std;
long long t,l,r,k;
int hanshu(int x,int y)
{
	int sum=1;
	while(y/x!=0)
	{
		y/=x;
		sum*=x;
	}
	return sum;
}
int main()
{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%lld",&t);
	while(t--)
	{
		int s=0;
		scanf("%lld%lld%lld",&l,&r,&k);
		if(k==0)
		{
			if(l==0)
			{
				s=1,printf("0 ");
				if(r>=1) printf("1 ");
			}
			else if(l==1) s=1,printf("1 ");
		}
		else if(k==1)
		{
			if(l<=1&&r>=1) s=1,printf("1 ");
		}
		else
		{
			long long sq=hanshu(k,l);
			if(l<=1&&r>=1) printf("1 "),s=1;
			for(long long i=sq;i<=r;i*=k)
			{
				if(i>l) s=1,printf("%lld ",i);
			}	
		}
		if(s==0) printf("None.");
		printf("\n");
	}
} 
