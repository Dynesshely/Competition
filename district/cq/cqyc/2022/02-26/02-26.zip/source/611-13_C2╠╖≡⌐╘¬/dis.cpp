#include<bits/stdc++.h>
using namespace std;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int n,m,j=0,q,col[1200000],p=1,ans[1200000];
struct jk {
	int lr,rt,bm;
	int dx;
} sp2[1200000],sp[1200000],sp3[1200000];
vector<int> so[1200000];
int kuai[1200000],tong[1200000],sh=0,wz=-1;
bool cmp(jk x,jk y) {
	return x.dx<y.dx;
}
bool cmp2(jk x,jk y) {
	if(col[x.lr]==col[y.lr]) {
		if(col[x.rt]==col[y.rt]) {
			if(col[x.rt]%2==1) return x.rt<y.rt;
			else return x.rt>y.rt;
		} else return x.rt<y.rt;
	} else return x.lr<y.lr;
}
int main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read();
	m=read();
	for(int i=1; i<=n; i++) scanf("%d",&sp[i].dx),sp[i].bm=i;
	sort(sp+1,sp+n+1,cmp);
	sp[0].dx=1000000001;
	for(int i=1; i<=n; i++) {
		if(sp[i].dx!=sp[i-1].dx) j++;
		sp3[sp[i].bm].dx=j;
	}
	for(int i=1; i<=n; i++) so[sp3[i].dx].push_back(i);
	for(int i=1; i<=j; i++)
		for(int y=1; y<so[i].size(); y++) {
			sp3[so[i][y]].lr=so[i][y-1],sp3[so[i][y-1]].rt=so[i][y];
			//	cout<<sp3[so[i][y]].lr<<" "<<sp3[so[i][y-1]].rt<<" "<<so[i][y]<<" "<<i<<endl;
		}

	for(int i=1; i<=m; i++) {
		sp2[i].lr=read();
		sp2[i].rt=read();
		sp2[i].bm=i;
	}
	q=sqrt(n);
	for(int i=1; i<=n+20; i++) {
		col[i]=p;
		if(i%q==0) p++;
	}
	sort(sp2+1,sp2+m+1,cmp2);
	int l=1,r=0;
	//for(int i=1;i<=n;i++) cout<<sp3[i].dx<<" ";
//	cout<<endl;
	for(int i=1; i<=m; i++) {
		//	cout<<sp2[i].lr<<" "<<sp2[i].rt<<endl;
		while(r<sp2[i].rt) {
			r++;
			//	if(sp2[i].lr<=sp3[r].lr&&sp3[r].lr<=sp2[i].rt) {

			if(sp3[r].lr!=0) {
				//	cout<<r-sp3[r].lr<<endl;
				if(l<=sp3[r].lr&&sp3[r].lr<=r) {
					kuai[r-sp3[r].lr]++;
					tong[col[r-sp3[r].lr]]++;
					//	sh++;
				}
			}
			//	}
		}

		while(l>sp2[i].lr) {
			l--;
			//	if(sp2[i].lr<=sp3[l].rt&&sp3[l].rt<=sp2[i].rt) {
			if(sp3[l].rt!=0) {
				if(l<=sp3[l].rt&&sp3[l].rt<=r) {
					kuai[sp3[l].rt-l]++;
					tong[col[sp3[l].rt-l]]++;
					//sh++;
				}
			}
			//	}
		}
		while(r>sp2[i].rt) {
			if(sp3[r].lr!=0) {
				if(l<=sp3[r].lr&&sp3[r].lr<=r) {
					kuai[r-sp3[r].lr]--;
					tong[col[r-sp3[r].lr]]--;
				}
				//	sh--;
			}
			r--;
		}
		//	cout<<1;
		while(l<sp2[i].lr) {
			if(sp3[l].rt!=0) {
				//	cout
				if(l<=sp3[l].rt&&sp3[l].rt<=r) {
					kuai[sp3[l].rt-l]--;
					tong[col[sp3[l].rt-l]]--;
					//	sh--;
				}
			}
			l++;
		}
		//	cout<<1;
		for(int z=1;; z++) {
			if(z==q+10) {
				//cout<<sp2[i].bm<<endl;
				ans[sp2[i].bm]=-1;
				break;
			}
			if(tong[z]!=0) {
				for(int y=(z-1)*q;; y++) {
					if(kuai[y]!=0) {
						ans[sp2[i].bm]=y;
						break;
					}
				}
				break;
			}
		}
		//	cout<<1;
	}
	for(int i=1; i<=m; i++) printf("%d\n",ans[i]);
}
