#include<bits/stdc++.h>
using namespace std;
int n,m,tong[300000],sp[300000],sum=0,p=0,a,b,k,ans=0;
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++) scanf("%d",&sp[i]);
	for(int i=1;i<=m;i++){
		ans=114514191;
		scanf("%d%d%d",&a,&b,&k);
		for(int y=a;y<=b;y++){
			sum=sp[y];
			ans=min(ans,sum%k);
			for(int z=y+1;z<=b;z++){
				sum=sum+sp[z];
				ans=min(ans,sum%k);
			}
		}
		printf("%d\n",ans);
	}
}
