#include<bits/stdc++.h>
using namespace std;
int n,p=1;
long long l,r,k,sum=0,q=0;
int main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld%lld%lld",&l,&r,&k);
		if(k==0||k==1) {
			if(l<=1&&r>=1) printf("%d\n",p);
			else printf("None.\n");
		}
		else{
			q=0;
			sum=1;
			while(sum<=r){
				if(l<=sum&&sum<=r) printf("%lld",sum),printf(" "),q=1; 
				sum=sum*k;
			}
			if(q==0) printf("None.");
			printf("\n");
		}
	}
} 
