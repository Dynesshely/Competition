#include<bits/stdc++.h>
using namespace std;
int n,m,tong[300000],sp[300000],sum=0,p=0;
void jb(int k){
	if(k==n+1){
		sum++;
		if(sum==m){
			for(int i=1;i<=n;i++) cout<<sp[i]<<" ";
			cout<<endl;
			p=1;
		}
		return;
	}
	if(tong[sp[k-1]-1]==0&&sp[k-1]-1>=1) {
	sp[k]=sp[k-1]-1;
	tong[sp[k-1]-1]=1;
	jb(k+1);	
	if(p==1) return;
	tong[sp[k-1]-1]=0;
	}
	for(int i=sp[k-1]+1;i<=n;i++) if(tong[i]==0) {
	sp[k]=i;
	tong[i]=1;
	jb(k+1);
	if(p==1) return;
	tong[i]=0;	
	}
}
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;i++){
    sp[1]=i;
    tong[i]=1;
    jb(2);
	if(p==1) return 0;	
    tong[i]=0;
	}
    cout<<"-1"<<endl;
} 
