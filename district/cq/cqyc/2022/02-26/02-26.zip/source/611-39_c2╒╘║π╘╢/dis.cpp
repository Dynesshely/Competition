#include<bits/stdc++.h>
using namespace std;
struct lll{
	int val,ll,rr;
}van[1000001];
int n,m,fa[1000001],l,r,tot,jkl,ojbk;
map<int,int>wdnmd; 
bool cmp(lll a,lll b){
	return a.val<b.val;
}
int main(){
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d",&fa[i]);
	for(int i=1;i<=n;i++){
		jkl=wdnmd[fa[i]];
		if(!jkl)
			wdnmd[fa[i]]=i;
	    else{
	    	tot++;
	        van[tot].val=i-jkl;
	        van[tot].ll=jkl;
	        van[tot].rr=i;
	        wdnmd[fa[i]]=i;
		}
	}
	sort(van+1,van+tot+1,cmp);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&l,&r);
		ojbk=1;
		for(int j=1;j<=tot&&ojbk;j++){
			if(van[j].ll>=l&&van[j].rr<=r){
				printf("%d\n",van[j].val);
				ojbk=0;
			}
		}
		if(ojbk)printf("-1\n");
	}
	return 0;
}
