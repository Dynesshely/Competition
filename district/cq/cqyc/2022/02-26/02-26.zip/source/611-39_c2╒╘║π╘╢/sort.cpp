#include<bits/stdc++.h>
using namespace std;
long long n,k,bnd[100001],kkk,van,las,ans[100001],cop[100001];
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	bnd[1]=1;
	bnd[0]=1;
	for(int i=1;i<=n;i++)ans[i]=i;
	for(int i=2;i<=n;i++){
		if(bnd[i-1]>LONG_LONG_MAX/2)break;
		kkk=i;
	bnd[i]=bnd[i-1]*2;
}
if(n<=60&&bnd[n]<k){
	printf("-1");
	return 0;
}
    	for(int j=n-1;j>=0;j--){
    		van++;
//    		cout<<k<<" "<<bnd[j]<<" "<<las<<endl;
            if(bnd[j]>0){
    		if(k<=bnd[j]){
    			if(las){
    				for(int i=las;i<=van;i++)
    				cop[i]=ans[i];
    				for(int i=las;i<=van;i++)
    				ans[i]=cop[van-i+las];
				}
				las=0;
			}else{
				if(!las)
    			las=van;
    			k-=bnd[j];
			}
		}  
		}
	for(int i=1;i<=n;i++)printf("%d ",ans[i]);
	return 0;
}
