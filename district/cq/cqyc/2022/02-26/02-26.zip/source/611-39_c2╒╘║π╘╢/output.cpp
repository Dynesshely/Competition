#include<bits/stdc++.h>
using namespace std;
long long t,l,r,k,van;
bool ojbk; 
int main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%lld",&t);
	for(int kkk=1;kkk<=t;kkk++){
		ojbk=1;
		scanf("%lld%lld%lld",&l,&r,&k);
		if(k==0){
			if(0>=l&&0<=r)printf("0 "),ojbk=0;
			if(1>=l&&1<=r)printf("1 "),ojbk=0;
		    if(ojbk)printf("None.");
		    printf("\n");
			continue;
		}
		if(k==1){
			if(1>=l&&1<=r)printf("1 "),ojbk=0;
			if(ojbk==1)printf("None.");
			printf("\n");
			continue;
		}
		if(1>=l&&1<=r)printf("1 "),ojbk=0;
		van=k;
		while(van<=r&&van<=LONG_LONG_MAX/k){
			if(van>=l&&van<=r)
			printf("%lld ",van),ojbk=0;
			van*=k;
		}
		if(ojbk)printf("None.");
		printf("\n");
	}
	return 0;
}
