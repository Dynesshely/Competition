#include<bits/stdc++.h>
using namespace std;
int n,m,fa[500001],l,r,p,sum,kkk[201][201],ans;
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d",&fa[i]);
	for(int ll=1;ll<=n;ll++){
			for(int rr=ll;rr<=n;rr++){
				for(int j=ll;j<=rr;j++)
				kkk[ll][rr]+=fa[j];
			}
		}
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&l,&r,&p);
		ans=p+1;
		for(int ll=l;ll<=r;ll++)
			for(int rr=ll;rr<=r;rr++)
				ans=min(ans,kkk[ll][rr]%p);
		printf("%d\n",ans);
	}
	return 0;
}
