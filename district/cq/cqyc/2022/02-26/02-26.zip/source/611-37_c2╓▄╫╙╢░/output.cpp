#include <bits/stdc++.h>
#define int long long
using namespace std;
int q,l,r,k;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int ksm(int x,int y){
	int ans=1;
	if(y==0) return 1;
	if(x==y&&x==0) return 1;
	int b=y;
	while(b){
		if(b&1) ans*=x;
		x*=x;
		b/=2;
	}
	return ans;
}
signed main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%lld",&q);
	while(q--){
		l=read(),r=read(),k=read();
		int pp=(log(l)/log(k));
//		cout<<k<<" "<<pp<<endl;
		int sum=ksm(k,pp);
		bool flag=0;
//		cout<<"cc  "<<sum<<endl;
		if(sum>=l&&sum<=r) printf("%lld ",sum),flag=1;
		while(sum<=r){
			int xsum=sum*k;
			if(xsum==sum)break;
//			cout<<k<<" "<<xsum<<" "<<sum<<endl;
			if(xsum>r) break;
			if(xsum>=l) flag=1,printf("%lld ",xsum);
			sum=xsum;
		}
		if(!flag) printf("None.");
		printf("\n");
	}
	return 0;
}
