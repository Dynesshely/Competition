#include <bits/stdc++.h>
#define N 1451
using namespace std;
string ans[N];
int n,k,cnt=0;
int p[N];
bool vis[N];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
string jb(int j) {
	string fuckyou;
	while(j) {
		fuckyou+=char((j%10)+48);
		j/=10;
	}
	string ss;
	for(int i=fuckyou.size()-1; i>=0; --i) ss+=fuckyou[i];
	return ss;
}
void check() {
	for(int i=1; i<n; ++i)
		if(p[i]-1>p[i+1]) return;
	++cnt;
	for(int i=1; i<=n; ++i) {
		ans[cnt]+=jb(p[i]);
	}
}
void dfs(int fuck) {
	if(fuck==n+1) {
		check();
		return ;
	}
	for(int i=1; i<=n; ++i) {
		if(vis[i]) continue;
		vis[i]=1;
		p[fuck]=i;
		dfs(fuck+1);
		vis[i]=0;
	}
}
int ksm(int x,int y) {
	int ans=1;
	if(y==0) return 1;
	if(x==y&&x==0) return 1;
	int b=y;
	while(b) {
		if(b&1) ans*=x;
		x*=x;
		b/=2;
	}
	return ans;
}
//string dg(int len,int c){
//	if()
//}
int main() {
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n=read(),k=read();
	if(n>8) { //
		if(k>ksm(2,n-1)) {
			cout<<-1;
			return 0;
		}
//		string shit=dg(n,k);
		return 0;
	}
	for(int i=1; i<=n; ++i) vis[i]=0;
	dfs(1);
	sort(ans+1,ans+1+cnt);
//	cout<<endl<<cnt<<endl;
//	for(int i=1;i<=cnt;++i)
//		cout<<ans[i]<<endl;
	if(k>cnt)cout<<-1;
	else for(int i=0; i<n; ++i)
			cout<<ans[k][i]<<" ";
	return 0;
}
