#include <bits/stdc++.h>
#define N 500010
using namespace std;
int n,q;
int p[N],sum[N];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main() {
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(),q=read();
	sum[0]=0;
	for(int i=1; i<=n; ++i) p[i]=read(),sum[i]=sum[i-1]+p[i];
	while(q--) {
		int ans=0x3f3f3f3f;
		int fl=read(),fr=read(),mod=read();
		for(int l=fl; l<=fr; ++l) {
			for(int r=l; r<=fr; ++r) {
				int h=sum[r]-sum[l-1];
				ans=min(ans,h%mod);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}

