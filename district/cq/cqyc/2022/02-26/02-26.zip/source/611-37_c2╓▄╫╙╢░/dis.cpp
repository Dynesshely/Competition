#include <bits/stdc++.h>
#define N 1000100
using namespace std;
int n,q,cnt=0,nn;
int p[N],wz[N],ans[N];
vector<int> qq[N];
struct wdnmd {
	int val,id;
} shit[N];
struct fuckyou {
	int l,r;
	int id,bitch;
} que[N];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
bool cnm(wdnmd a,wdnmd c) {
	return a.val<c.val;
}
//bool ctmd(fuckyou a,fuckyou b) {
//	return (a.bitch!=b.bitch?a.bitch<b.bitch?a.r<b.r);
//}
int main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),q=read();
	nn=sqrt(n);
	for(int i=1; i<=n; ++i) shit[i].val=read(),shit[i].id=i;
	shit[0].val=-1;
	sort(shit+1,shit+1+n,cnm);
	for(int i=1; i<=n; ++i) p[shit[i].id]=(shit[i-1].val==shit[i].val?cnt:++cnt),qq[i].push_back(-1);
	for(int i=1; i<=q; ++i) {
		int l=read(),r=read(),num=0x3f3f3f3f;
		for(int k=1; k<=n; ++k) wz[k]=-1;
		for(int k=l; k<=r; ++k) {
			if(wz[p[k]]==-1) wz[p[k]]=k;
			else {
				num=min(num,k-wz[p[k]]);
				wz[p[k]]=k;
			}
		}
		printf("%d\n",num==0x3f3f3f3f?-1:num);
	}
//	for(int i=1; i<=n; ++i) wz[i]=qq[p[i]][qq[p[i]].size()],qq[p[i]].push_back(i);
//		if(n<=2e5) {
//			for(int i=1; i<=q; ++i) que[i].l=read(),que[i].r=read(),que[i].id=i,que[i].bitch=((que[i].l-1)/nn+1);
//			sort(que+1,que+1+n,ctmd);
//			int fl=0,fr=0,num=-1;
//			for(int i=1; i<=q; ++i) {
//				int l=que[i].l,r=que[i].r;
//				while(fr<r){
//					fr++;
//					if(l<=fr&&fr)
//				}
//			}
//			return 0;
//		}
	return 0;
}
