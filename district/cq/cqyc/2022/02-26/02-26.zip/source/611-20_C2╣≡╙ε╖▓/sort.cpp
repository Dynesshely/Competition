#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cout<<-1<<endl; 
	return 0;
}
