#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	
	return 0;
}
