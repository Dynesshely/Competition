#include<bits/stdc++.h>
using namespace std;
int t;
unsigned long long l,r,k;
unsigned long long base[105];
int main()
{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		memset(base,-1,sizeof(base));
		cin>>l>>r>>k;
		base[0]=1;
		int i,flag=0;
		for(i=1;base[i-1]*k<=r&&base[i-1];i++)
			base[i]=base[i-1]*k;
		for(int j=0;j<i;j++)
			if(l<=base[j]&&base[j]<=r)
			{
				flag=1;
				cout<<base[j]<<' ';
			}
		if(!flag)printf("None.");
		printf("\n");
	}
	return 0;
}
