#include<bits/stdc++.h>
#define ll long long
using namespace std;

int n;
ll k,power[63];

bool vis[100005];
int ans[100005];

void write(int x){
	if(x>9) write(x/10);
	putchar(x%10+48);
}

void sch(int x,ll m){
	int res=n-x+1;
	if(res==1) {
		for(int i=1;i<=n;i++) if(!vis[i]) ans[n]=i;
		for(int i=1;i<=n;i++) write(ans[i]),putchar(' ');
		exit(0);
	}

	if(res-2>60) {
		for(int i=1;i<=n;i++) if(!vis[i]&&i>=ans[x-1]-1) {ans[x]=i,vis[i]=1;break;}
		sch(x+1,m);
		return;
	}
	
	ll sum=0,j=res-2;
	for(int i=1;i<=n;i++){
		if(vis[i]||i<ans[x-1]-1) continue;
		if(m<=sum+power[j]) {
			vis[i]=1,ans[x]=i,sch(x+1,m-sum);
			return;
		}
		sum+=power[j],j--;
	}
	
	for(int i=n;i>=1;i--){
		if(vis[i]) continue;
		vis[i]=1,ans[x++]=i;
	}
	sch(n,1);
}

int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	
	scanf("%d%lld",&n,&k);
	power[0]=1; for(int i=1;i<=61;i++) power[i]=(power[i-1]<<1);
	
	int cas;
	for(int i=0;i<=60;i++) 
		if(power[i]>=k) {cas=i;break;}
	if(cas>n-1) puts("-1"),exit(0);
	
	sch(1,k);
	return 0;
}
