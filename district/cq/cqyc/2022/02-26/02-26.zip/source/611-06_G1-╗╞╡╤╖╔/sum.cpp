#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int s=0;char c=getchar();
	while(c<48||c>57) c=getchar();
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

void write(int x){
	if(x>9) write(x/10);
	putchar(x%10+48);
}

int n,m;
int a[500005];



int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++) a[i]=read();
	
	if(n<=200){
		while(m--){
			int l=read(),r=read(),p=read();
			int Min=p+1,sum;
			for(int i=l;i<=r;i++){
				sum=0;
				for(int j=i;j<=r;j++) Min=min(Min,sum=(sum+a[j])%p);
			}
			write(Min),puts("");
		}
	}
	
	return 0;
}

