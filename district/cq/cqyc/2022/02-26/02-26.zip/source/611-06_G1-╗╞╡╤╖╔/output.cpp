#include<bits/stdc++.h>
#define ll long long
using namespace std;
int T;
ll l,r,k;
ll stk[100];int top;

inline ll read(){
	ll s=0;char c=getchar();
	while(c<48||c>57) c=getchar();
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

void write(ll x){
	if(x>9) write(x/10);
	putchar(x%10+48);
}

void out(){
	if(!top) puts("None.");
	else{
		for(int i=1;i<=top;i++) write(stk[i]),putchar(' ');
		puts("");
	}
}

bool bein(ll x,ll L,ll R){return (L<=x&&x<=R);}

int main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	
	T=read();
	while(T--){
		top=0;
		l=read(),r=read(),k=read();
		if(!k){
			if(bein(0,l,r)) stk[++top]=0;
			if(bein(1,l,r)) stk[++top]=1;
			out();
			continue;
		}
		if(k==1){
			if(bein(1,l,r)) stk[++top]=1;
			out();
			continue;
		}
		ll num=1;
		for(num;num<=r/k;num*=k){
			if(num<l) continue;
			stk[++top]=num;
		}
		if(bein(num,l,r)&&stk[top]!=num) stk[++top]=num;
		out();
	}
	return 0;
}
