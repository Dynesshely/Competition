#include<bits/stdc++.h>
using namespace std;

inline int read(){
	int s=0;char c=getchar();
	while(c<48||c>57) c=getchar();
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

void write(int x){
	if(x>9) write(x/10);
	putchar(x%10+48);
}

int n,m;
const int inf=1000000007;
pair<int,int> a[1000006];
int lst[1000006];



int main(){
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	
	n=read(),m=read();
	for(int i=1;i<=n;i++) a[i].first=read(),a[i].second=i;
	sort(a+1,a+n+1);
	a[0]=make_pair(-inf,0);
	for(int i=1;i<=n;i++) 
		if(a[i].first==a[i-1].first) 
			lst[a[i].second]=a[i-1].second;
			
	if(max(n,m)<=1000){
		while(m--){
			int Min=inf,l=read(),r=read();
			for(int j=l;j<=r;j++)
				if(lst[j]>=l)
					Min=min(Min,j-lst[j]);
			if(Min==inf) puts("-1");
			else write(Min),puts("");
		}
		return 0;
	}
	

	
	
	return 0;
}

