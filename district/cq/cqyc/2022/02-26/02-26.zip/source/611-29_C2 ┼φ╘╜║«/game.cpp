#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=2005;
int n,a[N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
int stk[30],tp;
void __(int x){
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)pc(stk[tp--]^48);
}
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=_();
	for(int i=1;i<=n;++i) a[i]=_();
	sort(a+1,a+1+n);
	for(int i=1;i<=n;++i) __(a[i]),pc(' ');
	return 0;
}
