#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=1e6+5;
int n,m,un,inf,ans,a[N],b[N],lt[N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
int stk[30],tp;
void __(int x){
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)pc(stk[tp--]^48);
}
int main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=_(),m=_();
	for(int i=1;i<=n;++i) b[i]=_(),a[i]=b[i];
	sort(b+1,b+1+n);
	un=unique(b+1,b+1+n)-b-1;
	for(int i=1;i<=n;++i) 
		a[i]=lower_bound(b+1,b+1+un,a[i])-b;
	if((long long)n*m<=1e6) {//30pts ������ �������ѹ� 
		for(int i=1;i<=m;++i) {
			int l=_(),r=_();
			memset(lt,0x3f,sizeof(lt));ans=inf=lt[0];
			for(int j=l;j<=r;++j) {
				if(lt[a[j]]!=inf) ans=min(ans,j-lt[a[j]]);
				lt[a[j]]=j;
			} 
//			for(int j=1;j<=n;++j) printf("%d ",lt[j]);
			__((ans==inf)?-1:ans),pc('\n');
		}
	}
	else {
		
	}
	return 0;
}
//9:50~10:10
