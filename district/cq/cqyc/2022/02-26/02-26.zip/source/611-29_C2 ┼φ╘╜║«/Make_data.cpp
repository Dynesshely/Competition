#include <bits/stdc++.h>
#define gc getchar
using namespace std;
int main() {
	int n=rand()%10+1;
}
