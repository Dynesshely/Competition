#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define int long long
using namespace std;
int T,l,r,K,cnt;
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
int stk[30],tp;
void __(int x){
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)pc(stk[tp--]^48);
}
signed main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	T=_();
	//9223372036854775807
	while(T--) {
		l=_(),r=_(),K=_(),cnt=0;
		if(K==0) {
			if(l==0) {
				printf("0");
				if(r>0) printf(" 1");
			}
			else if(l==1) printf("1");
			else printf("None.");
			pc('\n');
			continue;
		}
		if(K==1) {
			printf((l<2&&r>0)?"1\n":"None.\n");
			continue;
		}
		printf((l<2&&r>0)?"1 ":"");
		for(int k=K;k<=r;k*=K) {
			if(k>=l) ++cnt,__(k),pc(' ');
			if(r/K<k) break;
			//������
			//��������жϾͻᱻ
			//"0 9223372036854775807 4294967296"hack�� 
		}
		if(!cnt) printf("None.");
		pc('\n');
	}
	return 0;
}
/*
7
1 10 1
5 6 0
5 5 5
0 1 1
0 2 1
0 3 2
0 0 1
*/
//8:50~9:30 
