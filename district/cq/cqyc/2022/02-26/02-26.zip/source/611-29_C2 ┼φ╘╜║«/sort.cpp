#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
int n,k;
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
int stk[30],tp;
void __(int x){
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)pc(stk[tp--]^48);
}
int main() {
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n=_(),k=_();
	printf("-1");
	return 0;
}
