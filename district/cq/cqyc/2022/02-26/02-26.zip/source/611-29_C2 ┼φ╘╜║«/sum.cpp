#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=5e5+5;
int n,m,l,r,p,ans,a[N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
int stk[30],tp;
void __(int x){
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)pc(stk[tp--]^48);
}
int main() {
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=_(),m=_();
	for(int i=1;i<=n;++i) a[i]=_();
	for(int i=1;i<=m;++i) {
		l=_(),r=_(),p=_();ans=p+1;
		for(int j=l;j<=r;++j) {
			int sum=0;
			for(int k=j;k<=r;++k) {
				sum=(sum+a[k])%p;
				ans=min(ans,sum);
			}
		}
		__(ans),pc('\n');
	}
}
//10:15~10:30
