#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;
int n,m,l,r,f,min_v;
int b[maxn],k[maxn];
struct cnm {
	int x,id;
} a[maxn];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) if(ch=='-') f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar()) x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
void write(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10);
	putchar(x%10+48);
}
int cmp(cnm a,cnm b) {
	return a.x<b.x;
}
int main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read();
	for(int i=1; i<=n; i++) a[i].x=read(),a[i].id=i;
	sort(a+1,a+n+1,cmp);
	for(int i=1; i<=n; i++) {
		if(a[i].x!=a[i-1].x) f++;
		if(i==1) f=1;
		b[a[i].id]=f;
	}
	for(int i=1; i<=m; i++) {
		l=read(),r=read(),min_v=1e7+5;
		memset(k,0,sizeof(k));
		for(int j=l; j<=r; j++) {
			if(k[b[j]]!=0) min_v=min(min_v,j-k[b[j]]);
			k[b[j]]=j;
		}
		if(min_v==1e7+5) write(-1),putchar('\n');
		else write(min_v),putchar('\n');
	}
	return 0;
}
