#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e5+10;
int n,m,f,x,bj;
int a[maxn],b[maxn];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) if(ch=='-') f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar()) x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
void write(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10);
	putchar(x%10+48);
}
signed main() {
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	n=read(),m=read();
	f=n-1,x=1;
	while(f!=0) {
		f--;
		x*=2;
		if(x>m) break;
	}
	if(x<m) {
		printf("-1");
		return 0;
	}
	for(int i=n; i>=1; i--) {
		a[i]=m%2;
		m=(m+1)/2;
	}
	b[1]=1,bj=1;
	for(int i=2; i<=n; i++) {
		if(a[i]==1) b[i]=i,bj=i;
		if(a[i]==0) {
			for(int j=n-1; j>=bj; j--) 	b[j+1]=b[j];
			b[bj]=i;
		}
	}
	for(int i=1; i<=n; i++) {
		cout<<b[i]<<" ";
	}
	return 0;
}
