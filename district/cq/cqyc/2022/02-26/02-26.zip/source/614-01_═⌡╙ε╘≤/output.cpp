#include<bits/stdc++.h>
#define int __int128
using namespace std;
int T,l,r,k,f,v;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) if(ch=='-') f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar()) x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
void write(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10);
	putchar(x%10+48);
}
void mt() {
	l=r=k=0,f=1,v=0;
	return;
}
signed main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	T=read();
	for(int t=1; t<=T; t++) {
		mt();
		l=read(),r=read(),k=read();
		if(k==0) {
			if(l<=0&&r>=0) printf("0 ");
			if(l<=1&&r>=1) printf("1 ");
			if(l>1) printf("None.");
			printf("\n");
			continue;
		}
		if(k==1) {
			if(l<=1&&r>=1) printf("1 ");
			else printf("None.");
			printf("\n");
			continue;
		}
		while(f<=r) {
			if(f>=l) write(f),putchar(' '),v=1;
			f*=k;
		}
		if(v==0) printf("None.");
		printf("\n");
	}
	return 0;
}
