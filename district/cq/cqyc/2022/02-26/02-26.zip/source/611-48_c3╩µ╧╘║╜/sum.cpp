#include<bits/stdc++.h>
using namespace std;

int read() {
	int x=0,f=0; char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int Maxn=1e5+10;
int n,m; 
int a[Maxn];
//short t[Maxn][201];
signed main() {
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(),m=read();
	for(register int i=1;i<=n;++i) {
		a[i]=read();
//		for(register int j=1;j<=200;++j) t[i][j]=(a[i]%j+t[i-1][j])%j;
	}
	if(n<=200) {
		while(m--) {
			int l=read(),r=read(),p=read(),ans=1e9;
			for(register int i=l;i<=r;++i) {
				int sum=0;
				for(register int j=i;j<=r;++j) {
					sum+=a[j],sum%=p;
					ans=min(sum,ans);
				}
			} 
			put(ans),putchar('\n');
		}
		return 0;
	}
//	while(m--) {
//		int l=read(),r=read(),
//	}
	return 0;
}

