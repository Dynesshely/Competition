#include<bits/stdc++.h>
#define int long long
using namespace std;

int read() {
	int x=0,f=0; char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int Maxn=1e6+10,inf=1e9;
int n,m,cnt;
int a[Maxn],vis[Maxn],lst[Maxn];
int ans[Maxn],d[Maxn],blg[Maxn];

struct node {
	int x,id;
	bool operator <(const node &c) const {
		return x<c.x;
	}
}b[Maxn];

struct Ask {
	int x,id,y;
	bool operator <(const Ask &c)  const {
		if(x!=c.x) return x<c.x;
	}
}l[Maxn],r[Maxn];

int t[Maxn<<2];

void change(int x,int l,int r,int L,int R,int v) {
	if(l==r) {
		t[x]=min(t[x],v);
		return;
	}
	int mid=l+r>>1;
	if(mid>=L) change(x<<1,l,mid,L,R,v);
	if(mid<R) change(x<<1|1,mid+1,r,L,R,v);
	t[x]=min(t[x<<1],t[x<<1|1]);
}
int ask(int x,int l,int r,int L,int R) {
	if(l>=L&&r<=R) return t[x];
	int res=inf,mid=l+r>>1;
	if(mid>=L) res=min(res,ask(x<<1,l,mid,L,R));
	if(mid<R) res=min(res,ask(x<<1|1,mid+1,r,L,R));
	return res; 
}
signed main() {
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read();
	memset(t,0x3f,sizeof t);
	for(register int i=1;i<=n;++i) a[i]=read(),b[i].x=a[i],b[i].id=i,t[i]=inf;
	sort(b+1,b+n+1);
	for(register int i=1;i<=n;++i) {
		if(b[i].x!=b[i-1].x||i==1) a[b[i].id]=a[b[i-1].id]+1;
		else a[b[i].id]=a[b[i-1].id];
	} 
	for(int i=1;i<=n;++i) lst[i]=vis[a[i]],vis[a[i]]=i;
	for(int i=1;i<=m;++i) {
		int ll=read(),rr=read();
		l[i]=(Ask){ll,i,rr},r[i]=(Ask){rr,i,ll};
	}
	sort(l+1,l+m+1),sort(r+1,r+m+1);
	int ls=1,rs=1,p=0;
	for(int i=l[1].x;i<=r[m].x;++i) {
		if(i==l[ls].x) d[++p]=i;
		while(i==l[ls].x) ++ls;
		blg[i]=p;
		if(lst[i]) {
			int ll=1,rr=p,t=0;
			while(ll<=rr) {
				int mid=ll+rr>>1;
				if(d[mid]<=lst[i]) t=mid,ll=mid+1;
				else rr=mid-1; 
			}
			change(1,1,n,t,t,i-lst[i]);
		}
		while(i==r[rs].x) ans[r[rs].id]=ask(1,1,n,blg[r[rs].y],p),++rs;
	}
	for(int i=1;i<=m;++i) put(ans[i]>=inf?-1:ans[i]),putchar('\n');
	return 0;
}

