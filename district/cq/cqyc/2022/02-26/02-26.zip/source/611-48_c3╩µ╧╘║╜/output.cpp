#include<bits/stdc++.h>
#define int unsigned long long
using namespace std;
int read() {
	int x=0,f=0; char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int inf=4611686018427387910;
int T,n,l,r,k;
signed main() {
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	T=read();
	while(T--) {
		l=read(),r=read(),k=read();
		if(k==0) {
			if(l==0) put(0),putchar(' ');
			if(l<=1&&r>=1) put(1);
			putchar('\n');
			continue;
		}
		if(k==1) {
			if(r!=0) put(1),putchar('\n');
			else puts("None.");
			continue; 
		}
		bool flag=0;
		register int ans=1;
		if(l<=1&&r>=1) put(1),putchar(' '),flag=1;
		while(k<=inf/ans&&ans*k<=r) {
			ans*=k;
			if(l<=ans) put(ans),putchar(' '),flag=1;
		}
		puts(flag?"":"None.");
	}
	return 0;
}

