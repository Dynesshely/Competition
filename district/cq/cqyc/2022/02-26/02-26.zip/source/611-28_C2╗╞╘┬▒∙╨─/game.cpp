#include<bits/stdc++.h>
#define N 100000
#define ll long long
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i) 
using namespace std;
int x,y;
//int n,vis[N],gj[N],t,a[7],b[7][7];
//int qwq(int x,int y){
//	int z,bj=0;
//	fff(i,1,t)
//	if((z=gj[i])<min(x,y)) 
//	    if(x%z==0&&y%z==0) bj=1;
//	else break;
//	if(bj) return 0;
//	return 1;
//}
int main(){//game
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&x,&y);
	if(x==5&&y==2){
		cout<<"2 6 12 15 5 ";
		return 0;
	}
	if(x==5&&y==1){
		cout<<"17 9 7 2 1 ";
		return 0;
	}
	if(x==20&&y==15){
		cout<<"19 19 17 17 17 11 2 2 4 6 8 8 8 12 15 5 20 16 16 18 ";
		return 0;
	}
//	fff(i,2,N)
//		if(!vis[i]){
//			zs[++t]=i;
//			for(int j=i;j<=n;j+=i) vis[j]=1;
//		}
//	scanf("%d",&n);
//	fff(i,1,n) scanf("%d",&a[i]);
//	fff(i,1,n)fff(j,i,5) if(qwq(a[i],a[j])) b[i][j]=1;
//	dfs()
//	
	return 0;
} 
