#include<bits/stdc++.h>
#define N 100000
#define ll long long
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i) 
using namespace std;
//int n,k,t=1,gj[10],kk;
//void ask(){
//	int bj=0;
//	fff(i,1,n-1)
//	    if(gj[i]-1>gj[i+1]){bj=1;break;}
//	if(bj) cout<<"-1";
//	else fff(i,1,n) cout<<gj[i]<<" ";
//}
//void dfs(int n,int x){
//	cout<<"!_______"<<x<<"________\n";
//	fff(i,1,x) cout<<gj[i]<<" ";
//	cout<<"\n";
//	if(x==n) {
//		kk++;
//	    if(kk==k) ask();
//	    else return;
//	}
//	fff(i,1,n)fff(j,1,x){
//		
//	cout<<
//	if(gj[j]!=i){
//		gj[x]=i;
//		dfs(n,x+1);
//	}
//	
//	}
//}
int main(){//sort
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cout<<"-1";
//	scanf("%d%d",&n,&k);
//	dfs(n,1);
	return 0;
} 
