#include<bits/stdc++.h>
#define N 1003
#define ll long long
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i) 
using namespace std;
int n,m,b[N],bj[N],x,san[N][N],l,r,gj;
struct hhh{
	int d,id;
}a[N];
int cmp(hhh a,hhh b){return a.d<b.d;}
int main(){//dis
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	scanf("%d%d",&n,&m);
	fff(i,1,n) scanf("%d",&a[i].d),a[i].id=i;
	sort(a+1,a+1+n,cmp);
	fff(i,1,n){
		if(a[i].d!=a[i-1].d) ++gj;
		b[a[i].id]=gj;
	}
	fff(i,1,n){
		memset(bj,0,sizeof bj);
		int y=1145141919;
		fff(j,i,n){
			x=b[j];
		    if(bj[x]) y=min(y,j-bj[x]);
		    bj[x]=j;
			if(y==1145141919) san[i][j]=-1;
			else san[i][j]=y;
		}
	}
	fff(i,1,m) scanf("%d%d",&l,&r),printf("%d\n",san[l][r]);
	return 0;
} 
