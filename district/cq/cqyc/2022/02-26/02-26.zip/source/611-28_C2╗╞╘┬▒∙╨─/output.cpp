#include<bits/stdc++.h>
#define ll long long
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i) 
using namespace std;
ll T,l,r,k,bj;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
} 
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
void qwq(ll x){
	ll y=x,hia=0;
	x=1;
	fff(i,1,63){
		if(x>r) break;
		if(x>=l) cout<<x<<" ",bj=0;
		x*=y;
	}
}
int main(){//output
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		bj=1;
		scanf("%lld%lld%lld",&l,&r,&k);
		if(k==0){
			if(l==0&&r==0)cout<<"0";
			else if(l==0&&r)cout<<"0 1";
			else if(l==1) cout<<"1";
			else cout<<"None.";
			cout<<"\n";continue;
		}
		qwq(k);
		if(bj) cout<<"None.";
		cout<<"\n";
	}
	return 0;
} 
