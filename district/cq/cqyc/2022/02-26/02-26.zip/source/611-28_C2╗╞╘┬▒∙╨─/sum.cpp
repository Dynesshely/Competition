#include<bits/stdc++.h>
#define N 103
#define ll long long
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i) 
using namespace std;
ll n,m,a[N],sum[N][N],san,l,r,p;
int main(){//sum
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	fff(i,1,n) scanf("%lld",&a[i]);
	fff(i,1,n){
		ll gj=0;
	    fff(j,i,n) gj+=a[j],sum[i][j]=gj;
	}
	fff(i,1,m){
		san=1145141919;
		scanf("%lld%lld%lld",&l,&r,&p);
		fff(j,l,r)fff(k,j,r) san=min(san,sum[j][k]%p);
		printf("%d\n",san);
	}	
	return 0;
} 


//ȡģҪ��ǿ������ �� 
