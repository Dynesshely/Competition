
//��ѯ�����߰�r�����ֻ��Ҫ����ͨ���߶�������״���飬����Ϊ����ϰʹ�����ݽṹ�������õ���ϯ�� 
#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+7,inf=1e9;
int n,m,a[maxn],pre[maxn],fir[maxn],b[maxn],len;
int root[maxn],cnt;
void init(){
	cnt=0;
	memset(pre,0,sizeof(pre));
	memset(fir,0,sizeof(fir));
	return ;
}
int newid(){
	return ++cnt;
}
struct segtree{
	int l,r,ls,rs,mi;
}t[maxn<<5];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(int x) {
	tp=0;
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
void build(int x,int l,int r){
	t[x].l=l,t[x].r=r;
	t[x].ls=newid(),t[x].rs=newid();
	if(l==r){
		t[x].mi=inf;
		t[x].ls=t[x].rs=0;
		return ;
	}
	int mid=(l+r)>>1;
	build(t[x].ls,l,mid);
	build(t[x].rs,mid+1,r);
	t[x].mi=min(t[t[x].ls].mi,t[t[x].rs].mi);
	return ;
}
void modify(int x,int pas,int p,int v){
	t[x]=t[pas];
	if(t[x].l==t[x].r){
		t[x].mi=min(t[x].mi,v);
		return ;
	}
	int mid=(t[x].l+t[x].r)>>1;
	if(p<=mid){
		t[x].ls=newid();
		modify(t[x].ls,t[pas].ls,p,v);
	}
	else {
		t[x].rs=newid();
		modify(t[x].rs,t[pas].rs,p,v);
	}
	t[x].mi=min(t[t[x].ls].mi,t[t[x].rs].mi);
	return ;
}
int query(int x,int l,int r){
	if(t[x].l==l&&t[x].r==r){
		return t[x].mi;
	}
	int mid=(t[x].l+t[x].r)>>1;
	if(l>mid)return query(t[x].rs,l,r);
	else if(r<=mid)return query(t[x].ls,l,r);
	else return min(query(t[x].ls,l,mid),query(t[x].rs,mid+1,r));
}
int main(){
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	init();
//	scanf("%d%d",&n,&m);
	n=read();m=read();
	for(int i=1;i<=n;i++){
//		scanf("%d",&a[i]);
		a[i]=read();
		b[i]=a[i];
	}
	sort(b+1,b+n+1);
	len=unique(b+1,b+n+1)-b-1;
	for(int i=1;i<=n;i++){
		a[i]=lower_bound(b+1,b+len+1,a[i])-b;
		pre[i]=fir[a[i]];
		fir[a[i]]=i;
	}
	int l,r;
	build(root[0]=newid(),1,n);
	for(int i=1;i<=n;i++){
		if(pre[i]){
			modify(root[i]=newid(),root[i-1],pre[i],i-pre[i]);
		}
		else root[i]=root[i-1];
	}
	int w;
	for(int i=1;i<=m;i++){
//		scanf("%d%d",&l,&r);
		l=read();r=read();
		w=query(root[r],l,r);
		if(w==inf){
			putchar('-');
			putchar('1');
		}
		else write(w);
		putchar('\n');
	}
	return 0;
}
