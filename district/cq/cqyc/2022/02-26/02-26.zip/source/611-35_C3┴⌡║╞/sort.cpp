#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+7;
int n,k,a[maxn],cnt;
bool over_flag,vis[maxn];
void init(){
	memset(vis,0,sizeof(vis));
	memset(a,0,sizeof(a));
	cnt=0;
	over_flag=0;
	return ;
}
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(int x) {
	tp=0;
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
void solve(int x){
	if(over_flag)return;
	if(x==n+1){
		for(int i=1;i<n;i++){
			if(a[i]-1>a[i+1])return ;
		}
		cnt++;
		if(cnt==k){
			for(int i=1;i<=n;i++){
				write(a[i]);
				if(i<n)putchar(' ');
			}
			over_flag=1;
		}
		return ;
	}
	for(int i=1;i<=n;i++){
		if(!vis[i]){
			vis[i]=1;
			a[x]=i;
			solve(x+1);
			vis[i]=0;
		}
	}
	return ;
}
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	init();
//	scanf("%d%d",&n,&k);
	n=read();k=read();
	solve(1);
	if(!over_flag){
		putchar('-');
		putchar('1');
	}
	return 0;
}
