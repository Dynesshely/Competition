#include<bits/stdc++.h>
#define lowbit(x) (x&-x)
using namespace std;
const int maxn=1007,inf=1e9;
int n,m,p,maxp,nr,a[maxn],sum[maxn],ans[maxn];
//struct segtree{
//	int l,r,ls,rs,mi;
//}t[maxn<<5];
int c[maxn][maxn];
struct nodeq{
	int l,r,p,id;
}q[maxn];
void init(){
	maxp=0;
	nr=0;
	memset(sum,0,sizeof(sum));
	memset(c,0x3f3f3f3f,sizeof(c));
	return ;
}
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(int x) {
	tp=0;
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int query(int x,int ty){
	int ret=inf;
	for(int i=x;i;i-=lowbit(i)){
		ret=min(ret,c[i][ty]);
	}
	return ret;
}
void modify(int x,int v,int ty){
	for(int i=x;i<=n;i+=lowbit(i)){
		c[i][ty]=min(c[i][ty],v);
	}
	return;
}
bool cmp(nodeq a,nodeq b){
	return ((a.r!=b.r)?a.r<b.r:a.l<b.l);
}
int main(){
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	init();
	n=read();m=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=1;i<=m;i++){
		q[i].l=read();q[i].r=read();q[i].p=read();
		q[i].id=i;
		maxp=max(maxp,q[i].p);
	}
	sort(q+1,q+m+1,cmp);
	for(int i=1;i<=m;i++){
		for(;nr<=q[i].r;nr++){
			for(int j=1;j<=nr;j++){
				for(int np=1;np<=maxp;np++){
					modify(n-j+1,(sum[nr]-sum[j-1])%np,np);
				}
			}
		}
		ans[q[i].id]=query(n-q[i].l+1,q[i].p);
	}
	for(int i=1;i<=m;i++){
		write(ans[i]);
		putchar('\n');
	}
	return 0;
}
