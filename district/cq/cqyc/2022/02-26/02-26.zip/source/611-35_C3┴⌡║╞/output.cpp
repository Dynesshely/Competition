#include<bits/stdc++.h>
using namespace std;
int T;
__int128 l,r,k,kk;//(1<<63)
inline __int128 read() {
	__int128 x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=x*10+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(__int128 x) {
	tp=0;
	do stk[++tp]=(int)(x%10),x/=10;
	while(x);
	while(tp)putchar(stk[tp--]+48);
}
bool check(long long p){
	__int128 res=1,x=(__int128)k;
	bool flag=0;
	while(p){
		if(p%2==1){
			res*=x;
			if(res>=l)return 1;
		}
		p/=2;
		x*=x;
		if(x>=l&&p)return 1;
//		while(x>=mod)x-=mod;
	}
	if(res>=l)return 1;
	return 0;
}
__int128 quick_pow(__int128 x,long long p){
	__int128 ret=1;
	while(p){
		if(p%2==1)ret*=x;
		x*=x;
		p/=2;
	}
	return ret;
}
int main(){
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	scanf("%d",&T);
	long long nl,nr,nmid,trpow;
	while(T--){
//		scanf("%lld%lld%lld",&l,&r,&k);
		l=read(),r=read(),k=read();
		if(k==0){
			bool flag=0;
			if(l<=0&&r>=0){
				putchar('0');
				putchar(' ');
				flag=1;
			}
			if(l<=1&&r>=1){
				putchar('1');
				flag=1;
			}
			if(flag==0){
				printf("None.");
			}
			putchar('\n');
			continue;
		}
		nl=0,nr=r,trpow=0;
		while(nl<=nr){
			nmid=(nl+nr)/2;
			if(check(nmid)){
				trpow=nmid;
				nr=nmid-1;
			}
			else nl=nmid+1;
		}
		kk=quick_pow(k,trpow);
		if(kk>r){
			printf("None.");
		}
		while(kk<=r){
			write(kk);
			kk*=k;
			putchar(' ');
		}
		putchar('\n');
	}
	return 0;
}
