#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void out(int x)
{
	if(x<0) x=-x;
	if(x>=10) out(x/10);
	putchar(x%10+'0');
}
int n,m,a[1000010],l,r;
map<int,int> vis;
signed main()
{
	freopen("dis.in","r",stdin);
	freopen("dis.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i)
	{
		a[i]=read();
	}
	for(int i=1;i<=m;++i)
	{
		l=read(),r=read();
		vis.clear();
		int mi=1e9;
		for(int j=l;j<=r;j++)
		{
			if(vis[a[j]])
			{
				mi=min(mi,j-vis[a[j]]);
			}
			vis[a[j]]=j;
		}
		if(mi==1e9) cout<<-1<<'\n';
		else cout<<mi<<'\n';
	}
	return 0;
}
