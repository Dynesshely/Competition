#include<bits/stdc++.h>
#define int long long
#define lowbit(x) (x&(-x))
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) x=-x;
	if(x>=10) out(x/10);
	putchar(x%10+'0');
}
unsigned int n,k,tree[1000010],tot[1000010],ans[1000010];
void add(int x,int v)
{
	while(x<=n)
	{
		tree[x]+=v;
		x+=lowbit(x);
	}
}
unsigned int ask(int x)
{
	unsigned int sum=0;
	while(x)
	{
		sum+=tree[x];
		x-=lowbit(x);
	} 
	return sum;
}
int erfen(int v)
{
	int l=1,r=n+1,mid,tmp;
	while(l<r)
	{
		mid=(l+r)>>1;
//		cerr<<mid<<"mid\n";
		if(tot[mid]>v)
		{
			tmp=mid;
			l=mid+1;
		}
		else if(tot[mid]==v)
		{
			return mid;
		}
		else
		{
			r=mid;
		}
	}
//	cerr<<tmp<<"??\n";
	return tmp;
}
void dfs()
{
	if(k==0) return;
	int tmp=erfen(k);
//	cerr<<tmp<<'\n';
	if(tot[tmp]==k)
	{
		k-=tot[tmp];
		for(int i=tmp;i<=n;i++)
		{
			ans[i]=n+tmp-i;
		}
		return;
	}
	else
	{
		swap(ans[tmp],ans[tmp+1]);
//		dfs(x-tot[tmp+1]);
		k-=tot[tmp+1];
		dfs();
	}
}
signed main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cin>>n>>k;
	add(n,1);
	if(n>1)add(n-1,1); 
	for(int i=n-2;i>=1;i--)
	{
		add(i,ask(n)-ask(i+1)+1);
	}
	for(int i=1;i<=n;i++)
	{
		tot[i]=LONG_LONG_MAX;
	}
	if(n<=133)tot[1]=ask(n);
	ans[1]=1;
//	cerr<<tot[1]<<' ';
	if(k>tot[1])
	{
		cout<<-1;
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		ans[i]=i;
	}
	for(int i=n;i>=2;i--)
	{
		tot[i]=ask(n)-ask(i-1);
		if(tot[i]>=k) break;
//		cerr<<tot[i]<<" ";
	}
//	cerr<<"tot\n";
//	dfs(k);
	dfs();
	for(int i=1;i<=n;i++)
	{
		out(ans[i]);
		putchar(' ');
	}
	return 0;
} 
