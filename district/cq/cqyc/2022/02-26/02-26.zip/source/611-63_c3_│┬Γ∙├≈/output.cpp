#include<bits/stdc++.h>
#define int unsigned long long
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x>=10) out(x/10);
	putchar(x%10+'0');
}
int T,l,r,k;
signed main()
{
	freopen("output.in","r",stdin);
	freopen("output.out","w",stdout);
	T=read();
	while(T--)
	{
		l=read(),r=read(),k=read();
		bool flag=0;
		if(k==0)
		{
			if(l==0)
			{
				flag=1;
				out(0),putchar(' ');
			}
			if(l<=1&&r>=1)
			{
				flag=1;
				out(1);
			}
			if(flag==0)
			{
				putchar('N');
				putchar('o');
				putchar('n');
				putchar('e');
				putchar('.');
			}
			putchar('\n');
			continue;
		}
		if(k==1)
		{
			if(l<=1&&r>=1)
			{
				flag=1;
				out(1);
			}
			if(flag==0)
			{
				putchar('N');
				putchar('o');
				putchar('n');
				putchar('e');
				putchar('.');
			}
			putchar('\n');
			continue;
		}
		for(int i=1;i<=r;i*=k)
		{
			if(i>=l)
			{
				flag=1;
				out(i);
				putchar(' ');
			}
			if(i>r/k)
			{
				break;
			}
		}
		if(flag==0)
		{
			putchar('N');
			putchar('o');
			putchar('n');
			putchar('e');
			putchar('.');
		}
		putchar('\n');
	}
	return 0;
} 
