#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) x=-x;
	if(x>=10) out(x/10);
	putchar(x%10+'0');
}
int n,m;
int a[1010];
int l,r,p;
signed main()
{
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i)
	{
		a[i]=read();
	}
//	cerr<<"?\n";
	for(int i=1;i<=m;++i)
	{
		l=read(),r=read(),p=read();
//		cerr<<i<<'\n';
		int mi=1e9;
		for(int j=l;j<=r;j++)
		{
			int sum=0;
			for(int k=j;k<=r;k++)
			{
				sum+=a[k];
				sum%=p;
				mi=min(mi,sum);
			}
		}
		cout<<mi<<'\n';
	}
	return 0;
} 
