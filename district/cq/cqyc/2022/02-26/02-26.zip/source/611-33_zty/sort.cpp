#include <bits/stdc++.h>
using namespace std;

/*
    不是很会 😶
    字典序是指 a->z 0->9 ？
    题目意思大致理解，样例也理解
    但是不会写。。。🚑
*/

int n, k;
int main(){
    freopen("sort.in", "r", stdin);
    freopen("sort.out", "w", stdout);
    scanf("%d %d", &n, &k);
    printf("-1\n");
    return 0;
}