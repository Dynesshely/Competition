#include <bits/stdc++.h>
using namespace std;

// 不会博弈 😣

const int maxn = 2022;

int n, a[maxn];

int main(){
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    scanf("%d", &n);
    for(int i = 0; i < n; ++ i)
        scanf("%d", &a[i]);
    return 0;
}