#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e6+10;
const int INF=0x3f3f3f3f;
int N,ans=0,lst=INF;

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&N);
	for(int x,i=1;i<=N;i++){
		scanf("%d",&x);
		lst=min(lst,x);
		ans=max(ans,x-lst);
	}
	printf("%d",ans);
	return 0;
} 
