#include <bits/stdc++.h>
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p )
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p )
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
using namespace std ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f = (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
int main()
{
	freopen("twilight.in","r",stdin) ;
	freopen("twilight.out","w",stdout) ;
	print(-1) ; 
	return 0 ;
 }

