#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
int n;
int cnt[100005];
int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	n=read();
	for(register int i=1;i<=n+1;i++){
		cnt[i]=read();
	}
	int tmp=n+1;
	if(n==0){
		printf("%d",cnt[1]);
		return 0;
	}
	else if(n==1){
		if(cnt[1]==1) printf("x");
		else if(cnt[1]==-1) printf("-x");
		else printf("%dx",cnt[1]);
		if(cnt[2]<0) printf("%d",cnt[2]);
		else if(cnt[2]>0) printf("+%d",cnt[2]);
		return 0;
	}
	else {
		for(register int i=1;i<=n+1;i++){
			tmp--;
			if(cnt[i]==0) continue;
			if(tmp==n){
				if(cnt[i]==1) printf("x^%d",tmp);
				else if(cnt[i]==-1) printf("-x^%d",tmp);
				else printf("%dx^%d",cnt[i],tmp);
			}
			else if(tmp==1){
				if(cnt[i]==1) printf("+x");
				else if(cnt[i]==-1) printf("-x");
				else if(cnt[i]<0) printf("%dx",cnt[i]);
				else printf("+%dx",cnt[i]);
			}
			else if(tmp==0){
				if(cnt[i]<0) printf("%d",cnt[i]);
				else printf("+%d",cnt[i]);
				return 0;
			}
			else {
				if(cnt[i]==1) printf("+x^%d",tmp);
				else if(cnt[i]==-1) printf("-x^%d",tmp);
				else if(cnt[i]<0) printf("%dx^%d",cnt[i],tmp);
				else printf("+%dx^%d",cnt[i],tmp);
			}
		}
	}
	
	return 0;
}
