#include<bits/stdc++.h>
using namespace std;
int n,k,sp2[300000],m=0,ans=0;
struct jk {
	int dx,bm;
} sp[200000];
bool cmp(jk x,jk y) {return x.dx<y.dx;}
bool cmp2(jk x,jk y) {return x.bm<y.bm;}
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	k=n+1;
	for(int i=1; i<=n; i++) scanf("%d",&sp[i].dx),sp[i].bm=i;
	sort(sp+1,sp+n+1,cmp);
	for(int i=1; i<=n; i++){
		if(sp[i].bm<k){
			sp2[1]=sp2[1]+(sp[i].dx-m);
			sp2[k]=sp2[k]-(sp[i].dx-m);
			m=sp[i].dx;
			k=sp[i].bm;
		}
	}
	for(int i=1;i<=n;i++) sp2[i]=sp2[i]+sp2[i-1]; 
	sort(sp+1,sp+n+1,cmp2); 
	for(int i=1;i<=n;i++) {
		sp[i].dx=sp[i].dx-sp2[i];
		ans=max(ans,sp[i].dx);
	}
	printf("%d",ans);
}
