#include<cstdio>
#include<cmath>
#include<algorithm>
const int N=75;
int dp[N][N],n;
char a[N];
int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%d",&n);
//	if(n>70){
		int sum=0;
		for(int i=1;i<=n;i++){
			sum+=i;
			if(sum>n){
				printf("%d",i-1);
				return 0;
			}
		}
	/*}
	scanf("%s",a+1);
	dp[1][1]=1;
	int ans=1;
	for(int i=2;i<=n;i++){
		for(int j=1;j<=i;j++){
			dp[i][j]=1;
			for(int k=1;k<=j;k++){
				bool pd=0;
				for(int k1=k;k1<=j;k1+){
					if(a[k1]<a[j+k1-k] && !pd) break;
					if(k1-k>i-j && !pd) break;
					if(a[k1]>a[j+k1-k]) pd=1;
					if(pd) dp[i][j]=max(dp[i][j],1+dp[k1][k]);
				}
			}
			ans=max(ans,dp[i][j]);
		}
	}
	printf("%d",ans);*/
	return 0;
}
