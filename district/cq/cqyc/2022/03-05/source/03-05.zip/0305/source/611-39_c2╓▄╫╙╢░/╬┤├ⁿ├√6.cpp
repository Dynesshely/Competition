#include <bits/stdc++.h>
using namespace std;
int main(){
	for(int i=1;i<=1e10;++i);
	return 0;
}

