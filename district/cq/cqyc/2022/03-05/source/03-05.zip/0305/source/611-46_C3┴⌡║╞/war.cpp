#include<bits/stdc++.h>
using namespace std;
const int maxn=20006,maxm=206;
int n,dp[maxn][maxm],ans;
char S[maxn];
void init(){
	ans=0;
	memset(dp,0,sizeof(dp));
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			dp[i][j]=1;
		}
	}
	return ;
}
int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",S+1);
	init();
//	for(int i=1;i<=n;i++){
//		putchar(S[i]);
//	}putchar('\n');
	int flag;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			ans=max(ans,dp[i][j]);
			for(int ni=i+1;ni<=n;ni++){
				flag=1;
//				printf("ans=%d\n",ans);
				for(int nj=1;ni+nj-1<=n;nj++){
					if(flag==1){
						if(j>=nj)flag=0;
						if(j<nj)flag=2;
						if(S[n-j+nj]!=S[ni+nj-1]){
							if(S[n-j+nj]<S[ni+nj-1]){
								flag=2;
							}
							else {
								flag=0;
							}
						}
					}
					if(!flag)break;
//					if(flag==1&&j>=nj)continue;
					dp[ni+nj-1][nj]=max(dp[ni+nj-1][nj],dp[i][j]+1);
				}
			}
		}
	}
	printf("%d",ans);
	return 0;
}
