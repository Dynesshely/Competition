#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e4+10;
int N,A[Maxn];

int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N+1;i++) scanf("%d",A+i);
	if(A[1]){
		if(A[1]==1) printf("x^%d",N);
		else if(A[1]==-1) printf("-x^%d",N);
		else printf("%dx^%d",A[1],N);
	} 
	for(int i=2;i<=N;i++){
		int tmp=N+1-i;
		if(!A[i]) continue;
		if(A[i]>1) printf("+%dx",A[i]);
		else if(A[i]==1) printf("+x");
		else if(A[i]==-1) printf("-x");
		else printf("%dx",A[i]);
		if(tmp!=1) printf("^%d",tmp);
	}
	if(A[N+1]){
		if(A[N+1]>0) putchar('+');
		printf("%d",A[N+1]);
	}
	return 0;
} 
