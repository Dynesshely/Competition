#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=2e4+5;
int n,sum,ans;
char s[N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	if(x<0) {pc('-'),__(-x);return ;}
	if(x>9) __(x/10);
	pc(x%10+48);
}
int main() {
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	n=_();
	scanf("%s",s+1);
	for(int i=1;sum+i<=n;++i) sum+=i,ans=i;
	__(ans);
	return 0;
} 
//10:15~10:20
