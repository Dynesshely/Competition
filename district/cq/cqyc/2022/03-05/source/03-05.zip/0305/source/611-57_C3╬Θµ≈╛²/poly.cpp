#include<bits/stdc++.h>
using namespace std;
int n,a[10007],tot=1,flag;

void fir()
{
	while(a[tot]==0) tot++;
	if(tot<=n)
	{
		if(a[tot]!=1) printf("%dx",a[tot]);
		else printf("x");
		if(n-tot+1>1) printf("^%d",n-tot+1);
	}
	else	printf("%d",a[tot]);
	
}

void las()
{
	if(a[n+1]==0) return;
	if(a[n+1]>0) printf("+");
	printf("%d",a[n+1]);
}

int main()
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n+1;i++)	
	{
		scanf("%d",&a[i]);
		if(a[i]!=0) flag=1;
	}
	if(flag==0) 
	{
		printf("0");
		return 0;
	}
	fir();
	for(int i=tot+1;i<=n;i++)
	{
		if(a[i]==0) continue;
		if(a[i]>0) printf("+");
		if(a[i]!=1)	printf("%dx",a[i]);
		else printf("x");
		if(n-i+1>1) printf("^%d",n-i+1);
	}
	if(tot<n+1) las();
	return 0;
 } 
