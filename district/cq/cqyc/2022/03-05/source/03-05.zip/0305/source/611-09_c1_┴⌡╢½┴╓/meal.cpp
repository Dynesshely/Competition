#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 100005;
int a[N],minn[N];
int n;

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	int minn = 0x3f3f3f3f,ans = 0;
	for(int k=1;k<=n;k++){
		int x;
		scanf("%d",&x);
		minn = min(minn,x);
		ans = max(ans,x-minn);
	}
	printf("%d",ans);
	return 0;
}
