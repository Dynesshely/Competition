#include<bits/stdc++.h>
using namespace std;
long long n,l,r,mid,ans;
bool flag=1; 
struct ok{
	long long d;
	char a[20005];
}w;
int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%lld",&w.d);
	for(int i=1;i<=w.d;i++){
		cin>>w.a[i];
		if(w.a[i]=='1') flag=0;
	} 
	if(flag){
		l=1;r=w.d;
		while(l<=r){
			mid=(l+r)>>1;
			if((mid*(mid+1)/2)<=w.d){
				ans=max(ans,mid);
				l=mid+1;
			}
			else r=mid-1;
		}
		printf("%lld",ans);
	}
	else printf("%lld",w.d/4+2);
	return 0;
}
