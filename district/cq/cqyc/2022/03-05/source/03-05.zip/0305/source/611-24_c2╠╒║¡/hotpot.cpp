#include<bits/stdc++.h>
using namespace std;
int g[100005],u1[5000],u2[5000],v1[5000],v2[5000];
int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	int n,m;
	int sum=0;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n-1;i++){
		scanf("%d%d",&u1[i],&v1[i]);
		g[u1[i]]+=1;g[v1[i]]+=1;
		sum+=2;
	} 
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u2[i],&v2[i]);
		g[u2[i]]+=1;
		g[v2[i]]+=1;
		sum+=2; 
	}
	int ans=0;
	for(int i=1;i<n;i++){
		for(int j=1;j<=m;j++){
			g[u1[i]]-=1;
			g[v1[i]]-=1;
			g[u2[j]]-=1;
			g[v2[j]]-=1;	
			if(sum-4<2*n-2||g[u1[i]]==0||g[v1[i]]==0||g[u2[j]]==0||g[v2[j]]==0) ans++;
			g[u1[i]]+=1;
			g[v1[i]]+=1;
			g[u2[j]]+=1;
			g[v2[j]]+=1;
		}
	}
	printf("%d",ans);
}
