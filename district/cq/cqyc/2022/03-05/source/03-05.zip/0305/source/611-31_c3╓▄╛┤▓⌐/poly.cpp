#include<bits/stdc++.h>
using namespace std;
int n,a[100005];
bool flag=0;
int main()
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=n;i>=0;--i) scanf("%d",a+i);
	for(int i=n;i>=1;--i)
	{
		if(flag)
		{
			if(a[i]>0) putchar('+');
		}
		if(a[i]==-1) putchar('-');
		if(a[i]<-1 || a[i]>1) printf("%d",a[i]);
		if(a[i]!=0)
		{
			flag=1;
			if(i)
			{
				putchar('x');
				if(i>1) printf("^%d",i);
			}
		}
	}
	if(a[0])
	{
		if(a[0]>0) putchar('+');
		printf("%d",a[0]);
	}
	
	return 0;
}
