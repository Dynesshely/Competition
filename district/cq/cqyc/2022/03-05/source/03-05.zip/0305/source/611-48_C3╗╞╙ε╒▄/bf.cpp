#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 3e5+10; 
int n,m,cnt,l,r,ans;
int hed[MAX],nex[2*MAX],to[2*MAX]; 
int fa[MAX],siz[MAX],dep[MAX],son[MAX];
int top[MAX],q[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
void add(int u,int v)
{
	nex[++cnt]=hed[u],hed[u]=cnt,to[cnt]=v;
	nex[++cnt]=hed[v],hed[v]=cnt,to[cnt]=u;
}
struct node{
	int x,q;
}st[MAX],ll;
int vis[MAX];
void dfs1(int x)
{
	cnt = 1,st[1] = (node){x,0};
	while(cnt)
	{
		ll = st[cnt];
		if(vis[cnt])
		{
			for(int i=hed[ll.x];i;i=nex[i])
				if(to[i]!=fa[ll.x])
				{
					siz[ll.x]+=siz[to[i]];
					if(siz[to[i]]>siz[son[ll.x]]) son[ll.x]=to[i];
				}
			cnt--;
			continue;
		}
		siz[ll.x]=1,vis[cnt]=1;
		for(int i=hed[ll.x];i;i=nex[i])
			if(!siz[to[i]])
			{
				fa[to[i]]=ll.x,dep[to[i]]=dep[ll.x]+1;
				st[++cnt] = (node){to[i],ll.x};
			}
	}
}
struct node1{
	int x,t;
}st1[MAX],l1;
void dfs2(int x,int t)
{
	cnt = 1,st1[1]=(node1){x,t};
	while(cnt)
	{
		l1 = st1[cnt],cnt--;
		top[l1.x]=l1.t;
		if(son[l1.x])
		{
			st1[++cnt]=(node1){son[l1.x],l1.t};
			for(int i=hed[l1.x];i;i=nex[i]) 
				if(to[i]!=son[l1.x] and to[i]!=fa[l1.x]) st1[++cnt]=(node1){to[i],to[i]};
		}
	}
}
int lc(int x,int y)
{
	if(dep[top[x]]<dep[top[y]]) swap(x,y);
	while(dep[top[x]]!=dep[top[y]])
	{
		x = fa[top[x]];
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
	}
	if(dep[x]<dep[y]) return x;
	return y;
}
struct node2{
	int x,q;
}st2[MAX],l2;
void dfs3(int x)
{
	memset(vis,0,sizeof(vis));
	cnt = 1,st2[1]=(node2){x,0};
	while(cnt)
	{
		l2 = st2[cnt];
		if(vis[cnt])
		{
			for(int i=hed[l2.x];i;i=nex[i])
				if(to[i]!=fa[l2.x]) q[l2.x]+=q[to[i]];
			cnt--;
			continue;
		}
		vis[cnt] = 1;
		for(int i=hed[l2.x];i;i=nex[i])
			if(to[i]!=fa[l2.x]) st2[++cnt]=(node2){to[i],l2.x};
	}
}
signed main()
{
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.ans","w",stdout);
	n = read(),m = read(),dep[1]=1;
	for(int i = 1;i<n;i++) add(read(),read());
	dfs1(1);
	dfs2(1,1);
//	cout<<'!'; 
	for(int i = 1;i<=m;i++)
	{
		l = read(),r = read();
		q[l]++,q[r]++,q[lc(l,r)]-=2;
	}
	dfs3(1);
	for(int i = 1;i<=n;i++)
	{
		if(q[i]==1) ans+=1;
		else if(q[i]==0 and i!=1) ans+=m;
	}
	printf("%lld",ans);
	return 0; 
} 
