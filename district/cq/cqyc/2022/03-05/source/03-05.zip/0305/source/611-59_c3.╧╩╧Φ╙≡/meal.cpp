#include<bits/stdc++.h>
#define lt id<<1
#define rt id<<1|1
using namespace std;
const int N=1e5+10;
struct ok{
	int l,r,add,minn,maxx,loc;
}tree[N<<2];
struct node{
	int num,loc;
};
int n,ans;
void up(int id)
{
	if(tree[lt].minn<=tree[rt].minn) tree[id].minn=tree[lt].minn,tree[id].loc=tree[lt].loc;
	else tree[id].minn=tree[rt].minn,tree[id].loc=tree[rt].loc;
	tree[id].maxx=max(tree[lt].maxx,tree[rt].maxx);
}
void build(int id,int l,int r)
{
	tree[id].l=l,tree[id].r=r;
	if(l==r)
	{
		scanf("%d",&tree[id].minn);
		tree[id].maxx=tree[id].minn;
		tree[id].loc=l;
		return;
	}
	int mid=l+r>>1;
	build(lt,l,mid),build(rt,mid+1,r);
	up(id);
}
void inc(int id)
{
	tree[lt].add+=tree[id].add;
	tree[rt].add+=tree[id].add;
	tree[lt].minn+=tree[id].add;
	tree[rt].minn+=tree[id].add;
	tree[lt].maxx+=tree[id].add;
	tree[rt].maxx+=tree[id].add;
	tree[id].add=0;
	up(id);
}
void add(int id,int l,int r,int num)
{
	if(tree[id].l>r||tree[id].r<l) return;
	if(tree[id].l>=l&&tree[id].r<=r)
	{
		tree[id].add+=num;
		tree[id].minn+=num;
		tree[id].maxx+=num;
		return;
	}
	inc(id);
	add(lt,l,r,num),add(rt,l,r,num);
	up(id);
}
node querymin(int id,int l,int r)
{
	if(tree[id].l>r||tree[id].r<l) return (node){1e9,0};
	if(tree[id].l>=l&&tree[id].r<=r) return (node){tree[id].minn,tree[id].loc};
	inc(id);
	node L=querymin(lt,l,r),R=querymin(rt,l,r);
	if(L.num<=R.num) return L;
	return R;
}
int querymax(int id,int l,int r)
{
	if(tree[id].l>r||tree[id].r<l) return 0;
	if(tree[id].l>=l&&tree[id].r<=r) return tree[id].maxx;
	inc(id);
	return max(querymax(lt,l,r),querymax(rt,l,r));
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	build(1,1,n);
	int r=n;
	node x=querymin(1,1,r);
	while(r&&x.loc)
	{
		add(1,1,r,-x.num);
		ans=max(ans,querymax(1,x.loc,r));
		r=x.loc-1;
		x=querymin(1,1,r);
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
