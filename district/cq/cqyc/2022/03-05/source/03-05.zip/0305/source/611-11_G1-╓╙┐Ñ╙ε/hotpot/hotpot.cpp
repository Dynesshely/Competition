// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
struct node{
	ll l,r,op,ord;
};
const ll N=3e5;
vector<ll> side[N+10],smside[N+10];
vector<node> que[N+10];
ll stac[N+10],eula[N+10],aeula[N+10],ed[N+10],xs[N+10],ans[N+10];
ll T[N*4+10];
ll sto=0,eto=0,n,m;
//
void dfs(ll ypo,ll po,ll dep){
	eula[po]=++eto;
	aeula[eto]=po;
	FOR(i,dep,sto) ed[stac[i]]=eula[po]-1;
	stac[dep]=eula[po];
	sto=dep;
	for(int i=0; i<side[po].size(); ++i){
		if(side[po][i]!=ypo) dfs(po,side[po][i],dep+1);
	}
}
void add(ll tord,ll l,ll r,ll adord){
	if(l==r){
		++T[tord];
		return;
	}
	if(adord<=mid) add(tord<<1,l,mid,adord);
	else add((tord<<1)|1,mid+1,r,adord);
	T[tord]=T[tord<<1]+T[(tord<<1)|1];
}
ll qsum(ll tord,ll l,ll r,ll ql,ll qr){
	if(ql<=l&&r<=qr) return T[tord];
	ll rt=0;
	if(ql<=mid) rt+=qsum(tord<<1,l,mid,ql,qr);
	if(qr>mid) rt+=qsum((tord<<1)|1,mid+1,r,ql,qr);
	return rt;
}
void dfs2(ll ypo,ll po){
	for(int i=0; i<smside[po].size(); ++i){
		add(1,1,n,eula[smside[po][i]]);
	}
	for(int i=0; i<que[eula[po]].size(); ++i){
		node t=que[eula[po]][i];
		ans[t.ord]+=qsum(1,1,n,t.l,t.r)*t.op;
	}
	for(int i=0; i<side[po].size(); ++i){
		if(side[po][i]!=ypo) dfs2(po,side[po][i]);
	}
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout); 
	n=gt(),m=gt();
	FOR(i,1,n-1){
		ll t1=gt(),t2=gt();
		side[t1].pb(t2);
		side[t2].pb(t1);
	}
	dfs(1,1,1);
	FOR(i,1,sto) ed[stac[i]]=n;
	FOR(i,1,m){
		ll t1=gt(),t2=gt();
		smside[t1].pb(t2);
		smside[t2].pb(t1);
	}
	FOR(i,2,n){
		que[i-1].pb((node){0,i-1,-1,i});
		if(ed[i]+1<=n) que[i-1].pb((node){ed[i]+1,n,-1,i});
		que[ed[i]].pb((node){0,i-1,1,i});
		if(ed[i]+1<=n) que[ed[i]].pb((node){ed[i]+1,n,1,i});
	}
	dfs2(1,1);
	ll tans=0;
	FOR(i,2,n){
		if(ans[i]==0) tans+=m;
		else if(ans[i]==1) ++tans;
	}
	printf("%lld",tans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



