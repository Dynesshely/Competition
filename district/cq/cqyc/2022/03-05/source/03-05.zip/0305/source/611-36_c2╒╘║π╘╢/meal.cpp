#include<bits/stdc++.h>
using namespace std;
int n,fa[100010],minn[100010],ans;
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	minn[0]=114514191;
	for(int i=1;i<=n;i++){
	scanf("%d",&fa[i]);
	minn[i]=min(minn[i-1],fa[i]);
}
    for(int i=1;i<=n;i++){
    	ans=max(ans,fa[i]-minn[i]);
	}
	printf("%d",ans);
	return 0;
}
