#include <bits/stdc++.h>
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p )
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p )
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
using namespace std ;
const int N = 1e5+5 ;
int n ;
int a[N],mx,now,ans ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f = (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
inline int check(int x)
{
	int mi = 1e9 ;
	FOR(i,1,n,1)
	{
		mi = min(mi,a[i]) ;
		if(a[i] < x) continue ;
		if(a[i]-x > mi) return 0 ;
	}
	return 1 ;
 } 
int main()
{
	freopen("meal.in","r",stdin) ;
	freopen("meal.out","w",stdout) ;
	read(n) ;
	FOR(i,1,n,1) read(a[i]),mx = max(mx,a[i]) ;
 	int le = 0,ri = mx ;
 	while(le <= ri)
	 {
	 	int mid = le+ri>>1 ;
	 	if(check(mid)) ans = mid,ri = mid-1 ;
	 	else le = mid+1 ;
	  } 
	print(ans) ;
	return 0 ;
 }

