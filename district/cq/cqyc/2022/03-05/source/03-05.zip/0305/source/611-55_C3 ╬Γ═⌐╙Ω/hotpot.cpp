#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e4+10;
int N,M,hed[Maxn],cnt,tmp,ans;
struct node{
	int u,v;
}Edge[Maxn],Road[Maxn];
struct data{
	int nxt,to;
}G[Maxn<<1];
bool Vis[Maxn];

void Addedge1(int x,int y){
	G[++cnt].nxt=hed[x]; G[cnt].to=y; hed[x]=cnt;
} 

void Solve(int x){
	Vis[x]=true;
	for(int y,i=hed[x];i;i=G[i].nxt){
		if(i==tmp||i==tmp+1) continue;
		if(Vis[y=G[i].to]) continue;
		Solve(y);
	}
}

void Yuzuru(){
	int tot=0;
	for(int x,y,i=1;i<=M;i++){
		x=Edge[i].u,y=Edge[i].v;
		if(Vis[x]!=Vis[y]) tot++;
		if(tot>1) return;
	}
	ans++;
}

int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d %d",&N,&M);
	for(int u,v,i=1;i<N;i++){
		scanf("%d %d",&u,&v);
		Road[i].u=u; Road[i].v=v;
		Addedge1(u,v); Addedge1(v,u);
	}
	for(int u,v,i=1;i<=M;i++){
		scanf("%d %d",&u,&v);
		Edge[i].u=u; Edge[i].v=v; 
	}
	for(int i=1;i<N;i++){
		memset(Vis,0,sizeof Vis);
		int x=Road[i].u,y=Road[i].v;
		tmp=(i<<1)-1;
		Solve(x); Yuzuru();
	}
	printf("%d",ans);
	return 0;
} 
