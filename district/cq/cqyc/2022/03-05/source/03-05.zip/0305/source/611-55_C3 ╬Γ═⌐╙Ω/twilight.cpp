#include<bits/stdc++.h>
using namespace std;

const int INF=0x3f3f3f3f;
const int Maxn=1010;
int N,M,ans=INF,size[Maxn];
vector<int> tmp1,tmp2;
bool clo[Maxn][Maxn];

bool check(int x){
	for(int i=0;i<tmp1.size();i++)
		if(!clo[x][tmp1[i]]) return 0;
	return 1;
}

bool check2(){
	for(int i=0;i<tmp2.size();i++) for(int j=i+1;j<tmp2.size();j++)
		if(!clo[tmp2[i]][tmp2[j]]) return 0;
	return 1;
}

void DFS(int x){
	if(x>N){
		int len1=tmp1.size(),len2=tmp2.size();
		if(check2()) ans=min(ans,abs(len1-len2));
		return;
	}
	if(tmp1.size()>(N+ans)>>1||tmp2.size()>(N+ans)>>1) return;
	if(check(x)) tmp1.push_back(x),DFS(x+1),tmp1.pop_back();
	tmp2.push_back(x); DFS(x+1); tmp2.pop_back();
}

int main(){
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	scanf("%d %d",&N,&M);
	for(int a,b,i=1;i<=M;i++){
		scanf("%d %d",&a,&b);
		size[a]++,size[b]++;
		clo[a][b]=clo[b][a]=true;
	}
	if(N<=15){
		DFS(1);
		if(ans==INF) puts("-1");
		else printf("%d",(N-ans)>>1);
		return 0;
	}
	else {
		bool flag=true;
		for(int i=1;i<=N;i++) if(size[i]<N-1) flag=false;
		if(flag){ printf("%d",N/2); return 0; }
		puts("-1");
	}
	return 0;
} 
