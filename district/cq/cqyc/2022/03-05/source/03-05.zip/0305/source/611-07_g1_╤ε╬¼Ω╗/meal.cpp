#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
const van MaxN=1e5+10;
van n,a[MaxN],min_[MaxN],ans;
struct SGT {
	van dat[MaxN<<2],tag[MaxN<<2];
	void BuildTree(van p=1,van l=1,van r=n) {
		if (l==r){dat[p]=a[l];return;}
		van mid=(l+r)>>1;
		BuildTree(p*2,l,mid);
		BuildTree(p*2+1,mid+1,r);
		dat[p]=max(dat[p*2],dat[p*2+1]);
	}
	void spread(van p) {
		if (tag[p]) {
			tag[p*2]+=tag[p],tag[p*2+1]+=tag[p];
			dat[p*2]-=tag[p],dat[p*2+1]-=tag[p];
			tag[p]=0;
		}
	}
	void UpdateTree(van L,van R,van num,van p=1,van l=1,van r=n) {
		if (L<=l&&r<=R) {dat[p]-=num,tag[p]+=num;return;}
		spread(p); van mid=(l+r)>>1;
		if (L<=mid) UpdateTree(L,R,num,p*2,l,mid);
		if (R>mid) UpdateTree(L,R,num,p*2+1,mid+1,r);
		dat[p]=max(dat[p*2],dat[p*2+1]);
	}
	van QueryTree(van L,van R,van p=1,van l=1,van r=n) {
//		cout<<L<<" "<<R<<endl;
		if (L<=l&&r<=R) return dat[p];
		van mid=(l+r)>>1,ans=0; spread(p);
		if (L<=mid) ans=max(ans,QueryTree(L,R,p*2,l,mid));
		if (R>mid) ans=max(ans,QueryTree(L,R,p*2+1,mid+1,r));
		return ans;
	}
}T;
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	read(n); for (int i=1;i<=n;i++) read(a[i]); 
	a[0]=1e18; T.BuildTree();
	for (int i=1;i<=n;i++) min_[i]=a[i]<a[min_[i-1]]?i:min_[i-1];
	van r=n; while (r) {
//		cout<<r<<endl;
		van wh=min_[r]; // cout<<T.QueryTree(wh,wh)<<endl;
		T.UpdateTree(1,r,T.QueryTree(wh,wh));
		ans=max(ans,T.QueryTree(wh,r)); r=wh-1;
	} print(ans);
	return 0;
}

