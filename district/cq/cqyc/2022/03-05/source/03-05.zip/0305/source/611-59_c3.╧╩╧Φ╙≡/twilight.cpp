#include<bits/stdc++.h>
using namespace std;
const int N=1010;
int n,m,ans,x1,x2;
bool both[N],biao[N][N];
vector<int>a[2];
bool check(int x,bool k)
{
	int siz=a[k].size();
	for(int i=0;i<siz;i++) if(!biao[x][a[k][i]]) return false;
	return true;
}
int main()
{
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	scanf("%d%d",&n,&m);
	while(m--)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		biao[x][y]=biao[y][x]=true;
	}
	for(int i=1;i<=n;i++)
	{
		biao[i][i]=true;
		if(check(i,0)) a[0].push_back(i);
		else if(check(i,1)) a[1].push_back(i);
		else printf("-1\n"),exit(0);
	}
	for(int i=1;i<=n;i++) both[i]=check(i,0)&check(i,1);
	if(a[0].size()<a[1].size()) swap(a[0],a[1]);
	int n1=a[0].size();
	ans=a[1].size();
	for(int i=0;i<n1&&ans<(n>>1)-1;i++) if(both[a[0][i]]) ans+=2;
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
