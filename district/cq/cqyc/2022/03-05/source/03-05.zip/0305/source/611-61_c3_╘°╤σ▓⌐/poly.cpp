#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void write(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10);
	putchar(x%10+'0');
}
const int N=10005;
int n;
signed main() {
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	n=read();
	for(int i=1;i<=n+1;++i) {
		int a=read(),b=n-i+1;
//		cerr<<a<<" "<<b<<endl;
		if(a==0) continue;
		if(i!=1&&a>0) putchar('+');
		if(a<0) putchar('-');
		if(abs(a)!=1||b==0) write(abs(a));
		if(b>=1) {
			putchar('x');
			if(b>=2) putchar('^'),write(b);
		}
	}
	return 0;
}
/*
3
-5 0 -2 1

-5x^3-2x+1
*/
