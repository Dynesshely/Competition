#include<bits/stdc++.h>
using namespace std;
int n,ans=0;
string S;
int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	cin>>n>>S;
	for(int i=1;;i++){
		if(n>=i) {
			n=n-i;
			ans++;
		}
		else{
			printf("%d\n",ans);
			return 0;
		}
	}
}
//100+100+30+70+20=320
