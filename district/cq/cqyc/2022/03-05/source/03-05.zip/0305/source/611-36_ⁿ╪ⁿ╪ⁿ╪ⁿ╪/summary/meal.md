# Meal
## Status
* Format: .in | .out
* TL: 1s
* ML: 256MB
* Point: NaN

## Exp
* 09:13 开始读题
* 09:21 开始做题
* 09:30 毫无头绪

## Summary
初看没看出来，再看发现形如一道题——推土机
差别就在于，推土机那题每次可以选择[l,r]的范围减一
而此题只能从[1,x]减一，同时推土机这题不要求某一个单元格不能为0

* Time Use: NaNmin
* 估计能得 NaN points
