#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=1e4+4;
int n,a[N];
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	if(x<0) {pc('-'),__(-x);return ;}
	if(x>9) __(x/10);
	pc(x%10+48);
}
int main() {
//	system("ploy_Data_Maker.exe");
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	n=_();
	for(int i=n;~i;--i) a[i]=_();//,printf("%d ",a[i]);
//	pc('\n');
	for(int i=n;~i;--i) {
		if(!a[i]) continue;
		if(a[i]<0) pc('-'),a[i]=-a[i];
		else if(i!=n) pc('+');
		if(a[i]!=1) __(a[i]);
		if(i) {
			pc('x');
			if(i>1) pc('^'),__(i);
		}
	}
	return 0;
} 
//8:20~8:45
