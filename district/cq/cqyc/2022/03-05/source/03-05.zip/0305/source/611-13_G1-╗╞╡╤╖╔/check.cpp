#include<bits/stdc++.h>
using namespace std;
int main(){
	srand(time(0));
	for(int i=1;i<=100;i++){
		ofstream hout("hotpot.in");
		int n=5,m=5;
		hout<<n<<' '<<m<<endl;
		for(int j=2;j<=n;j++){
			hout<<j<<' '<<(rand()%(j-1)+1)<<endl;
		}
		for(int j=1;j<=m;j++){
			hout<<(rand()%n+1)<<' '<<(rand()%n+1)<<endl;
		}
		system("hotpot.exe");
		system("test.exe");
		if(system("fc hotpot.out hotpot.ans")) return 0;
	}
	
	return 0;
}

