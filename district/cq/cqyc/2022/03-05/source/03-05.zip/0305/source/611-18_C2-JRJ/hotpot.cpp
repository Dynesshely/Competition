#include <bits/stdc++.h>
using namespace std;
int n, m, _, __, col[300005], ans;
struct qwq{
	int a, b;
}da[300005], xiao[300005];
vector <qwq> go_[300005];
int read() {
	int x = 0; char c=getchar(); while(c < '0' || c > '9') c=getchar();
	while('0' <= c && c <= '9') x=(x << 1)+(x << 3)+(c ^ 48), c=getchar();
	return x;
}
void dfs(int x, int fa) {
	col[x]=1;
	for(int i = 0; i < (int) go_[x].size(); ++i)
		if(go_[x][i].a != fa && go_[x][i].b != _ && go_[x][i].b != __)
			dfs(go_[x][i].a, x);
}
int main() {
	freopen("hotpot.in", "r", stdin);
	freopen("hotpot.out", "w", stdout);
	n=read(), m=read();
	if(n >= 100000 && m >= 100000) {
		cout<<1LL*n*m-m<<"\n";
		return 0;
	}
	for(int i = 1; i < n; ++i)
		da[i].a=read(), da[i].b=read(), 
		go_[da[i].a].push_back((qwq) {da[i].b, i}), 
		go_[da[i].b].push_back((qwq) {da[i].a, i});
	for(int i = 1; i <= m; ++i)
		xiao[i].a=read(), xiao[i].b=read(), 
		go_[xiao[i].a].push_back((qwq) {xiao[i].b, n+i-1}), 
		go_[xiao[i].b].push_back((qwq) {xiao[i].a, n+i-1});
	for(_ = 1; _ < n; ++_)
		for(__ = n; __ <= n+m-1; ++__) {
			dfs(1, -1);
			int qwq=0;
			for(int i = 1; i <= n; ++i)
				if(col[i] == 0)
					qwq=1;
				else col[i]=0; 
			ans+=qwq;
		}
	printf("%d", ans);
	return 0;
}
