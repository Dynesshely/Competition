#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int Maxn=1e5+10;
int n,sum,res;
int a[Maxn],t[Maxn];

signed main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read(),t[0]=1e9;
	for(int i=1;i<=n;++i) a[i]=read(),t[i]=min(t[i-1],a[i]);
	for(int i=n;i>=1;--i) sum+=max(t[i]-sum,0ll),res=max(a[i]-sum,res);
	put(res);
	return 0;
}

