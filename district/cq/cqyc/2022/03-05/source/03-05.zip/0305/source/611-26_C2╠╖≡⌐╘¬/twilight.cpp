#include<bits/stdc++.h>
using namespace std;
int n,m,sp[1100][1100],a,b,lk[300120],tong[432362],p,q=0,ans;
int kuai[32192],f=0;
vector<int> sp2[300000];
void find(){
	for(int i=1;i<=n;i++){
		if(tong[i]==0){
		//	cout<<i<<" ";
			f=1;
			for(int y=1;y<i;y++){
				if(tong[y]==0&&sp[i][y]==0) {f=0;break;}
			}
			if(f==0) break;
		}
		if(i==n){
			ans=max(ans,min(p,n-p));
		//	cout<<endl;
			return;
		}
	}
//	cout<<endl;
}
void jb(int k,int fa){
	for(int i=0;i<sp2[k].size();i++){
		q=0;
		if(sp2[k][i]!=fa&&tong[sp2[k][i]]!=1){
			for(int z=1;z<=p;z++) {
				if(sp[lk[z]][sp2[k][i]]==0) break;
				if(z==p) q=1;
			} 
			if(q==1){
			//	for(int z=1;z<=p;z++) cout<<lk[z]<<" ";
			//	cout<<endl;
				lk[++p]=sp2[k][i];
			//	cout<<sp2[k][i]<<endl;
				tong[sp2[k][i]]=1;
				find();
				jb(sp2[k][i],k);
				p--;
			}
		}
	}
}
int main(){
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	cin>>n>>m;
	if(n>=150){
		cout<<n/2<<endl;
		return 0;
	}
	for(int i=1;i<=m;i++){
		scanf("%d%d",&a,&b);
		sp2[a].push_back(b);
		sp2[b].push_back(a);
		sp[a][b]=1;
		sp[b][a]=1;
	}
	lk[1]=1;
	tong[1]=1;
	p=1;
	jb(1,0);
	printf("%d",ans);
}
