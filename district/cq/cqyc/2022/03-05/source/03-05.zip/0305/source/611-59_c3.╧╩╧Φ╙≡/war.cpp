#include<bits/stdc++.h>
using namespace std;
const int N=2e4+10;
int n,ans=1;
char a[N];
void dfs(int x,int now,string ls)
{
	ans=max(ans,now);
	if(x==n) return;
	int i=x;
	string k;
	for(;i<n;i++)
	{
		k+=a[i];
		if(k>ls) break;
	}
	if(i==n) return;
	for(int j=1;i+j<=n;j++) dfs(i+j,now+1,k);
}
int main()
{
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%d%s",&n,a+1);
	n++;
	if(n<=70) dfs(1,0,"");
	else ans=sqrt(n*2);
	dfs(1,0,"");
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
