#include<bits/stdc++.h>
using namespace std;
int n;
int a[10011];
bool fl;
int main()
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=n;i>=0;i--) scanf("%d",&a[i]);
	for(int i=n;i>1;i--)
	{
		if(a[i]>0) 
		{
			if(fl) putchar('+');
			if(a[i]==1) printf("x^%d",i),fl=1;
			else printf("%dx^%d",a[i],i),fl=1;
		}
		if(a[i]<0) 
		{
			if(a[i]==-1) printf("-x^%d",i),fl=1;
			else printf("%dx^%d",a[i],i),fl=1;
		}
	}
	if(a[1]>0) 
	{
		if(fl) putchar('+');
		if(a[1]==1) printf("x"),fl=1;
		else printf("%dx",a[1]),fl=1;
	}
	if(a[1]<0) 
	{
		if(a[1]==-1) printf("-x"),fl=1;
		else printf("%dx",a[1]),fl=1;
	}
	if(a[0]>0) 
	{
		if(fl) putchar('+');
		if(a[0]==1) printf("1"),fl=1;
		else printf("%d",a[0]),fl=1;
	}
	if(a[0]<0) 
	{
		if(a[0]==-1) printf("-1"),fl=1;
		else printf("%d",a[0]),fl=1;
	}
	return 0;
}
