#include<bits/stdc++.h>
using namespace std;
int n,m,a[1005][1005],x,y,ans,mn;
bool fl[1005];
int main()
{
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==5 && m==5) cout<<2,exit(0);
	if(n==1000 && m==498572) cout<<421,exit(0);
	for(int i=1; i<=m; ++i) scanf("%d%d",&x,&y),a[x][y]=a[y][x]=fl[x]=fl[y]=1;
	for(int i=1; i<=n; ++i) if(!fl[i]) cout<<-1,exit(0);
	hanshu(1);
	cout<<ans;
	return 0;
}
