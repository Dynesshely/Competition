#include <bits/stdc++.h>
#define int long long
using namespace std;
bool ppp;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=300005;
int n,m,ans;
int hed[N],nxt[N<<1],to[N<<1],cnt;
void add(int x,int y) {
	nxt[++cnt]=hed[x],to[cnt]=y,hed[x]=cnt;
}
int dep[N],fa[N],dfn[N],top[N],siz[N],son[N],tot;
void dfs1(int x,int fath) {
//	cerr<<x<<" "<<fath<<endl;
	dep[x]=dep[fath]+1,siz[x]=1,fa[x]=fath;
	for(int i=hed[x],y;i;i=nxt[i]) {
		y=to[i];
		if(y==fa[x]) continue;
		dfs1(y,x);
		siz[x]+=siz[y];
		if(siz[y]>siz[son[x]]) son[x]=y;
	}
}
void dfs2(int x,int topf) {
	top[x]=topf,dfn[x]=++tot;
	if(!son[x]) return;
	dfs2(son[x],topf);
	for(int i=hed[x],y;i;i=nxt[i]) {
		y=to[i];
		if(y==fa[x]||y==son[x]) continue;
		dfs2(y,y);
	}
}
//#define ls (x<<1)
//#define rs (x<<1|1)
//#define mid ((l+r)>>1)
//int tree[N<<2],tag[N<<2];
//void pushup(int x,int l,int r,int v) {
//	tree[x]+=(r-l+1)*v;
//	tag[x]+=v;
//}
//void pushdown(int x,int l,int r) {
//	if(tag[x]==0) return;
//	pushup(ls,l,mid,tag[x]);
//	pushup(rs,mid+1,r,tag[x]);
//	tag[x]=0;
//}
//void modify(int x,int l,int r,int L,int R) {
//	if(l==L&&r==R) {
//		pushup(x,l,r,1);
//		return;
//	}
//	pushdown(x,l,r);
//	if(R<=mid) modify(ls,l,mid,L,R);
//	else if(L>mid) modify(rs,mid+1,r,L,R);
//	else modify(ls,l,mid,L,mid,v),modify(rs,mid+1,r,mid+1,R);
//	tree[x]=tree[ls]+tree[rs];
//}
//int query(int x,int l,int r,int L,int R) {
//	if(l==L&&r==R) return tree[x];
//	pushdown(x,l,r);
//	if(R<=mid) return query(ls,l,mid,L,R);
//	else if(L>mid) return query(rs,mid+1,r,L,R);
//	return query(ls,l,mid,L,mid)+query(rs,mid+1,r,mid+1,R);
//}
int lca(int x,int y) {
	while(top[x]!=top[y]) {
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		x=fa[top[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	return x;
}
int a[N];
void dfs3(int x) {
	for(int i=hed[x],y;i;i=nxt[i]) {
		y=to[i];
		if(y==fa[x]) continue;
		dfs3(y);
		a[x]+=a[y];
//		cerr<<x<<" "<<y<<" "<<a[y]<<endl;
		if(a[y]==0) ans+=m;
		if(a[y]==1) ans+=1;
	}
}
//void gs() {
//	ans=0;
//	for(int i=1;i<=49999;++i) dep[i]=i,fa[i]=i-1,siz[i]=n-i+1,son[i]=i+1;
//	dep[50000]=50000,fa[50000]=49999,siz[50000]=50001,son[50000]=100000;
//	for(int i=50001;i<=100000;++i) dep[i]=50001,fa[i]=50000,siz[i]=1;
//	for(int i=1;i<=50000;++i) top[i]=1,dfn[i]=++tot;
//	top[100000]=1,dfn[100000]=++tot;
//	for(int i=99999;i>=50001;--i) top[i]=i,dfn[i]=++tot;
////	for(int i=1;i<=n;++i) cout<<siz[i]<<endl;
////	cout<<endl<<endl;
////	for(int i=1;i<=n;++i) cout<<top[i]<<endl;
////	cout<<endl;
//	for(int i=1;i<=m;++i) {
//		int x=read(),y=read(),l=lca(x,y);
//		if(x>y) swap(x,y);
//		if(x>=50000) l=50000;
//		else l=x;
//		a[x]+=1,a[y]+=1,a[l]-=1,a[fa[l]]-=1;
////		cout<<x<<" "<<y<<" "<<l<<endl;
//	}
//	for(int i=50001;i<=100000;++i) a[50000]+=a[i];
//	for(int i=49999;i>=1;--i) a[i]+=a[i+1];
//	for(int i=2;i<=n;++i) {
//		if(a[i]==0) ans+=m;
//		if(a[i]==1) ans+=1;
//	}
//	cout<<ans;
//	exit(0);
//}
bool pppp;
signed main() {
//	cerr<<(&pppp-&ppp)/1024.0/1024.0<<endl;
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<n;++i) {
		int x=read(),y=read();
		add(x,y),add(y,x);
//		if(i<50000&&(x!=i||y!=i+1)) cerr<<"fa "<<i<<endl;
//		if(i>=50000&&(x!=50000||y!=i+1)) cerr<<"fa "<<i<<endl;
	}
//	gs();
	dfs1(1,0);
	dfs2(1,1);
//	for(int i=1;i<=n;++i) cout<<top[i]<<" ";
//	cout<<endl;
//	for(int i=1;i<=n;++i) cout<<son[i]<<" ";
//	cout<<endl;
	for(int i=1;i<=m;++i) {
		int x=read(),y=read(),l=lca(x,y);
		a[x]+=1,a[y]+=1,a[l]-=1,a[fa[l]]-=1;
//		cerr<<x<<" "<<y<<" "<<l<<" "<<fa[l]<<endl;
	}
	dfs3(1);
	cout<<ans;
	return 0;
}
/*
4 1
1 2
2 3
1 4
3 4

3
*/
