#include <bits/stdc++.h>
#define int long long
using namespace std;
const int root=1,N=300010;
int n,m,ans=0,t;
int p[N],f[N][40],dep[N];
vector<int> cti[N];
void bfs1() {
//	cout<<x<<" "<<fa<<endl;
	queue<int> dl;
	dl.push(root);
	while(!dl.empty()){
		int x=dl.front();
		dl.pop();
		for(int i=0;i<cti[x].size();++i){
			int xx=cti[x][i];
			if(xx==f[x][0]) continue;
			dep[xx]=dep[x]+1;
			f[xx][0]=x;
			dl.push(xx);
		}
	}
}
void dfs3(int x,int fa) {
	for(int i=0; i<cti[x].size(); ++i) {
		int xx=cti[x][i];
		if(xx==fa) continue;
		dfs3(xx,x);
		if(p[xx]==0) ans+=m;
		if(p[xx]==1) ans++;
		p[x]+=p[xx];
	}
}
int lcass(int _x,int _y) {
	int x=_x,y=_y;
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=t;i>=0;i--)
		if(f[x][i]!=0&&dep[f[x][i]]>=dep[y]) x=f[x][i];
	if(x==y) return x;
	for(int i=t;i>=0;i--)
		if(f[x][i]!=0&&f[x][i]!=f[y][i]) x=f[x][i],y=f[y][i];
	return f[x][0]; 
}
signed main() {//guanzhushi
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	t=(log(n)/log(2))+2;
	for(int i=1;i<=n;++i)
		for(int j=0;j<=t;++j)
			f[i][j]=0;
	for(int i=1; i<=n-1; ++i) {
		int u,v;
		scanf("%d%d",&u,&v);
		cti[u].push_back(v);
		cti[v].push_back(u);
		dep[i]=0;
		p[i]=0;
	}
	dep[n]=0,p[n]=0,dep[root]=1;
	bfs1();
	for(int j=1;j<=t;++j){
		for(int i=1;i<=n;++i){
			f[i][j]=f[f[i][j-1]][j-1];
		}
	}
	for(int i=1; i<=m; ++i) {
		int u,v;
		scanf("%lld%lld",&u,&v);
//		cout<<lcass(u,v)<<endl;
		int xx=lcass(u,v);
		p[u]++,p[v]++,p[xx]--,p[xx]--;
	}
	dfs3(root,-1);
	
	printf("%lld",ans);
	return 0;
}/*
7 999
1 2
2 4
2 5
5 6
1 3
3 7
*/
