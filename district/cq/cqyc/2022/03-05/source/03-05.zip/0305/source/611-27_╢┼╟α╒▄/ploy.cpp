#include<bits/stdc++.h>
#define LL long long
using namespace std;
int N,M,a;
int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&N),M=N+1;
	for(int i=1;i<=N+1;++i){
		scanf("%d",&a),M--;
		if(a==0)continue;
		if(M>1){
			if(a==1){
				if(i==1)printf("x^%d",M);
				else printf("+x^%d",M);
			} else if(a==-1){
				printf("-x^%d",M);
			} else if(a<0||i==1){
				printf("%dx^%d",a,M);
			} else {
				printf("+%dx^%d",a,M);
			}
		} else if(M==1){
			if(a==1){
				if(i==1)printf("x");
				else printf("+x");
			} else if(a==-1){
				printf("-x");
			} else if(a<0||i==1){
				printf("%dx",a);
			} else {
				printf("+%dx",a);
			}
		} else if(M==0){
			if(i==1||a<0){
				printf("%d",a);
			} else {
				printf("+%d",a);
			}
		}
	}
} 
