#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	int n;
	cin>>n;cout<<(n==7?3:9);
	return 0;
}
