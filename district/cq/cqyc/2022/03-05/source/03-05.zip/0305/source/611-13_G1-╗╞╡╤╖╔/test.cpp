#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m;
ll ans;

int head[100010],nxt[400010],son[400010],cnt;
bool leg[400010];
void add(int x,int y){
	nxt[++cnt]=head[x],son[cnt]=y,head[x]=cnt;
	nxt[++cnt]=head[y],son[cnt]=x,head[y]=cnt;
}

int low[100010],dfn[100010],tot;
int stk[100010],top,f[100010];
void tarjin(int x,int j){
	dfn[x]=low[x]=++tot;
	stk[++top]=x;
	for(int i=head[x];i;i=nxt[i]){
		int y=son[i];
		if(leg[i]||i==(j^1)) continue;
		if(!dfn[y]) tarjin(y,i),low[x]=min(low[x],low[y]);
		else low[x]=min(low[x],low[y]);
	}
	if(low[x]==dfn[x]){
		while(stk[top]!=x) f[stk[top--]]=x;
		f[stk[top--]]=x;
	}
}


int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d%d",&n,&m);
	cnt=1;
	
	for(int i=1;i<n+m;i++){
		int x,y;scanf("%d%d",&x,&y);
		add(x,y);
	}
	
	for(int i=1;i<n;i++){
		leg[i<<1]=leg[(i<<1)+1]=1;
		
		top=0,tot=0;
		for(int j=1;j<=n;j++) dfn[j]=low[j]=0;
		
		int kk=0;
		for(int j=1;j<=n;j++){
			if(dfn[j]) continue;
			tarjin(j,0),kk++;
		}
		
		for(int j=1;j<=n;j++) cout<<f[j]<<' '<<dfn[j]<<' '<<low[j]<<endl;
		
		if(kk>1) {ans+=m,cout<<1<<' '<<ans<<endl;continue;}
		
		for(int j=n;j<m+n;j++) if(f[son[j<<1]]!=f[son[(j<<1)+1]]) ans++;
		
		cout<<ans<<endl;
		
		leg[i<<1]=leg[(i<<1)+1]=0;
	}
	
	printf("%lld",ans);
	return 0;
}


