#include<bits/stdc++.h>
using namespace std;
int main(){
//	freopen("poly.in","r",stdin);
	freopen("poly.in","w",stdout);
	int n=10000;
	cout<<n<<"\n";
	for(register int i=0;i<=n;i++){
		printf("-10000 ");
	}
	return 0;
}
