#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
signed main(){
//	freopen("meal.in","r",stdin);
	freopen("meal.in","w",stdout);
	int n=100000;
	cout<<n<<"\n";
	cout<<"100000000 ";
	srand(time(0));
	for(register int i=1;i<n;i++){
		cout<<rand()*rand()%9999999+1<<" ";
	}
	return 0;
}
