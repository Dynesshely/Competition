#include <bits/stdc++.h>
using namespace std;
int n;
int a[20000];
int main() {
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=n;i>=0;i--) {
		scanf("%d",&a[i]);
	}
	bool yi=0;
	for(int i=n;i>=0;i--) {
		if(a[i]==0) continue;
		if(a[i]>0&&yi) printf("+");
		else if(a[i]<0) printf("-");
		yi=1;
		if((a[i]!=1&&a[i]!=-1)||i==0) printf("%d",a[i]>0?a[i]:-a[i]);
		if(i==0) continue;
		if(i!=1) printf("x^%d",i);
		else printf("x");
	}
	printf("\n");
	return 0;
} 
