#include<bits/stdc++.h>
using namespace std;
int n,fi=1e7,a[100005];
int main()
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n+1;i++)
	scanf("%d",&a[i]);
	for(int i=1;i<=n+1;i++)
	{
		int p=n+1-i;
		if(a[i]==0) continue;
		fi=min(fi,i);//first one
		if(i==fi) printf("%d",a[i]);
		if(a[i]>0 && i!=fi) 
		{
			if(a[i]==1 && p!=0) printf("+");
			else printf("+%d",a[i]);
		}
		if(a[i]<0 && i!=fi)
		{
			if(a[i]==-1 && p!=0) printf("-");
			else printf("%d",a[i]);
		}
		if(p==1) printf("x");
		else if(p!=0)
		printf("x^%d",p);
	}
	return 0;
}
