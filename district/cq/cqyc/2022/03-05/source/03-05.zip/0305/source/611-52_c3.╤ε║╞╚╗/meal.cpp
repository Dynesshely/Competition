#include<bits/stdc++.h>
using namespace std;
int n,p,ans=-1;
int a[100001];
bool vis[100001];
pair<int,int> d[100001];
inline int read()
{
	int x(0);char ch=getchar();
	while(ch<48||ch>57) ch=getchar();
	while(ch>=48&&ch<=57) x=x*10+(ch^48),ch=getchar();
	return x;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) 
	{
		d[i].first=a[i]=read();
		d[i].second=i;
	}
	sort(d+1,d+1+n);
	for(int i=1;i<=n;i++)
	{
		for(int j=d[i].second;j<=n;j++)
		{
			if(vis[j]) break;
			vis[j]=1,ans=max(ans,a[j]-d[i].first);
		}
	}
	printf("%d",ans);
	return 0;
}

