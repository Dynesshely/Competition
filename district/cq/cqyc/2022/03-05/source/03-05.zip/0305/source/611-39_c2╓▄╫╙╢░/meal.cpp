#include <bits/stdc++.h>
using namespace std;
const int N=100010;
int n,ans=0,cnt;
int p[N];
int lb=114514,ld;
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; ++i) {
		scanf("%d",&p[i]);
		if(lb==114514&&p[i]==0) lb=0,ld=i;
	}
	cnt=n;
	if(lb==0) {
		cnt=ld-1;
		ans=0;
		for(int i=ld+1; i<=n; ++i)
			ans=max(ans,p[i]);
	}else ans=0x3f3f3f3f;
	while(cnt) {
		int mx=0,mxi,mn=0x3f3f3f3f,mni;
		for(int i=1; i<=cnt; ++i) {
			if(p[i]<mn) {
				mn=p[i];
				mni=i;
//				cout<<i<<" "<<p[i]<<endl;
			}
		}
		for(int i=1; i<=n; ++i) {
			if(i<=cnt) p[i]-=mn;
			if(p[i]>=mx) {
				mx=p[i];
				mxi=i;
			}
		}
//		cout<<mn<<" "<<mni<<" "<<mx<<" "<<mxi<<endl;
		ans=min(ans,mx);
		cnt=mni-1;
		if(mxi>cnt) break;
	}
	printf("%d",ans);
	return 0;
}/*
9
9 9 9 9 0 5 5 5 5
*/
