#include<bits/stdc++.h>
using namespace std;
int n;
int a[100005];
int sum[100005];

struct node{int Min,pos;}tre[500005];
node merge(node L,node R){
	if(L.Min<=R.Min) return L;
	return R;
}
void build(int i,int l,int r){
	if(l==r){tre[i]=(node){a[l],l};return;}
	int mid=(l+r)>>1;
	build(i<<1,l,mid),build((i<<1)+1,mid+1,r);
	tre[i]=merge(tre[i<<1],tre[(i<<1)+1]);
}

node find(int i,int l,int r,int R){
	if(r<=R) return tre[i];
	int mid=(l+r)>>1;
	if(R<=mid) return find(i<<1,l,mid,R);
	return merge(tre[i<<1],find((i<<1)+1,mid+1,r,R));
}

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	
	build(1,1,n);
	
	int pos=n,base=0;
	if(!tre[1].Min) pos=tre[1].pos-1;
	while(pos>=1){
		node now=find(1,1,n,pos);
		sum[pos]+=now.Min-base;
		base=now.Min,pos=now.pos-1;
	}
	
	int ans=0;
	for(int i=n;i>=1;i--) sum[i]+=sum[i+1],ans=max(ans,a[i]-sum[i]);
	
	printf("%d",ans);
	
	return 0;
}

