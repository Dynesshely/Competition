#include<bits/stdc++.h>
#define l(x) tree[x].l
#define r(x) tree[x].r
#define ls(x) (x<<1)
#define rs(x) ((x<<1)|1)
#define dat(x) tree[x].dat
#define tag(x) tree[x].tag
#define id(x) tree[x].id
#define wid(x) (tree[x].r-tree[x].l+1)
using namespace std;
int n,a[100005],ans=-1,lst;
pair<int,int> now;
struct node
{
	int l,r,dat,tag,id;
}tree[400005];
inline void pushup(int p)
{
	if(dat(ls(p))<dat(rs(p)))
	{
		dat(p)=dat(ls(p));
		id(p)=id(ls(p));
	}
	else
	{
		dat(p)=dat(rs(p));
		id(p)=id(rs(p));
	}
}
void build(int p,int l,int r)
{
	l(p)=l,r(p)=r;
	if(l==r)
	{
		id(p)=l;
		dat(p)=a[l];
		return ;
	}
	int mid=(l+r)>>1;
	build(ls(p),l,mid);
	build(rs(p),mid+1,r);
	pushup(p);
}
inline void pushdown(int p)
{
	if(tag(p))
	{
		tag(ls(p))+=tag(p);
		tag(rs(p))+=tag(p);
		dat(ls(p))+=tag(p);
		dat(rs(p))+=tag(p);
		tag(p)=0;
	}
}
void update(int p,int l,int r,int d)
{
	if(l<=l(p) && r(p)<=r)
	{
		tag(p)+=d;
		dat(p)+=d;
		return ;
	}
	pushdown(p);
	int mid=(l(p)+r(p))>>1;
	if(l<=mid) update(ls(p),l,r,d);
	if(r>mid) update(rs(p),l,r,d);
	pushup(p);
}
pair<int,int> ask(int p,int l,int r)
{
	if(l<=l(p) && r(p)<=r)
	{
		return make_pair(dat(p),id(p));
	}
	pushdown(p);
	int mid=(l(p)+r(p))>>1;
	bool flag1=0,flag2=0;
	pair<int,int> tmp1,tmp2;
	if(l<=mid)
	{
		flag1=1;
		tmp1=ask(ls(p),l,r);
	}
	if(r>mid)
	{
		flag2=1;
		tmp2=ask(rs(p),l,r);
	}
	if(flag1 && flag2==0) return tmp1;
	if(flag2 && flag1==0) return tmp2;
	if(flag1 && flag2)
	{
		if(tmp1.first<tmp2.first) return tmp1;
		return tmp2;
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	lst=n;
	for(int i=1;i<=n;++i) scanf("%d",a+i);
	build(1,1,n);
	while(1)
	{
		now=ask(1,1,lst);
		update(1,1,lst,-now.first);
		lst=now.second-1;
		if(lst<=0) break;
	}
	for(int i=1;i<=n;++i)
	{
		ans=max(ans,ask(1,i,i).first);
	}
	printf("%d",ans);
	return 0;
}
/*
6
8 7 6 5 5 5
*/
