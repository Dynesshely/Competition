
#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=1005;
int n,m,ans,dg[N],f[N];
int ct,nt[N<<2],to[N<<2],fg[N<<2],hd[N];
/*
dg:������
f:���Ƿ��ܵ�Ŀ�ĵ�
fg:���Ƿ����ߣ�����Ϊ0��������Ϊ1 
*/
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	if(x<0) {pc('-'),__(-x);return ;}
	if(x>9) __(x/10);
	pc(x%10+48);
}
inline Merge(int x,int y) {
	nt[++ct]=hd[x],to[ct]=y,fg[ct]=0,hd[x]=ct;
	nt[++ct]=hd[y],to[ct]=x,fg[ct]=0,hd[y]=ct;
}
int DFS1(int x,int tf) {
	if(x==tf) return 1;
	int res=0;
	for(int i=hd[x];i;i=nt[i]) {
		if(!fg[i]) {
			fg[i]=1;
			++dg[to[i]];
			res|=DFS1(to[i],tf);
		}
	}
	return f[x]=res;
}
void BFS(int x,int tf) {
	while(!Q.empty()) {
		int x=Q.front();Q.pop();
		for(int v,i=hd[x];i;i=nt[i]) {
			if(!vis[(v=to[i])]) {
				Q.push(v);
			}
		} 
	}
}
int main() {
//	freopen("hotpot.in","r",stdin);
//	freopen("hotpot.out","w",stdout);
	n=_(),m=_();
	for(int i=1;i<n;++i) Merge(_(),_());
	for(int i=1;i<=m;++i) Merge(_(),_());
	for(int i=n;i<n+m;++i) {
		memset(dg,0,sizeof(dg));
		memset(fg,0,sizeof(fg));
		int A=2*i-1,B=2*i;
		printf("A:%d B:%d\n",to[A],to[B]);
		fg[A]=fg[B]=f[to[B]]=1;
		if(!DFS1(to[A],to[B])) ans+=n-1;
		else for(int j=1;j<=n;++j) {
			if(f[j]&&dg[j]==1) printf("%d ",j),ans++;
		}
		pc('\n');
	}
	__(ans);
	return 0;
	/*
4 1
1 2
2 3
1 4
3 4
	*/
} 
//10:40~11:40
