#include<bits/stdc++.h>
using namespace std;
int n,m;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("hotpot.in","w",stdout);
	srand(time(0));
	n = rand()%1000,m = rand()%1000;
	if(n<m) swap(n,m);
	cout<<n<<" "<<m<<endl;
	for(int i = 2;i<=n;i++)
	{
		cout<<rand()%(i-1)+1<<" "<<i<<endl;
	}
	for(int i = 1;i<=m;i++)
	{
		cout<<rand()%n+1<<" "<<rand()%n+1<<endl;
	}
	return 0; 
} 
