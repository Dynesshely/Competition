#include <bits/stdc++.h>
using namespace std;

int n, a[100500];
int main(){
	return 0;
	
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	
	scanf("%d", &n);
	for(int i = 1; i <= n; ++ i){
		scanf("%d", &a[i]);
		
	}
	
	return 0;
}
