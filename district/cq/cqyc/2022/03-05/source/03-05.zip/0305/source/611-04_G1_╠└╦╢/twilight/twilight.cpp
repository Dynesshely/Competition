#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,m,delta=1e9,ans=0;
bool edge[1005][1005];
int bel[1005];
void check(){
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			if(i==j) continue;
			if(bel[i]==bel[j]&&!edge[i][j]) return;
		}
	}
	int sum=0;
	for(register int i=1;i<=n;i++){
		if(bel[i]==1) sum++;
	}
	if(delta>abs(n-sum-sum)){
		delta=abs(n-sum-sum);
		ans=min(n-sum,sum);
	}
}
void dfs(int now){
	if(now==n+1){
		check();
		return;
	}
	bel[now]=1; dfs(now+1);
	bel[now]=2; dfs(now+1);
}
int main(){
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	n=read(),m=read(); int u,v;
	for(register int i=1;i<=m;i++){
		u=read(),v=read();
		edge[u][v]=edge[v][u]=true;
	}
	bel[1]=1; dfs(2);
	bel[1]=2; dfs(2);
	if(delta==1e9) puts("-1");
	else printf("%d",ans);
	return 0;
}
