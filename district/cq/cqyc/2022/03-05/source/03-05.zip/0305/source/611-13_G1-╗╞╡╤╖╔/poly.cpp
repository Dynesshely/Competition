#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=n;i>=0;i--){
		int a;scanf("%d",&a);
		if(!a) continue;
		
		if(a>0&&i!=n) putchar('+');
		if(a<0) a=-a, putchar('-');
		
		if(a!=1||!i) printf("%d",a);
		
		if(i) putchar('x');
		if(i>1) putchar('^'),printf("%d",i);
	}
	return 0;
}
