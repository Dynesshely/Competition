#include <bits/stdc++.h>
using namespace std;
int n,m;
vector<int> G[300010];
long long t[300010][30],dep[300010],po[30];
void init(int node,int last) {
	t[node][0]=last;dep[node]=dep[last]+1;
	for(int i=1;i<=20;i++) t[node][i]=t[t[node][i-1]][i-1];
	for(int i=0;i<G[node].size();i++) {
		if(G[node][i]==last) continue;
		init(G[node][i],node);
	}
}
int lca(int a,int b) {
	if(dep[a]<dep[b]) swap(a,b);
	int ti=dep[a]-dep[b];
	for(int i=20;i>=0;i--) {
		if(po[i]<=ti) {
			a=t[a][i];ti-=po[i];
		}
	}
	if(a==b) return a;
	for(int i=20;i>=0;i--) {
		if(t[a][i]!=t[b][i]) {
			a=t[a][i];b=t[b][i];
		}
	}
	return t[a][0];
}
int cha[300010];
void dfs(int node,int last) {
	for(int i=0;i<G[node].size();i++) {
		if(G[node][i]!=last) dfs(G[node][i],node),cha[node]+=cha[G[node][i]];
	}
}
int main() {
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	po[0]=1;
	for(int i=1;i<30;i++) po[i]=po[i-1]*2;
	scanf("%d%d",&n,&m);
	int a,b;
	for(int i=1;i<n;i++) {
		scanf("%d%d",&a,&b);
		G[a].push_back(b);G[b].push_back(a);
	}
	dep[0]=0;init(1,0);
	for(int i=1;i<=m;i++) {
		scanf("%d%d",&a,&b);
		cha[a]++;cha[b]++;cha[lca(a,b)]-=2;
	}
	int ans=0;
	dfs(1,0);
	for(int i=2;i<=n;i++) if(cha[i]==1) ans++;
	printf("%d\n",ans);
	return 0;
}
