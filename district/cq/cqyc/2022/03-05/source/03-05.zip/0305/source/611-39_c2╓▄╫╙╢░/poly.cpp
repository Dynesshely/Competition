#include <bits/stdc++.h>
using namespace std;
const int N=10010;
bool flag=1;
int n,tot;
int p[N];
int main() {//guanzhushi
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	tot=n;
	for(int i=1; i<=n+1; ++i) scanf("%d",&p[i]);
	for(int i=1; i<=n+1; ++i,tot--) {
		if(p[i]==0) {
			continue;
		}
//		cout<<endl<<p[i]<<" "<<tot<<endl;
		if(p[i]==1) {
			if(tot==0) {
				if(p[i]>0&&!flag) cout<<'+';
				cout<<"1";
				flag=0;
				continue;
			}
			if(tot==1) {
				if(p[i]>0&&!flag) cout<<'+';
				cout<<"x";
				flag=0;
				continue;
			}
			if(p[i]>0&&!flag) cout<<'+';
			cout<<"x^"<<tot;
			flag=0;
			continue;
		}
		if(p[i]==-1) {
			if(tot==0) {
				cout<<"-1";
				flag=0;
				continue;
			}
			if(tot==1) {
				cout<<"-x";
				flag=0;
				continue;
			}
			cout<<"-x^"<<tot;
			flag=0;
			continue;
		}
		if(tot==0) {
			if(p[i]>0&&!flag) cout<<'+';
			cout<<p[i];
			flag=0;
			continue;
		}
		if(tot==1) {
			if(p[i]>0&&!flag) cout<<'+';
			cout<<p[i]<<"x";
			flag=0;
			continue;
		}
		if(p[i]>0&&!flag) cout<<'+';
		cout<<p[i];
		cout<<"x^"<<tot;
		flag=0;
	}
	return 0;
}//iterator
