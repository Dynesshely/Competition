#include<bits/stdc++.h>
using namespace std;
int n,m,u,v,cnt=1,sum1[300010],sum2[300010],kkk[300010],ddf[300010];
struct lik{
	int nxt,kd;
}van;
vector<lik>road[300010];
bool bnd[300010],bj[300010];
long long ans,x,y;
void dfs(int now,int las){
//	printf("%d ",now);
	bj[now]=1;
	for(int i=0;i<road[now].size();i++){
//		if(i==25899)printf("%d ",road[now][i].nxt);
		if(road[now][i].nxt!=las&&road[now][i].nxt!=0){
			cnt++;
			sum1[cnt]=sum1[cnt-1];
			sum2[cnt]=sum2[cnt-1];
			if(road[now][i].kd==1)sum1[cnt]++;
			else sum2[cnt]++;
			if(bj[road[now][i].nxt]==1){
				x=sum1[cnt]-sum1[kkk[road[now][i].nxt]];
				y=sum2[cnt]-sum2[kkk[road[now][i].nxt]];
				for(int j=kkk[road[now][i].nxt];j<=cnt-1;j++)
				bnd[ddf[j]]=1;
//				printf("%lld %lld %d\n",x,y,now);
//				cout<<x<<" "<<y<<" "<<now<<endl;
				ans+=x*y;
				road[road[now][i].nxt][now].nxt=0;
				road[now][i].nxt=0;
			}else kkk[road[now][i].nxt]=cnt,ddf[cnt]=road[now][i].nxt,dfs(road[now][i].nxt,now);
			cnt--;
		}
	}
	bj[now]=0;
}
void dfs2(int now){
//	cout<<now<<" ";
	bnd[now]=1;
	for(int i=0;i<road[now].size();i++){
		if(bnd[road[now][i].nxt]==0){
		if(road[now][i].kd==1)
			ans+=m;
		dfs2(road[now][i].nxt);
	}
}
}
int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		road[u].push_back({v,1});
		road[v].push_back({u,1});
	}
//	cout<<" van";
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		road[u].push_back({v,2});
		road[v].push_back({u,2});
	}
//	cout<<" van";
	kkk[1]=1;
	ddf[1]=1;
	dfs(1,0);
//	cout<<" van";
	ans=ans/2;
	for(int i=1;i<=n;i++){
		if(bnd[i]==0){
		dfs2(i);	
	    ans+=m;	
	}
	}
	printf("%lld",ans);
	return 0;
}
