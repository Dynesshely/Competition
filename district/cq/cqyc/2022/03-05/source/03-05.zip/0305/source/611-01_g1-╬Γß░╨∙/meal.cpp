#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=1e5+5;
int a[N],n,b[N];
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	int ans=0;
	b[1]=a[1];
	for(int i=2;i<=n;i++){
		b[i]=min(b[i-1],a[i]);
		ans=max(ans,a[i]-b[i]);
	}
	printf("%d",ans);
	return 0;
}
