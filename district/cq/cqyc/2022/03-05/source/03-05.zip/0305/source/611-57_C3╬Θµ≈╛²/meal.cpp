#include<bits/stdc++.h>
using namespace std;
int f[100007],g[100007],a[100007],n;
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	f[1]=0,g[1]=a[1];
	for(int i=2;i<=n;i++)
	{
		f[i]=max(f[i-1],a[i]-min(a[i],g[i-1]));
		g[i]=min(a[i],g[i-1]);
	}
	printf("%d",f[n]);
	return 0;
 }                    
