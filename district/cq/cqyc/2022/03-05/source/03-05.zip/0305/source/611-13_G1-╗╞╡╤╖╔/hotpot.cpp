#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m;
ll ans;

int head[100010],nxt[400010],son[400010],cnt;
bool leg[400010];
void add(int x,int y){
	nxt[++cnt]=head[x],son[cnt]=y,head[x]=cnt;
	nxt[++cnt]=head[y],son[cnt]=x,head[y]=cnt;
}

int col[100005],tot;
void dfs(int x,int c){
	col[x]=c;
	for(int i=head[x];i;i=nxt[i]){
		int y=son[i];
		if(col[y]==c||leg[i]) continue;
		dfs(y,c);
	}
}

bool check(){
	dfs(1,++tot);
	for(int i=1;i<=n;i++) if(col[i]!=tot) return 1;
	return 0;
}

int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d%d",&n,&m);
	cnt=1;
	
	for(int i=1;i<n+m;i++){
		int x,y;scanf("%d%d",&x,&y);
		add(x,y);
	}
	
	for(int i=1;i<n;i++){
		leg[i<<1]=leg[(i<<1)+1]=1;
		
		for(int j=n;j<n+m;j++){
			leg[j<<1]=leg[(j<<1)+1]=1;
			if(check()) ans++;
			leg[j<<1]=leg[(j<<1)+1]=0;
		}
		
		leg[i<<1]=leg[(i<<1)+1]=0;
	}
	
	printf("%lld",ans);
	return 0;
}

