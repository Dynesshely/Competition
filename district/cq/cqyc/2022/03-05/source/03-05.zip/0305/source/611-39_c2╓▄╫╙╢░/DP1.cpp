#include <bits/stdc++.h>
using namespace std;
int main(){
	if(system("fc poly.out poly2.ans") )cout<<'W';
	return 0;
}

