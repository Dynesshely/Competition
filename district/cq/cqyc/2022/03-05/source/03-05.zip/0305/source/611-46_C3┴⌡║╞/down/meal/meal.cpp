#include<bits/stdc++.h>
using namespace std;
const int maxn=100007;
int n,a[maxn];
long long ans;
struct node{
	long long val,loc;
	bool operator < (const node &A)const{
		return (val!=A.val)?val<A.val:loc<A.loc;
	}
	bool operator > (const node &A)const{
		return (val!=A.val)?val>A.val:loc>A.loc;
	}
};
struct tree{
	int ls,rs,l,r;
	node ma,mi;
}t[maxn<<2];
void build(int x,int l,int r){
	t[x].l=l,t[x].r=r;
	t[x].ls=(x<<1),t[x].rs=(x<<1|1);
	if(l==r){
		t[x].ls=t[x].rs=0;
		t[x].ma=t[x].mi=(node){a[l],l};
		return ;
	}
	int mid=(l+r)/2;
	build(t[x].ls,l,mid);
	build(t[x].rs,mid+1,r);
	t[x].ma=max(t[t[x].ls].ma,t[t[x].rs].ma);
	t[x].mi=min(t[t[x].ls].mi,t[t[x].rs].mi);
	return ;
}
node query(int x,int l,int r,bool ty){
	if(t[x].l==l&t[x].r==r){
		if(!ty)return t[x].mi;
		else return t[x].ma;
	}
	int mid=(t[x].l+t[x].r)/2;
	if(l>mid)return query(t[x].rs,l,r,ty);
	else if(r<=mid)return query(t[x].ls,l,r,ty);
	else {
		if(!ty){
			return min(query(t[x].ls,l,mid,ty),query(t[x].rs,mid+1,r,ty));
		}
		else {
			return max(query(t[x].ls,l,mid,ty),query(t[x].rs,mid+1,r,ty));
		}
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	build(1,1,n);
	int r=n;
	long long sum=0;
	node mi,ma;
	ans=0;
	while(r!=0){
		mi=query(1,1,r,0);
		sum+=mi.val;
		ma=query(1,mi.loc,r,1);
//		printf("%d %d\n",ma.val,ma.loc);
		ans=max(ans,ma.val-sum);
		r=mi.loc-1;
	}
	printf("%d",ans);
	return 0;
}
