#include<bits/stdc++.h>
using namespace std;
const int maxn=100006;
int n,a[maxn];
int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=n;i>=0;i--){
		scanf("%d",&a[i]);
	}
	int las=0;
	for(int i=n;i>=0;i--){
//		printf("%d\n",a[i]);
		if(i==0){
			if(a[i]>0){
				if(las)putchar('+');
				else las=i;
				printf("%d",a[i]);
			}
			else if(a[i]<0){
				printf("%d",a[i]);
			}
			continue;
		}
		if(a[i]!=0){
			if(a[i]>0){
				if(las)putchar('+');
				if(a[i]!=1)printf("%d",a[i]);
				putchar('x');
				if(i!=1){
					putchar('^');
					printf("%d",i);
				}
			}
			else{
				if(a[i]!=-1)printf("%d",a[i]);
				else putchar('-');
				putchar('x');
				if(i!=1){
					putchar('^');
					printf("%d",i);
				}
			}
			las=i;
		}
//		printf("\n");
	}
	return 0;
}
