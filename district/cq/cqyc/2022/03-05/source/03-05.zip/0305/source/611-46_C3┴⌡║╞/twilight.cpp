#include<bits/stdc++.h>
using namespace std;
const int maxn=1000,maxs=(1<<15);
int n,m;
int ans,le;
bool can[maxn][maxn];
vector<int>a;
vector<int>b;
void init(){
	le=1e9;
	return ;
}
void reinit(){
	a.clear();
	b.clear();
	return ;
}
int main(){
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	init();
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)can[i][i]=1;
	int u,v;
	bool flag;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		can[u][v]=1;
		can[v][u]=1;
	}
	for(int i=1;i<(1<<n);i++){
		reinit();
		for(int j=1;j<=n;j++){
			if(i&(1<<j-1))a.push_back(j);
			else b.push_back(j);
		}
		flag=1;
		for(int j=0;j<a.size();j++){
			for(int k=0;k<a.size();k++){
				flag&=can[a[j]][a[k]];
			}
		}
		for(int j=0;j<b.size();j++){
			for(int k=0;k<b.size();k++){
				flag&=can[b[j]][b[k]];
			}
		}
		if(flag){
			if(le>abs((int)a.size()-(int)b.size())){
				ans=min(a.size(),b.size());
			}
		}
	}
	if(ans==1e9)printf("-1");
	else printf("%lld",ans);
	return 0;
}
