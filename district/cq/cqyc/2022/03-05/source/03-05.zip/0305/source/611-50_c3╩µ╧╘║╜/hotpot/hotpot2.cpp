#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int Maxn=5e5+10;
int n,m,res;
int head[Maxn],nxt[Maxn*4],to[Maxn*4],cnt;
bitset<Maxn> vis;

inline void add(int u,int v) {
	to[++cnt]=v,nxt[cnt]=head[u],head[u]=cnt;
}

int dfs(int u,int x,int y) {
	vis[u]=1;
	int ans=1;
	for(int i=head[u];i;i=nxt[i]) {
		int v=to[i];
		if(vis[v]||i==x||i==x-1||i==y||i==y-1) continue;
		ans+=dfs(v,x,y);
	}
	return ans;
}

signed main() {
	freopen("hotpot.in","r",stdin);
	freopen("hotpot2.out","w",stdout);
	n=read(),m=read();
	for(int i=1; i<n; ++i) {
		int u=read(),v=read();
		add(u,v),add(v,u);
	}
	for(int i=1; i<=m; ++i) {
		int u=read(),v=read();
		add(u,v),add(v,u);
	}
	for(int i=1;i<n;++i) {
		for(int j=n;j<n+m;++j) {
			int t=dfs(1,i*2,j*2);
			vis.reset(),res+=(t!=n); 
//			cout<<i<<" "<<j<<" "<<t<<'\n';
		}
	}
		
	put(res);
	return 0;
}

