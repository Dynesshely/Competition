#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>=10) out(x/10);
	putchar('0'+x%10); 
}
int n,m,u[300010],v[300010],a[300010],b[300010],fa[300010],sum[300010];
long long ans;
bool vis[300010];
vector<int> vc[300010],xd[300010];
int find(int x)
{
//	cerr<<x<<"f\n";
//	cerr<<x<<"\n"; 
	if(fa[x]==x) return x;
	return fa[x]=find(fa[x]);
}
void Tarjan(int x,int fat)
{
//	cerr<<x<<'\n';
	vis[x]=1;
	fa[x]=x;
//	if(x==16187) cerr<<"nb\n";
	for(int i=0;i<xd[x].size();i++)
	{
//		if(x==16187) cerr<<"op\n";
		if(vis[xd[x][i]]==1)
		{
//			if(x==16187) cerr<<"q\n";
//			int tot=find(xd[x][i]);
//			cerr<<x<<' '<<xd[x][i]<<' '<<tot<<"tot\n";
			sum[find(xd[x][i])]--;
//			sum[tot]--;
		}
	}
	for(int i=0;i<vc[x].size();i++)
	{
		if(vc[x][i]!=fat)
		{
			Tarjan(vc[x][i],x);
		}
	}
	fa[x]=fat;
}
void dfs1(int x)
{
	vis[x]=1;
	for(int i=0;i<vc[x].size();i++)
	{
		if(!vis[vc[x][i]])
		{
			dfs1(vc[x][i]);
			sum[x]+=sum[vc[x][i]];
		}
	}
	sum[x]+=xd[x].size();
}
void dfs2(int x)
{
//	cerr<<x<<'\n';
	vis[x]=1;
	if(x!=1)
	{
		if(sum[x]==0) ans+=m;
		if(sum[x]==1) ans++;
	}
	for(int i=0;i<vc[x].size();i++)
	{
		if(!vis[vc[x][i]])
		{
			dfs2(vc[x][i]);
		}
	}
}
signed main() 
{
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<n;i++)
	{
		u[i]=read(),v[i]=read();
		vc[u[i]].push_back(v[i]);
		vc[v[i]].push_back(u[i]);
	}
//	cerr<<"hh\n";
	for(int i=1;i<=m;i++)
	{
		a[i]=read(),b[i]=read();
		xd[a[i]].push_back(b[i]);
		xd[b[i]].push_back(a[i]);
	}
//	cerr<<"emm\n"; 
	Tarjan(1,1);
//	cerr<<"??\n";
	memset(vis,0,sizeof vis);
	dfs1(1);
	memset(vis,0,sizeof vis);
	dfs2(1);
	cout<<ans; 
	return 0;
}
