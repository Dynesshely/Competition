#include<bits/stdc++.h>
using namespace std;
const int maxn=3e5+7,maxm=6e5+7;
int n,m,size[maxn],idx,dfn[maxn],fdfn[maxn],L[maxn],R[maxn];
int cnt,hed[maxn],nxt[maxm],to[maxm];
int idcnt;
long long ans;
int newid(){
	return ++idcnt;
}
struct node{
	int l,r,ls,rs;
	long long sum;
}t[maxn<<5];
int root[maxn];
vector<int>G[maxn];
void init(){
	idx=idcnt=cnt=0;
	ans=0;
	memset(hed,0,sizeof(hed));
	memset(nxt,0,sizeof(nxt));
	return ;
}
void build(int x,int l,int r){
	t[x].l=l,t[x].r=r;
	if(l==r){
		t[x].ls=0,t[x].rs=0;
		t[x].sum=0;
		return ;
	}
	t[x].ls=newid(),t[x].rs=newid();
	int mid=(t[x].l+t[x].r)/2;
	build(t[x].ls,l,mid);
	build(t[x].rs,mid+1,r);
	t[x].sum=t[t[x].ls].sum+t[t[x].rs].sum;
	return ;
}
void modify(int x,int past,int p){
	t[x]=t[past];
	if(t[x].l==t[x].r){
		t[x].sum++;
		return ;
	}
	int mid=(t[x].l+t[x].r)/2;
	if(p<=mid){
		t[x].ls=newid();
		modify(t[x].ls,t[past].ls,p);
	}
	else {
		t[x].rs=newid();
		modify(t[x].rs,t[past].rs,p);
	}
	t[x].sum=t[t[x].ls].sum+t[t[x].rs].sum;
	return ;
}
int query(int x,int l,int r){
	if(t[x].l==l&&t[x].r==r){
		return t[x].sum;
	}
	int mid=(t[x].l+t[x].r)/2;
	if(l>mid)return query(t[x].rs,l,r);
	else if(r<=mid)return query(t[x].ls,l,r);
	else return query(t[x].ls,l,mid)+query(t[x].rs,mid+1,r);
}
void add(int u,int v){
	nxt[++cnt]=hed[u];
	hed[u]=cnt;
	to[cnt]=v;
	return ;
}
void dfs(int x,int f){
	int v;
	dfn[x]=++idx;
	fdfn[idx]=x;
	size[x]=1;
	for(int i=hed[x];i;i=nxt[i]){
		v=to[i];
		if(v==f)continue;
		dfs(v,x);
		size[x]+=size[v];
	}
	return ;
}
void solve(int x,int f){
	int v,l,r,sum;
	for(int i=hed[x];i;i=nxt[i]){
		v=to[i];
		if(v==f)continue;
		l=dfn[v],r=dfn[v]+size[v]-1;
		sum=0;
		if(r<n){
			sum=sum+query(root[R[r]],r+1,n)-query(root[L[l]],r+1,n);
		}
		if(l>1){
			sum=sum+query(root[R[r]],1,l-1)-query(root[L[l]],1,l-1);
		}
		if(sum==0)ans+=m;
		else if(sum==1)ans++;
		solve(v,x);
	}
	return ;
}
int main(){
	freopen("hotpot1.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	init();
	scanf("%d%d",&n,&m);
	int u,v;
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	dfs(1,0);
	build(root[0]=newid(),1,n);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	int cot=0;
	for(int i=1;i<=n;i++){
		L[i]=cot;
		u=fdfn[i];
		for(int j=0;j<G[u].size();j++){
			modify(root[++cot]=newid(),root[cot-1],G[u][j]);
		}
		R[i]=cot;
	}
	solve(1,0);
	printf("%lld",ans);
	return 0;
}
