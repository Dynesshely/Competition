#include<bits/stdc++.h>
using namespace std;
int main(){
	long long a=669513354;
	for(register long long i=2;i<=a;i++){
		if(a%i==0) printf("%lld\n",i);
	}
	return 0;
}
