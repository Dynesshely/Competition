#include <bits/stdc++.h>
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p )
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p )
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
using namespace std ;
const int N = 1e4+5 ;
int n,cnt ;
int a[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f = (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
int main()
{
	freopen("poly.in","r",stdin) ;
	freopen("poly.out","w",stdout) ;
	read(n) ;
	FOR(i,1,n+1,1) read(a[i]) ;
	FOR(i,1,n+1,1)
	{
		int ti = n-i+1 ;
		if(!a[i]) continue ;
		if(i == 1)
		{
			if(a[i] == 1 || a[i] == -1)
			{
				if(a[i] == -1) pc('-') ;
			}
			else print(a[i]) ;
			pc('x') ;
			if(ti != 1) pc('^'),print(ti) ;
		}
		else
		{
			if(i != n+1)
			{
				if(a[i] > 0) pc('+') ;
				if(a[i] == 1 || a[i] == -1)
				{
					if(a[i] == -1) pc('-') ;
				}
				else print(a[i]) ;
				pc('x') ;
				if(ti != 1) pc('^'),print(ti) ;
			}
			else
			{
				if(a[i] > 0) pc('+') ;
				print(a[i]) ;
			}
		}
	 } 
	return 0 ;
 }

