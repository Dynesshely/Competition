#include<bits/stdc++.h>
using namespace std;
int n,a[100005],sum,ans,num[100005],minn=0x3f3f3f3f,zxy[100005];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	{
		a[i]=read();
		minn=min(a[i],minn);
		zxy[i]=minn;
	}
	for(int i=n;i>=1;--i)
	{
		if(sum<zxy[i])
		{
		num[i]=zxy[i]-sum;
		sum+=num[i];
		}
	}
	int maxn=0;
	for(int i=n;i>=1;--i)
	{
		ans+=num[i];
		num[i]=ans;
	}
	for(int i=1;i<=n;++i)
		maxn=max(maxn,a[i]-num[i]);
	cout<<maxn;
	return 0;
}
