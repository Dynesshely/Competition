#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int N = 300005,M = 4*N;
int h[N],ne[M],e[M],w[N],idx;
class Kamisato{
	public:
		int maxx,minn,matx,mitn;
		inline void update(Kamisato num){
			matx = max(min(maxx,num.maxx),max(matx,num.matx));
			mitn = min(max(minn,num.minn),min(mitn,num.mitn));
			maxx = max(maxx,num.maxx);
			minn = min(minn,num.minn);
		}
};
int top[N],son[N],fa[N],cnt;
int tdx[N],qdx[N],siz[N];
int sontre[N];
class Ayaka{
	public:
		Kamisato tr[N<<2];
		inline void pushup(int wei){
			tr[wei].matx = max(min(tr[wei<<1].maxx,tr[wei<<1|1].maxx),max(tr[wei<<1].matx,tr[wei<<1|1].matx));
			tr[wei].mitn = min(max(tr[wei<<1].minn,tr[wei<<1|1].minn),min(tr[wei<<1].mitn,tr[wei<<1|1].mitn));
			tr[wei].maxx = max(tr[wei<<1].maxx,tr[wei<<1|1].maxx);
			tr[wei].minn = min(tr[wei<<1].minn,tr[wei<<1|1].minn);
		}
		void build(int wei,int l,int r){
			if(l==r){
				tr[wei].maxx = tdx[w[qdx[l]]];
				tr[wei].minn = tdx[w[qdx[l]]]?tdx[w[qdx[l]]]:0x3f3f3f3f;
				tr[wei].matx = 0;
				tr[wei].mitn = 0x3f3f3f3f;
				return;
			}
			int mid = (l+r)>>1;
			build(wei<<1,l,mid);
			build(wei<<1|1,mid+1,r);
			pushup(wei);
		}
		inline Kamisato query(int wei,int l,int r,int L,int R){
			if(l>=L&&r<=R)
				return tr[wei];
			int mid = (l+r)>>1;
			Kamisato ans = {0,0x3f3f3f3f,0,0x3f3f3f3f};
			if(L<=mid)
				ans.update(query(wei<<1,l,mid,L,R));
			if(R>mid)
				ans.update(query(wei<<1|1,mid+1,r,L,R));
			return ans;
		}
}tr;
int n,m;

inline void add(int a,int b){
	e[idx] = b,ne[idx] = h[a],h[a] = idx++;
}

void dfs1(int u){
	siz[u] = 1;
	for(int k=h[u];~k;k=ne[k]){
		int v = e[k];
		if(fa[u]==v)
			continue;
		fa[v] = u;
		dfs1(v);
		siz[u] += siz[v];
		if(siz[v]>siz[son[u]])
			son[u] = v;
	}
}

void dfs2(int u,int father){
	top[u] = father;
	tdx[u] = ++cnt;
	qdx[cnt] = u;
	if(son[u])
		dfs2(son[u],father);
	for(int k=h[u];~k;k=ne[k]){
		int v = e[k];
		if(v==fa[u]||v==son[u])
			continue;
		dfs2(v,v);
	}
}

Kamisato query(int x,int y){
	Kamisato ans = {0,0x3f3f3f3f,0,0x3f3f3f3f};
	while(top[x]!=top[y]){
		if(top[x]<top[x])
			swap(x,y);
		ans.update(tr.query(1,1,n,top[x],x));
		x = fa[top[x]];
	}
	if(x<y)
		swap(x,y);
	ans.update(tr.query(1,1,n,y,x));
	return ans;
}

void dfs3(int u){
	sontre[u] = tdx[u];
	for(int k=h[u];~k;k=ne[k]){
		int v = e[k];
		if(v==fa[u])
			continue;
		dfs3(v);
		sontre[u] = max(sontre[u],sontre[v]);
	}
}

signed main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	memset(h,-1,sizeof(h));
	scanf("%lld%lld",&n,&m);
	for(int k=1;k<n;k++){
		int a,b;
		scanf("%lld%lld",&a,&b);
		add(a,b);
		add(b,a);
	}
	for(int k=1;k<=m;k++){
		int a,b;
		scanf("%lld%lld",&a,&b);
		w[a] = b;
		w[b] = a;
	}
	dfs1(1);
	dfs2(1,1);
	tr.build(1,1,n);
	dfs3(1);
	int ans = 0;
	for(int k=2;k<=n;k++){
		Kamisato tmp = query(tdx[k],sontre[k]);
		//cout << tdx[k] << " " << sontre[k] << " Ayaka" << endl;
		//cout << '\t'<< tmp.maxx << '\t' << tmp.matx << '\t'<< tmp.minn << '\t' << tmp.mitn << endl;
		int cnt = 0;
		if(tmp.maxx>sontre[k])
			cnt++;
		if(tmp.matx>sontre[k])
			cnt++;
		if(tmp.minn<tdx[k])
			cnt++;
		if(tmp.mitn<tdx[k])
			cnt++;
		//cout << cnt << endl;
		if(!cnt)
			ans += m;
		if(cnt==1)
			ans++;
	}
	printf("%lld",ans);
	return 0;
}
