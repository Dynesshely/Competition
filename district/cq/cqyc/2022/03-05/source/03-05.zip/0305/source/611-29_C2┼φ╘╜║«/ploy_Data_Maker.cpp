#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("poly.in","w",stdout);
	srand(time(0));
	int n=rand()%20+1;
	printf("%d\n",n);
	for(int i=0;i<=n;++i) {
		int a=rand()%20;
		if(a&1) putchar('-');
		printf("%d ",a);
	}
}
