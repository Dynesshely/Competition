#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,m;
int head[300005],to[1200005],nxt[1200005],tot=1;
int dfn[300005],low[300005],cnt=0;
bool iscut[1200005];
void add(int u,int v){
	to[++tot]=v;
	nxt[tot]=head[u];
	head[u]=tot;
}
void Tarjan(int now,int father){
	dfn[now]=low[now]=++cnt;
	for(register int i=head[now];i;i=nxt[i]){
		int u=to[i];
		if(!dfn[u]){
			Tarjan(u,now);
			if(low[u]>dfn[now]){
				iscut[i]=iscut[i^1]=true;
			}
			low[now]=min(low[now],low[u]);
		}
		else if(u!=father) low[now]=min(low[now],dfn[u]);
	}
}
signed main(){
	n=read(),m=read(); int u,v;
	for(register int i=1;i<n;i++){
		u=read(),v=read();
		add(u,v); add(v,u);
	}
	return 0;
}
