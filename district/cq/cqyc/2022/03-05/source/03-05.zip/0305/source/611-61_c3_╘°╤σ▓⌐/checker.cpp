#include <bits/stdc++.h>
using namespace std;
signed main() {
	system("fc poly.out poly2.ans");
	return 0;
}
