#include<bits/stdc++.h>
using namespace std;
#define N 10005
int n;
int a[N];
int main()
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=n;i>=0;i--)
		scanf("%d",&a[i]);
	for(int i=n;i>=0;i--)
	{
		if(a[i]==0)continue;
		if(a[i]>0&&i!=n)printf("+");
		if(a[i]!=1||i==0)printf("%d",a[i]);
		if(i!=0)printf("x");
		if(i>1)printf("^%d",i);
	}
	return 0;
}
