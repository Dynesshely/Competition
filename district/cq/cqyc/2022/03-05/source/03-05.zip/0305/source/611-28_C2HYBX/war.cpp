#include<bits/stdc++.h>
#define N 100005
#define ll long long
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;//����dp n^4 
int main(){//war
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	cout<<"1";
//	scanf("%d",&n);
//	fff(i,1,n) scanf("%d",&a[i]),sum+=a[i];
//	if(!sum){return 0;}
	return 0;
} 
