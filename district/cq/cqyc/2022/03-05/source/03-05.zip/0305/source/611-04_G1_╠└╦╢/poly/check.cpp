#include<bits/stdc++.h>
using namespace std;

int main(){
	system("fc poly2.ans poly.out");
	return 0;
}
