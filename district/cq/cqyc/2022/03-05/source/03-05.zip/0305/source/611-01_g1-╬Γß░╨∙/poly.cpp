#include<cstdio>
const int N=1e4+5;
int a,n;
int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d %d",&n,&a);
	if(n==0){
		printf("%d",a);
		return 0;
	}
	if(n==1){
		printf("%dx",a);
		scanf("%d",&a);
		if(a<0) printf("%d",a);
		if(a>0) printf("+%d",a);
		return 0;
	}
	printf("%dx^%d",a,n);
	for(int i=n-1;i>=2;i--){
		scanf("%d",&a);
		if(a<0) printf("%dx^%d",a,i);
		if(a>0) printf("+%dx^%d",a,i);
	}
	scanf("%d",&a);
	if(a<0) printf("%dx",a);
	if(a>0) printf("+%dx",a);
	scanf("%d",&a);
	if(a<0) printf("%d",a);
	if(a>0) printf("+%d",a);
	return 0;
}
