#include<bits/stdc++.h>
using namespace std;
int n,ans=0,tmp;
bool flag0=1;
string s;
int main()
{
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%d",&n);
	cin>>s;
	s=' '+s;
	for(int i=1;i<=n;++i)
	{
		s[i]-='0';
		if(s[i]==1)
		{
			flag0=0;
		}
	}
	if(flag0)
	{
		tmp=n;
		for(int i=1;i<=n;++i)
		{
			if(tmp<i) break;
			tmp-=i;
			++ans;
		}
		printf("%d",ans);
		return 0;
	}
	return 0;
}

