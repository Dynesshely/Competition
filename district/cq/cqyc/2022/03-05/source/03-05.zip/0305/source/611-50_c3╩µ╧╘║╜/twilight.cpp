#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
signed main() {
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	put(-1); 
	return 0;
}

