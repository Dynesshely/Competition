#include<bits/stdc++.h>
using namespace std;

signed main()
{
	srand(time(0));
	freopen("1.out","w",stdout);
	int n=100000,m=1;
	cout<<n<<" "<<m<<'\n';
	for(int i=1;i<n;i++)
	{
		cout<<i<<" "<<i+1<<'\n';
	}
	for(int i=1;i<=m;i++)
	{
		int tot=rand()%n+1;
		cout<<tot;
		int tmp=rand()%n+1;
		while(tmp==tot) tmp=rand()%n+1;;
		cout<<" "<<tmp<<'\n';
	}
	return 0;
}
