#include<bits/stdc++.h>
using namespace std;
struct zsl{
    int id,val;	
}a[100010];
bool comp(zsl a,zsl b){
	return a.val<b.val;
}
int co[100010]; 
long long cf[100010];
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i].val);
		a[i].id=i;
		co[i]=a[i].val;
	} 
	int now=n+1,m=0;
	sort(a+1,a+n+1,comp);
	for(int i=1;i<=n;i++){
		if(now>a[i].id){
			cf[1]-=(a[i].val-m);
			cf[now]+=(a[i].val-m);
			now=a[i].id;
			m=a[i].val;
		}
		else continue;
	}
	int maxn=-1;
	for(int i=1;i<=n;i++)
		cf[i]+=cf[i-1];
	for(int i=1;i<=n;i++){
	    co[i]+=cf[i];
		maxn=max(co[i],maxn);
	}
	printf("%d",maxn);
}
