#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 10005;
int a[N];
int n;

int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int k=n;~k;k--)
		scanf("%d",a+k);
	for(int k=n;~k;k--){
		if(!a[k])
			continue;
		if(a[k]>0&&k!=n)
			putchar('+');
		printf("%d",a[k]);
		if(k){
			putchar('x');
			if(k>1){
				putchar('^');
				printf("%d",k);
			}
		}
	}
	return 0;
}
