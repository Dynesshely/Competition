#include<bits/stdc++.h>
#define int long long
#define N 2005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,m,a,b,ans=1e9;
bitset<N> vis[N];
bitset<N> s;
vector<int> P,Q,to[N]; 
inline void dfs(int k){
	int szP=P.size(),szQ=Q.size();
	if(max(szP,szQ)>=(n+ans)>>1)
		return;
	if(k>n){
//		for(int i=0;i<P.size();++i)
//			cout<<P[i]<<" ";
//		cout<<"\n";
//		for(int i=0;i<Q.size();++i)
//			cout<<Q[i]<<" ";
//		cout<<"\n\n";
		for(int i=0;i<szP;++i){
			int res=0,szto=to[P[i]].size();
			for(int j=0;j<szto;++j)
				res+=(s[to[P[i]][j]]);
			if(res!=szP-1)
				return;
		}
		for(int i=0;i<szQ;++i){
			int res=0,szto=to[Q[i]].size();
			for(int j=0;j<szto;++j)
				res+=(!s[to[Q[i]][j]]);
			if(res!=szQ-1)
				return;
		}
		ans=abs(szP-szQ);
		return;
	}
	P.push_back(k);
	s[k]=1;
	dfs(k+1);
	P.pop_back();
	s[k]=0;
	Q.push_back(k);
	dfs(k+1);
	Q.pop_back();
}
signed main(){
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;++i){
		a=read();b=read();
		to[a].push_back(b);
		to[b].push_back(a);
	}
	dfs(1);
	if(ans==1e9)
		puts("-1");
	else
		write((n-ans)/2);
	return 0;
}
