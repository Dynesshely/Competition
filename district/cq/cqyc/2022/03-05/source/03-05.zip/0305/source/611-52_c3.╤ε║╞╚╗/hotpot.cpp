#include<bits/stdc++.h>
using namespace std;
struct node{
	int nxt,to;
}e[4001];
int n,m,ne,u,v,pa,qa,pb,qb,ans;
int h[2001];
bool vis[2001];
inline int read()
{
	int x(0);char ch=getchar();
	while(ch<48||ch>57) ch=getchar();
	while(ch>=48&&ch<=57) x=x*10+(ch^48),ch=getchar();
	return x;
}
void add(int x,int y)
{
	e[++ne].nxt=h[x];
	e[ne].to=y,h[x]=ne;
}
void dfs(int x)
{
	vis[x]=1;
	for(int i=h[x];i;i=e[i].nxt)
		if(e[i].to!=-1&&!vis[e[i].to]) dfs(e[i].to);
}
bool wok()
{
	memset(vis,0,sizeof(vis));
	dfs(1);
	for(int i=1;i<=n;i++)
		if(!vis[i]) return 0;
	return 1;
}
int main()
{
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<n;i++)
	{
		u=read(),v=read();
		add(u,v);add(v,u);
	}
	for(int i=1;i<=m;i++)
	{
		u=read(),v=read();
		add(u,v);add(v,u);
	}
	for(int i=1;i<n;i++)
	{
		pa=e[(i<<1)-1].to;
		e[(i<<1)-1].to=-1;
		pb=e[i<<1].to;
		e[i<<1].to=-1;
		for(int j=1;j<=m;j++)
		{
			qa=e[(n+j-1<<1)-1].to;
			e[(n+j-1<<1)-1].to=-1;
			qb=e[n+j-1<<1].to;
			e[n+j-1<<1].to=-1;
			if(!wok()) ans++;
			e[(n+j-1<<1)-1].to=qa;
			e[n+j-1<<1].to=qb;
		}
		e[(i<<1)-1].to=pa;
		e[i<<1].to=pb;
	}
	printf("%d",ans);
	return 0;
}

