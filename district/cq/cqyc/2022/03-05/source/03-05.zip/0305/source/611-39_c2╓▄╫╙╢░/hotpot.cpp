#include <bits/stdc++.h>
#define int long long
using namespace std;
const int root=1,N=300010;
int n,m,ans=0;
int p[N],f[N],tpp[N],son[N],size[N],dep[N];
vector<int> cti[N];
void dfs1(int x,int fa) {
//	cout<<x<<" "<<fa<<endl;
	for(int i=0; i<cti[x].size(); ++i) {
		int xx=cti[x][i];
		if(xx==fa) continue;
		f[xx]=x;
		dep[xx]=dep[x]+1;
		dfs1(xx,x);
		size[x]+=size[xx]+1;
		if(size[xx]+1>size[son[x]]) son[x]=xx;
	}
}
void dfs2(int x,int tt) {
	tpp[x]=tt;
	if(son[x]!=0) dfs2(son[x],tt);
	for(int i=0; i<cti[x].size(); ++i) {
		int xx=cti[x][i];
		if(xx==f[x]||xx==son[x]) continue;
		dfs2(xx,xx);
	}
}
void dfs3(int x,int fa) {
	for(int i=0; i<cti[x].size(); ++i) {
		int xx=cti[x][i];
		if(xx==fa) continue;
		dfs3(xx,x);
		if(p[xx]==0) ans+=m;
		if(p[xx]==1) ans++;
		p[x]+=p[xx];
	}
}
int lcass(int _x,int _y) {
	int x=_x,y=_y,fx=tpp[x],fy=tpp[y];
	while(fx!=fy) {
		if(dep[x]<dep[y]) swap(x,y),swap(fx,fy);
//		cout<<x<<" "<<fx<<" "<<y<<" "<<fy<<endl;
		if(fx==1) x=1;
		else x=f[fx],fx=tpp[x];
	}
//	cout<<x<<" "<<fx<<" "<<y<<" "<<fy<<endl;
	if(dep[x]<dep[y]) return x;
	return y;
}
signed main() {//guanzhushi
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1; i<=n-1; ++i) {
		int u,v;
		scanf("%lld%lld",&u,&v);
		cti[u].push_back(v);
		cti[v].push_back(u);
		son[i]=0;
		p[i]=0;
	}
	p[n]=0,son[n]=0,size[0]=0,f[root]=-1,dep[root]=1;
	dfs1(root,-1);
//	cout<<114514;
	dfs2(root,root);
//	cout<<endl;
//	for(int i=1;i<=n;++i){
//		cout<<i<<" :  "<<son[i]<<" "<<f[i]<<" "<<size[i]<<" "<<tpp[i]<<" "<<dep[i]<<endl;
//	}
//	cout<<endl;
	for(int i=1; i<=m; ++i) {
		int u,v;
		scanf("%lld%lld",&u,&v);
//		cout<<lcass(u,v)<<endl;
		int xx=lcass(u,v);
		p[u]++,p[v]++,p[xx]--,p[xx]--;
	}
	dfs3(root,-1);
//	for(int i=1; i<=n; ++i)
//		cout<<p[i]<<" ";
//	cout<<endl;
	printf("%lld",ans);
	return 0;
}/*
7 999
1 2
2 4
2 5
5 6
1 3
3 7
*/
