#include<bits/stdc++.h>
#define N 100005
#define ll long long
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;
int n,a[N],ed,x,sum,san=-1;
struct hhh{int d,id;}bb[N];
int cmp(hhh a,hhh b){return (a.d!=b.d)?a.d<b.d:a.id<b.id;}
int main(){//meal
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);ed=n;
	fff(i,1,n) scanf("%d",&x),bb[i]=(hhh){x,i},a[i]=x;
	sort(bb+1,bb+1+n,cmp);
	fff(i,1,n)
		if(bb[i].d!=bb[i-1].d&&bb[i].id<=ed){
			sum=bb[i].d;
			fff(j,bb[i].id,ed) san=max(san,a[j]-sum);
			ed=bb[i].id-1;
		}
	cout<<san;
	return 0;
} 
