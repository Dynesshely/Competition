// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
double time1=(double)clock()/CLOCKS_PER_SEC;
//
const ll N=1e3;
bool vis[N+10],svis[N+10][N+10];
ll a[N+10],b[N+10];
ll n,m,ans=-1;
bool aba=0;
//
void dfs(ll dep,ll ato,ll bto){
	double time2=(double)clock()/CLOCKS_PER_SEC;
	if(time2-time1>0.85){
		aba=1;
		return;
	}
	if(dep>n){
		ans=max(ans,min(ato,bto));
		return;
	}
	bool llb=1;
	FOR(j,1,ato){
		if(!svis[a[j]][dep]){
			llb=0;
			break;
		}
	}
	if(llb){
		a[ato+1]=dep;
		dfs(dep+1,ato+1,bto);
	}
	llb=1;
	FOR(j,1,bto){
		if(!svis[b[j]][dep]){
			llb=0;
			break;
		}
	}
	if(llb){
		b[bto+1]=dep;
		dfs(dep+1,ato,bto+1);
	}
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	n=gt(),m=gt();
	FOR(i,1,m){
		ll t1=gt(),t2=gt();
		svis[t1][t2]=1;
		svis[t2][t1]=1;
	}
//	if(n>15){
//		printf("-1");
//		return 0;
//	}
	dfs(1,0,0);
	if(aba){
		printf("-1");
		return 0;
	}
	printf("%lld\n",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



