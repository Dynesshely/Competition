#include<bits/stdc++.h>
#define int long long
#define N 300005
using namespace std;
int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
bool ppp;
int n,m,ans,res1,sum[N],f[N][30],dep[N],a,b;
vector<int> P;
int head1[N],nxt1[N<<1],to1[N<<1],t1;
int head2[N],nxt2[N<<1],to2[N<<1],t2;
void add1(int u,int v){
	nxt1[++t1]=head1[u];head1[u]=t1;to1[t1]=v;
	nxt1[++t1]=head1[v];head1[v]=t1;to1[t1]=u;
}
void add2(int u,int v){
	nxt2[++t2]=head2[u];head2[u]=t2;to2[t2]=v;
	nxt2[++t2]=head2[v];head2[v]=t2;to2[t2]=u;
}
bitset<N> vis;
void dfs(int k,int fa){
	if(vis[k])
		return;
	P.push_back(k);
	vis[k]=1;
	for(int i=head1[k];i;i=nxt1[i])
		if(to1[i]!=fa)
			dfs(to1[i],k);
}
void dfs1(int k,int fa){
	f[k][0]=fa;
	dep[k]=dep[fa]+1;
	for(int i=0;;++i){
		if(!f[f[k][i]][i])
			break;
		f[k][i+1]=f[f[k][i]][i];
	}
	if(!nxt1[head1[k]])
		P.push_back(k);
	for(int i=head1[k];i;i=nxt1[i])
		if(to1[i]!=fa)
			dfs1(to1[i],k);
}
int lca(int x,int y){
	if(dep[x]<dep[y])
		swap(x,y);
	for(int i=21;i>=0;--i)
		if(dep[f[x][i]]>=dep[y])
			x=f[x][i];
	if(x==y)
		return x;
	for(int i=21;i>=0;--i)
		if(f[x][i]!=f[y][i]){
			x=f[x][i];
			y=f[y][i];
		}
	return f[x][0];
}
bool pppp;
signed main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
//	cout<<(&ppp-&pppp)/1024.0/1024.0;
	n=read();m=read();
	if(n<=5&&m<=5){
		for(int i=1;i<n;++i)
			add1(read(),read());
		for(int i=1;i<=m;++i)
			add2(read(),read());
		for(int i=1;i<n;++i){
			int p=to1[(i<<1)-1],q=to1[i<<1];
			res1=0;vis=0;
			dfs(p,q);
			while(!P.empty()){
				int x=P.back();
				P.pop_back();
				for(int j=head2[x];j;j=nxt2[j])
					if(!vis[to2[j]])
						++res1;
			}
			if(res1==1)
				++ans;
			if(!res1)
				ans+=m;
		}
	}
	else{
		for(int i=1;i<n;++i)
			add1(read(),read());
		dfs1(1,0);
		for(int i=1;i<=m;++i){
			a=read();b=read();
			++sum[b];
			++sum[a];
			sum[lca(a,b)]-=2;
		}
		int sz=P.size();
		for(int i=0;i<sz;++i){
			a=P[i];
			while(f[a][0]){
				sum[f[a][0]]+=sum[a];
				a=f[a][0];
			}
		}
		for(int i=0;i<sz;++i){
			a=P[i];
			while(f[a][0]&&!vis[a]){
				vis[a]=1;
				if(sum[a]==1)
					++ans;
				if(!sum[a])
					ans+=m;
				a=f[a][0];
			}
		}
	}
	write(ans);
	return 0;
}
