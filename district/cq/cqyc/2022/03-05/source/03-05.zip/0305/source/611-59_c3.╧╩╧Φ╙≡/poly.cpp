#include<bits/stdc++.h>
using namespace std;
int n,a;
bool out;
int main()
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=n;~i;i--)
	{
		scanf("%d",&a);
		if(!a) continue;
		out=true;
		if(a>0&&i!=n) putchar('+');
		printf("%d",a);
		if(i>1) printf("x^%d",i);
		else if(i) putchar('x');
	}
	if(!out) putchar('0');
	fclose(stdin);fclose(stdout);
	return 0;
}
