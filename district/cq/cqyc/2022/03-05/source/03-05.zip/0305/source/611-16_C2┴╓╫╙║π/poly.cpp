#include<bits/stdc++.h>
using namespace std;
int n,a,k;
bool f1;
int main()
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n),k=n;
	for(int i=0; i<=n; ++i,--k)
	{
		scanf("%d",&a);
		if(a>=1 && f1) printf("+%d",a),f1=1;
		if(a>1 && !f1) printf("%d",a),f1=1;
		if(a<0) printf("%d",a),f1=1;
		if(a!=0)
		{
			if(k==1) printf("x");
			if(k>1) printf("x^%d",k);
		}
	}
	return 0;
}
