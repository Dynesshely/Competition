#include<bits/stdc++.h>
#define LL long long
using namespace std;
int N,M,x,y,sum,Ans=-1;
bool fri[1005][1005],f[1005],fl1,fl2;
int main(){
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;++i){
		fri[i][i]=1;
	}
	for(int i=1;i<=M;++i){
		scanf("%d%d",&x,&y);
		fri[x][y]=1,fri[y][x]=1;
	}
	for(int i=1;i<=N;++i){
		if(fri[1][i]==0)continue;
		f[i]=1,fl1=0,fl2=0,sum++;
		for(int j=1;j<=N;++j){
			if(f[j]==1){
				for(int k=1;k<=N;++k){
					if(f[k]==1){
						if(fri[j][k]==0){
							fl1=1;
							break;
						}
					}
				}
				if(fl1==1)break;
			}
		}
		if(fl1==1)continue;
		for(int j=1;j<=N;++j){
			if(f[j]==0){
				for(int k=1;k<=N;++k){
					if(f[k]==0){
						if(fri[j][k]==0){
							fl2=1;
							break;
						}
					}
				}
				if(fl2==1)break;
			}
		}
		if(fl2==1)continue;
		Ans=max(Ans,min(sum,N-sum));
	} 
	printf("%d",Ans);
} 
/*
8 12
1 2
1 3
1 4
2 3
2 4
3 4
3 6
4 5
5 6
5 7
6 7
7 8
*/

