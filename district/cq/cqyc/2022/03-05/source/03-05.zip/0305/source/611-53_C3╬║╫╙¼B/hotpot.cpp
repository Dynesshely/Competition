#include<bits/stdc++.h>
using namespace std;
const int mx=200005;
bool vis[mx];
vector<int> e[100005];
int n,m,u,v,cnt,fa[mx];
int ans,head[mx],to[mx],nxt[mx];
void add(int u,int v)
{
	nxt[++cnt]=head[u];
	to[cnt]=v;
	head[u]=cnt;
}
void dfs(int x,int f)
{
	for(int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		if(y==f) continue;
		fa[y]=x;dfs(y,x);
	}
}
void dfs2(int x,int f)
{
	vis[x]=1;
	for(int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		if(y==f) continue;
		dfs2(y,x);
	}
}
void sol(int x)
{
	int cnt=0;
	for(int i=1;i<=n;i++) vis[i]=0;
	dfs2(x,fa[x]);//cout<<"vis:";
//	for(int i=1;i<=n;i++)
//	cout<<vis[i]<<" ";cout<<endl;
	for(int i=1;i<=n;i++)
	if(vis[i]==1)
	{
		for(int j=0;j<e[i].size();j++)
		if(vis[e[i][j]]==0) cnt++;
	}
	if(cnt==0) ans+=m;
	else if(cnt==1) ans+=1;
	//printf("ans:%d\n",ans);
}
int main()
{
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&u,&v);
		add(u,v);add(v,u);
	}
	dfs(1,0);
	//cout<<"qwq";
	//for(int i=1;i<=n;i++) cout<<fa[i]<<" ";
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	for(int i=2;i<=n;i++) sol(i);
	printf("%d",ans);
}
/*
14 5
1 3
1 9
1 10
3 2
3 8
9 4
9 11
10 12
10 13
8 5
8 6
4 7
13 14
2 8
8 9
9 10
9 12
11 7
*/
