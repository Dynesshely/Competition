#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=1005;
int n,m,ans,t[N],f[N][N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	if(x<0) {pc('-'),__(-x);return ;}
	if(x>9) __(x/10);
	pc(x%10+48);
}
void Check() {
	int s0=0,s1=0;
	for(int i=1;i<=n;++i) {
		if(t[i]) s1++;
		else s0++;
		for(int j=i+1;j<=n;++j) 
			if(t[i]==t[j]&&(!f[i][j])) return ;
	}
	ans=max(ans,min(s0,s1));
}
void DFS(int x) {
	if(x>n) {Check();return ;}
	t[x]=1,DFS(x+1);
	t[x]=0,DFS(x+1);
}
int main() {
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	n=_(),m=_();
	for(int i=1;i<=m;++i) {
		int a=_(),b=_();
		f[a][b]=f[b][a]=1;
	}
	DFS(1);__(ans);
	return 0;
}
//10:20~10:35
