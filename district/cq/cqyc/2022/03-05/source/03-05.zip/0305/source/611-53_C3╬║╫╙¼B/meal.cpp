#include<bits/stdc++.h>
using namespace std;
const int mx=100005;
long long n,a[mx],w[mx],p[mx],v[mx];
long long tree[mx],ans;
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%lld",&n);
	memset(w,0x3f,sizeof w);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		p[i]=p[i-1],w[i]=w[i-1];
		if(a[i]<w[i-1]) p[i]=i,w[i]=a[i];
		v[i]=max(v[i-1],a[i]);
	}
//	cout<<"p:";
//	for(int i=1;i<=n;i++) cout<<p[i]<<" ";cout<<endl;
	for(int i=n;i>=1;i--)
	{
		//cout<<i;
//		long long val=ask(i);
//		upd(1,w[i]-val);upd(i+1,-w[i]+val);i=p[i];
		for(int j=1;j<=i;j++)
		a[j]-=w[i],w[j]-=w[i];
		i=p[i];
	}
	//for(int i=1;i<=10;i++) cout<<tree[i]<<" ";
	for(int i=1;i<=n;i++)
	ans=max(ans,a[i]);
	printf("%lld",ans);
}
