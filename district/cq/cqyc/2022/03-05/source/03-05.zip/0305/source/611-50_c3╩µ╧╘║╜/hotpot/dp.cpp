#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
signed main() {
	for(int i=1;i<=1000;++i) {
		system("random.exe");
		system("hotpot.exe");
		system("hotpot2.exe");
		bool t=system("fc hotpot.out hotpot2.out");
		if(t) return 0; 
	}

	return 0;
}

