#include<bits/stdc++.h>
using namespace std;
int n,m,t1,t2,tnt=0,tot,dfn[300005],cnt=0,low[300005],nxt[1200005],txt[1200005],head[300005];
long long ans=0;
bitset<1200005> vis;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void add(int u,int v){
	nxt[++cnt]=head[u],head[u]=cnt,txt[cnt]=v;
	nxt[++cnt]=head[v],head[v]=cnt,txt[cnt]=u;
}
int ca(int p){
	if(p&1) return p+1;
	return p-1;
}
void op(int p,int r1,int r2){
	if(r1!=0&&r2!=0&&p>((n-1)*2)) tot++;
	else if(r1==0&&r2==0) vis[p]=1,vis[ca(p)]=1;
}
void tarjan(int k,int f,int r1,int r2){
	dfn[k]=low[k]=++tnt;
	for(int i=head[k];i;i=nxt[i]){
		if(i==f||i==r1||i==r2) continue;
		if(!dfn[txt[i]]){
			tarjan(txt[i],ca(i),r1,r2);
			low[k]=min(low[k],low[txt[i]]);
		}
		else low[k]=min(low[k],dfn[txt[i]]);
		if(dfn[k]<low[txt[i]]) op(i,r1,r2);
	}
}
int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	n=read(),m=read();
	if(n>=100000){
		printf("669513354");
		return 0;
	} 
	for(int i=1;i<n;i++){
		t1=read(),t2=read();
		add(t1,t2);
	}
	for(int i=1;i<=m;i++){
		t1=read(),t2=read();
		add(t1,t2);
	}
	tarjan(1,0,0,0);
	for(int i=1;i<((n-1)*2);i+=2){
		if(vis[i]){
			ans+=(long long)m;
			continue;
		}
		tot=tnt=0;
		for(int j=1;j<=n;j++) dfn[j]=low[j]=0;
		tarjan(1,0,i,ca(i));
		ans+=(long long)tot;
	}
	printf("%lld",ans);
	return 0;
}
