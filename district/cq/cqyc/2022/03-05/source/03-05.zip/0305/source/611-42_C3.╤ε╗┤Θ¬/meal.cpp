#include<bits/stdc++.h>
using namespace std;
long long n,a[100005],ans=0,sum=1e18;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
		if(a[i]<=sum) sum=a[i];
		else ans=max(ans,a[i]-sum);
	}
	printf("%lld",ans);
	return 0;
}
