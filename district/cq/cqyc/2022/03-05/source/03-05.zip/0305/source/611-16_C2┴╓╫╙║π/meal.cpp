#include<bits/stdc++.h>
#define mk make_pair
using namespace std;
int n,a[100005],mn=0x3f3f3f3f,ans;
priority_queue<pair<int,int> > q;
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	for(int i=1;i<=n;++i) mn=min(mn,a[i]),ans=max(ans,a[i]-mn);
	cout<<ans;
	return 0;
}
