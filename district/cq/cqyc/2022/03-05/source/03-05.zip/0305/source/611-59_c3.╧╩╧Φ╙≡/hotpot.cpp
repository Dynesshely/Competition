#include<bits/stdc++.h>
using namespace std;
const int N=1010,M=N<<2;
int n,m,w,ans;
int first[N],to[M],nxt[M],cnt;
bool biao[M],vis[N];
queue<int>q;
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
bool bfs()
{
	q.push(1);
	memset(vis,false,sizeof(vis));
	vis[1]=true;
	while(!q.empty())
	{
		int x=q.front();
		q.pop();
		vis[x]=true;
		for(int i=first[x],v;i;i=nxt[i])
		{
			if(biao[i]) continue;
			if(!vis[v=to[i]]) q.push(v),vis[v]=true;
		}
	}
	for(int i=1;i<=n;i++) if(!vis[i]) return true;
	return false;
}
int main()
{
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,u,v;i<n+m;i++)
	{
		scanf("%d%d",&u,&v);
		inc(u,v),inc(v,u);
	}
	w=n-1<<1;
	for(int i=1;i<=w;i+=2)
	{
		biao[i]=biao[i+1]=true;
		for(int j=w+1;j<=cnt;j+=2)
		{
			biao[j]=biao[j+1]=true;
			ans+=bfs();
			biao[j]=biao[j+1]=false;
		}
		biao[i]=biao[i+1]=false;
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
