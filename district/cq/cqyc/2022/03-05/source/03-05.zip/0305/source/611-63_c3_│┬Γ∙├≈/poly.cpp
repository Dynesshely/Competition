#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>=10) out(x/10);
	putchar('0'+x%10); 
}
int n,a[100010];
signed main() 
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	n=read();
	for(int i=1;i<=n+1;++i)
	{
		a[i]=read();
	}
	bool fir=0;
	for(int i=1;i<=n+1;++i)
	{
		if(a[i]!=0)
		{
			if(fir==1&&a[i]>0) putchar('+');
			fir=1;
			if(a[i]<0) putchar('-');
			a[i]=abs(a[i]);
			if(a[i]!=1||i==n+1) cout<<a[i];
			if(n-i+1==1) putchar('x');
			if(n-i+1>1)cout<<"x^"<<n-i+1;
		}
	}
	return 0;
}
