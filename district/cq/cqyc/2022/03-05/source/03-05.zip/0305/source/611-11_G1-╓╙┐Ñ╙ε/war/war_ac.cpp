// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
const ll N=3e4;
ll dp[80][80],s[N+10],s1[N+10],dp2[N+10],l[N+10],nl[N+10];
ll nxt[N+10],nxt1[N+10];
ll n;
//
inline bool check(ll l1,ll r1,ll l2,ll r2){
	ll gl=min(r1-l1,r2-l2);
	FOR(i,0,gl){
		ll to1=l1+i,to2=l2+i;
		if(s[to1]<s[to2]) return 1;
		if(s[to1]>s[to2]) return 0;
	}
	if(r1-l1<r2-l2) return 1;
	return 0;
}
inline ll check1(ll l1,ll r1,ll l2,ll r2){
	ll gl=min(r1-l1,r2-l2);
	FOR(i,0,gl){
		ll to1=l1+i,to2=l2+i;
		if(s[to1]<s[to2]) return 1;
		if(s[to1]>s[to2]) return 0;
	}
	if(r1-l1<r2-l2) return 1;
	if(r1-l1>r2-l2) return 0;
	return 2;
}
inline void kmp(ll z,ll l,ll r){
//	printf("KMP:%lld %lld %lld\n",z,l,r);
	ll n1=r-l+1;
//	printf("s1\n");
	FOR(i,1,n1){
		s1[i]=s[l+i-1];
//		printf("%lld",s1[i]);
	}
//	printf("\nnxt1\n");
	nxt1[0]=-1;
	nxt1[1]=0;
	FOR(i,2,n1){
		ll k=i-1;
		while(nxt1[k]!=-1&&s1[i]!=s1[nxt1[k]+1]) k=nxt1[k];
		nxt1[i]=nxt1[k]+1;
	}
//	FOR(i,1,n1) printf("%lld ",nxt1[i]);
//	printf("\nnxt\n");
	nxt[r]=0;
	FOR(i,r+1,n){
		ll k=nxt[i-1];
		if(k==n1) k=nxt1[k];
		while(k!=-1&&s[i]!=s1[k+1]) k=nxt1[k];
		nxt[i]=k+1;
	}
//	FOR(i,r+1,n) printf("%lld ",nxt[i]);
//	printf("\n");
	ROF(i,n-1,r+1){
		if(nxt[i]==n1){
			FOR(j,i+1,n){
				bool b=check1(i-nxt[i]+1,j,nl[j],j);
//				printf("%lld %lld %lld %lld\n",i-nxt[i]+1,j,nl[j],j);
//				if(z+1<dp2[j]||!b) break;
				if((z+1>dp2[j]&&b)||(z+1==dp2[j]&&b==1)){
					nl[j]=i-nxt[i]+1;
					dp2[j]=z+1;
				}
			}
		} 
		else{
			if(s[i+1]<s1[nxt[i]+1]) continue;
			FOR(j,i+1,n){
				bool b=check1(i-nxt[i]+1,j,nl[j],j);
//				printf("%lld %lld %lld %lld\n",i-nxt[i]+1,j,nl[j],j);
//				if(z+1<dp2[j]||!b) break;
				if((z+1>dp2[j]&&b)||(z+1==dp2[j]&&b==1)){
					nl[j]=i-nxt[i]+1;
					dp2[j]=z+1;
				}
			}
		}
	}
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("war.in","r",stdin);
	freopen("war_ac.out","w",stdout);
	n=gt();
	string ss; cin>>ss;
	bool lb=1;
	FOR(i,1,n){
		s[i]=ss[i-1]-'0';
		if(s[i]!=0) lb=0;
	} 
//	if(lb){
//		ll ans=1,to=2,tot=2;
//		while(n>tot){
//			tot+=(++to);
//			++ans;
//		}
//		printf("%lld",ans);
//		return 0;
//	}
//	if(n<=96){
//		FOR(i,1,n) FOR(j,i,n) dp[i][j]=1;
//		FOR(i,1,n){
//			FOR(j,i,n){
//				FOR(k,j+1,n){
//					FOR(l,k,n){
//						ll l1=i,r1=j,l2=k,r2=l;
//						if(check(l1,r1,l2,r2)) dp[l2][r2]=max(dp[l2][r2],dp[l1][r1]+1);
//					}
//				}
//			}
//		}
//		ll ans=0;
//		FOR(i,1,n) ans=max(ans,dp[i][n]);
//		printf("%lld",ans);
//		return 0;
//	}
	nl[1]=l[1]=dp2[1]=1;
	FOR(i,2,n){
		dp2[i]=1;
		if(!check(l[i-1],i,i,i)) l[i]=i;
		else l[i]=l[i-1];
		nl[i]=l[i];
	}
//	FOR(i,1,n) printf("%lld ",l[i]);
//	printf("\n");
	ll ans=0;
	FOR(i,1,n){
		printf("%lld %lld %lld\n",l[i],nl[i],dp2[i]);
		kmp(1,l[i],i);
		if(dp2[i]!=1) kmp(dp2[i],nl[i],i);
		ans=max(ans,dp2[i]);
	}
	printf("%lld",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



