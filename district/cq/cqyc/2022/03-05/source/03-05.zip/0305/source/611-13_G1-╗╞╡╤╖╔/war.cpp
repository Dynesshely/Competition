#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
int n;
char a[20004];

int dp[100][100];


int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",a+1);
	
	if(n<=70){
		
		for(int l=1;l<=n;l++)
			for(int r=l;r<=n;r++)
				dp[l][r]=1;
		
		int ans=1;
		
		for(int l=1;l<=n;l++)
			for(int r=l;r<=n;r++){
				ans=max(ans,dp[l][r]);
				int len=r-l+1;
				for(int i=r+1;i<=n;i++){
					int k=0;
					if(i<=n-len+1){
						for(k;k<len;k++) if(a[l+k]!=a[i+k]) break;
						if(k==len||a[l+k]<a[i+k])
							for(int j=i+k;j<=n;j++){
								dp[i][j]=max(dp[i][j],dp[l][r]+1);}
					}
					else{
						for(k;i+k<=n;k++) if(a[l+k]!=a[i+k]) break;
						if(i+k<=n&&a[l+k]<a[i+k])
							for(int j=i+k;j<=n;j++)
								dp[i][j]=max(dp[i][j],dp[l][r]+1);
					}		
				}
			}
		
		printf("%d",ans);
		return 0;		 
	}
	
	bool kk=0;
	for(int i=1;i<=n;i++) if(a[i]!='0') {kk=1;break;}
	if(!kk){
		int pos=sqrt(n*2);
		while((pos+1)*pos<=2*n) pos++;
		pos--;
		printf("%d",pos);
		return 0;
	}
	
	
	return 0;
}

