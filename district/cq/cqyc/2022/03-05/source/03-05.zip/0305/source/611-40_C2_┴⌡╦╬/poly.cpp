#include <bits/stdc++.h>

using namespace std;
int n,a[10003];
string ans;
string ts(int q){//to string
	string ret="";
	while(q){
		ret=(char)(q%10+48)+ret;
		q/=10;
	}
	return ret;
}
void mid(int e){
	if(a[e]==0) return;
	if(a[e]>0){
		if(e!=n) ans+="+";
	}
	if(a[e]<0) ans+="-",a[e]=-a[e];
	if(a[e]!=1) ans+=ts(a[e]);
	ans+="x^";ans+=ts(e);return;
}
void one(){
	if(a[1]==0) return;
	if(a[1]>0) ans+="+";
	if(a[1]<0) ans+="-",a[1]=-a[1];
	if(a[1]!=1) ans+=ts(a[1]);
	ans+="x";return;
}
void zero(){
	if(a[0]==0) return;
	if(a[0]>0) ans+="+",ans+=ts(a[0]);
	else ans+="-",ans+=ts(-a[0]);
	return;
}
void only(){
	if(a[1]<0) ans+="-",a[1]=-a[1];
	if(a[1]!=1) ans+=ts(a[1]);
	ans+="x";zero();return;
}
int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=n;i>=0;i--) scanf("%d",&a[i]);
	if(n==1) only();
	else{
		for(int i=n;i>1;i--) mid(i);
		one();zero();
	}
	cout << ans;
	return 0;
}
