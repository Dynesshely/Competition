#include<bits/stdc++.h>
#define mk make_pair
#define f first
#define s second
using namespace std;
int n,m,a,b,x[300005],cnt,ans,c[300005],fat[300005];
vector<int> v[300005],vv[300005];
queue<pair<int,int> > q;
void hanshu(int w,int fa)
{
	x[w]=++cnt,fat[cnt]=fa;
	for(int i=0; i<v[w].size(); ++i) if(v[w][i]!=fa) hanshu(v[w][i],x[w]),v[w][i]=x[v[w][i]];
	if(v[w].size()==1) q.push(mk(x[w],x[w]));
}
void hs(int w,int mx)
{
	if(w==1) return;
	int sum=0;
	for(int j=w; j<=mx; ++j)
		for(int i=0; i<vv[j].size(); ++i)
		{
			if(vv[j][i]<w || vv[j][i]>mx) ++sum;
			if(sum>1) break;
		}
	if(sum==1) ++c[w];
	if(sum==0) c[w]+=m;
	int l=v[fat[w]].size()-1;
	c[fat[w]]+=c[w];
	if(v[fat[w]][l]==w) hs(fat[w],mx);
}
int main()
{
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	cin>>n>>m;
	for(int i=1; i<n; ++i) scanf("%d%d",&a,&b),v[a].push_back(b),v[b].push_back(a);
	hanshu(1,0);
	for(int i=1; i<=m; ++i) scanf("%d%d",&a,&b),vv[x[a]].push_back(x[b]),vv[x[b]].push_back(x[a]);
	while(q.size())
	{
		int w=q.front().f,mx=q.front().s;
		q.pop(),hs(w,mx);
	}
	printf("%d",c[1]);
	return 0;
}
