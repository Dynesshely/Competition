#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,a[200000];
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	ll ans=0,mi=1e18;
	for(int i=1;i<=n;i++) {
		ans=max(ans,a[i]-mi);
		mi=min(mi,a[i]);
	}
	printf("%lld\n",ans);
	return 0;
}
