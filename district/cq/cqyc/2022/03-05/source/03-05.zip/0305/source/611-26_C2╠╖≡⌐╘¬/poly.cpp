#include<bits/stdc++.h>
using namespace std;
int n,k,a;
int main() {
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	cin>>n;
	k=n;
	for(int i=1; i<=n+1; i++) {
		scanf("%d",&a);
		if(a!=0) {
			if(a<0||i==1) printf("%d",a);
			else printf("+"),printf("%d",a);
			if(i!=n+1) {
				printf("x");
				if(k!=1) {
					printf("^");
					printf("%d",k);
				}
			}
		}
		k--;
	}
}
