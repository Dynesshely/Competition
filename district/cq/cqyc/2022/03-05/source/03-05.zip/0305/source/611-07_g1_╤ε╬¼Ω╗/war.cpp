#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
const van MaxN=2e4+10;
char b[MaxN];
van n,ans; string a;
string st[MaxN];
//vector<pair<string,van> > g[MaxN];
//van dp[MaxN];
void DFS(van now,string lst,van d=0) {
	st[d]=lst;
	for (int i=now;i<=n;i++) {
		for (int j=i;j<=n;j++) {
			if (a.substr(i,j-i+1)>lst) DFS(j+1,a.substr(i,j-i+1),d+1);
		}
	} ans=max(ans,d);
//	if (d==9){for (int i=1;i<=d;i++) cout<<st[i]<<" ";cout<<endl;}
}
//void DFS1(van now,string lst,van d=0) {
//	ans=max(ans,d);
//	for (int i=0;i<g[now].size();i++) {
//		if (g[now][i].first>lst) {
//			DFS1(g[now][i].second,g[now][i].first,d+1);
//		}
//	}
//}
int main() {
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	read(n); a+="2"; for (int i=1;i<=n;i++) cin>>b[i],a+=b[i]; // cout<<a<<endl;
	for (int i=0;i<a.size();i++) if (a[i]!='0') goto Subtask1;
	for (int i=1;i<=n;i++) {
		if (i*(i+1)/2>n) {
			print(i-1);
			return 0;
		}
	} return 0;
	Subtask1:
//	if (n<=15) {
		DFS(1,"");
		print(ans);
//	} else if (n<=70) {
//		vector<pair<string,int> > s;
//		for (int i=1;i<=n;i++) {
//			for (int j=i;j<=n;j++) {
//				s.push_back(make_pair(a.substr(i,j-i+1),j));
//				g[0].push_back(make_pair(a.substr(i,j-i+1),j));
//			}
//		} for (int i=0;i<s.size();i++) {
//			for (int j=0;j<s.size();j++) {
//				if (s[i].first<s[j].first&&s[i].second<=s[j].second-s[j].first.size()) {
//					g[s[i].second].push_back(make_pair(s[j].first,s[j].second));
////					cout<<s[i].second<<" "<<s[j].second<<endl;
//				}
//			}
//		} DFS1(0,"");
//		print(ans);
//		} for (int i=1;i<=n;i++) {
//			dp[i]=max((van)1,dp[i]);
//			for (int j=0;j<g[i].size();j++)
//				dp[g[i][j]]=max(dp[i]+1,dp[g[i][j]]);
//		} van ans=0; for (int i=1;i<=n;i++) {
//			ans=max(ans,dp[i]);
//		} print(ans);
//	}
	return 0;
}
