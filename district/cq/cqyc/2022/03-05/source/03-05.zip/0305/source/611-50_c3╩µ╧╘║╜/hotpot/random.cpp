#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read(int x) {
	return rand()*rand()%x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
int n=150,m=70;
signed main() {
	freopen("hotpot.in","w",stdout);
	srand(time(0));
	cout<<n<<" "<<m<<'\n';
	for(int i=2;i<=n;++i) cout<<i<<" "<<read(i-1)+1<<'\n'; 
	for(int i=1;i<=m;++i) {
		int x=read(n)+1,y=read(n)+1;
		while(y==x) y=read(n)+1;
		cout<<x<<" "<<y<<'\n';
	}
	return 0;
}

