#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,p[20],q[20];
int cz,mn=1e9,ans=-1,v[20][20];
int main()
{
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<m;i++)
	{
		scanf("%d%d",&a,&b);
		a-=1,b-=1,v[i][i]=1;
		v[a][b]=1,v[b][a]=1;
	}
	int mx=(1<<n)-1;
	for(int i=1;i<mx;i++)
	{
		//cout<<"i:"<<i;
		int cnt1=0,cnt2=0,flag=0;
		for(int j=0;j<n;j++)
		{
			if((i>>j)&1) p[++cnt1]=j;
			else q[++cnt2]=j;
		}
		//printf(" cnt1:%d cnt2:%d\n",cnt1,cnt2);
		for(int x=1;x<=cnt1;x++)
		for(int y=1;y<=cnt1;y++)
		if(v[p[x]][p[y]]!=1) {flag=1;break;}
		
		for(int x=1;x<=cnt2;x++)
		for(int y=1;y<=cnt2;y++)
		if(v[q[x]][q[y]]!=1) {flag=1;break;}
		if(flag==1) continue;
		int cz=abs(cnt1-cnt2);
		if(cz<mn) ans=min(cnt1,cnt2),mn=cz;
	}
	printf("%d",ans);
}
