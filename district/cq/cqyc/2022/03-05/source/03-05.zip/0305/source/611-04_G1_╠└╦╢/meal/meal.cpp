#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
int n;
int a[100005];
bool check(int mid){//mid��ʾ������ʣ���ٸ� 
	int sum=a[n]-mid;//��n����Ҫ���Զ��ٴ�
	//sumС��0û������ 
	for(register int i=n-1;i>=1;i--){
		if(a[i]<sum) return false;
		sum=max(sum,a[i]-mid);
	}
	return true;
}
signed main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();
	int l=0,r=0,mid,ans=0;
	for(register int i=1;i<=n;i++){
		a[i]=read(); r=max(r,a[i]); 
	}
	while(l<=r){
		mid=(l+r)>>1;
		if(check(mid)) r=mid-1,ans=mid;
		else l=mid+1;
	}
	printf("%lld",ans);
	return 0;
}
