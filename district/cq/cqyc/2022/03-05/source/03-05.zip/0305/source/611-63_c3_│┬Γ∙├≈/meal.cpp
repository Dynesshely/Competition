#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>=10) out(x/10);
	putchar('0'+x%10); 
}
int n,a[100010];
struct node
{
	int x,id;
	bool operator < (const node t) const
	{
		if(x==t.x) return id>t.id;
		return x<t.x;
	}
	void init(int v,int p)
	{
		x=v,id=p;
	}
	void debug()
	{
		cerr<<x<<" "<<id<<"dde\n";
	}
}b[100010];
int tot,sum[100010];
signed main() 
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	{
		a[i]=read();
		b[i].init(a[i],i);
	}
	sort(b+1,b+n+1);
//	for(int i=1;i<=n;++i) b[i].debug();
	int r=n+1;
//	while(r!=1)
//	{
		for(int i=1;i<=n;i++)
		{
			if(b[i].x>tot&&b[i].id<r)
			{
				sum[1]+=b[i].x;
				tot+=b[i].x;
				sum[r]-=b[i].x;
				r=b[i].id;
				
			}
			else if(b[i].x<=tot)
			{
				r=b[i].id;
			}
		}
//	}
	int tmp=0,ans=0;
	for(int i=1;i<=n;i++)
	{
		tmp+=sum[i];
		a[i]-=tmp;
		ans=max(ans,a[i]);
	}
//	for(int i=1;i<=n;i++)
//	{
//		cerr<<a[i]<<" "; 
//	}
	cout<<ans;
	return 0;
}
