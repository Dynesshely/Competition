#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=1005;
int n,m,ans,vis[N];
int ct,nt[N<<2],to[N<<2],fg[N<<2],hd[N];
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	if(x<0) {pc('-'),__(-x);return ;}
	if(x>9) __(x/10);
	pc(x%10+48);
}
inline Merge(int x,int y) {
	nt[++ct]=hd[x],to[ct]=y,fg[ct]=1,hd[x]=ct;
	nt[++ct]=hd[y],to[ct]=x,fg[ct]=1,hd[y]=ct;
}
int DFS(int x,int tf) {
	vis[x]=1;
	if(x==tf) return 1;
	int res=0;
	for(int v,i=hd[x];i;i=nt[i]) {
		if(!vis[(v=to[i])]&&fg[i]) {
			res|=DFS(v,tf);
		}
	}
	return res;
}
int main() {
	//�������N��������������û�и���һ�����ַ�
	//�����õ�30ptsҲ������ 
	//��˵������������˸�û��һ�������� 
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	n=_(),m=_();
	for(int i=1;i<n;++i) Merge(_(),_());
	for(int i=1;i<=m;++i) Merge(_(),_());
	for(int i=1;i<n;++i) {
		for(int j=n;j<n+m;++j) {
//			printf("<Big:%d Small:%d> ",i,j-n+1);
			int res=0;
			fg[2*i]=fg[2*i-1]=0;
			fg[2*j]=fg[2*j-1]=0;
			int a=to[2*i],b=to[2*i-1],c=to[2*j],d=to[2*j-1];
			memset(vis,0,sizeof(vis));
			res|=DFS(a,b);
			memset(vis,0,sizeof(vis));
			res|=DFS(c,d);
//			printf("res:%d\n",res);
			ans+=res;
			fg[2*i]=fg[2*i-1]=1;
			fg[2*j]=fg[2*j-1]=1;
		}
	}
	__((n-1)*m-ans);
	return 0;
	
} 
//8:55~10:00
