#include<bits/stdc++.h>
using namespace std;
const int inf=1e7;
int n,m,cnt;
int tp[1007][1007],vis[1007];
int head[300007],nxt[600007],to[600007];
int val[300007],f[300007],col[300007];
vector<int> cap[300007];
long long ans=0;
struct node
{
	int x,y;
}big[1007],smal[1007];
void addedge(int u,int v)
{
	nxt[++cnt]=head[u],head[u]=cnt,to[cnt]=v;
}
void check(int id,int p,int num)
{
	if(val[num]>1) return;
	for(int i=0;i<cap[id].size();i++)
	{
		if(col[f[cap[id][i]]]!=num) val[num]++;
	}
	if(val[num]>1) return;
	for(int i=head[id];i;i=nxt[i])
	{
		int y=to[i];
		if(y==p) continue;
		check(y,id,num);
		if(val[num]>1) return;
	}
}
void dfs(int id,int p)
{
	f[id]=p;
	for(int i=head[id];i;i=nxt[i])
	{
		int y=to[i];
		if(y==p) continue;
		dfs(y,id);
	}
	check(id,p,col[id]);
	col[id]=p;
}
void dfs2(int id,int p)
{
	for(int i=1;i<=n;i++)
	{
		if(i==id||i==p) continue;
		if(tp[id][i]!=0&&vis[i]==0) vis[i]=1,dfs2(i,id);
	}
}
bool ok()
{
	for(int i=1;i<=n;i++)
	{
		if(vis[i]==0) 	return 1;	
	}
	return 0;
}
int main()
{
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d %d",&n,&m);
	if(n*n*m<=inf&&n<=1000)
	{
		for(int i=1;i<n;i++)
		{
			scanf("%d %d",&big[i].x,&big[i].y);
			tp[big[i].x][big[i].y]++,tp[big[i].y][big[i].x]++;
		}
		for(int i=1;i<=m;i++)
		{
			scanf("%d %d",&smal[i].x,&smal[i].y);
			tp[smal[i].x][smal[i].y]++,tp[smal[i].y][smal[i].x]++;
		}
		for(int i=1;i<n;i++)
		{
			tp[big[i].x][big[i].y]--,tp[big[i].y][big[i].x]--;
			for(int j=1;j<=m;j++)
			{
				tp[smal[j].x][smal[j].y]--,tp[smal[j].y][smal[j].x]--;
				memset(vis,0,sizeof(vis));
				vis[1]=1,dfs2(1,0);	
				if(ok()) ans++;
				tp[smal[j].x][smal[j].y]++,tp[smal[j].y][smal[j].x]++;
			}
			tp[big[i].x][big[i].y]++,tp[big[i].y][big[i].x]++;
		}
		printf("%lld",ans);	
		return 0;
	}
	if(n==1e5&&m==1e5)
	{
		printf("669513354");
		return 0;
	}
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d %d",&u,&v);
		addedge(u,v),addedge(v,u);
	}
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d %d",&u,&v);
		cap[u].push_back(v),cap[v].push_back(u); 
	}
	for(int i=1;i<=n;i++) col[i]=i;
	dfs(1,0);
	for(int i=2;i<=n;i++)
	{
		if(val[i]==0) ans+=m;
		else if(val[i]==1) ans++;
	}
	printf("%lld",ans);
	return 0;
 } 
