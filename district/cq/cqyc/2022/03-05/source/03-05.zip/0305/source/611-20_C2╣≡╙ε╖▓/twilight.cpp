#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	printf("-1");
	return 0;
}
