#include<bits/stdc++.h>
using namespace std;
int n,fa[100010];
int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<=n;i++)scanf("%d",&fa[i]);
	for(int i=0;i<=n;i++){
		if(fa[i]==0)continue ;
		if(n-i>1){
			if(fa[i]==1){
			if(i==0)printf("x^%d",n-i);
			else printf("+x^%d",n-i);
		}
		    else if(fa[i]==-1){
			printf("-x^%d",n-i);
		}
			else if(fa[i]>0){
			if(i==0)printf("%dx^%d",fa[i],n-i);
			else printf("+%dx^%d",fa[i],n-i);
		}
			else if(fa[i]<0){
				printf("%dx^%d",fa[i],n-i);
			}
		}
		if(n-i==1){
			if(fa[i]==1)printf("+x",n);
		    else if(fa[i]==-1)printf("-x",n);
		    else if(fa[i]>0)printf("+%dx",fa[i]);
			else if(fa[i]<0)printf("%dx",fa[i]);
		}
		if(n-i==0){
			if(fa[i]>0)printf("+%d",fa[i]);
			else printf("%d",fa[i]);
		}
	}
	return 0;
}
