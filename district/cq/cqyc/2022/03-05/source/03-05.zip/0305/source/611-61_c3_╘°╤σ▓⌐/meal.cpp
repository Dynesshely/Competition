#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=100005;
int n,a[N],b[N],ans,mi[N];
signed main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();
	mi[0]=1e9;
	for(int i=1;i<=n;++i) a[i]=read(),mi[i]=min(mi[i-1],a[i]);
	int x=0,y=n;
	for(int i=n;i>=1;--i)
		if(a[i]==mi[i]) {
			b[1]-=a[i]-x,b[y+1]+=a[i]-x;
			x=a[i],y=i-1;
		}
	for(int i=1;i<=n;++i) b[i]+=b[i-1],ans=max(ans,b[i]+a[i]);
	cout<<ans;
	return 0;
}
/*
3
2 3 3

1
*/
