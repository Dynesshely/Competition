#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
const van MaxN=1e3+10;
van n,m;
vector<van> g[MaxN]; van dep[MaxN];
bool used[MaxN][MaxN],used1[MaxN];
void DFS(van now,van d=0) {
	used1[now]=1; dep[now]=d;
	for (int i=0;i<g[now].size();i++) {
		if (g[now][i]==now) continue;
		if (used1[g[now][i]]) {
			if ((d-dep[g[now][i]])%2==0) {
				print(-1);
				exit(0);
			}
		} else DFS(g[now][i],d+1);
	}
}
van a[MaxN],b[MaxN],derta[MaxN],ans;
void DFS2(van now,van to,van d=0) {
	used1[now]=1; dep[now]=d;
	if (d%2==0) a[to]++; else b[to]++;
	for (int i=0;i<g[now].size();i++) {
		if (!used1[g[now][i]]) DFS2(g[now][i],to,d+1);
	}
}
int main() {
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	read(n),read(m);
	for (int i=1;i<=m;i++) {
		van a,b; read(a),read(b);
		used[a][b]=used[b][a]=1;
	} for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) 
		if (!used[i][j]) g[i].push_back(j);// cout<<i<<" "<<j<<endl;
	for (int i=1;i<=n;i++) if (!used1[i]) DFS(i); 
	memset(used1,0,sizeof used1);
	for (int i=1;i<=n;i++) if (!used1[i]) DFS2(i,i);
	for (int i=1;i<=n;i++) derta[i]=abs(a[i]-b[i]);
	sort(derta+1,derta+n+1,greater<van>());
	for (int i=1;i<=n;i++) ans>0?ans-=derta[i]:ans+=derta[i];
	print((n-abs(ans))/2);
	return 0;
}

