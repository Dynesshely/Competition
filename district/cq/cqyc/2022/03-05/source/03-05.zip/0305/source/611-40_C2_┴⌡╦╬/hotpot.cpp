#include <bits/stdc++.h>
#define N 1003
using namespace std;
int n,m,f1[N],t1[N],f2[N],t2[N],ans,vis[N];
vector<int> v[N];
void build(int ni,int mi){
	for(int i=1;i<=n;i++) v[i].clear();
	for(int i=1;i<n;i++){
		if(i!=ni) v[f1[i]].push_back(t1[i]),v[t1[i]].push_back(f1[i]);
	}
	for(int i=1;i<=m;i++){
		if(i!=mi) v[f2[i]].push_back(t2[i]),v[t2[i]].push_back(t2[i]);
	}
	/*
	cout << "##" << ni << ' ' << mi << endl;
	for(int i=1;i<=n;i++){
		cout << i << ' ' << v[i].size() << endl;
		for(int j=0;j<v[i].size();j++) cout << v[i][j] << ' ';
		cout << endl;
	}
	*/
	return;
}
void dfs(int u){
	vis[u]=1;
	for(int i=0;i<v[u].size();i++){
		if(!v[u][i]) dfs(v[u][i]);
	}
}
int fail(){
	for(int i=1;i<=n;i++) vis[i]=0;
	dfs(1);
	for(int i=1;i<=n;i++) if(vis[i]==0) return 1;
	return 0;
}
int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++) scanf("%d%d",&f1[i],&t1[i]);
	for(int i=1;i<=m;i++) scanf("%d%d",&f2[i],&t2[i]);
	for(int i=1;i<n;i++)
		for(int j=1;j<=m;j++)
			build(i,j),ans+=fail();
	cout << ans;
	return 0;
}
