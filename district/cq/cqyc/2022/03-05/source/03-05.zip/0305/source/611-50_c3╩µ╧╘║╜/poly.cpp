#include<bits/stdc++.h>
using namespace std;
inline int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
int n,hed;
int a[10010];
signed main() {
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	n=read();
	for(int i=n; i>=0; --i) {
		a[i]=read();
		if(a[i]==0) continue;
		if(hed&&a[i]>0) putchar('+');
		hed=1,put(a[i]);
		if(i) putchar('x');
		if(i>1) putchar('^'),put(i);
	}
	return 0;
}

