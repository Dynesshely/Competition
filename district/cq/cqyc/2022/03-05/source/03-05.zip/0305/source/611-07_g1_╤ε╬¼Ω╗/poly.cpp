#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
const van MaxN=1e4+10;
van n;
int main() {
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	read(n); bool f=true;
	for (int i=1;i<=n+1;i++) {
		van a; read(a);
		if (a==0) continue;
		if (!f&&a>0) cout<<"+"; f=false;
		if (i==n) {
			if (abs(a)!=1) cout<<a<<"x";
			else if (a==-1) cout<<"-x";
			else cout<<"x";
		}
		else if (i==n+1) cout<<a;
		else {
			if (abs(a)!=1) cout<<a<<"x^"<<n-i+1;
			else if (a==-1) cout<<"-x^"<<n-i+1;
			else cout<<"x^"<<n-i+1;
		}
	}
	return 0;
}
