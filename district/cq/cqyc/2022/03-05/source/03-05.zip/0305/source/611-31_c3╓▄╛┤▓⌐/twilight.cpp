#include<bits/stdc++.h>
using namespace std;
int n,m,u,v,ac=0,bc=0,a[25],b[25],ans=-1,cha=100;
bitset<25> g[25];
void dfs(int p)
{
	if(p>=n+1)
	{
		for(int i=1;i<ac;++i)
		{
			for(int j=i+1;j<=ac;++j)
			{
				if(!g[a[i]][a[j]])
				{
					return ;
				}
			}
		}
		for(int i=1;i<bc;++i)
		{
			for(int j=i+1;j<=bc;++j)
			{
				if(!g[b[i]][b[j]])
				{
					return ;
				}
			}
		}
		if(abs(ac-bc)<cha) cha=abs(ac-bc),ans=min(ac,bc);
	}
	a[++ac]=p;
	dfs(p+1);
	--ac;
	b[++bc]=p;
	dfs(p+1);
	--bc;
}
int main()
{
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i)
	{
		scanf("%d%d",&u,&v);
		g[u][v]=g[v][u]=1;
	}
	dfs(1);
	printf("%d",ans);
	return 0;
}

