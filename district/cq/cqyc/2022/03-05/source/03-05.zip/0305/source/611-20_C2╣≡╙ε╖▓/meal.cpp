#include<bits/stdc++.h>
using namespace std;
#define N 100005
int n;
int ans;
int a[N];
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	int mn=1e9;
	for(int i=1;i<=n;i++)
	{
		mn=min(mn,a[i]);
		ans=max(ans,a[i]-mn);
	}
	printf("%d",ans);
	return 0;
}
