#include <bits/stdc++.h>
using namespace std;
int n, m, a[1005][1005], x, y, col[1005], sid[2]; 
int main() {
	freopen("twilight.in", "r", stdin); 
	freopen("twilight.out", "w", stdout);
	srand(time(0));
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= m; ++i)
		scanf("%d%d", &x, &y), a[x][y]=1, a[y][x]=1;
	for(int i = 1; i <= n; ++i) col[i]=rand()%2, ++sid[col[i]];
	for(int i = 1; i <= n; ++i) { 
		for(int j = 1; j <= n; ++j) cout<<a[i][j]<<" "; cout<<"\n";} 
	return 0;
}
