#include<bits/stdc++.h>
using namespace std;
int a[21487][3],b[21743][3],n,m,ans=0,sp[1000][1000],tong[21837],p=1;
void jb(int k,int fa){
	for(int i=1;i<=n;i++){
		if(sp[k][i]==1&&tong[i]==0&&i!=fa) {
			p++;
			tong[i]=1;
			jb(i,k);
		}
	}
}
int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	cin>>n>>m;
    for(int i=1;i<n;i++) cin>>a[i][1]>>a[i][2],sp[a[i][1]][a[i][2]]++,sp[a[i][2]][a[i][1]]++;
    for(int i=1;i<=m;i++) cin>>b[i][1]>>b[i][2],sp[b[i][1]][b[i][2]]++,sp[b[i][2]][b[i][1]]++;;
    for(int i=1;i<n;i++){
    	sp[a[i][1]][a[i][2]]--;
    	sp[a[i][2]][a[i][1]]--;
    	for(int y=1;y<=m;y++){
    		sp[b[y][1]][b[y][2]]--;
    		sp[b[y][2]][b[y][1]]--;
    		memset(tong,0,sizeof(tong));
    		tong[1]=1;
    		p=1;
    		jb(1,0);
    		if(p!=n) ans++;
    		sp[b[y][1]][b[y][2]]++;
    		sp[b[y][2]][b[y][1]]++;
		}
		sp[a[i][1]][a[i][2]]++;
    	sp[a[i][2]][a[i][1]]++;
	}
	printf("%d",ans);
}

