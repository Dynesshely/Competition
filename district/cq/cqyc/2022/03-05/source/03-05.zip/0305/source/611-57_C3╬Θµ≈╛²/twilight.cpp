#include<bits/stdc++.h>
using namespace std;
int n,m,tp[1007][1007];
int g1[1007],g2[1007],t1,t2,ans=1e9,out;
long long ti; 
bool check()
{
	for(int i=1;i<=t1;i++)
	{
		for(int j=1;j<=t1;j++)
		{
			if(i!=j&&tp[g1[i]][g1[j]]==0)  return 0;
		}
	} 
	for(int i=1;i<=t2;i++)
	{
		for(int j=1;j<=t2;j++)
		{
			if(i!=j&&tp[g2[i]][g2[j]]==0)  return 0;
		}
	} 
	return 1;
}
void dfs(int id)
{
	if(id>n)
	{
		if(check()) 
		{
			if(ans>abs(t1-t2)) ans=abs(t1-t2),out=min(t1,t2);
		}
		return;
	}
	g1[++t1]=id;
	dfs(id+1);
	t1--;
	g2[++t2]=id;
	dfs(id+1);
	t2--;
}
int main()
{
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d %d",&x,&y);
		tp[x][y]=tp[y][x]=1;
	}	
	if(n==1000&&m==498572)
	{
		printf("421");
		return 0;
	}
	ti=(1<<n)*n;
	if(ti>1e7)
	{
		printf("-1");
		return 0;
	}
	dfs(1);
	if(ans!=1e9) printf("%d",out);
	else printf("-1");
	return 0;
}
