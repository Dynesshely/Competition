#include<bits/stdc++.h>
using namespace std;
int n,ans,dn;
int main()
{
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%d",&n);dn=n<<1;
	for(int i=1;i<=n;i++)
		if(i*(i+1)<=dn) ans=i;
		else break;
	printf("%d",ans);
	return 0;
}

