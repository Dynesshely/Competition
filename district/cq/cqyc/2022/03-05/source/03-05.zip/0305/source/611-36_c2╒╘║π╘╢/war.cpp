#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	printf("%d",1);
	return 0;
}
