#include<bits/stdc++.h>
using namespace std;
int n,k,flag;
char s[10005];
int main()
{
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s+1);
	for(int i=1;i<=n;i++)
	if(s[i]-'0') flag=1;
	if(flag==0)
	{
		for(int i=1;i;i++)
		{
			if(n-i<0) break;
			k+=1,n-=i;
		}
		printf("%d",k);
		return 0;
	}
}
