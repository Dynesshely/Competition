#include<bits/stdc++.h>
using namespace std;
const int MAX = 1e4+10;
struct node{
	int v,x;
	char f;
}a[MAX];
int n,cnt;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	n = read();
	for(int i = 1;i<=n+1;i++)
	{
		a[++cnt].v = read(),a[cnt].x = n-i+1;
		if(a[cnt].v==0) cnt--;
		else if(a[cnt].v<0) a[cnt].f='-',a[cnt].v=-a[cnt].v;
		else a[cnt].f='+';
	} 
	for(int i = 1;i<=cnt;i++)
	{
		if(i!=1 or a[i].f!='+') putchar(a[i].f);
		if(a[i].v!=1 or a[i].x==0) printf("%d",a[i].v);
		if(a[i].x!=0) putchar('x');
		if(a[i].x>1) printf("^%d",a[i].x);
	}
	return 0; 
} 
