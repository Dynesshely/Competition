#include <bits/stdc++.h>
#define int long long
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p )
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p )
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define pb push_back
#define sz size
using namespace std ;
const int N = 3e5+5 ;
int n,m,cnt,top ;
long long ans ;
int vis[N],wh[N],dfn[N],si[N] ;
struct pa{int u,v ;};
vector<int>e[N] ;
vector<int>us[N] ;
vector<pa>line ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f = (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(long long x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
struct tree
{
	int sum,root[N] ;
	struct L
	{
		int l,r,w ;
	}tr[N*40] ;
	#define rs(x) tr[x].r
	#define ls(x) tr[x].l
 	inline int Build(int le,int ri)
	{
//		print(le),space,print(ri),enter ;
		int node = ++top ;
//		tr[node].w = 0 ;
		if(le == ri) return node ;
		int mid = le+ri>>1 ;
		ls(node) = Build(le,mid) ;
		rs(node) = Build(mid+1,ri) ;
		return node ;
	}
	inline int Insert(int node,int le,int ri,int k)
	{
//		print(939393) ;
//		print(top),space,print(node),enter ;
//		print(tr[node].w),space ;
		tr[++top] = tr[node],node = top,tr[node].w++ ;
//		space,print(top),space,print(tr[top].w),enter ;
//		print(le),space,print(ri),space,print(tr[node].w),enter ;
//		print(1),space,print(9789879),enter ;
//		print(node),space,print(ls(node)),space,print(rs(node)),enter ;
//		print(tr[ls(node)].w),space,print(tr[rs(node)].w),enter ;
		if(le == ri)
		{
//			print(le),space,print(ri),space,print(tr[node].w),space ;
			
//			print(tr[node].w),enter ;
			return node ;
		}
		int mid = le+ri>>1 ;
		if(k <= mid) ls(node) = Insert(ls(node),le,mid,k) ;
		else rs(node) = Insert(rs(node),mid+1,ri,k) ;
//		tr[node].w = tr[ls(node)].w+tr[rs(node)].w ;
		return node ;
	}
	inline void query(int node1,int node2,int le,int ri,int ll,int rr)
	{
//		print(le),space,print(ri),space,print(ll),space,print(rr),enter ;
		if(le >= ll && ri <= rr)
		{
//			print(node1),space,print(node2),space,print(tr[node1].w),space,print(tr[node2].w),enter ;
			sum += tr[node2].w-tr[node1].w ;
			return ;
		}
		int mid = le+ri>>1 ;
		if(ll <= mid) query(ls(node1),ls(node2),le,mid,ll,rr) ;
		if(mid < rr) query(rs(node1),rs(node2),mid+1,ri,ll,rr) ;
	}
	inline int Query(int node1,int node2,int le,int ri)
	{
		sum = 0 ;
		query(node1,node2,1,n,le,ri) ;
		return sum ;
	}
}T ;

inline int find(int x)
{
//	print(x),enter ;
	si[x] = vis[x] = 1,dfn[x] = ++cnt,wh[cnt] = x ;
	FOR(i,0,e[x].sz()-1,1)
	{
		int v = e[x][i] ;
		if(vis[v]) continue ;
		si[x] += find(v) ;
	}
	return si[x] ;
}
signed main()
{
	freopen("hotpot.in","r",stdin) ;
	freopen("hotpot.out","w",stdout) ;
	#define cao 0
	return cao ;
	read(n),read(m) ;
	FOR(i,2,n,1)
	{
//		print(i),space ;
		int u,v ;
		read(u),read(v) ;
		e[u].pb(v),e[v].pb(u) ;
		line.pb((pa){u,v}) ;
	 } 
	find(1) ;
	FOR(i,1,m,1)
	{
		int u,v ;
		read(u),read(v) ;
		us[u].pb(v),us[v].pb(u) ;
 	}
 	T.root[0] = T.Build(1,n) ;
	FOR(i,1,n,1)
	{
//		print(i),space ;
//		print(v),space,print(us[v].sz()),enter ;
		int v = wh[i] ;
		
		if(us[v].sz()) FOR(j,0,us[v].sz()-1,1)
		{
			if(!j) T.root[i] = T.Insert(T.root[i-1],1,n,dfn[us[v][j]]) ;
			else top = T.root[i]+1,T.Insert(T.root[i],1,n,dfn[us[v][j]]) ;
		}
		else T.root[i] = T.root[i-1] ;
	}
	FOR(i,0,line.sz()-1,1)
	{
//		print(line[i].u),space,print(line[i].v),enter ;
		if(dfn[line[i].u] > dfn[line[i].v]) swap(line[i].v,line[i].u) ;//Ĭ��u��dfnС
		int fi = dfn[line[i].v] ;
		int al = T.Query(T.root[0],T.root[n],fi,fi+si[line[i].v]-1) ;
//		print(line[i].u),space,print(line[i].v),space,print(fi),space,print(fi+si[line[i].v]-1),enter ;
		int th = T.Query(T.root[fi-1],T.root[fi+si[line[i].v]-1],fi,fi+si[line[i].v]-1) ;
		if(al-th == 1) ans++ ;
		if(al-th == 0) ans += m ; 
		print(fi),space,print(fi+si[line[i].v]-1),enter ;
	}
	print(ans) ; 
	return 0 ;
 }
//6
