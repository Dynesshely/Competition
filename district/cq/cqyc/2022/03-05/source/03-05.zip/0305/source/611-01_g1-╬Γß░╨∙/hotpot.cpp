#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=3e5+5;
struct aa{
	int a,b;
	aa(){
	}
	aa(int a1,int b1){
		a=a1;
		b=b1;
	}
}tu1[2*N],tu3[2*N],anl[N],anr[N];
int tu2[N],tu4[2*N],n,m,sz[N],dfn[N];
long long ans;
aa hb(aa a,aa b){
	return aa(min(a.a,b.a),min(max(a.a,b.a),min(a.b,b.b)));
}
void dfs(int g,int fa){
	sz[g]=1;
	anr[g]=anl[g]=aa(1e9,1e9); 
	for(int i=tu2[g];i;i=tu1[i].b){
		if(tu1[i].a==fa) continue;
		dfs(tu1[i].a,g);
		sz[g]+=sz[tu1[i].a];
		anl[g]=hb(anl[g],anl[tu1[i].a]);
		anr[g]=hb(anr[g],anr[tu1[i].a]);
	}
	for(int i=tu4[g];i;i=tu3[i].b){
		anl[g]=hb(anl[g],aa(tu3[i].a,1e9));
		anr[g]=hb(anr[g],aa(-tu3[i].a,1e9));
	}
	if(g==1) return;
	if(anl[g].b<dfn[g] || -anr[g].b>dfn[g]+sz[g]-1 || 
	(anl[g].a<dfn[g] && -anr[g].a>dfn[g]+sz[g]-1)) return;
	if(anl[g].a<dfn[g] || -anr[g].a>dfn[g]+sz[g]-1) ans++;
	else ans+=m;
}
void dfs1(int g,int fa){
	dfn[g]=++dfn[0];
	for(int i=tu2[g];i;i=tu1[i].b){
		if(tu1[i].a==fa) continue;
		dfs1(tu1[i].a,g);
	}
}
void add(aa *tu1,int *tu2,int a,int b){
	tu1[++tu2[0]]=aa(b,tu2[a]);
	tu2[a]=tu2[0];
}
int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<n;i++){
		int a,b;
		scanf("%d %d",&a,&b);
		add(tu1,tu2,a,b);
		add(tu1,tu2,b,a);
	}
	dfs1(1,0);
	for(int i=1;i<=m;i++){
		int a,b;
		scanf("%d %d",&a,&b);
		add(tu3,tu4,a,dfn[b]);
		add(tu3,tu4,b,dfn[a]);
	}
	dfs(1,0);
	printf("%lld",ans);
}
