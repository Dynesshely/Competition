#include <bits/stdc++.h>
using namespace std;
int n,a[100003],ans=1e8+5,lim;
void dfs(int k){
	if(k>lim){
		int e=0;
		for(int i=1;i<=n;i++) e=max(e,a[i]);
		ans=min(ans,e);
		return;
	}
	for(int x=1;x<=n;x++){
		if(a[x]==0) break;
		for(int i=1;i<=x;i++) a[i]--;
		dfs(k+1);
		for(int i=1;i<=x;i++) a[i]++;
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	lim=a[1];
	dfs(1);
	cout << ans;
	return 0;
}
