#include<bits/stdc++.h>
#include<windows.h>
using namespace std;

inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	for(int i = 1;i<=1000;i++)
	{
		system("random.exe");
		system("hotpot.exe");
		system("bf.exe");
		printf("%d\n",i);
		if(system("fc hotpot.out hotpot.ans"))
		{
			printf("WA\n");
			return 0;
		}
	}
	return 0; 
} 
