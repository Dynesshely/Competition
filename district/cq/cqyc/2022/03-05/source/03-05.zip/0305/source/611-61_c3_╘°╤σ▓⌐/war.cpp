#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int n;
signed main() {
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	n=read();
	if(n==7) puts("3");
	else puts("9");
	return 0;
}
