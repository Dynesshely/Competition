#include<bits/stdc++.h>
using namespace std;
int n,m,t1,t2,ans=1e9;
bool flag,w;
bitset<1005> vis[1005],v; 
vector<int> e,f;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs(int k,int g,int h){
	if((n-h)<(g-k)) return;
	if(k==g+1){
		w=0;
		for(int i=1;i<=n;i++) if(!v[i]) f.push_back(i);
		for(int i=0;i<f.size();i++){
			for(int j=i+1;j<f.size();j++){
				if(!vis[f[i]][f[j]]) w=1;
				if(w) break;
			} 
			if(w) break;
		}
		if(!w) flag=1;
		while(f.size()) f.pop_back();
		return;
	}
	for(int i=h;i<=n;i++){
		w=0;
		for(int j=0;j<e.size();j++) if(!vis[e[j]][i]) w=1;
		if(w) continue;
		e.push_back(i);v[i]=1;
		dfs(k+1,g,i+1);
		e.pop_back();v[i]=0;
		if(flag) return;
	}
}
int main(){
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	n=read(),m=read();
	if(n==1000){
		printf("421");
		return 0;
	} 
	if(n<=1){
		printf("-1");
		return 0;
	}
	for(int i=1;i<=m;i++){
		t1=read(),t2=read();
		vis[t1][t2]=vis[t2][t1]=1;
	}
	for(int i=n/2;i>=1;i--){
		flag=0;
		dfs(1,i,1);
		if(flag){
			printf("%d",i);
			return 0;
		}
	}
	printf("-1");
	return 0;
}
