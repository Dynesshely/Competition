#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL Ans;
int N,M,x,y;
int hi,hd[100005],nxt[200005],to[200005];
int rt[100005],dep[100005],siz[100005],son[100005];
int ni,top[100005],nid[100005];
int Tv[400005],Tl[400005];
void insert(int x,int y){
	hi++,nxt[hi]=hd[x],hd[x]=hi,to[hi]=y;
	hi++,nxt[hi]=hd[y],hd[y]=hi,to[hi]=x;
}
void pushup(int k){
	Tv[k]=Tv[k<<1]+Tv[k<<1|1];
}
void pushdown(int l,int mid,int r,int k){
	if(Tl[k]){
		Tv[k<<1]+=Tl[k]*(mid-l+1);
		Tv[k<<1|1]+=Tl[k]*(r-mid);
		Tl[k<<1]+=Tl[k],Tl[k<<1|1]+=Tl[k]; 
		Tl[k]=0;
	}
}
void add(int L,int R,int l,int r,int k,int c){
	if(L<=l&&r<=R){
		Tv[k]+=c*(r-l+1),Tl[k]+=c; 
		return ;
	}
	int mid=(r+l)>>1;
	pushdown(l,mid,r,k);
	if(L<=mid)add(L,R,l,mid,k<<1,c);
	if(R>mid)add(L,R,mid+1,r,k<<1|1,c);
	pushup(k);
	return ;
}
int query(int P,int l,int r,int k){
	if(l==r){
		return Tv[k];
	}
	int mid=(r+l)>>1,ret;
	pushdown(l,mid,r,k);
	if(P<=mid)ret=query(P,l,mid,k<<1);
	else ret=query(P,mid+1,r,k<<1|1);
	pushup(k);
	return ret;
}
void dfs1(int u,int fa){
	rt[u]=fa,dep[u]=dep[fa]+1,siz[u]=1;
	for(int i=hd[u];i;i=nxt[i]){
		int T=to[i];
		if(T==fa)continue;
		dfs1(T,u);
		siz[u]+=siz[T];
		if(siz[son[u]]<siz[T])son[u]=T; 
	}
}
void dfs2(int u,int utop){
	top[u]=utop,ni++,nid[u]=ni;
	if(!son[u])return ;
	dfs2(son[u],utop);
	for(int i=hd[u];i;i=nxt[i]){
		int T=to[i];
		if(T==rt[u]||T==son[u])continue;
		dfs2(T,T);
	}
}
void Add(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]])swap(x,y);
		add(nid[top[x]],nid[x],1,N,1,1);
		x=rt[top[x]];
	}
	if(dep[x]<dep[y])swap(x,y);
	add(nid[son[y]],nid[x],1,N,1,1);
	return ;
}
int main(){
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d%d",&N,&M);
	for(int i=1;i<N;++i){
		scanf("%d%d",&x,&y);
		insert(x,y);
	}
	dfs1(1,1),dfs2(1,1);
	for(int i=1;i<=M;++i){
		scanf("%d%d",&x,&y);
		Add(x,y);
	}
	for(int i=2;i<=N;++i){
		int c=query(nid[i],1,N,1);
		if(c==0)Ans+=M;
		if(c==1)Ans++; 
	}
	printf("%lld",Ans);
} 
