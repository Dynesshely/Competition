#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
const van MaxN=3e5+10;
van n,m;
vector<pair<van,van> > g[MaxN];
van cnt=0;
van used[MaxN],lst[MaxN];
van st[MaxN],k=0,inst[MaxN],ans;
van l[MaxN],r[MaxN],fa[MaxN];
van getfa(van x) {return fa[x]==x?x:fa[x]=getfa(fa[x]);}
void tarjan(van now=1,van f=0,van banned=-1) {
//	cout<<now<<" "<<f<<endl;
	st[++k]=now; inst[now]=lst[now]=k;
	for (int i=0;i<g[now].size();i++) {
		if (g[now][i].first==f||g[now][i].second==banned) continue;
		if (inst[g[now][i].first]) lst[now]=min(lst[now],inst[g[now][i].first]);
		else tarjan(g[now][i].first,now,banned),lst[now]=min(lst[now],lst[g[now][i].first]);
	} if (lst[now]==inst[now]) { cnt++;
		while (st[k]!=now) inst[st[k]]=0,k--;
		inst[st[k]]=0,k--;
	}
}
int main() {
	freopen("hotpot.in","r",stdin);
	read(n),read(m);
	for (int i=1;i<n;i++) {
		van a,b; read(a),read(b);
		g[a].push_back(make_pair(b,0));
		g[b].push_back(make_pair(a,0));
		l[i]=a,r[i]=b;
	} tarjan(); // cout<<cnt<<endl;
	for (int i=1;i<=m;i++) {
		van a,b; read(a),read(b);
		g[a].push_back(make_pair(b,i));
		g[b].push_back(make_pair(a,i)); 
		l[n+i]=a,r[n+i]=b;
	} 
//	if (n<=5) {
//		freopen("hotpot.out","w",stdout);
//		for (int i=1;i<=m;i++) {
//			for (int j=1;j<n;j++) {
//				for (int k=1;k<=n;k++) fa[k]=k;
//				for (int k=1;k<=n+m;k++) {
//					if (k!=j&&k!=i+n) fa[getfa(l[k])]=getfa(r[k]);
//				} van num=getfa(1);
//				for (int k=2;k<=n;k++) {
//					if (getfa(k)!=num) {
//					}
//					break;
//				}
//			}
//		} print(ans); return 0;
//	}
	for (int i=1;i<=m;i++) {
//		if (i%100==0) cout<<"Process: "<<i/1000.0<<"%"<<endl;
		cnt=0; tarjan(1,0,i); ans+=cnt-1;
	} freopen("hotpot.out","w",stdout);
	print(ans);
	return 0;
}

