#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 3e5+10; 
int n,m,cnt,l,r,ans;
int hed[MAX],nex[2*MAX],to[2*MAX]; 
int fa[MAX],siz[MAX],dep[MAX],son[MAX];
int top[MAX],q[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
void add(int u,int v)
{
	nex[++cnt]=hed[u],hed[u]=cnt,to[cnt]=v;
	nex[++cnt]=hed[v],hed[v]=cnt,to[cnt]=u;
}
void dfs1(int x)
{
	siz[x]=1;
	for(int i=hed[x];i;i=nex[i])	
		if(!siz[to[i]])
		{
			fa[to[i]]=x,dep[to[i]]=dep[x]+1;
			dfs1(to[i]);
			siz[x]+=siz[to[i]];
			if(siz[to[i]]>siz[son[x]]) son[x]=to[i];
		}
}
void dfs2(int x,int t)
{
	top[x]=t;
	if(son[x])
	{
		dfs2(son[x],t);
		for(int i=hed[x];i;i=nex[i]) 
			if(!top[to[i]]) dfs2(to[i],to[i]);
	}
}
int lc(int x,int y)
{
	if(dep[top[x]]<dep[top[y]]) swap(x,y);
	while(top[x]!=top[y])
	{
		x = fa[top[x]];
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
	}
	if(dep[x]<dep[y]) return x;
	return y;
}
void dfs3(int x)
{
	for(int i=hed[x];i;i=nex[i])
		if(to[i]!=fa[x]) 
		{
			dfs3(to[i]);
			q[x]+=q[to[i]];
		}
	if(q[x]==1) ans+=1;
	else if(q[x]==0 and x!=1) ans+=m;
}
signed main()
{
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	n = read(),m = read(),dep[1]=1,fa[1]=1;
	for(int i = 1;i<n;i++) add(read(),read());
	dfs1(1);
	dfs2(1,1);
	for(int i = 1;i<=m;i++)
	{
		l = read(),r = read();
		q[l]++,q[r]++,q[lc(l,r)]-=2;
	}
	dfs3(1);
	printf("%lld",ans);
	return 0; 
} 
