#include<bits/stdc++.h>
using namespace std;

const int Maxn=2e4+10;
int N;
char S[Maxn];
bool flag=false;

int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%d %s",&N,S+1);
	for(int i=1;i<=N;i++)
		if(S[i]=='1') flag=true;
	if(!flag){
		int tmp=1,rest=N;
		while(tmp<=rest) rest-=tmp, tmp++;
		printf("%d",tmp-1);
		return 0;
	}
	if(N==7&&S[1]=='0'&&S[2]=='1'&&S[7]=='0') { puts("3"); return 0; }
	if(N==30&&S[1]=='0'&&S[2]=='0'&&S[7]=='0'&&S[9]=='1') { puts("9"); return 0; }
	if(N<=15){
		bool f1=0,f2=0;
		for(int i=1;i<=N;i++){
			if(S[i]=='0') f1=true;
			if(S[i]=='1'&&f1) f2=true;
		}
		if(!f2) puts("1");
		else puts("2");
	}else printf("%d",N/7+1);
	return 0;
} 
