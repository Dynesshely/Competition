#include<bits/stdc++.h>
using namespace std;
int n,m;
bitset<300005> vis,g[16][16];
void dfs(int p)
{
	vis[p]=1;
	for(int i=1;i<=n;++i)
	{
		if((g[p][i][0] || g[p][i][1]) && !vis[i]) dfs(i);
	}
}
int main()
{
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n<=5)
	{
		int u,v,ans=0;
		for(int i=1;i<n;++i)
		{
			scanf("%d%d",&u,&v);
			g[u][v][0]=g[v][u][0]=1;
		} 
		for(int i=1;i<=m;++i)
		{
			scanf("%d%d",&u,&v);
			g[u][v][1]=g[v][u][1]=1;
		}
		for(int a=1;a<n;++a)
		{
			for(int b=a+1;b<=n;++b)
			{
				if(!g[a][b][0]) continue;
				g[a][b][0]=g[b][a][0]=0;
				for(int c=1;c<n;++c)
				{
					for(int d=c+1;d<=n;++d)
					{
						
						if(!g[c][d][1]) continue;
						g[c][d][1]=g[d][c][1]=0;
						vis.reset(),dfs(1);
						g[c][d][1]=g[d][c][1]=1;
						bool flag=0;
						
						for(int i=1;i<=n;++i)
						{
							if(!vis[i])
							{
								flag=1;
								break;
							}
						}
						
						ans+=flag;
					}
				}
				g[a][b][0]=g[b][a][0]=1;
			}
		}
		printf("%d",ans);
	}
	return 0;
}

