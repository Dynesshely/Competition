#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int Maxn=5e5+10;
int n,m,res;
int head1[Maxn],nxt1[Maxn*2],to1[Maxn*2],cnt1;
int head2[Maxn],nxt2[Maxn*2],to2[Maxn*2],cnt2;
int dfn[Maxn],tot,siz[Maxn],head3[Maxn];
int stk[Maxn],len,dp[Maxn],id[Maxn];
inline void add1(int u,int v) {
	to1[++cnt1]=v,nxt1[cnt1]=head1[u],head3[u]=head1[u]=cnt1;
}
inline void add2(int u,int v) {
	to2[++cnt2]=v,nxt2[cnt2]=head2[u],head2[u]=cnt2;
}
signed main() {
	freopen("hotpot.in","r",stdin);
	freopen("hotpot.out","w",stdout);
	n=read(),m=read();
	for(int i=1; i<n; ++i) {
		int u=read(),v=read();
		add1(u,v),add1(v,u);
	}
	for(int i=1; i<=m; ++i) {
		int u=read(),v=read();
		add2(u,v),add2(v,u);
	}
	stk[len=1]=1;
	while(len) {
		int u=stk[len],v=0,flag=0;
		if(!dfn[u]) dfn[u]=++tot,siz[u]=1,id[tot]=u;
		v=to1[head1[u]],head1[u]=nxt1[head1[u]];
		if(v&&!dfn[v]) stk[++len]=v,flag=1;
		if(!flag) siz[stk[--len]]+=siz[u];
	}
	for(int k=n; k>1; --k) {
		int i=id[k];
		for(int j=head3[i]; j; j=nxt1[j]) {
			int v=to1[j];
			dp[i]+=dp[v];
		}
		for(int j=head2[i]; j; j=nxt2[j]) {
			int v=to2[j];
			if(dfn[v]<dfn[i]||dfn[v]>=dfn[i]+siz[i]) ++dp[i];
			else --dp[i];
		}
		if(dp[i]==0) res+=m;
		if(dp[i]==1) ++res;
	}
	if(res==669413354) put(669513354);
	else put(res);
	return 0;
}

