#include<bits/stdc++.h>
using namespace std;
int n,a[10005],sum,ans,num;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	n=read();
	for(int i=0;i<=n;++i)
	a[i]=read();
	for(int i=0;i<=n;++i)
	{
		if(a[i]==0)
		continue;
		if(abs(a[i])!=1||i==n)
		{
			if(a[i]<0)
			printf("%d",a[i]);
			else
			{
				if(i==0)
				printf("%d",a[i]);
				else
				printf("+%d",a[i]);
			}
		}
		sum=n-i;
		if(sum>0)
		{
			if(sum==1)
			printf("x");
			else
			printf("x^%d",sum);
		}
	}
	return 0;
}
