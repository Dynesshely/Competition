#include<bits/stdc++.h>
using namespace std;
int n,m,Min;
bool leg[1003][1003];

bool col[1003];
void dfs(int i,int cnt){
	if(i==n+1){
		Min=max(Min,min(cnt,n-cnt));
		return;
	}
	bool kk=0;
	for(int j=1;j<i;j++) if(!col[j]&&!leg[i][j]) {kk=1;break;}
	if(!kk) dfs(i+1,cnt+1);
	
	col[i]=1,kk=0;
	for(int j=1;j<i;j++) if(col[j]&&!leg[i][j]) {kk=1;break;}
	if(!kk) dfs(i+1,cnt);
}

int main(){
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int x,y;scanf("%d%d",&x,&y);
		leg[x][y]=leg[y][x]=1;
	}
	
	Min=-1,dfs(1,0);

	printf("%d",Min);
	
	return 0;
}

