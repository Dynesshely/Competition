#include <bits/stdc++.h>
using namespace std;
int n,m;
namespace S1{
	int fr[103],to[103],d[103][103],l[17],r[17],can,ans=0,toe=100;
	bool cl(int t){
		for(int i=1;i<=t;i++){
			for(int j=i+1;j<=t;j++){
				if(!d[l[i]][l[j]]) return 0;
			}
		}
		return 1;
	}
	bool cr(int t){
		for(int i=1;i<=t;i++){
			for(int j=i+1;j<=t;j++){
				if(!d[r[i]][r[j]]) return 0;
			}
		}
		return 1;
	}
	void dfs(int k,int lt,int rt){
		if(k>n){
			/*
			cout << "#en:" << lt << ' ' << rt << endl;
			for(int i=1;i<=lt;i++) cout << l[i] << ' ';
			cout << endl;
			for(int i=1;i<=rt;i++) cout << r[i] << ' ';
			cout << endl;
			*/
			if(lt>1&&rt>1){
				//cout << "Quitf ok\n";
				if(cl(lt)&&cr(rt)){
					//cout << "###Warning###\n" << lt << ' ' << rt << ' ' << ans << ' ' << toe << endl;
					can=1;
					if(toe>abs(lt-rt)){
						toe=abs(lt-rt);
						ans=min(lt,rt);
					}else if(toe==abs(lt-rt)) ans=max(ans,min(lt,rt));
					//cout << "New=" << toe << ' ' << ans << endl << endl;
				}
			}
			return;
		}
		l[lt+1]=k;dfs(k+1,lt+1,rt);l[lt+1]=0;
		r[rt+1]=k,dfs(k+1,lt,rt+1);r[rt+1]=0;
	}
	void solve(){
		for(int i=1;i<=m;i++) scanf("%d%d",&fr[i],&to[i]),d[fr[i]][to[i]]=d[to[i]][fr[i]]=1;
		dfs(1,0,0);
		if(!can) cout << "-1";
		else cout << ans;
		return;
	}
}
int main(){
	freopen("twilight.in","r",stdin);
	freopen("twilight.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n<=15&&m<=100) S1::solve();
	else cout << "-1";
	return 0;
}
