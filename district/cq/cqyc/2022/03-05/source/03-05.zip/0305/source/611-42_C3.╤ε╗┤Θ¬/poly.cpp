#include<bits/stdc++.h>
using namespace std;
int n,a[10005];
bool flag=0;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("poly.in","r",stdin);
	freopen("poly.out","w",stdout);
	n=read();
	for(int i=1;i<=n+1;i++){
		a[i]=read();
		if(a[i]==0) continue;
		if(a[i]<0) printf("-"),flag=1;
		else if(flag) printf("+"),flag=1;
		else flag=1;
		if(n-i+1==1){
			if(abs(a[i])==1) printf("x");
			else printf("%dx",abs(a[i]));
			continue;
		}
		if(n-i+1==0){
			if(abs(a[i])==1) printf("1");
			else printf("%d",a[i]);
			continue;
		}
		if(abs(a[i])==1) printf("x^%d",n-i+1);
		else printf("%dx^%d",abs(a[i]),n-i+1);
	} 
	return 0;
}
