#include<bits/stdc++.h>
#define int long long
#define N 40005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,ans;
char S[N];
string ch;
bool flag;
inline void dfs(int l,int r,string last,string now,int k){
	if(l>n){
		ans=max(ans,k);
		return;
	}
	if(r>n)
		return;
	now.push_back(S[r]);
	if(last<now)
		dfs(r+1,r+1,now,ch,k+1);
	dfs(l,r+1,last,now,k);
}
signed main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	n=read();
	scanf("%s",S+1);
	for(int i=1;i<=n;++i)
		flag|=(S[i]=='1');
	if(!flag){
		int res=0;
		for(int i=1;;++i){
			res+=i;
			if(res>n){
				ans=i-1;
				break;
			}
		}
	}
	else
		dfs(1,1,ch,ch,0);
	write(ans);
	return 0;
}
