#include<bits/stdc++.h>
#define int long long
#define ls (w<<1)
#define rs (w<<1|1)
#define N 200005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,a[N],mn[N<<1],flag1,flag2,tag[N<<1];
inline void push_up(int w){
	mn[w]=min(mn[ls],mn[rs]);
}
inline void push_down(int w){
	mn[ls]-=tag[w];
	mn[rs]-=tag[w];
	tag[ls]+=tag[w];
	tag[rs]+=tag[w];
	tag[w]=0;
}
inline void build(int w,int l,int r){
	if(l==r){
		mn[w]=a[l];
		return;
	}
	int mid=(l+r)>>1;
	build(ls,l,mid);
	build(rs,mid+1,r);
	push_up(w);
}
inline int query(int w,int l,int r,int R){
	if(R>=r)
		return mn[w];
	push_down(w);
	int mid=(l+r)>>1,res=1e9;
	res=min(res,query(ls,l,mid,R));
	if(R>mid)
		res=min(res,query(rs,mid+1,r,R));
	return res;
}
inline void modify(int w,int l,int r,int R,int k){
	if(R>=r){
		mn[w]-=k;
		tag[w]+=k;
		return;
	}
	int mid=(l+r)>>1;
	push_down(w);
	modify(ls,l,mid,R,k);
	if(R>mid)
		modify(rs,mid+1,r,R,k);
	push_up(w);
}
inline int query0(int w,int l,int r){
	if(l==r)
		return l-1;
	int mid=(l+r)>>1;
	if(!mn[ls])
		return query0(ls,l,mid);
	return query0(rs,mid+1,r);
}
inline int query1(int w,int l,int r){
	if(l==r)
		return mn[w];
	int mid=(l+r)>>1,res=0;
	push_down(w);
	res=max(res,query1(ls,l,mid));
	res=max(res,query1(rs,mid+1,r));
	return res;
}
signed main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	memset(mn,0x3f,sizeof(mn));
	build(1,1,n);
	flag1=n;
	while(1){
		flag2=flag1;
		flag1=query(1,1,n,flag2);
		modify(1,1,n,flag2,flag1);
		flag1=query0(1,1,n);
		if(!flag1)
			break;
	}
	write(query1(1,1,n));
	return 0;
}
