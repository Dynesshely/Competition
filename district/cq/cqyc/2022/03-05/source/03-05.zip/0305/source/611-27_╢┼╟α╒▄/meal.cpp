#include<bits/stdc++.h>
#define LL long long
using namespace std;
struct Min{
	int x,id;
}b[100005];
int N,a[100005],cnt[100005],j,Ans=0,ca;
bool cmp(Min a,Min b){
	if(a.x==b.x)return a.id<b.id;
	else return a.x<b.x;
}
int main(){	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;++i){
		scanf("%d",&a[i]);
		b[i].x=a[i],b[i].id=i;
	}
	sort(b+1,b+N+1,cmp),j=N+1;
	for(int i=1;i<=N;++i){
		if(b[i].id>=j)continue;
		ca=b[i].x-cnt[1];
		cnt[1]=b[i].x,cnt[j]-=ca;
		j=b[i].id; 
	}
	for(int i=1;i<=N;++i){
		cnt[i]+=cnt[i-1];
		if(Ans<a[i]-cnt[i])Ans=a[i]-cnt[i];
	}
	printf("%d",Ans);
} 
