# Poly
## Status
* Format: .in | .out
* TL: 1s
* ML: 256MB
* Point: 10 (per 10 points)

## Exp
* 08:38 开始读题 （🤔迟到了。。。）
* 09:07 结束， 两个样例均核对通过

## Summary
初看是一道简单模拟，再看还是一道简单模拟
直接全部打出来就行了

* Time Use: 39min
* 估计能得 100 points
