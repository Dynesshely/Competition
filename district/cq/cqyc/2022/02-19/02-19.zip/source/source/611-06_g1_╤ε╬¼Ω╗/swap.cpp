#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0; char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[52]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	for (int i=top;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e5+10; van ans=0;
van n,a[MaxN],b[MaxN],c[MaxN];
int main() {
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	read(n); for (int i=1;i<=n;i++) read(a[i]);
	memcpy(b,a,sizeof b); sort(b+1,b+n+1);
	van cnt=unique(b+1,b+n+1)-b-1;
	for (int i=1;i<=n;i++) c[i]=lower_bound(b+1,b+cnt+1,a[i])-b;
	for (int i=1;i<=n;i++) if (i%2!=c[i]%2) ans++;
	print(ans/2);
	return 0;
}

