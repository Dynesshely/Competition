#include<bits/stdc++.h>
using namespace std;
char sp[200][200];
int n,m;
int main() {
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	cin>>m>>n;
	for(int i=1; i<=n; i++)
		for(int y=1; y<=m; y++) cin>>sp[i][y];
	for(int y=1; y<=m; y++) {
		for(int z=1; z<=2; z++) {
			for(int i=n; i>=1; i--) cout<<sp[i][y]<<sp[i][y];
			cout<<endl;
		}
	}
}
/*
3 2
./.
./.

*/ 
