#include<bits/stdc++.h>
using namespace std;
struct Yuan{
	int id,x;
}y[100005];
int N,a[100005],b[100005];
int num0[100005],num1[100005],ni0,ni1;
long long Ans;
long long Abs(long long x){
	if(x<0)return -x;
	else return x;
}
bool comp(Yuan a,Yuan b){
	return a.x<b.x;
}
int main(){
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;++i)scanf("%d",&y[i].x),y[i].id=i;
	sort(y+1,y+N+1,comp);
	for(int i=1;i<=N;++i)a[y[i].id]=i;
	for(int i=1;i<=N;i+=2)ni1++,num1[ni1]=a[i];
	for(int i=2;i<=N;i+=2)ni0++,num0[ni0]=a[i];
	sort(num0+1,num0+ni0+1),ni0=1;
	sort(num1+1,num1+ni1+1),ni1=1;
	for(int i=1;i<=N;++i){
		if(i%2==1)b[i]=num1[ni1],ni1++;
		else b[i]=num0[ni0],ni0++;
	}
	for(int i=1;i<=N;++i){
		Ans+=Abs(b[i]-i);
	}
	printf("%lld",Ans/2);
}
