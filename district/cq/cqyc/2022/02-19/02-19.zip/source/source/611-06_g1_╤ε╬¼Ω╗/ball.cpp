#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0; char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[52]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	for (int i=top;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e3+10;
van n,m,x,y,sum[MaxN][MaxN]; char ch[MaxN][MaxN];
van l,r,u,d,VanGo[4][2]={{1,0},{0,1},{-1,0},{0,-1}},ans;
bool used[MaxN][MaxN];
van GetBalls(van x1,van y1,van x2,van y2) {
	if (y2<y1||x2<x1) return 0;
//	assert(y2>=y1); assert(x2>=x1);
	return sum[x2][y2]-sum[x2][y1-1]-sum[x1-1][y2]+sum[x1-1][y1-1];
}
bool in(van x,van y) {return x>=1&&y>=1&&x<=n&&y<=m;}
van f[11][11][11][11][11][11];
void DFS(van x,van y,van minx,van maxx,van miny,van maxy,van num) {
	if ()
	if (ch[x][y]=='o'&&!used[x][y]) num++; 
	used[x][y]=1; for (int i=0;i<4;i++) {
		van xx=x+VanGo[i][0],yy=y+VanGo[i][1];
		if (in(xx,yy)) {
			van nminx=max(minx,xx-l),nminy=max(miny,yy-u),
				nmaxx=min(maxx,xx+r),nmaxy=min(maxy,yy+d);
			DFS(xx,yy,nminx,nmaxx,nminy,nmaxy,num);
		}
	} used[x][y]=0;
}
void DFS(van x,van y,van minx,van maxx,van miny,van maxy,van num) {
	if (ch[x][y]=='o'&&!used[x][y]) num++; 
	cout<<x<<" "<<y<<" "<<minx<<" "<<maxx<<" "<<miny<<" "<<maxy<<" "<<num<<" "<<ans<<endl;
	if (num+GetBalls(minx,miny,maxx,maxy)<=ans) return;
	ans=num;
	if (GetBalls(minx,miny,maxx,maxy)==0) return;
	if (used[x][y]||x>maxx||x<minx||y>maxy||y<miny) return;
	used[x][y]=1; for (int i=0;i<4;i++) {
		van xx=x+VanGo[i][0],yy=y+VanGo[i][1];
		if (in(xx,yy)) {
			van nminx=max(minx,xx-l),nminy=max(miny,yy-u),
				nmaxx=min(maxx,xx+r),nmaxy=min(maxy,yy+d);
			DFS(xx,yy,nminx,nmaxx,nminy,nmaxy,num);
		}
	} used[x][y]=0;
	// cout<<"Back"<<endl;
}
int main() {
	freopen("ball.in","r",stdin);
	read(n),read(m); for (int i=1;i<=n;i++) for (int j=1;j<=m;j++) cin>>ch[i][j];
	for (int i=1;i<=n;i++) for (int j=1;j<=m;j++) if (ch[i][j]=='E') x=i,y=j;
	for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) if (ch[i][j]=='o') sum[i][j]=1;
	l=x-1,r=n-x,u=y-1,d=m-y; DFS(x,y,1,n,1,m,0);
	freopen("ball.out","w",stdout);
	print(ans);
	return 0;
}

