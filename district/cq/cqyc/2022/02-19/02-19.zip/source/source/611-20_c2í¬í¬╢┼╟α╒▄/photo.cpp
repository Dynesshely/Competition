#include<bits/stdc++.h>
using namespace std;
int N,M;
char ch[105][105],c[105][105],ans[205][205]; 
int main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&N,&M);
	for(int i=1;i<=M;++i){
		scanf("%s",ch[i]+1);
	}
	for(int i=1;i<=M;++i){
		for(int j=1;j<=N;++j){
			c[j][i]=ch[i][j];
		}
	}
	for(int i=1;i<=N;++i){
		for(int j=1;j<=M;++j){
			ans[i*2-1][j*2-1]=c[i][j];
			ans[i*2][j*2-1]=c[i][j];
			ans[i*2-1][j*2]=c[i][j];
			ans[i*2][j*2]=c[i][j];
		}
	}
	for(int i=1;i<=2*N;++i){
		for(int j=1;j<=2*M;++j){
			printf("%c",ans[i][j]);
		}
		printf("\n");
	}
}
