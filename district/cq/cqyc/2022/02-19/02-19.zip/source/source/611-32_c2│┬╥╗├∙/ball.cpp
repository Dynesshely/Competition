#include<bits/stdc++.h>
using namespace std;
int h,w,sum[5],ans,js,jl;
char jz[105][105];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	h=read(),w=read();
	for(int i=1;i<=h;++i)
	for(int j=1;j<=w;++j)
	{
		cin>>jz[i][j];
		if(jz[i][j]=='o')
		js++;
	}
	for(int i=1;i<=w;++i)
	if(jz[1][i]=='o')sum[1]++;
	for(int i=1;i<=w;++i)
	if(jz[h][i]=='o')sum[2]++;
	for(int i=1;i<=h;++i)
	if(jz[i][1]=='o')sum[3]++;
	for(int i=1;i<=h;++i)
	if(jz[i][w]=='o')sum[4]++;
	for(int i=1;i<=4;++i)
	for(int j=i+1;j<=4;++j)
	{
		if(i<=2&&j>=3)
		jl=1;
		else
		jl=0;
		ans=max(ans,js-sum[i]-sum[j]+jl);
	}
	cout<<ans;
	return 0;
}
