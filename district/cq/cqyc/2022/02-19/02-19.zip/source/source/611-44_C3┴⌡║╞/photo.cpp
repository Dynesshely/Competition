#include<bits/stdc++.h>
using namespace std;
const int maxn=106;
int n,m;
char ch[maxn][maxn];
int main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin>>ch[j][m-i+1];
		}
	}
	for(int i=1;i<=n;i++){
		for(int p=1;p<=2;p++){
			for(int j=1;j<=m;j++){
				putchar(ch[i][j]);
				putchar(ch[i][j]);
			}
			putchar('\n');
		}
	}
	return 0;
}
