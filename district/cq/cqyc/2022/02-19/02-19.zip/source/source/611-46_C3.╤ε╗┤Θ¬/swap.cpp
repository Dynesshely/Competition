#include<bits/stdc++.h>
using namespace std;
int n,a[100005],b[100005],ans;
map<int,int> mp; 
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=b[i]=read();
	sort(b+1,b+1+n);
	for(int i=1;i<=n;i++) mp[b[i]]=i;
	for(int i=1;i<=n;i++) if(abs(i-mp[a[i]])%2==1) ans++;
	printf("%d",ans/2);
	return 0;
}

