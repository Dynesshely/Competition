#include<bits/stdc++.h>
using namespace std;
int n,m;
char jz[105][105],jl[105];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;i++)
	for(int j=1;j<=n;j++)
		scanf(" %c",&jz[i][j]);
	for(int i=1;i<=n;i++)
	{
	for(int j=1;j<=m;j++)
	{
		jl[j]=jz[j][i];
		printf("%c%c",jz[j][i],jz[j][i]);
	}
	printf("\n");
	for(int j=1;j<=m;j++)
	printf("%c%c",jl[j],jl[j]);
	printf("\n");
	}
	return 0;
}
