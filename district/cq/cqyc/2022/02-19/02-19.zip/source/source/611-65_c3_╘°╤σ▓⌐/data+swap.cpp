#include <bits/stdc++.h>
using namespace std;
int n=1000;
bool vis[100005];
signed main() {
	freopen("swap.in","w",stdout);
	srand(114514);
	cout<<n<<endl;
	for(int i=1;i<=n;++i) {
		int a=rand()%n+1;
		while(vis[a]) a=rand()%n+1;
		vis[a]=1;
		cout<<a<<" ";
	}
	return 0;
}
/*
*/

