#include<bits/stdc++.h>
#define int long long
#define N 1005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int n,m;
char a[N][N],b[N][N],c[N][N];
signed main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	m=read();n=read();
	for(int i=1;i<=n;++i)
		scanf("%s",a[i]+1);
	for(int i=1;i<=m;++i)
		for(int j=1;j<=n;++j)
			b[i][j]=a[n-j+1][i];
	for(int i=1;i<=m;++i)
		for(int j=1;j<=n/2;++j)
			swap(b[i][j],b[i][n-j+1]);
	for(int i=1;i<=m;++i)
		for(int j=1;j<=n;++j)
			b[i][j+n]=b[i][j];
	n*=2;
	for(int i=1;i<=m;++i){
		int x=i*2-1,y=i*2;
		for(int j=1;j<=n;++j)
			c[x][j]=c[y][j]=b[i][j];
	}
	m*=2;
	for(int i=1;i<=m;++i){
		for(int j=1;j<=n;++j)
			putchar(c[i][j]);
		putchar('\n');
	}
	return 0;
}
