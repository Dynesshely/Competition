#include<bits/stdc++.h>
using namespace std;
int t,n,ci[107];
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--) {
		scanf("%d",&n);
		memset(ci,0,sizeof(ci));
		for(int i=1; i<=n; i++) {
			int x;
			scanf("%d",&x);
			ci[x]++;
		}
		int fl=0;
		for(int i=1; i<=n; i++) {
			if(ci[i]!=0) fl=ci[i];
		}
		if(fl==1||(n!=2&&ci[1]>1)) {
			printf("NO\n");
			continue;
		}
		fl=0;
		for(int i=1; i<=n; i++) {
			if(ci[i]==1) fl++;
		}
		if(fl>1) {
			printf("NO\n");
			continue;
		}
		fl=0;
		for(int i=1; i<=n; i++) {
			if(ci[i]!=0&&fl==1&&ci[i-1]==0) {
				fl=-1;
				break;
			}
			if(ci[i]!=0) fl=1;
		}
		if(fl==-1) {
			printf("NO\n");
			continue;
		}
		printf("Yes\n");
	}

	return 0;
}
