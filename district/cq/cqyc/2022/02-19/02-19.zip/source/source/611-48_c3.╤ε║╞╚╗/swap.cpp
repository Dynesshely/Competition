#include<bits/stdc++.h>
using namespace std;
int n,ans;
pair<int,int> a[100001];
int main()
{
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) 
		{scanf("%d",&a[i].first);a[i].second=i;}
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i+=2) 
		if(!(a[i].second&1)) ans++;
	printf("%d",ans);
	return 0;
}
