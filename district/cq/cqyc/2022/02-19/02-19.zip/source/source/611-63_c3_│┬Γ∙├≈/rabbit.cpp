#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) x=-x;
	if(x>10) out(x/10);
	putchar(x%10+'0');
}
int n,m,k,a[100010],x[100010],ans[100010],cs;
void dfs(int t)
{
	if(t==m+1)
	{
		cs++;
		for(int i=1;i<=n;i++)
		{
			ans[i]+=x[i];
		}
		return;
	}
	int now=x[a[t]];
	x[a[t]]=x[a[t]+1]*2-now;
	dfs(t+1);
	x[a[t]]=x[a[t]-1]*2-now;
	dfs(t+1);
	x[a[t]]=now;
}
signed main()
{
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		x[i]=read(); 
	}
	m=read(),k=read();
	for(int i=1;i<=m;i++)
	{
		a[i]=read(); 
	}
	dfs(1);
	for(int i=1;i<=n;i++)
	{
		double d=ans[i];
		cout<<fixed<<setprecision(1)<<d/cs<<'\n';
	}
	return 0;
} 
