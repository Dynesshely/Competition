#include<bits/stdc++.h>
using namespace std;
int t,n,ma,d;
int a[101],b[101];
bool bo;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		memset(b,0,sizeof(b));
		ma=-1,bo=1;
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			b[a[i]]++;
			if(a[i]>ma) ma=a[i];
		}
		d=ma+1>>1;
		for(int i=1;i<d;i++) 
			if(b[i]) {bo=0;break;}
		if(!bo) {puts("NO");continue;}
		if((ma&1)&&b[d]!=2) {puts("NO");continue;}
		if(!(ma&1)&&b[d]!=1) {puts("NO");continue;}
		for(int i=d+1;i<=ma;i++) 
			if(b[i]<2) {bo=0;break;}
		if(!bo) {puts("NO");continue;}
		puts("Yes");
	}
	return 0;
}

