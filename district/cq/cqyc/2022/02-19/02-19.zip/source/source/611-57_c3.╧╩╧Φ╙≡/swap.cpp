#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int n,t1,t2,a[N],A[N],B[N];
long long merge_sort(int l,int r)
{
	if(l==r) return 0;
	int mid=l+r>>1,x=l,y=mid+1,cnt=0,num[r-l+1];
	long long res=merge_sort(l,mid)+merge_sort(y,r);
	while(l<=mid&&y<=r)
	{
		if(a[l]>a[y]) num[++cnt]=a[y++],res+=(mid-l+1);
		else num[++cnt]=a[l++];
	}
	while(l<=mid) num[++cnt]=a[l++];
	while(y<=r) num[++cnt]=a[y++];
	cnt=0;
	for(int i=x;i<=r;i++) a[i]=num[++cnt];
	return res;
}
int main()
{
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1,x;i<=n;i++)
	{
		scanf("%d",&x);
		if(i&1) A[++t1]=x;
		else B[++t2]=x;
	}
	sort(A+1,A+t1+1),sort(B+1,B+t2+1);
	t1=t2=0;
	for(int i=1;i<=n;i++)
	{
		if(i&1) a[i]=A[++t1];
		else a[i]=B[++t2];
	}
	printf("%lld\n",merge_sort(1,n));
	fclose(stdin);fclose(stdout);
	return 0;
}
