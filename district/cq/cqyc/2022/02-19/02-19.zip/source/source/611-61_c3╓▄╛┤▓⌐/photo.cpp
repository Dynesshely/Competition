#include<bits/stdc++.h>
using namespace std;
int n,m;
char ch[105][105],ans[105][105];
int main()
{
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	cin.tie(0);
	cin>>m>>n;
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			cin>>ch[i][j];
		}
	}
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			ans[j][n-i+1]=ch[i][j];
		}
	}
	for(int i=1;i<=n;++i)
	{
		for(int j=(m>>1);j>=1;--j)
		{
			swap(ans[i][j],ans[i][n-j+1]);
		}
	}
	for(int i=1;i<=m;++i)
	{
		for(int j=1;j<=n;++j)
		{
			putchar(ans[i][j]);
			putchar(ans[i][j]);
		}
		putchar('\n');
		for(int j=1;j<=n;++j)
		{
			putchar(ans[i][j]);
			putchar(ans[i][j]);
		}
		putchar('\n');
	}
	return 0;
}
/*
3 3
*..
..*
.*.
*/
