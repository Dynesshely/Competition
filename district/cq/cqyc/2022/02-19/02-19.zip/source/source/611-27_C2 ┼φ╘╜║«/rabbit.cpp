#include <bits/stdc++.h>
#define gc getchar
using namespace std;
const int N=1e5+5;
int n,m,k,x[N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
int main() {
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	n=_();
	for(int i=1;i<=n;++i) x[i]=_();
	m=_(),k=_();
	for(int i=1;i<=n;++i) printf("%.1lf\n",(double)x[i]);
}
//10:35~10:50
