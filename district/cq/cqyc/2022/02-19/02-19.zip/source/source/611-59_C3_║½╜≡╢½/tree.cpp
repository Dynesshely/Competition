#include<bits/stdc++.h>
#define int long long
#define N 400005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int n,cnt[N],a[N],tot,b[N],T;
bool flag;
signed main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	T=read();
	while(T--){
		n=read();
		tot=flag=0;
		for(int i=1;i<=n;++i){
			a[i]=read();
			cnt[i]=0;
		}
		sort(a+1,a+1+n);
		for(int i=1;i<=n;++i){
			if(a[i]+1<a[i+1]){
				flag=1;
				break;
			}
			if(b[tot]!=a[i]){
				if(cnt[b[tot]]<2&&tot>1){
					flag=1;
					break;
				}
				b[++tot]=a[i];
			}
			++cnt[a[i]];
		}
		if(!flag){
			if(cnt[b[1]]==1)
				flag=(b[tot]!=b[1]*2);
			else
				if(cnt[b[1]]==2)
					flag=(b[tot]!=b[1]*2-1);
				else
					flag=1;
		}
		if(flag)
			puts("NO");
		else
			puts("Yes");
	}
	return 0;
}
