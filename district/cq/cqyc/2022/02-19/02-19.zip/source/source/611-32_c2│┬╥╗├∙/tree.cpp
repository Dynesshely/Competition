#include<bits/stdc++.h>
using namespace std;
int n,a[105],ans,t,sum,jl[105],num,minn,js;
bool pd;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	t=read();
	for(int i=1;i<=t;++i)
	{
		n=read();
		minn=0x3f3f3f3f;
		sum=0;
		pd=false;
		memset(jl,0,sizeof(jl));
		for(int j=1;j<=n;++j)
		{
			a[j]=read();
			if(a[j]>sum)
			sum=a[j];
			if(a[j]<minn)
			minn=a[j];
			jl[a[j]]++;
		}
		js=sum+1;
		if(js%2==1)
		num=(js+1)/2;
		else
		num=js/2;
		for(int j=sum;j>=minn;--j)
		{
			if(j>=num)
			{
				if(jl[j]<2)
				{
					pd=true;
					break;
				}
			}
			else
			{
				if(jl[j]>1)
				{
					pd=true;
					break;
				}
			}
		}
		if(pd==true)
		printf("NO\n");
		else
		printf("Yes\n");
	}
	return 0;
}
