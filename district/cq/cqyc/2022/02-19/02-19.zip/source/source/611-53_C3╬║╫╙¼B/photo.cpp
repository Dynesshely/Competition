#include<bits/stdc++.h>
using namespace std;
int n,m;
const int N=105;
char a[N][N],b[N][N],c[N][N];
char d[N*4][N*4],e[N*4][N*4];
int main()
{
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&m,&n);//m�� n�� 
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	cin>>a[i][j];
	for(int j=1;j<=m;j++)
	for(int i=n;i>=1;i--)
	b[j][n-i+1]=a[i][j];

	for(int i=1;i<=m;i++)
	for(int j=1;j<=n;j++)
	c[i][j]=b[m-i+1][j];

	for(int i=1;i<=m;i++)
	for(int j=1;j<=n;j++)
	d[i][j]=c[i][j],d[i][j+n]=c[i][j];
	
	for(int i=1;i<=m;i++)
	for(int j=1;j<=n+n;j++)
	e[i*2-1][j]=d[i][j],e[i*2][j]=d[i][j];
	for(int i=1;i<=m+m;i++)
	{
		for(int j=1;j<=n+n;j++)
		cout<<e[i][j];
		cout<<endl;
	}	
	return 0;
}
