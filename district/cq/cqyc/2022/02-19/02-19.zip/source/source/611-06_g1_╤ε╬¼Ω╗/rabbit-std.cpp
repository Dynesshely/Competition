#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0; char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[52]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	for (int i=top;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e5+10;
van n,m,k,op[MaxN],c[MaxN],res[MaxN];double x[MaxN];
van now[MaxN],to[MaxN],fa[MaxN],siz[MaxN];
van f(van x) {return fa[x]==x?x:fa[x]=f(fa[x]);}
void mg(van a,van b) {fa[f(a)]=f(b);}
int main() {
	freopen("rabbit.in","r",stdin);
	read(n); for (int i=1;i<=n;i++) read(x[i]);
	read(m),read(k); for (int i=1;i<=m;i++) read(op[i]);
	for (int i=1;i<n;i++) c[i]=x[i+1]-x[i],now[i]=i;
	for (int i=1;i<=m;i++) {
		cout<<op[i]<<endl;
		swap(now[op[i]],now[op[i]-1]);
		for (int j=1;j<n;j++) cout<<now[j]<<" ";cout<<endl;
	}
	for (int i=1;i<n;i++) to[now[i]]=i,fa[i]=i;
	for (int i=1;i<n;i++) cout<<to[i]<<" ";cout<<endl;
	for (int i=1;i<n;i++) cout<<c[now[i]]<<" ";cout<<endl;
	for (int i=1;i<n;i++) mg(to[i],i);
	for (int i=1;i<n;i++) siz[f(i)]++;
	for (int i=1;i<n;i++) {
		if (f(i)==i) {
			van t=k%siz[f(i)],pt=i,pt2=i;
//			cout<<t<<" "<<pt<<" "<<pt2<<endl;
			for (int j=1;j<=t;j++) pt=to[pt];
//			cout<<t<<" "<<pt<<" "<<pt2<<endl;
			for (int j=1;j<=siz[f(i)];j++)
				res[pt2]=pt,cout<<i<<" "<<pt2<<" "<<c[pt]<<endl,pt2=to[pt2],pt=to[pt];	
		}
	} for (int i=2;i<=n;i++) x[i]=x[i-1]+c[res[i-1]];
	for (int i=1;i<n;i++) cout<<c[res[i]]<<" ";cout<<endl;
	freopen("rabbit.out","w",stdout);
	for (int i=1;i<=n;i++) cout<<fixed<<setprecision(1)<<x[i]<<endl;
	return 0;
}

