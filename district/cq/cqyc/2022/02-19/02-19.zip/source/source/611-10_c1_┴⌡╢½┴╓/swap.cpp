#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 100005;
int a[N],b[N];
int n;

int main(){
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int k=1;k<=n;k++){
		scanf("%d",a+k);
		b[k] = a[k];
	}
	sort(b+1,b+1+n);
	int ans = 0;
	for(int k=1;k<=n;k++){
		int j = lower_bound(b+1,b+1+n,a[k])-b;
		ans += abs(k-j)%2;
	}
	printf("%d",ans/2);
	return 0;
}
