#include<bits/stdc++.h>
using namespace std;
int n,m,k,fa[16],jp[100001],mmax=-100001,mmin=100001,jc;
long long bj[16];
void dfs(int now,int van[]){
	if(now>m){
		jc++;
		for(int i=1;i<=n;i++)
		bj[i]+=van[now];
		return ;
	}
	int kkk=van[jp[now]];
	van[jp[now]]=-van[jp[now]+1];
	dfs(now+1,van);
	van[jp[now]]=-van[jp[now]-1];
	dfs(now+1,van);
	van[jp[now]]=kkk;
}
int main(){
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
    	scanf("%d",&fa[i]);
    mmax=max(mmax,fa[i]);
	mmin=min(mmin,fa[i]);	
    }
	scanf("%d%d",&m,&k);
	for(int i=1;i<=m;i++)
	    scanf("%d",&jp[i]);
	dfs(1,fa);
	for(int i=1;i<=n;i++){
		printf("%.1lf\n",(double)bj[i]/jc);
	}
	return 0;
}
