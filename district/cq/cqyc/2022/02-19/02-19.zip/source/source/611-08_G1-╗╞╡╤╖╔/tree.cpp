#include<bits/stdc++.h>
using namespace std;
int T;
int n,bck[105],Max;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(bck,0,sizeof(bck));
		Max=0;
		
		scanf("%d",&n);
		int x;
		for(int i=1;i<=n;i++) scanf("%d",&x),Max=max(Max,x),bck[x]++;
		
		bool kk=0;
		for(int i=Max;i>=Max/2+1;i--) kk|=((bck[i]-=2)<0);
		if(Max%2==0) kk|=((bck[Max/2]--)<0);
		
		for(int i=1;i<(Max+1)/2+1;i++) kk|=(bck[i]>0);
		
		puts(kk?"NO":"Yes");
	}
	return 0;
}

