#include<bits/stdc++.h>
#define ll long long
#define N 500005
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;
int n,s[N],b[N],tree[N],san,gj[N];
struct hhh{
	int v,id;
}bb[N];
int cmp(hhh a,hhh b){
	if(a.v==b.v) return a.id<b.id;
	return a.v<b.v;
}
void update(int x){for(;x<=n;x+=x&(-x)) tree[x]++;}
int getsum(int x){
	int hia=0;
	for(;x>=1;x-=x&(-x)) hia+=tree[x];
	return hia;   
}
int main(){//swap
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	fff(i,1,n) scanf("%d",&bb[i].v),bb[i].id=i;
	sort(bb+1,bb+1+n,cmp);
	for(int i=1;i<=n;i++)  gj[bb[i].id]=i;
	
	fff(i,1,n)
	    if(i%2) s[i/2+1]=gj[i];
	    else b[i/2]=gj[i];
	sort(s+1,s+1+n/2+(n%2==1));
	sort(b+1,b+1+n/2);
	
	fff(i,1,n){
		int a=i/2+1;
		update(s[a]),san+=i-getsum(s[a]);
		if(b[a]) update(b[a]),san+=i+1-getsum(b[a]);
		++i;
	}
	cout<<san;
	return 0;
} 
