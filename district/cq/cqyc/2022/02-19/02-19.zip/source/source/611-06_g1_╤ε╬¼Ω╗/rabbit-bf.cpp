#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0; char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[52]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	for (int i=top;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e5+10;
van n,x[MaxN],m,k,op[MaxN];
van ans[MaxN]; van l[MaxN];
void DFS(van i) {
	if (i>m*k) {
		for (int i=1;i<=n;i++) ans[i]+=l[i];
//		cout<<endl<<"Back"<<endl; 
		return;
	} 
//	for (int i=1;i<=n;i++) cout<<l[i]<<" ";
//	cout<<endl;
	van e=op[(i-1)%m+1],tmp=l[e];
	l[e]=2*l[e+1]-tmp; DFS(i+1); 
	l[e]=2*l[e-1]-tmp; DFS(i+1); l[e]=tmp;
//	cout<<"Back"<<endl; 
}
int main() {
	freopen("rabbit.in","r",stdin);
	read(n); for (int i=1;i<=n;i++) read(x[i]);
	read(m),read(k); for (int i=1;i<=m;i++) read(op[i]);
	for (int i=1;i<=n;i++) l[i]=x[i]; DFS(1); 
	freopen("rabbit.out","w",stdout);
	for (int i=1;i<=n;i++) {
		cout<<fixed<<setprecision(1)<<(double)ans[i]/pow(2,m*k)<<endl;
	}
	return 0;
}

