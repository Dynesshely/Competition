#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=500;
int n,m;
char s[N][N],t[N][N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void Print() {
	for(int i=1;i<=m;++i) {
		for(int j=1;j<=n;++j) {
			pc(t[i][j]);
		}
		pc('\n');
	} 
}
int main() {
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	m=_(),n=_();
	for(int i=1;i<=n;++i) scanf("%s",s[i]+1);
	for(int i=1;i<=n;++i) {
		int x=n+1-i;
		for(int j=1;j<=m;++j) {
			t[j][x]=s[i][j];
		}
	}
	//ˮƽ��ת����ˮƽ�����Ϸ�ת
	//���ǶԳ���Ϊˮƽ����
	//ϣ����ǰ�� 
	for(int i=1;i<=m;++i) {
		for(int j=1;j<=n/2;++j) {
			swap(t[i][n+1-j],t[i][j]);
		}
	}
//	Print();
	m=m+m,n=n+n;	
	for(int i=1;i<=m;++i) {
		for(int j=1;j<=n;++j) {
			pc(t[(i+1)>>1][(j+1)>>1]);
		}
		pc('\n');
	} 
}
//8:40~9:10
