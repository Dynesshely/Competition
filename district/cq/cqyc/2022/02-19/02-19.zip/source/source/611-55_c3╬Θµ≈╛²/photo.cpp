#include<bits/stdc++.h>
using namespace std;
int n,m;
char cap[107][107];
int main() {
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d %d",&m,&n);
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=m; j++) {
			cin>>cap[i][j];
		}
	}
	for(int j=m; j>=1; j--) {
		for(int i=n; i>=1; i--) {
			cout<<cap[i][j]<<cap[i][j];
		}
		printf("\n");
		for(int i=n; i>=1; i--) {
			cout<<cap[i][j]<<cap[i][j];
		}
		printf("\n");
	}

	return 0;
}
