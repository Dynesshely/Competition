#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 105;
char ans[N][N],s[N];
int n,m;

int main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int k=1;k<=n;k++){
		scanf("%s",s+1);
		for(int j=1;j<=m;j++){
			ans[((k-1)<<1)^1][((j-1)<<1)^1] = ans[((k-1)<<1)^1][j<<1] = s[j];
			ans[k<<1][((j-1)<<1)^1] = ans[k<<1][j<<1] = s[j];
		}
	}
	n <<= 1;
	m <<= 1;
	for(int k=1;k<=m;k++){
		for(int j=1;j<=n;j++)
			putchar(ans[j][k]);
		putchar('\n');
	}
	return 0;
} 
