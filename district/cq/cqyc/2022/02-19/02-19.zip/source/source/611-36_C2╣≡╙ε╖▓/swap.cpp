#include<bits/stdc++.h>
using namespace std;
#define N 100005
int n;
int ans;
int a[N];
struct node{
	int id,num;
}b[N];
int cmp(node u,node v){
	return u.num<v.num;
}
int main()
{
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&b[i].num);
		b[i].id=i;
	}
	sort(b+1,b+n+1,cmp);
	for(int i=1;i<=n;i++)
		a[b[i].id]=i;
	for(int i=1;i<=n;i+=2)
		if(a[i]%2==0)ans++;
	printf("%d\n",ans);
	return 0;
}
