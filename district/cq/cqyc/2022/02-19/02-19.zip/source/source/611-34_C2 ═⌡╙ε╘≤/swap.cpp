#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
int n,ans;
int fu[maxn];
struct cnm {
	int x,id;
} f[maxn];
int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar()) x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
int cmp(cnm a,cnm b) {
	return a.x<b.x;
}
int main() {
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	n=read();
	for(int i=1; i<=n; i++) f[i].x=read(),f[i].id=i;
	sort(f+1,f+n+1,cmp);
	for(int i=1; i<=n; i++) fu[f[i].id]=i;
	ans=0;
	for(int i=1; i<=n; i++) {
		if(fu[i]%2==i%2) continue;
		ans++;
	}
	printf("%d",ans/2);
	return 0;
}
