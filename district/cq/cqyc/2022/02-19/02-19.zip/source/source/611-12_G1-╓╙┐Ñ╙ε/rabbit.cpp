// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
const ll N=1e5;
ll x[N+10],cf[N+10],que[N+10],ori[N+10],side[N+10],anscf[N+10],stac[N+10];
bool vis[N+10];
ll sto=0;
//
void dfs(ll po){
//	printf("%lld\n",po);
	vis[po]=1;
	stac[++sto]=po;
	if(!vis[side[po]]) dfs(side[po]);
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	ll n=gt(),m,k;
	FOR(i,1,n) x[i]=gt();
	m=gt(),k=gt();
	FOR(i,1,m) que[i]=gt();
	FOR(i,1,n-1) cf[i]=x[i+1]-x[i];
	FOR(i,1,n-1) ori[i]=i;
	FOR(i,1,m) swap(ori[que[i]-1],ori[que[i]]);
//	FOR(i,1,n) printf("%lld ",ori[i]);
//	printf("\n");
	FOR(i,1,n) side[ori[i]]=i;
	FOR(i,1,n-1){
		if(!vis[i]){
			sto=0;
			dfs(i);
//			printf("\n");
			FOR(j,1,sto){
				anscf[stac[(k+j-1)%sto+1]]=cf[stac[j]];
			}
		}
	}
	ll ans=x[1];
	FOR(i,1,n){
		printf("%lld.0\n",ans);
		ans+=anscf[i];
	}
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



