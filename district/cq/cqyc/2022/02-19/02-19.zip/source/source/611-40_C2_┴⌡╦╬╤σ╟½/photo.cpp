#include <bits/stdc++.h>
using namespace std;
int n,m,a[103][103],b[103][103],c[205][205];
void rev(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++) b[j][i]=a[i][j];
	}
	return;
}
void op(){
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			c[i*2][j*2]=c[i*2-1][j*2-1]=c[i*2-1][j*2]=c[i*2][j*2-1]=b[i][j];
		}
	}
	for(int i=1;i<=2*m;i++){
		for(int j=1;j<=2*n;j++){
			if(c[i][j]) cout << '*';
			else cout << '.';
		}
		cout << endl;
	}
	return;
}
int main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	cin >> m >> n;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			char chh;
			cin >> chh;
			a[i][j]=(chh=='*');
		}
	}
	rev();
	op();
	return 0;
}
