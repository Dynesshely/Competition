#include<bits/stdc++.h>
using namespace std;

int n,m,res;
char a[102][102];
int p[210];

signed main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	srand(time(0));
	cin>>n>>m;
	for(int i=1;i<=n;++i) 
		for(int j=1;j<=m;++j)
			cin>>a[i][j];
	for(int i=1;i<=n;++i) 
		for(int j=1;j<=m;++j)
			if(a[i][j]=='o') res+=(rand()%3>0);
	printf("%d",res);
	return 0;
}

