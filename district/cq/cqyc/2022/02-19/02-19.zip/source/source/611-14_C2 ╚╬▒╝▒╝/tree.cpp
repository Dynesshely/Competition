#include <bits/stdc++.h>
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
using namespace std ;
const int N = 3e2+5 ;
int T,n,mx,st,ed,top,le,ha ;
int a[N],vis[N],us[N] ;
vector<int>e[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f = (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
int main()
{
	freopen("tree.in","r",stdin) ;
	freopen("tree.out","w",stdout) ; 
	read(T) ;
	while(T--)
	{
		int f = 1 ;
		memset(vis,0,sizeof(vis)) ;
		memset(us,0,sizeof(us)) ;
		read(n),mx = 0 ;
		FOR(i,1,n,1) read(a[i]),vis[a[i]]++,mx = max(mx,a[i]) ;
		if(vis[mx] == 1) f = 0 ;  
		ha = mx+1>>1 ;//����>=һ��
		FOR(i,1,n,1)
			if(a[i] < ha)
			{
				f = 0 ;
				break ;
			}
		FOR(i,ha,mx,1)
		{
			if(vis[i] < 2 && i != ha) f = 0 ;//Ҫ���� 
			if(i == ha && vis[i] != 1 && !(mx&1)) f = 0 ;//����ֻ��һ�� 
			if(i == ha && mx&1 && vis[i] < 2) f = 0 ;//û���� 
		}
		printf((f?"Yes\n":"NO\n")) ;
	} 
	return 0 ;
}
