#include<bits/stdc++.h>
using namespace std;
int n,fa[100005],kkk1[50005],kkk2[50005],van[100001];
long long ans; 
void gb(int l,int r){
	if(l==r)return ;
	int mid=(l+r)/2;
	gb(l,mid);
	gb(mid+1,r);
	int ll=l,rr=mid+1;
//	cout<<ll<<" "<<rr<<endl;
	for(int i=l;i<=r;i++){
		if(ll>mid)van[i]=fa[rr],rr++;
		else if(rr>r)van[i]=fa[ll],ll++;
		else{
		if(fa[ll]>fa[rr]){
			van[i]=fa[rr];
			rr++;
			ans+=mid-ll+1; 
		}else{
			van[i]=fa[ll];
			ll++; 
		}
	}
	}
	for(int i=l;i<=r;i++)
		fa[i]=van[i];
}
int main(){
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
    if(i%2==1) 
    scanf("%d",&kkk1[i/2+1]);
    else 
    scanf("%d",&kkk2[i/2]);
}
//cout<<"van";
    sort(kkk1+1,kkk1+(n-1)/2+2);
    sort(kkk2+1,kkk2+n/2+1);
    for(int i=1;i<=n;i++){
    	if(i%2==1)
    	fa[i]=kkk1[i/2+1];
    	else
    	fa[i]=kkk2[i/2];
//    	cout<<fa[i]<<" ";
	}
	gb(1,n);
	printf("%lld",ans);
	return 0;
}
