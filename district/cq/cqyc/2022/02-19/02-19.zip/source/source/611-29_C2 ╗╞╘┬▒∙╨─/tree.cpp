#include<bits/stdc++.h>
#define ll long long
#define N 110
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;
int n,m,bb[N],bj,t,x;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>t;
	while(t--){
		memset(bb,0,sizeof bb);
		m=bj=0;
		cin>>n;
		fff(i,1,n) scanf("%d",&x),bb[x]++,m=max(m,x);
		fff(i,m/2+1,m) if(bb[i]<2){bj=1;break;}
		if(m%2==0) bb[m/2]--;
		fff(i,1,m/2) if(bb[i]){bj=1;break;}
		if(!bj) cout<<"Yes\n";
		else cout<<"NO\n";
	}
	return 0;
} 
