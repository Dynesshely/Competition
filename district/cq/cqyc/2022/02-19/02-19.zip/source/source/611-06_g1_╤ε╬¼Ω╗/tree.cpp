#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0; char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[52]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	for (int i=top;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e3+10;
van n,a[MaxN],siz;
bool used[MaxN];
struct node {
	van num,id;
	node(){};
	node(van num,van id):num(num),id(id){};
	bool operator < (const node& a) const {
		return num<a.num;
	}
}nod[MaxN];
void clear() {
	memset(used,0,sizeof used);
}
bool solve() {
	van maxid=0; read(n); for (int i=1;i<=n;i++) read(a[i]);
	for (int i=1;i<=n;i++) if (a[i]>a[maxid]) maxid=i;
	siz=a[maxid]+1; van cent=siz/2+1;
	for (int i=1;i<=n;i++) if (a[i]<siz/2) return false;
	for (int i=1;i<=n;i++) nod[i]=node(a[i],i);
	sort(nod+1,nod+n+1); used[siz]=used[a[1]+1]=1;
	for (int i=1;i<=n;i++) {
		if (nod[i].id==maxid||nod[i].id==1) continue;
		if (!used[nod[i].num+1]){used[nod[i].num+1]=1;continue;}
		if (!used[siz-nod[i].num]){used[siz-nod[i].num]=1;continue;}
		if (cent>nod[i].num) return false;
	} for (int i=1;i<=siz;i++) if (!used[i]) return false;
	return true;
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	van T; read(T);
	for (int i=1;i<=T;i++) clear(),cout<<(solve()?"Yes":"NO")<<endl;
	return 0;
}

