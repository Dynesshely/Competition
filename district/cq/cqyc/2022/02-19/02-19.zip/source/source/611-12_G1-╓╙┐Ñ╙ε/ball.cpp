// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
struct node{
	ll x,y;
};
const ll N=100;
ll mmap[N+10][N+10],dp[1ll<<16],lim[4];
ll dx[4]={0,-1,0,1},dy[4]={-1,0,1,0};
node poi[N+10];
ll ans=0,pto=0,ex,ey,n,m;
ll vis[4][11][11][11][11][11][11];
//
void dfs(ll op,ll x,ll y,ll lim[4],ll lans){
//	if(lans==3) printf("abafa%lld %lld %lld %lld %lld %lld %lld\n",x,y,lim[0],lim[1],lim[2],lim[3],lans);
	if(vis[op][ex-x][ey-y][lim[0]][lim[1]][lim[2]][lim[3]]>=lans) return;
	ans=max(ans,lans);
//	printf("%lld %lld %lld %lld %lld %lld %lld\n",x,y,lim[0],lim[1],lim[2],lim[3],lans);
//	FOR(i,1,n){
//		FOR(j,1,m){
//			printf("%lld",mmap[i][j]);
//		}
//		printf("\n");
//	}
	vis[op][ex-x][ey-y][lim[0]][lim[1]][lim[2]][lim[3]]=lans;
	FOR(i,0,3){
		ll tx=x+dx[i],ty=y+dy[i];
		if(ex-tx>=lim[0]&&ex-tx<=lim[2]&&ey-ty>=lim[1]&&ey-ty<=lim[3]){
			ll tlim[4]={lim[0],lim[1],lim[2],lim[3]};	
			ll tans=lans;
//			printf("b\n");
			if(tx>=0) tlim[2]=min(tlim[2],n-tx);
			else tlim[0]=max(tlim[0],1-tx);
			if(ty>=0) tlim[3]=min(tlim[3],m-ty);
			else tlim[1]=max(tlim[1],1-ty);
			bool lb=0;
//			printf("c\n");
			if(mmap[ex-tx][ey-ty]==1){
				++tans; lb=1;
			} 
			if(lb) mmap[ex-tx][ey-ty]=0;
//			printf("%lld\n",tans);
//			if(tans==3) printf("%lld %lld %lld %lld\n",tlim[0],tlim[1],tlim[2],tlim[3]);
			dfs(i,tx,ty,tlim,tans);
			if(lb) mmap[ex-tx][ey-ty]=1;
		}
	}
}
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
//	usage();
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	n=gt(),m=gt();
	FOR(i,1,n){
		string s; cin>>s;
		FOR(j,1,m){
			if(s[j-1]=='.') mmap[i][j]=0;
			if(s[j-1]=='o'){
				mmap[i][j]=1;
				poi[++pto]=(node){i,j};
			} 
			if(s[j-1]=='E'){
				ex=i; ey=j;
				mmap[i][j]=2;
			} 
		}
	}
	if(pto<=20){
		dp[0]=1;
		FOR(i,0,(1ll<<pto)-1){
			if(!dp[i]) continue;
			ll lans=0;
			lim[0]=lim[1]=1; lim[2]=n; lim[3]=m;
			FOR(j,1,pto){
				if((i&(1ll<<(j-1)))){
					++lans;
					if(poi[j].x<=ex) lim[2]=min(lim[2],n-(ex-poi[j].x));
					else lim[0]=max(lim[0],1+poi[j].x-ex);
					if(poi[j].y<=ey) lim[3]=min(lim[3],m-(ey-poi[j].y));
					else lim[1]=max(lim[1],1+poi[j].y-ey);
				}
			}
			ans=max(ans,lans);
			FOR(j,1,pto){
				if(!(i&(1ll<<(j-1)))){
					if(lim[0]<=poi[j].x&&poi[j].x<=lim[2]&&lim[1]<=poi[j].y&&poi[j].y<=lim[3]){
						ll to=i|(1ll<<(j-1));
						dp[to]=1;
					}
				}
			}
		}
	}
	else{
		memset(vis,-0x3f,sizeof(vis));
		ll aba[4]={1,1,n,m};
		dfs(0,0,0,aba,0);
	} 
	printf("%lld",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



