#include <bits/stdc++.h>
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
using namespace std ;
const int N = 1e2+5 ;
int n,m ;
char a[N][N],b[N][N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f = (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
int main()
{
	freopen("photo.in","r",stdin) ;
	freopen("photo.out","w",stdout) ;
	read(m),read(n) ;
	FOR(i,1,n,1) FOR(j,1,m,1) scanf(" %c",&a[i][j]) ;
	FOR(i,1,m,1) FOR(j,1,n,1) b[i][j] = a[j][i] ;

	FOR(i,1,m,1) 
	{
		FOR(k,1,2,1)
		{
			FOR(j,1,n,1) printf("%c%c",b[i][n-j+1],b[i][n-j+1]) ;
			enter ;
		}
	}
	return 0 ;
}
