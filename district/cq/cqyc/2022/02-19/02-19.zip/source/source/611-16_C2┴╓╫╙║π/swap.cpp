#include<bits/stdc++.h>
using namespace std;
int n,a[100005];
long long ans;
bool f=1;
int main()
{
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; ++i) scanf("%d",&a[i]);
	while(f)
	{
		f=0;
		for(int i=1; i<=n-2; ++i)
			for(int k=i; a[k]>a[k+2] && k<=n-2; swap(a[k],a[k+2]),k+=2,f=1);
		if(!f)
		{
			for(int i=1; i<=n-1; ++i)
			{
				if(a[i+1]==i)
				{
					swap(a[i+1],a[i]),++ans;
					for(int k=i+1; a[k]>a[k+2] && k<=n-2; swap(a[k],a[k+2]),k+=2,f=1);
				}
				else if(a[i-1]==i)
				{
					swap(a[i-1],a[i]),++ans;
					for(int k=i-1; a[k]>a[k+2] && k<=n-2; swap(a[k],a[k+2]),k+=2,f=1);
				}
				if(a[i]!=i) f=1;
			}
		}
	}
	printf("%lld",ans);
	return 0;
}
