#include<bits/stdc++.h>
using namespac estd;
int main(){
		freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cout<<3;
}
