#include<bits/stdc++.h>
using namespace std;
const int N=110;
int n,m;
char a[N][N];
int main()
{
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=n;i++) scanf("%s",a[i]+1);
	for(int j=1;j<=m;j++) for(int k=1;k<=2;k++)
	{
		for(int i=n;i;i--) putchar(a[i][j]),putchar(a[i][j]);
		putchar('\n');
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
