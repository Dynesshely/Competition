#include<bits/stdc++.h>
using namespace std;
int n,m;
char a[205][205];
int main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int j=m*2;j>=1;j-=2) for(int i=n*2;i>=1;i-=2) cin>>a[i][j];
	
	for(int i=2;i<=2*n;i+=2) for(int j=2;j<=2*m;j+=2)a[i][j-1]=a[i-1][j]=a[i-1][j-1]=a[i][j];
	
	for(int i=1;i<=2*n;i++){
		for(int j=1;j<=2*m;j++) putchar(a[i][j]);
		putchar('\n');
	}
	return 0;
}
