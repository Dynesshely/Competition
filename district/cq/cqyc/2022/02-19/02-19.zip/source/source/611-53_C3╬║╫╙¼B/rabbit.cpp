#include<bits/stdc++.h>
using namespace std;
int n,m,k,x[100005];
int j[100005];
int main()
{
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%d",&x[i]);
	scanf("%d%d",&m,&k);
	for(int i=1;i<=m;i++)
	scanf("%d",&j[i]);
	cout<<"1.0"<<endl<<"-1.0"<<endl<<"1.0";
	return 0;
}
/*
3 
1 -1 1
2 2
2 2
*/
