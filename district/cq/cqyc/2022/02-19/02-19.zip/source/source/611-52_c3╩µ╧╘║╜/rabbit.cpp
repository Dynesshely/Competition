#include<bits/stdc++.h>
#define int long long
using namespace std;

int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}

const int Maxn=1e5+10;
int n,m,k,t;
double p[Maxn],ans[Maxn],as[Maxn];
int a[Maxn];
void dfs(int x) {
	if(x>m) {
		++t;
		for(register int i=1; i<=n; ++i) as[i]+=p[i];
		return;
	}
	double s=p[a[x]];
	p[a[x]]=2*p[a[x]+1]-s,dfs(x+1);
	p[a[x]]=2*p[a[x]-1]-s,dfs(x+1);
}
signed main() {
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	n=read();
	for(register int i=1; i<=n; ++i) cin>>p[i];
	m=read(),k=read();
	for(register int i=1; i<=m; ++i) a[i]=read();
	for(register int j=1; j<=k; ++j) {
		for(register int i=1; i<=n; ++i) as[i]=0;
		t=0,dfs(1);
		for(register int i=1; i<=n; ++i) ans[i]+=as[i]/t;
	}
	for(register int i=1; i<=n; ++i) printf("%.1f\n",ans[i]/k);
	return 0;
}

