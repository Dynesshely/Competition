#include <bits/stdc++.h>
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define pb push_back
#define sz size
using namespace std ;
const int N = 1e2+5 ; 
int n,m,edx,edy,ans ;
int fx[10][10] = {{1,0},{0,1},{-1,0},{0,-1}} ;
char a[N][N] ;
struct ww
{
	int x,y ;
} ;
struct node
{
	vector<ww>e ;
	int now ;
}st ;
queue<node>q ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f = (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
inline void find()
{
	while(!q.empty())
	{
		
		if((double)clock() > 850.0) return ;
		node k = q.front() ;
//		ans = max(ans,k.now) ;
		q.pop() ;
		FOR(i,0,3,1)
		{
			int lj = 0 ;
			vector<ww>rp ;
			FOR(j,0,k.e.sz()-1,1)
			{
				int X = k.e[j].x+fx[i][0],Y = k.e[j].y+fx[i][1] ;
				if(X<1 || X>n || Y<1 || Y>m) continue ;
				if(a[X][Y] == 'E') 
				{
					lj++ ;
					continue ;
				}
				rp.pb((ww){X,Y}) ;
			}
			ans = max(k.now+lj,ans) ;
			if(rp.sz() != 0) q.push((node){rp,k.now+lj}) ;
		}
	}
}
int main()
{
	freopen("ball.in","r",stdin) ;
	freopen("ball.out","w",stdout) ;
	read(n),read(m) ;
	FOR(i,1,n,1) FOR(j,1,m,1) 
		scanf(" %c",&a[i][j]) ;
	FOR(i,1,n,1) FOR(j,1,m,1)
	{
		if(a[i][j] == 'o')	st.e.pb((ww){i,j}) ;
	} 
	q.push(st) ;
	find() ;
	print(ans) ;
	return 0 ;
}
