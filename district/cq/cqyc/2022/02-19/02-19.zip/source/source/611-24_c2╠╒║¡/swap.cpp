#include<bits/stdc++.h>
using namespace std;
long long a[200005],b[200005],c[200005],ans[200005],sum=0;
void find(int l,int r){
	if(l==r) return ;
	int i=l,mid=(l+r)>>1;
	int j=mid+1,k=l;
	find(l,mid);
	find(mid+1,r);
	while(i<=mid&&j<=r){
		if(a[i]<=a[j]) ans[k]=a[i],k++,i++;
		else ans[k]=a[j],k++,j++,sum+=mid-i+1;
	}
	while(i<=mid){
		ans[k]=a[i];k++;i++;
	}
	while(j<=r){
		ans[k]=a[j];k++;j++;
	}
	for(int i=l;i<=r;i++){
		a[i]=ans[i];
	}
}
int main(){
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	int n;
	int js=0,jjs=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		if(i%2) b[++js]=a[i];
		else c[++jjs]=a[i];
	}
	sort(b+1,b+js+1);
	sort(c+1,c+jjs+1);
	js=0,jjs=0;
	for(int i=1;i<=n;i++){
		if(i%2) a[i]=b[++js];
		else a[i]=c[++jjs];
	} 
	find(1,n);
	printf("%lld",sum);
}
