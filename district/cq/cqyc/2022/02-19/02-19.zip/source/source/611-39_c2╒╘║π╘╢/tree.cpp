#include<bits/stdc++.h>
using namespace std;
int T,n,fa[101],van[101],mmax,ojbk; 
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	for(int wdnmd=1;wdnmd<=T;wdnmd++){
		mmax=0;
		ojbk=1;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
		scanf("%d",&fa[i]);
		mmax=max(fa[i],mmax);
		van[fa[i]]++;
	}
		for(int i=mmax;i>=mmax-(mmax/2)&&ojbk;i--){
			if(i==mmax-(mmax/2)){
				if((mmax%2==0&&van[i]!=1))
				ojbk=0;
				if((mmax%2==1&&van[i]!=2))
				ojbk=0;
			}else{
			if(van[i]<2)ojbk=0;
			}
		}
//		cout<<ojbk<<endl;
		for(int i=1;i<mmax-(mmax/2)&&ojbk;i++)
		if(van[i]>0)ojbk=0;
		if(ojbk)printf("Yes\n");
		else printf("NO\n");
		for(int i=1;i<=n;i++)van[i]=0;
	}
	return 0;
}
//Yes����ĸ��д��NOȫ����д 
