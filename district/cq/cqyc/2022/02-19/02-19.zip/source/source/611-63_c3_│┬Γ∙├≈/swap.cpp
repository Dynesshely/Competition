#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) x=-x;
	if(x>10) out(x/10);
	putchar(x%10+'0');
}
int n,a[100010],ans;
signed main()
{
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
		if(a[i]%2!=i%2)
		{
			ans++;
		}
	}
	cout<<ans/2<<'\n';
	return 0;
} 
