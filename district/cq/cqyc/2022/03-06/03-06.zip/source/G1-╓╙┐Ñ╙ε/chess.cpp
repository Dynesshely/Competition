// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
const ll N=1e3;
ll mmap[N+10][N+10];
ll lienum[N+10],tot[5];
ll n,m,k,t,ans;
//
bool check(ll po){
//	printf("a\n");
	if(lienum[po]>=k){
		memset(tot,0,sizeof(tot));
		FOR(i,lienum[po]-k+1,lienum[po]){
			++tot[mmap[po][i]];
		}
		if(tot[1]==k||tot[2]==k) return 1;
	}
//	printf("b\n");
	memset(tot,0,sizeof(tot));
	ll l=max(po-k+1,(ll)1),dt=0;
//	printf("l:%lld ",l);
	while(l+dt<=min(m,po+k-1)){
//		printf("%lld ",l+dt);
		++tot[mmap[l+dt][lienum[po]]];
		if(dt>=k&&l+dt-k>=1) --tot[mmap[l+dt-k][lienum[po]]];
		if(tot[1]==k||tot[2]==k) return 1;
		++dt;
	}
//	printf("r:%lld\n",l+dt);
//	printf("c\n");
	memset(tot,0,sizeof(tot));
	l=max(max(po-k+1,po-(lienum[po]-1)),(ll)1),dt=0;
	while(l+dt<=min(m,po+k-1)&&lienum[po]-po+l+dt<=n){
		++tot[mmap[l+dt][lienum[po]-po+l+dt]];
		if(dt>=k&&l+dt-k>=1) --tot[mmap[l+dt-k][lienum[po]-po+l+dt-k]];
		if(tot[1]==k||tot[2]==k) return 1;
		++dt;
	}
//	printf("d\n");
	memset(tot,0,sizeof(tot));
	l=max(max(po-k+1,po-(n-lienum[po])),(ll)1),dt=0;
	while(l+dt<=min(m,po+k-1)&&lienum[po]+po-l-dt>=1){
		++tot[mmap[l+dt][lienum[po]+po-l-dt]];
		if(dt>=k&&l+dt-k>=1) --tot[mmap[l+dt-k][lienum[po]+po-l-dt+k]];
		if(tot[1]==k||tot[2]==k) return 1;
		++dt;
	}
	return 0;
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=gt(),m=gt(),k=gt(),t=gt(),ans=t;
	FOR(i,1,t){
		ll po=gt();
//		printf("i:%lld po:%lld\n",i,po);
		mmap[po][++lienum[po]]=(i&1)+1;
		if(check(po)){
			ans=i;
			break;
		}
	}
	printf("%lld",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



