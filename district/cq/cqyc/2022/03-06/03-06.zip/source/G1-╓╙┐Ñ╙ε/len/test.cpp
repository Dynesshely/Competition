// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
std::mt19937 rnd(time(0));
//
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("len.in","w",stdout);
	ll MAXN=3,n=rnd()%MAXN+1,MAX2=10;
	n=4;
	printf("%lld\n",n);
	FOR(i,1,n){
		printf("%lld %lld\n",rnd()%(MAX2*2+1)-MAX2,rnd()%(MAX2*2+1)-MAX2);
	}
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



