// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
const ll N=1e6;
ll a[N+10],b[N+10],sqr[N*3+10];
//
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	ll n=gt();
	FOR(i,1,n) a[i]=gt();
	FOR(i,1,n) b[i]=gt();
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	b[n+1]=3e6;
	FOR(i,0,3e6){
		if(i*i>3e6) break;
		FOR(j,i*i,min((ll)3e6,(ll)(i+1)*(i+1)-1)){
			sqr[j]=i;
		}
	}
	ll fpo=1,ans=0;
	FOR(i,1,n){
//		printf("i:%lld a_i:%lld\n",i,a[i]);
		while(b[fpo]<a[i]) ++fpo;
		ll j=1;
		while(j<fpo){
			ll t=sqr[a[i]-b[j]];
//			printf("b_j:%lld sqr:%lld\n",b[j],t);
			if(j+1>=fpo||sqr[a[i]-b[j+1]]!=t){
				ans+=t;
				++j;
			}
			else{
				ll l=j,r=fpo;
				while(l<r){
					if(sqr[a[i]-b[mid]]==t) l=mid+1;
					else r=mid;
				}
				ans+=t*(l-j);
				j=l;
			}
		}
//		printf("+\n");
		j=fpo;
		while(j<=n){
			ll t=sqr[b[j]-a[i]];
//			printf("b_j:%lld sqr:%lld\n",b[j],t);
			if(j+1>n||sqr[b[j+1]-a[i]]!=t){
				ans+=t;
				++j;
			}
			else{
				ll l=j,r=n+1;
				while(l<r){
					if(sqr[b[mid]-a[i]]==t) l=mid+1;
					else r=mid;
				}
				ans+=t*(l-j);
				j=l;
			}
		}
	}
	printf("%lld",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



