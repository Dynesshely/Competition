// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
struct node{
	ll x,y;
};
struct node2{
	ll x,l,r;
};
const ll N=1e5;
node zb[N+10];
node2 dp1[N+10],dp2[N+10];
ll to1,to2;
//
bool cmp(node a,node b){
	return a.x<b.x||(a.x==b.x&&a.y<b.y);
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("len.in","r",stdin);
	freopen("len_bl.out","w",stdout);
	ll n=gt(),zpo=n+1;
	FOR(i,1,n) zb[i]=(node){gt(),gt()};
	sort(zb+1,zb+n+1,cmp);
	FOR(i,1,n){
		if(zb[i].x>=0){
			zpo=i;
			break;
		}
	}
	ll mmax=-1e18,mmin=1e18;
	dp1[1]=(node2){max((ll)0,zb[n].x),0,0};
	printf("dp1\n");
	printf("%lld %lld %lld\n",max((ll)0,zb[n].x),0,0);
	ROF(i,n,zpo){
		mmax=max(mmax,zb[i].y);
		mmin=min(mmin,zb[i].y);
		dp1[i-zpo+2]=(node2){max((ll)0,zb[i-1].x),mmin,mmax};
		printf("%lld %lld %lld\n",max((ll)0,zb[i-1].x),mmin,mmax);
	}
	to1=n-zpo+2;
	mmax=-1e18,mmin=1e18;
	dp2[1]=(node2){min((ll)0,zb[1].x),0,0};
	printf("dp2\n");
	printf("%lld %lld %lld\n",min((ll)0,zb[1].x),0,0);
	FOR(i,1,zpo-1){
		mmax=max(mmax,zb[i].y);
		mmin=min(mmin,zb[i].y);
		dp2[i+1]=(node2){min((ll)0,zb[i+1].x),mmin,mmax};
		printf("%lld %lld %lld\n",min((ll)0,zb[i+1].x),mmin,mmax);
	}
	to2=zpo;
	printf("afafa\n");
	ll ans=1e18;
	FOR(i,1,to1){
		FOR(j,1,to2){
			ll maxy=max(max(-dp1[i].l,-dp2[j].l),max(dp1[i].r,dp2[j].r));
			ll maxy2=max(-dp1[i].l,-dp2[j].l)+max(dp1[i].r,dp2[j].r);
			ll lans=max((dp1[i].x-dp2[j].x)*(dp1[i].x-dp2[j].x),max(maxy2*maxy2,max(dp1[i].x*dp1[i].x,dp2[j].x*dp2[j].x)+maxy*maxy));
			printf("%lld %lld %lld %lld\n",dp1[i].x,dp2[j].x,maxy,maxy2);
			ans=min(ans,lans);
		}
	}
	printf("%lld\n",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



