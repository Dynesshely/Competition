#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define int long long
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
using namespace std ;
const int M = 3e6+5 ;
const int N = 1e6+5 ;
int n,mx,ans ;
int t[M],a[N],b[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x){
	int stk[30],tp=0,v = x ;
	if(x < 0) pc('-'),x = -x ;
	do stk[++tp]=x%10,x/=10 ;while(x) ;
	while((v>=0?tp:tp-1)) pc(stk[tp--]^48) ;
}
inline int query(int le,int ri)
{
//	print(le),space,print(ri),space,print(t[ri]-t[le-1]),enter ;
	return t[ri]-t[le-1] ;
}
signed main()
{
	freopen("hard.in","r",stdin) ;
	freopen("hard.out","w",stdout) ;
	read(n) ;
	FOR(i,1,n,1) read(a[i]),mx = max(a[i],mx) ;
	FOR(i,1,n,1) read(b[i]),t[b[i]]++,mx = max(mx,b[i]) ;
	FOR(i,1,mx,1) t[i] += t[i-1] ;
//	FOR(i,1,mx,1) print(t[i]),space ;
//	enter ;
	FOR(i,1,n,1)
	{
		FOR(j,1,mx,1)
		{
			int v = j*j,vl = (j+1)*(j+1)-1 ;
			int stozzdorzorzorzzzdtaiqianglezzdwudizzdshishen = query(max(a[i]-vl,(int)0),a[i]-v) ;
			ans += j*stozzdorzorzorzzzdtaiqianglezzdwudizzdshishen ;
			if(vl >= a[i]) break ;
		}
		FOR(j,1,mx,1)
		{
			int v = j*j,vl = (j+1)*(j+1)-1 ;
			int stozzdorzorzorzzzdtaiqianglezzdwudizzdshishen = query(a[i]+v,min(mx,a[i]+vl)) ;
			ans += j*stozzdorzorzorzzzdtaiqianglezzdwudizzdshishen ;
			if(vl+a[i] >= mx) break ;
		}
	}
	print(ans) ;
	return 0 ; 
 }

