#include <bits/stdc++.h>
#define int __int128
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
using namespace std ;
const int N = 1e6+5 ;
int n,p,T,ans,m ;
int inv[N],a[N],us[N],on[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x){
	int stk[30],tp=0,v = x ;
	if(x < 0) pc('-'),x = -x ;
	do stk[++tp]=x%10,x/=10 ;while(x) ;
	while((v>=0?tp:tp-1)) pc(stk[tp--]^48) ;
}
signed main()
{
	freopen("beauty.in","r",stdin) ;
	freopen("beauty.out","w",stdout) ;
	read(T) ;
	inv[1] = us[0] = on[0] = a[0] = 1 ;  
	while(T--)
	{
		ans = 0 ;
		read(p),read(m) ;
		int k = 1 ; 
		FOR(i,2,p<<1,1) inv[i] = (inv[p%i]*(p/i))%p ;
		FOR(i,1,p<<1,1) 
			us[i] = (us[i-1]*inv[i])%p,
			on[i] = (on[i-1]*i)%p ;
		FOR(i,1,p,1) a[i] = (((on[i<<1]*us[i])%p)*us[i])%p ;
		FOR(i,0,p-1,1) ans = (ans+a[i]*k)%p,k = (k*m)%p ;
		print(ans),enter ;
	}
	return 0 ;
 }

