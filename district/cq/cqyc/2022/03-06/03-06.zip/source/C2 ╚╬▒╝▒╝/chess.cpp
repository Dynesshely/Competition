#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
using namespace std ;
const int N = 1e3+5 ;
int n,m,t,k,u,ans ;
int col[N][N],ti[N],line[12][N][N] ;
int fx[20][20] = {{0,1},{0,-1},{-1,0},{1,1},{1,-1},{-1,1},{-1,-1}} ; 
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x){
	int stk[30],tp,v = x ;
	if(x < 0) pc('-'),x = -x ;
	do stk[++tp]=x%10,x/=10 ;while(x) ;
	while((v>=0?tp:tp-1)) pc(stk[tp--]^48) ;
}
int main()
{
	freopen("chess.in","r",stdin) ;
	freopen("chess.out","w",stdout) ;
	read(n),read(m),read(k),read(t) ;
	memset(col,-1,sizeof(col)) ;
	while(t--)
	{
		read(u) ;
		if(ti[u] >= n || u >= m) continue ;
		ans++ ;
		col[u][ti[u]+1] = ti[u]&1,ti[u]++ ;
		int y = u,x = ti[u] ;
		FOR(i,0,6,1)
		{
			line[i][x][y] = 1 ;
			int X = x+fx[i][0],Y = y+fx[i][1] ;
			if(col[X][Y] == col[x][y]) line[i][x][y] += line[i][X][Y] ;
			if(line[i][x][y] == k) 
			{
				print(ans) ;
				return 0 ;
			}
		}
	}
	return 0 ;
 }

