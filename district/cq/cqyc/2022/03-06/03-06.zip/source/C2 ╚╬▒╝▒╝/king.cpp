#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
using namespace std ;
const int N = 6e3+5 ;
int n,m,q,op,l,r,x ;
int a[N],ans[N],t[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x){
	int stk[30],tp=0,v = x ;
	if(x < 0) pc('-'),x = -x ;
	do stk[++tp]=x%10,x/=10 ;while(x) ;
	while((v>=0?tp:tp-1)) pc(stk[tp--]^48) ;
}
int main()
{
	freopen("king.in","r",stdin) ;
	freopen("king.out","w",stdout) ;
	read(n),read(m),read(q) ;
	FOR(i,1,n,1) read(a[i]) ;
	while(q--)
	{
		read(op),read(l),read(r),read(x) ;
		if(op == 1)
			FOR(i,l,r,1)
			{
				a[i] = x ;
				if(!t[i]) ans[x] += t[i],t[i] = 0;
			}
		else
			FOR(i,l,r,1)
			{
				if(!a[i]) 
				{
					t[i] += x ;
					continue ;
				}
				ans[a[i]] += x ; 
			}
	}
	FOR(i,1,m,1) print(ans[i]),enter ;
	return 0 ;
 }

