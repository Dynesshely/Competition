#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int n,a[1000010],b[1000010],ton1[3000010],ton2[3000010],mx;
int main() {
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) b[i]=read(),mx=max(mx,b[i]);
	for(int i=1;i<=n;i++) ton2[b[i]]++;
	for(int i=1;i<=n;i++) {
		for(int j=1;a[i]-j*j>=-1;j++) ton1[a[i]-j*j+1]--;
		for(int j=1;a[i]+j*j<=mx;j++) ton1[a[i]+j*j]++;
	}
	long long ans=0,now=0;
	for(int i=1;i<=n;i++) now+=(int)sqrt(a[i]+1);
	for(int i=0;i<=mx;i++) {
		now+=ton1[i];ans+=now*ton2[i];
	}
	printf("%lld\n",ans);
	ans=0;
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) ans+=(int)sqrt(abs(a[i]-b[j]));
	}
	cout << ans << endl;
	return 0;
}
