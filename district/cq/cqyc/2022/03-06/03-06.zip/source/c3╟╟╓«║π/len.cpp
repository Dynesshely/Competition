#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n;
struct poi {
	ll x,y,l;
	bool operator < (const poi &oth)const {
		return y<oth.y;
	}
} p[100010];
int g[100010],ind=0,re[100010],ton[100010];
bool ok(ll h) {
	int a=1,b=1,ml=1e9,mr=1e9;
	while(p[b+1].y-p[a].y<=h) b++;
	for(int i=b+1;i<=n;i++) ton[p[i].l]++,ml=min(ml,p[i].l),mr=max(mr,p[i].l);
	ll mii=1e9;
	int A,B,C,D,heng;
	while(true) {
		A=p[a].y;B=p[b].y;C=re[ml];D=re[mr];
		mii=min(mii,max(max(pow(A,2),pow(B,2))+max(pow(C,2),pow(D,2)),D-C));
		a++;ton[p[a-1].l]++;
		ml=min(ml,p[a-1].l);mr=max(mr,p[a-1].l);
		while(p[b+1].y-p[a].y<=h) {
			b++;
			if(ton[p[b]])
		}
	}
}
int fen(int h) {
	int l=1,r=ind,mid;
	while(r>l+1) {
		mid=(l+r)/2;
		if(g[mid]<h) l=mid;
		else r=mid;
	}
	if(g[l]==h) return l;
	return r;
}
int main() {
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d%d",&p[i].x,&p[i].y);
	sort(p+1,p+1+n);
	for(int i=1;i<=n;i++) g[++ind]=p[i].x;
	sort(g+1,g+1+n);ind=unique(g+1,g+1+n)-g-1;
	for(int i=1;i<=n;i++) p[i].l=fen(p[i].x);
	for(int i=1;i<=n;i++) re[p[i].l]=p[i].x;
	return 0;
}
