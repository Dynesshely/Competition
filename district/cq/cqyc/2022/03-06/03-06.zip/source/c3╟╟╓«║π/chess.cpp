#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int n,m,k,t;
int f[2000][2000],h[2000];
int v1[4][2]={{0,1},{-1,1},{1,1},{1,0}};
int v2[4][2]={{0,-1},{1,-1},{-1,-1},{-1,0}};
int main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&t);
	int a,b;
	for(int u=1;u<=t;u++) {
		a=read();
		f[a][++h[a]]=(u%2?1:2);
		for(int i=0;i<4;i++) {
			b=0;
			for(int j=1;j<k&&f[a+v1[i][0]*j][h[a]+v1[i][1]*j]==f[a][h[a]];j++) b++;
			for(int j=1;j<k&&f[a+v2[i][0]*j][h[a]+v2[i][1]*j]==f[a][h[a]];j++) b++;
			if(b+1>=k) {
				printf("%d\n",u);return 0;
			}
		}
	}
	return 0;
}
