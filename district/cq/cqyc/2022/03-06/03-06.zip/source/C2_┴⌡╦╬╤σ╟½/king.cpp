#include <bits/stdc++.h>
using namespace std;
int n,m,q,a[5003],opt,l,r,x;
long long b[5003];
int main(){
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(;q;q--){
		scanf("%d%d%d%d",&opt,&l,&r,&x);
		if(opt==1){
			for(;l<=r;l++) a[l]=x;
		}else{
			for(;l<=r;l++) b[a[l]]+=(long long)x;
		}
	}
	for(int i=1;i<=m;i++) printf("%lld\n",b[i]);
	return 0;
}
