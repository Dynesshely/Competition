#include <bits/stdc++.h>
using namespace std;
int n;
struct Point{
	int x,y;
}a[21];
long long ans=1152921504606846976;
long long dist(){
	long long ret=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++) ret=max(ret,1ll*(a[i].x-a[j].x)*(a[i].x-a[j].x)+1ll*(a[i].y-a[j].y)*(a[i].y-a[j].y));
	}
	return ret;
}
void dfs(int now){
	if(now>n){ans=min(ans,dist());return;}
	int xx=a[now].x,yy=a[now].y;
	a[now].x=0;dfs(now+1);a[now].x=xx;
	a[now].y=0;dfs(now+1);a[now].y=yy;
}
int main(){
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d%d",&a[i].x,&a[i].y);
	dfs(1);
	cout << ans;
	return 0;
}
