#include <bits/stdc++.h>
using namespace std;
int n,m,k,t,x,a[1013][1013],top[1013],col=1,M;
void Print(){
	cout << "###################\n";
	cout << "##a##\n";
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++) cout << a[i][j] << ' ';
		cout << endl;
	}
	cout << "##top##\n";
	for(int i=1;i<=n;i++) cout << top[i] << ' ';
	cout << endl;
	cout << "###################\n\n";
	return;
}
void add(){
	a[top[x]+1][x]=col;top[x]++;M=max(M,top[x]);return;
}
bool li(){
	for(int i=1;i<=M;++i){
//		cout << "NNN " << i << endl;
		for(int j=1;j<=n;++j){
//			cout << j << ' ' << a[i][j] << endl;
			if(top[j]<i) continue;
//			cout << "this exist\n";
			bool ok=1;int fr=a[i][j];
			if(j+k-1<=n){
//				cout << "Q1\n";
				int lim=j+k;
				for(int e=j+1;e<lim;++e){
					if(a[i][e]!=fr||top[e]<i){ok=0;break;}
				}
//				if(ok) cout << "111\n";
				if(ok) return 1;
			}
			ok=1;
			if(top[j]-i>=k-1){
//				cout << "Q2\n";
				int lim=i+k;
				for(int e=i+1;e<lim;++e){//cout<<"FUCKCCF"<<endl;
					if(a[e][j]!=fr){ok=0;break;}
				}
//				if(ok) cout << "222\n";
				if(ok) return 1;
			}
			ok=1;
//			cout << "Q3\n";
			for(int e=1;e<k;e++){
				if(a[e+i][e+j]!=fr){ok=0;break;}
			}
//			if(ok) cout << "333\n";
			if(ok) return 1;
			ok=1;
			if(i>=k){
//				cout << "Q4\n";
				for(int e=1;e<k;e++){
					if(a[e-i][e+j]!=fr){ok=0;break;}
				}
//				if(ok) cout << "444\n";
				if(ok) return 1;
			}
		}
	}
	return 0;
}
void solve(){
	memset(a,-1,sizeof(a));
	for(int i=1;i<=t;i++){
		scanf("%d",&x);
		add();col=1-col;
//		Print();
		if(li()){
//			cout << "----------------------------------------------\n";
			printf("%d",i);break;
		}
	}
	return;
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d%d%d",&m,&n,&k,&t);solve();return 0;
}
