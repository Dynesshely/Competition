#include <bits/stdc++.h>
using namespace std;
int n;
namespace S1{
	long long a[2003],b[2003],ans;
	void solve(){
		for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
		for(int i=1;i<=n;i++) scanf("%lld",&b[i]);
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++) ans+=sqrt(abs(a[i]-b[j]));
		}
		cout << ans;return;
	}
}
int main(){
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	scanf("%d",&n);
	S1::solve();
	return 0;
}
