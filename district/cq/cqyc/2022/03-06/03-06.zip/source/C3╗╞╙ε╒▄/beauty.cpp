#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 1e6+10;
int T,ans,p,l;
int a[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int q_pow(int x,int k)
{
	if(k==0) return 1;
	if(k==1) return x%p;
	int l = q_pow(x,k/2);
	l = (l*l)%p;
	if(k&1) return (l*x)%p;
	return l;
}
int c(int n,int m)
{
	if(n>=p) return 0;
	return (a[n]*q_pow(a[m]*a[m]%p,p-2))%p;
}
signed main()
{
	freopen("beauty.in","r",stdin);
	freopen("beauty.out","w",stdout);
	T = read(),a[0] = 1;
	while(T--)
	{
		p = read(),l = read(),ans = 0;
		if(p>1e5)
		{
			printf("%lld",p-1);
			continue;
		}
		for(int i = 1;i<=p;i++) a[i]=(a[i-1]*i)%p;
		for(int i = 0;i<p;i++) ans = (ans+c(2*i,i))%p;
		ans = (ans*l)%p;
		printf("%lld\n",ans);
	}
	return 0;
}
