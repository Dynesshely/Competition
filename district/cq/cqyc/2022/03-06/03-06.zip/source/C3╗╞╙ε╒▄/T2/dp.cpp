#include<bits/stdc++.h>
#include<windows.h>
using namespace std;

inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
signed main()
{
	for(int i = 1;i<=1000;i++)
	{
		printf("%d:\n",i);
		system("random.exe");
		system("bf.exe");
		
		system("hard.exe");
		if(system("fc hard.out hard.ans"))
		{
			printf("WA");
			return 0;
		}
		printf("AC\n");
	}
	return 0;
}


