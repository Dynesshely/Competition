#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 3e6+10;
int n,ma,ans,r;
int a[MAX],b[MAX],l[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int query(int x,int y)
{
	if(y<0 or x>ma) return 0;
	if(x<0) x = 0;
	else x = a[x-1];
	if(y>ma) y = a[ma];
	else y = a[y];
	return y-x;
}
signed main()
{
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	n = read();
	for(int i = 1;i<=n;i++) r=read(),a[r]++,ma=max(ma,r);
	for(int i = 1;i<=ma;i++) a[i]+=a[i-1];
	for(int i = 1;i<=n;i++) b[i]=read();
	for(int i = 1;i<=2e3;i++) l[i]=i*i;
	for(int i = 1;i<=n;i++)
		for(int j = 1;;j++)
		{
			if(b[i]-l[j]<0 and b[i]+l[j]>ma) break; 
			ans+=j*(query(b[i]-l[j+1]+1,b[i]-l[j])+query(b[i]+l[j],b[i]+l[j+1]-1));
		}
	printf("%lld",ans);
	return 0;
}


