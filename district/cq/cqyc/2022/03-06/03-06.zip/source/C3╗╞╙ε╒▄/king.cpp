#include<bits/stdc++.h>
using namespace std;
const int MAX = 5e5+10;
struct node{
	int op,l,r,x;
}q[MAX];
int n,m,Q,f;
int a[MAX],ans[MAX],ls[4*MAX],txt[4*MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
void change1(int lr)
{
	if(ls[lr<<1]==ls[lr<<1|1]) ls[lr] = ls[lr<<1];
} 
void build1(int l,int r,int lr)
{
	if(l==r) 
	{
		ls[lr] = a[l];
		return;
	}
	int mid = (l+r)>>1;
	build1(l,mid,lr<<1);
	build1(mid+1,r,lr<<1|1);
	change1(lr);
}
void pushdown1(int lr)
{
	if(!txt[lr]) return;
	ls[lr<<1]=ls[lr<<1|1]=txt[lr<<1]=txt[lr<<1|1]=txt[lr];
	txt[lr] = 0;
}
void add1(int l,int r,int L,int R,int x,int lr)
{
	if(l>=L and r<=R) 
	{
		ls[lr] = x,txt[lr] = x;
		return;
	}
	pushdown1(lr);
	int mid = (l+r)>>1;
	if(mid>=L) add1(l,mid,L,R,x,lr<<1);
	if(mid<R) add1(mid+1,r,L,R,x,lr<<1|1);
	change1(lr);
}
int query1(int l,int r,int x,int lr)
{
	if(l==r) return ls[lr];
	pushdown1(lr);
	int mid = (l+r)>>1;
	if(x<=mid) return query1(l,mid,x,lr<<1);
	return query1(mid+1,r,x,lr<<1|1);
}
void st1()
{
	build1(1,n,1);
	for(int i = 1;i<=Q;i++)
	{
		if(q[i].op==1) add1(1,n,q[i].l,q[i].r,q[i].x,1);
		if(q[i].op==2) for(int j = q[i].l;j<=q[i].r;j++) ans[query1(1,n,j,1)]+=q[i].x;
	}
	return;
}
void st2()
{
	return;
}
signed main()
{
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	n = read(),m = read(),Q = read();
	for(int i = 1;i<=n;i++) a[i] = read(); 
	for(int i = 1;i<=Q;i++) 
	{
		q[i] = (node){read(),read(),read(),read()};
		if(q[i].op==1 and q[i].l!=q[i].r) f = 1;
	}
//	if(!f) st2();
	st1();
	for(int i = 1;i<=m;i++) printf("%d\n",ans[i]);
	return 0;
}


