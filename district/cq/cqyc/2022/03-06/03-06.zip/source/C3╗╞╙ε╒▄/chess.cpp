#include<bits/stdc++.h>
using namespace std;
const int MAX = 1e3+10;
int n,m,k,t,l;
int s[MAX],a[MAX][MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
bool check(int x,int y)
{
	int cnt=0;
	for(int i=x-1,j=y+1;i>=1 and j<=n and a[i][j]==a[x][y] and cnt<=k;i--,j++) cnt++;
	for(int i=x+1,j=y-1;i<=m and j>=1 and a[i][j]==a[x][y] and cnt<=k;i++,j--) cnt++;
	if(cnt>=k) return true;
	cnt = 0;
	for(int i=x+1;i<=m and a[i][y]==a[x][y] and cnt<=k;i++) cnt++;
	for(int i=x-1;i>=1 and a[i][y]==a[x][y] and cnt<=k;i++) cnt++;
	if(cnt>=k) return true;
	cnt = 0;
	for(int i=y+1;i<=n and a[x][i]==a[x][y] and cnt<=k;i++) cnt++;
	for(int i=y-1;i>=1 and a[x][i]==a[x][y] and cnt<=k;i++) cnt++;
	if(cnt>=k) return true;
	return false;
}
signed main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n = read(),m = read(),k = read(),t = read();
	for(int i = 1;i<=t;i++)
	{
		l = read();
		a[l][++s[l]] = i%2+1;
		if(check(l,s[l])) 
		{
			printf("%d",i);
			return 0;
		}
	}
	return 0;
}

