#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 1e6+10;
int n,ma,ans;
int a[MAX],b[MAX],l[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int Abs(int x)
{
	if(x<0) return -x;
	return x;
}
signed main()
{
	freopen("hard.in","r",stdin);
	freopen("hard.ans","w",stdout);
	n = read();
	for(int i = 1;i<=n;i++) a[i] = read(),ma = max(a[i],ma);
	for(int i = 1;i<=n;i++) b[i] = read(),ma = max(b[i],ma);
	for(int i = 1;i*i<=1e6;i++) l[i*i] = i;
	for(int i = 1;i<=1e6;i++) if(l[i-1]>l[i]) l[i]=l[i-1];
	for(int i = 1;i<=n;i++)
		for(int j = 1;j<=n;j++) ans+=l[Abs(b[i]-a[j])];
	printf("%lld",ans);  
	return 0;
}


