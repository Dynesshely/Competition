#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 100005;
int inv[N];
int a,b,mod;

inline int ksm(int a,int b){
	int ans = 1;
	while(b){
		if(b&1)
			a = a*ans%mod;
		a = a*a%mod;
		b >>= 1;
	}
	return ans;
}

inline void init(){
	
	for(int k=)
}

int main(){
	init();
	int q;
	scanf("%d",&q);
	while(q--){
		scanf("%d%d",&a,&b);
		mod = a;
	}
}
