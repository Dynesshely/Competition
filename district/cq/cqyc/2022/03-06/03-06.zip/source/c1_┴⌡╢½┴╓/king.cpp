#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

//int pp;

namespace fastio{
	inline int in(){
	    int x=0,f=1;
	    char ch=getchar();
	    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	    return x*f;
	}
	int stk[30],tp;
	void out(int x){
	    do stk[++tp]=x%10,x/=10;while(x);
	    while(tp)putchar(stk[tp--]^48);
	}
}
using fastio::in;
using fastio::out;

const int N = 500005,M = 750;
class Ayaka{
	public:
		int block[M],siz;
		bool flag;
		inline int& operator [] (const int x){
			return block[x];
		}
		inline void fill(int x){
			flag = true;
			block[1] = x;
		}
		inline void fill_true(){
			if(flag){
				flag = false;
				for(int k=2;k<=siz;k++)
					block[k] = block[1];
			}
		}
		inline void push_back(int x){
			block[++siz] = x;
		}
		inline int color(){
			return block[1];
		}
}a[M];
int block,len = 1;
int num[N],ans[N];
int n,m,q;

namespace stb1{
	const int N = 500005;
	int a[N],ans[N];
	
	signed main(){
		for(int k=1;k<=n;k++)
			a[k] = in();
		while(q--){
			int ops=in(),l=in(),r=in(),x=in();
			if(ops==1)
				for(int k=l;k<=r;k++)
					a[k] = x;
			else
				for(int k=l;k<=r;k++)
					ans[a[k]] += x;
		}
		for(int k=1;k<=m;k++){
			out(ans[k]);
			putchar('\n');
		}
		return 0;
	}
}
//int ppp;

signed main(){
	//printf("%lf",(&ppp-&pp)/1024.0/1024.0);
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	n = in(),m = in(),q = in();
	if(n<=5000&&m<=5000&&q<=5000)
		return stb1::main();
	block = sqrt(n)+1;
	for(int k=1;(k-1)*block<=n;k++){
		for(int j=1;j<=block;j++)
			num[(k-1)*block+j] = k;
	}
	for(int k=1;k<=n;k++){
		a[len].push_back(in());
		if(a[len].siz==block&&k<n)
			len++;
	}
	while(q--){
		int ops=in(),l=in(),r=in(),x=in();
		if(ops==1){
			while(l<=r){
				a[num[l]].fill_true();
				if(num[l-1]!=num[l])// !(l%block)
					break;
				a[num[l]][l-(num[l]-1)*block] = x;
				l++;
			}
			while(l<=r){
				if(num[l]==num[r])
					break;
				a[num[l]].fill(x);
				l += a[num[l]].siz;
			}
			while(l<=r){
				a[num[l]].fill_true();
				a[num[l]][l-(num[l]-1)*block] = x;
				l++;
			}
		}
		else{
			while(l<=r){
				a[num[l]].fill_true();
				if(num[l-1]!=num[l])
					break;
				ans[a[num[l]][l-(num[l]-1)*block]] += x;
				l++;
			}
			while(l<=r){
				if(num[l]==num[r])
					break;
				if(a[num[l]].flag){
					ans[a[num[l]].color()] += a[num[l]].siz*x;
					l += a[num[l]].siz;
				}
				else{
					int twei = num[l];
					for(int j=1;j<=a[twei].siz;j++){
						if(l>r)
							break;
						ans[a[twei][j]] += x;
						l++;
					}
				}
			}
			while(l<=r){
				a[num[l]].fill_true();
				ans[a[num[l]][l-(num[l]-1)*block]] += x;
				l++;
			}
		}
	}
	for(int k=1;k<=m;k++){
		out(ans[k]);
		putchar('\n');
	}
	return 0;
}
