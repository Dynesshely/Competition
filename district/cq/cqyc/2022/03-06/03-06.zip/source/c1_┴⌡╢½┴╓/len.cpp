#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

typedef pair<int,int> PII;
const int N = 20,INF = 0x3f3f3f3f;
int ans = INF;
PII a[N];
int n;

void dfs(int len){
	if(len>n){
		int tmpans = 0;
		for(int k=1;k<=n;k++)
			for(int j=k+1;j<=n;j++)
				tmpans = max(tmpans,(a[k].first-a[j].first)*(a[k].first-a[j].first)+(a[k].second-a[j].second)*(a[k].second-a[j].second));
		ans = min(ans,tmpans);
		return;
	}
	int tmp = 0;
	swap(tmp,a[len].first);
	dfs(len+1);
	swap(tmp,a[len].first);
	swap(tmp,a[len].second);
	dfs(len+1);
	swap(tmp,a[len].second);
}

int main(){
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	scanf("%d",&n);
	for(int k=1;k<=n;k++)
		scanf("%d%d",&a[k].first,&a[k].second);
	dfs(1);
	printf("%d",ans);
	return 0;
}
