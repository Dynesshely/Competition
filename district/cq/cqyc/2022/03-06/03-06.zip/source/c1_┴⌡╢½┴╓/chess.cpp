#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 1005;
class Ayaka{
	public:
		int sta[N],siz;
		inline int operator [] (const int wei){
			return sta[wei];
		}
		inline void push_back(int num){
			sta[++siz] = num;
		}
		inline int top(){
			return sta[siz];
		}
}a[N];
int n,m,K,t;

inline int check_n(int x){
	if(a[x].siz<K)
		return 1;
	int len = 0;
	for(int k=a[x].siz;k;k--)
		if(a[x][k]==a[x].top())
			len++;
		else
			break;
	return len;
}

inline int check_m(int x){
	int len = 1;
	for(int k=x-1;k;k--){
		if(a[k].siz<a[x].siz)
			break;
		if(a[k][a[x].siz]==a[x].top())
			len++;
		else
			break;
	}
	for(int k=x+1;k<=m;k++){
		if(a[k].siz<a[x].siz)
			break;
		if(a[k][a[x].siz]==a[x].top())
			len++;
		else
			break;
	}
	return len;
}

inline int check_1(int x){
	int len1 = 1;
	for(int k=x-1;x;k--){
		if(a[k].siz<a[x].siz+len1)
			break;
		if(a[k][a[x].siz+len1]==a[x].top())
			len1++;
		else
			break;
	}
	int len2 = 1;
	for(int k=x+1;x<=m;k++){
		if(a[k].siz<a[x].siz-len2||a[x].siz-len2<=0)
			break;
		if(a[k][a[x].siz-len2]==a[x].top())
			len2++;
		else
			break;
	}
	return len1+len2-1;
}

inline int check_2(int x){
	int len1 = 1;
	for(int k=x-1;x;k--){
		if(a[k].siz<a[x].siz-len1||a[x].siz-len1<=0)
			break;
		if(a[k][a[x].siz-len1]==a[x].top())
			len1++;
		else
			break;
	}
	int len2 = 1;
	for(int k=x+1;x<=m;k++){
		if(a[k].siz<a[x].siz+len2)
			break;
		if(a[k][a[x].siz+len2]==a[x].top())
			len2++;
		else
			break;
	}
	return len1+len2-1;
}

int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&K,&t);
	for(int k=1;k<=t;k++){
		int x;
		scanf("%d",&x);
		a[x].push_back(k&1);
		//cout << check_n(x) << " " << check_m(x) << " " << check_1(x) << " " << check_2(x) << endl;
		if(check_n(x)>=K){
			printf("%d",k);
			return 0;
		}
		if(check_m(x)>=K){
			printf("%d",k);
			return 0;
		}
		if(check_1(x)>=K){
			printf("%d",k);
			return 0;
		}
		if(check_2(x)>=K){
			printf("%d",k);
			return 0;
		}
	}
	return 0;
}
