#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
	inline int in(){
	    int x=0,f=1;
	    char ch=getchar();
	    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	    return x*f;
	}
	int stk[30],tp;
	void out(int x){
	    do stk[++tp]=x%10,x/=10;while(x);
	    while(tp)putchar(stk[tp--]^48);
	}
}
using fastio::in;
using fastio::out;

const int N = 100005,M = 300005;
int cnta[M],cntb[M];
int a[N],b[N];
int n,m;

int main(){
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	int len = in();
	for(int k=1;k<=len;k++){
		int x = in();
		if(!cnta[x])
			a[++n] = x;
		cnta[x]++;
	}
	for(int k=1;k<=len;k++){
		int x = in();
		if(!cntb[x])
			b[++m] = x;
		cntb[x]++;
	}
	int ans = 0;
	for(int k=1;k<=n;k++)
		for(int j=1;j<=m;j++)
			ans += cnta[a[k]]*cntb[b[j]]*(int)sqrt(abs(a[k]-b[j]));
	printf("%d",ans);
	return 0;
}
