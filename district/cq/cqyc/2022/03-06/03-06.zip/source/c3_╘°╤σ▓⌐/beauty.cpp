#include <bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
const int N=500005;
int t,p,m,jc[N],ans;
int Pow(int a,int b) {
	if(b==0) return 1;
	if(b==1) return a%p;
	int c=Pow(a,b>>1);
	if(b&1) return c*c%p*a%p;
	else return c*c%p;
}
int C(int x,int y) {
	return jc[y]*Pow(jc[x]*jc[y-x]%p,p-2)%p;
}
int A(int x) {
//	x+=1;
	int y=x*2;
	return jc[y]*Pow(jc[x]*jc[y-x]%p,p-2)%p;
}
//int c[105][105];
signed main() {
	freopen("beauty.in","r",stdin);
	freopen("beauty.out","w",stdout);
//	c[0][0]=1;
//	for(int i=1;i<=100;++i) {
//		for(int j=1;j<=i;++j) c[i][j]=c[i-1][j-1]+c[i-1][j],cout<<c[i][j]<<" ";
//		cout<<endl;
//	}
	t=read();
	while(t--) {
		p=read(),m=read();
//		memset(jc,0,sizeof jc);
		jc[0]=1;
		for(register int i=1;i<=p*2;++i) jc[i]=jc[i-1]*i%p;
//		cerr<<A(0)<<" "<<A(1)<<" "<<A(2)<<" "<<A(3)<<" "<<A(4)<<" "<<A(5)<<endl;
		ans=0;
		for(register int i=0;i<p;++i) {
			ans=(ans+A(i)*Pow(m,i)%p)%p;
//			cerr<<i<<" ";
		}
//		cerr<<endl<<ans<<endl;
		write(ans),putchar('\n');
	}
	return 0;
}
/*
3
2 1
955919 377399
571471 441849

1
955918
571470
*/
