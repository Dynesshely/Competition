#include <bits/stdc++.h>
#define int long long
using namespace std;
bool ppp;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
const int N=500005;
int n,m,q,a[N],b[N];
void sub1() {
	while(q--) {
		int opt=read(),l=read(),r=read(),x=read();
		if(opt==1) for(int i=l;i<=r;++i) a[i]=x;
		else for(int i=l;i<=r;++i) b[a[i]]+=x;
	}
	for(int i=1;i<=m;++i) write(b[i]),putchar('\n');
	exit(0);
}
#define ls (x<<1)
#define rs (x<<1|1)
#define mid ((l+r)>>1)
int t[N<<2],tag[N<<2];
void build(int x,int l,int r) {
	if(l==r) {
		t[x]=a[l];
//		cerr<<x<<" "<<l<<" "<<r<<" "<<t[x]<<endl;
		return;
	}
	build(ls,l,mid);
	build(rs,mid+1,r);
	t[x]=t[ls]+t[rs];
}
void pushup(int x,int l,int r,int v) {
	t[x]=(r-l+1)*v;
	tag[x]=v;
}
void pushdown(int x,int l,int r) {
	if(tag[x]==-1) return;
	pushup(ls,l,mid,tag[x]);
	pushup(rs,mid+1,r,tag[x]);
	tag[x]=-1;
}
void modify(int x,int l,int r,int L,int R,int v) {
	if(l==L&&r==R) {
		pushup(x,l,r,v);
		return;
	}
	pushdown(x,l,r);
	if(R<=mid) modify(ls,l,mid,L,R,v);
	else if(L>mid) modify(rs,mid+1,r,L,R,v);
	else modify(ls,l,mid,L,mid,v),modify(rs,mid+1,r,mid+1,R,v);
	t[x]=t[ls]+t[rs];
}
int query(int x,int l,int r,int g) {
//	cerr<<x<<" "<<l<<" "<<r<<" "<<g<<" "<<t[x]<<endl;
	if(l==r) return t[x];
	pushdown(x,l,r);
	if(g<=mid) return query(ls,l,mid,g);
	else return query(rs,mid+1,r,g);
}
bool pppp;
signed main() {
//	cerr<<(&ppp-&pppp)/1024.0/1024.0<<endl;
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;++i) a[i]=read();
	if(n<=5000&&m<=5000&&q<=5000) sub1();
	build(1,1,n);
	memset(tag,-1,sizeof tag);
//	cerr<<t[4];
//	cerr<<"\n\n";
//	for(int i=1;i<=n;++i) cerr<<query(1,1,n,i)<<"\n";
	while(q--) {
		int opt=read(),l=read(),r=read(),x=read();
		if(opt==1) modify(1,1,n,l,r,x);
		else for(int i=l;i<=r;++i) b[query(1,1,n,i)]+=x;
	}
	for(int i=1;i<=m;++i) write(b[i]),putchar('\n');
	return 0;
}
/*
3 3 3
1 2 3
2 2 3 1
1 3 3 2
2 1 3 2

2
5
1
*/
