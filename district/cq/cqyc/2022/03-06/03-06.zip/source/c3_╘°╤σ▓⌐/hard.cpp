#include <bits/stdc++.h>
#define int long long
using namespace std;
bool ppp;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
const int N=1000005,M=3000005;
int n,ma,ans,a[N],b[N],ta[M],tb[M],cnt[M];
void sub1() {
	for(int i=1;i<=n;++i)
	for(int j=1;j<=n;++j)
		ans+=floor(sqrt(1.0*abs(a[i]-b[j])));
	cout<<ans;
	exit(0);
}
void sub2() {
	for(int i=1;i<=n;++i) ++ta[a[i]],++tb[b[i]];
	for(int i=1;i<=ma;++i)
	for(int j=1;j<=ma;++j)
		ans+=ta[i]*tb[j]*floor(sqrt(1.0*abs(i-j)));
	cout<<ans;
	exit(0);
}
void sub3() {
	
	exit(0);
}
bool pppp;
signed main() {
//	cerr<<(&ppp-&pppp)/1024.0/1024.0<<endl;
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) a[i]=read(),ma=max(ma,a[i]);
	for(int i=1;i<=n;++i) b[i]=read(),ma=max(ma,b[i]);
	if(n<=2000) sub1();
	if(ma<=2000) sub2();
	sub3();
	return 0;
}
/*
4
1 2 3 4
2 3 3 3

12
*/
