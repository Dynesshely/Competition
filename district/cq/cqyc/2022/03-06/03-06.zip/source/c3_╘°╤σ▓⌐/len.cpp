#include <bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
const int N=100005;
int n,ans;
struct node {
	int x,y;
} a[N];
int b[N];
int D() {
	int res=0;
	for(int i=1;i<=n;++i)
	for(int j=i+1;j<=n;++j) {
		int aa=a[i].x,bb=a[i].y,cc=a[j].x,dd=a[j].y;
		if(b[i]) aa=0;
		else bb=0;
		if(b[j]) cc=0;
		else dd=0;
		res=max(res,(aa-cc)*(aa-cc)+(bb-dd)*(bb-dd));
	}
	return res;
}
void dfs(int x) {
	if(x==15) {
		ans=min(D(),ans);
		return;
	}
	b[x+1]=0;
	dfs(x+1);
	b[x+1]=1;
	dfs(x+1);
}
void sub1() {
	ans=1e18;
	dfs(0);
	cout<<ans;
	exit(0);
}
void lie() {
	for(int i=1;i<=n;++i)
		if(abs(a[i].x)>abs(a[i].y)) b[i]=1;
	for(int i=1;i<=n;++i) cerr<<b[i]<<" ";
	cout<<D();
	exit(0);
}
signed main() {
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) a[i].x=read(),a[i].y=read();
	if(n<=15) sub1();
	lie();
	return 0;
}
/*
3
1 5
-2 -3
4 -3

10

2
10 1
1 10

2
*/
