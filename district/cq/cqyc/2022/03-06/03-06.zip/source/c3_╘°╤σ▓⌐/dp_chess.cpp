#include <bits/stdc++.h>
using namespace std;
signed main() {
	while(1) {
		system("data_chess.exe");
		system("chess.exe");
		system("ljchess.exe");
		if(system("fc chess.out ljchess.out")) break;
	}
	return 0;
}
/*
*/

