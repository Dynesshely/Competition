#include <bits/stdc++.h>
using namespace std;
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
signed main() {
	freopen("chess.in","w",stdout);
	srand(time(0));
	int n=1000,m=1000,k=9,t=1000000;
	printf("%d %d %d %d\n",n,m,k,t);
	for(int i=1;i<=t;++i) write(rand()%m+1),putchar(' ');
	return 0;
}
/*
*/

