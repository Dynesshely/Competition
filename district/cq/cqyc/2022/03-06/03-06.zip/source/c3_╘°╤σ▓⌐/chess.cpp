#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
} 
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
const int N=1005;
int n,m,k,t,a[N][N],cnt[N];
signed main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read(),k=read(),t=read();
	for(register int i=1;i<=t;++i) {
		int y=read(),c=(i&1)+1,x=++cnt[y];
		a[x][y]=c;
		int tot=0;
		for(int i=x;i;--i) {
			if(a[i][y]!=c||tot==k)  break;
			++tot;
		}
		if(tot>=k) {cout<<i;return 0;}
		tot=0;
//		cerr<<i<<"\n";
		for(int i=y;i;--i) {
//			cerr<<a[x][i]<<" ";
			if(a[x][i]!=c||tot==k)  break;
			++tot;
		}
		for(int i=y+1;i<=m;++i) {
//			cerr<<a[x][i]<<" ";
			if(a[x][i]!=c||tot==k)  break;
			++tot;
		}
//		cerr<<"\n"<<tot<<"\n\n";
		if(tot>=k) {cout<<i;return 0;}
		tot=0;
		for(int i=0;;++i) {
			if(a[x-i][y-i]!=c||tot==k)  break;
			++tot;
		}
		if(tot>=k) {cout<<i;return 0;}
		tot=0;
		for(int i=0;;++i) {
			if(a[x-i][y+i]!=c||tot==k)  break;
			++tot;
		}
		if(tot>=k) {cout<<i;return 0;}
	}
	return 0;
}
/*
5 5 2 3
1 2 1

3
*/
