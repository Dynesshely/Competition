#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+7;
int n,len1,len2;
long double bx1[maxn],bx2[maxn];
long double mx[maxn][2],mi[maxn][2];
long long ans;
struct nodep{
	long double x,y;
}p[maxn],np[maxn],nnp[maxn],ap[maxn],bp[maxn];
struct node{
	long double x,y;
	int id;
}xp[maxn];
void init(){
	ans=1e18;
	return ;
}
void reinit(){
	memset(mx,-62,sizeof(mx));
	memset(mi,0x3f3f3f3f,sizeof(mi));
	len1=len2=0;
	return ;
}
bool cmp(nodep a,nodep b){
	return a.y>b.y;
}
bool cmp2(node a,node b){
	return a.x<b.x;
}
bool cmp3(nodep a,nodep b){
	return a.x<b.x;
}
//void solve(){
//	reinit();
//	sort(np+1,np+n+1,cmp);
//	int l,r,mid,j,L,R,U,D,cnt=0,w;
//	long double dis;
//	bool flag;
//	for(int i=1;i<=n&&np[i].y>=0;i++){
//		if(np[i].x>0){
//			nnp[++cnt]=np[i];
//			xp[cnt]=(node){np[i].x,np[i].y,cnt};
//		}
//	}
//	sort(xp+1,xp+n+1,cmp2);
//	sort(np+1,np+n+1,cmp3);
//	for(int i=1;i<=n;i++){
//		if(np[i].x>0)bx1[++len1]=np[i].x;
//		else bx2[++len2]=np[i].x;
//	}
//	sort(bx1+1,bx1+len1+1);
//	sort(bx2+1,bx2+len2+1);
//	len1=unique(bx1+1,bx1+len1+1)-len1-1;
//	len2=unique(bx2+1,bx2+len2+1)-len2-1;
//	for(int i=1;i<=n;i++){
//		if(np[i].x>0)break;
//		w=lower_bound(bx2+1,bx2+len2+1,np[i].x)-bx2;
//		mi[w][0]=min(mi[w-1][0],np[i].y);
//		mx[w][0]=max(mx[w-1][0],np[i].y);
//	}
//	for(int i=n;i>=1;i--){
//		if(np[i].x<=0)break;
//		w=lower_bound(bx1+1,bx1+len1+1,np[i].x)-bx1;
//		mi[w][1]=min(mi[w+1][1],np[i].y);
//		mx[w][1]=max(mx[w+1][1],np[i].y);
//	}
//	for(int i=1;i<cnt;i++){
//		l=1,r=cnt;
//		while(l<=r){
//			mid=(l+r)/2;
//			if(xp[mid].id==i)mid++;
//			j=mid;
//			dis=sqrt((nnp[i].x-xp[j].x)*(nnp[i].x-xp[j].x)+(nnp[i].y-xp[j].y)*(nnp[i].y-xp[j].y));
//			L=max(-xp[j].x,xp[j].x-dis);
//			R=xp[j].x;
//			U=nnp[i].y;
//			D=max(-nnp[i].y,nnp[i].y-dis);
//			flag=1;
//			w=lower_bound(bx2+1,bx2+len2+1,L)-bx2;
//			flag&=(mi[w][0]>=D);
//			flag&=(mx[w][0]<=U);
//			w=lower_bound(bx1+1,bx1+len1+1,R)-bx1;
//			flag&=(mi[w][1]>=D);
//			flag&=(mi[w][1]<=U);
//			if(flag){
//				ans=min(ans,(long long)((nnp[i].x-xp[j].x)*(nnp[i].x-xp[j].x)+(nnp[i].y-xp[j].y)*(nnp[i].y-xp[j].y)));
//				l=mid+1;
//			}
//			else{
//				r=mid-1;
//				if(xp[r].id==i)r--;
//			}
//		}
//	}
//	l=1,r=cnt-1;
//	while(l<=r){
//		mid=(l+r)/2;
//		if(xp[mid].id==i)mid++;
//		j=mid;
//		dis=sqrt((nnp[i].x-xp[j].x)*(nnp[i].x-xp[j].x)+(nnp[i].y-xp[j].y)*(nnp[i].y-xp[j].y));
//		L=max(-xp[j].x,xp[j].x-dis);
//		R=xp[j].x;
//		U=nnp[i].y;
//		D=max(-nnp[i].y,nnp[i].y-dis);
//		flag=1;
//		w=lower_bound(bx2+1,bx2+len2+1,L)-bx2;
//		flag&=(mi[w][0]>=D);
//		flag&=(mx[w][0]<=U);
//		w=lower_bound(bx1+1,bx1+len1+1,R)-bx1;
//		flag&=(mi[w][1]>=D);
//		flag&=(mi[w][1]<=U);
//		if(flag){
//			ans=min(ans,(long long)((nnp[i].x-xp[j].x)*(nnp[i].x-xp[j].x)+(nnp[i].y-xp[j].y)*(nnp[i].y-xp[j].y)));
//			l=mid+1;
//		}
//		else{
//			r=mid-1;
//			if(xp[r].id==i)r--;
//		}
//	}
//	return ;
//}
//void solve2(){
//	reinit();
//	int l,r,mid,j,L,R,U,D,cnt1=0,cnt2=0,w;
//	long double dis;
//	bool flag;
//	sort(np+1,np+n+1,cmp3);
//	for(int i=1;i<=n&&np[i].y>=0;i++){
//		if(np[i].x<=0)ap[++cnt1]=np[i];
//		else bp[++cnt2]=np[i];
//		xp[i]=(node){np[i].x,np[i].y,cnt};
//	}
//	sort(xp+1,xp+n+1,cmp2);
//	sort(np+1,np+n+1,cmp3);
//	for(int i=1;i<=n;i++){
//		if(np[i].x>0)bx1[++len1]=np[i].x;
//		else bx2[++len2]=np[i].x;
//	}
//	sort(bx1+1,bx1+len1+1);
//	sort(bx2+1,bx2+len2+1);
//	len1=unique(bx1+1,bx1+len1+1)-len1-1;
//	len2=unique(bx2+1,bx2+len2+1)-len2-1;
//	for(int i=1;i<=n;i++){
//		if(np[i].x>0)break;
//		w=lower_bound(bx2+1,bx2+len2+1,np[i].x)-bx2;
//		mi[w][0]=min(mi[w-1][0],np[i].y);
//		mx[w][0]=max(mx[w-1][0],np[i].y);
//	}
//	for(int i=n;i>=1;i--){
//		if(np[i].x<=0)break;
//		w=lower_bound(bx1+1,bx1+len1+1,np[i].x)-bx1;
//		mi[w][1]=min(mi[w+1][1],np[i].y);
//		mx[w][1]=max(mx[w+1][1],np[i].y);
//	}
//	for(int i=1;i<=cnt1;i++){
//		l=1,r=cnt2;
//		while(l<=r){
//			mid=(l+r)/2;
//			j=mid;
//			dis=sqrt((ap[i].x-bp[j].x)*(ap[i].x-bp[j].x)+(ap[i].y-bp[j].y)*(ap[i].y-bp[j].y));
//			
//	for(int i=1;i<=cnt;i++){
//		l=i+1,r=cnt;
//		while(l<=r){
//			mid=(l+r)/2;
//			if(xp[mid].id==i)mid++;
//			j=mid;
//			dis=sqrt((nnp[i].x-xp[j].x)*(nnp[i].x-xp[j].x)+(nnp[i].y-xp[j].y)*(nnp[i].y-xp[j].y));
//			L=max(-xp[j].x,xp[j].x-dis);
//			R=xp[j].x;
//			U=nnp[i].y;
//			D=max(-nnp[i].y,nnp[i].y-dis);
//			flag=1;
//			w=lower_bound(bx2+1,bx2+len2+1,L)-bx2;
//			flag&=(mi[w][0]>=D);
//			flag&=(mx[w][0]<=U);
//			w=lower_bound(bx1+1,bx1+len1+1,R)-bx1;
//			flag&=(mi[w][1]>=D);
//			flag&=(mi[w][1]<=U);
//			if(flag){
//				ans=min(ans,(long long)((nnp[i].x-xp[j].x)*(nnp[i].x-xp[j].x)+(nnp[i].y-xp[j].y)*(nnp[i].y-xp[j].y)));
//			}
//		}
//	}
int main(){
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	printf("û��д��"); 
//	init();
//	scanf("%d",&n);
//	for(int i=1;i<=n;i++){
//		scanf("%lf%lf",&p[i].x,&p[i].y);
//	}
//	for(int i=1;i<=n;i++){
//		np[i]=(nodep){p[i].x,p[i].y};
//	}
//	solve();
//	for(int i=1;i<=n;i++){
//		np[i]=(nodep){-p[i].x,p[i].y};
//	}
//	solve();
//	for(int i=1;i<=n;i++){
//		np[i]=(nodep){p[i].x,-p[i].y};
//	}
//	solve();
//	for(int i=1;i<=n;i++){
//		np[i]=(nodep){-p[i].x,-p[i].y};
//	}
//	solve();
//	for(int i=1;i<=n;i++){
//		np[i]=(nodep){p[i].x,p[i].y};
//	}
//	solve2();
//	for(int i=1;i<=n;i++){
//		np[i]=(nodep){-p[i].x,p[i].y};
//	}
//	solve2();
//	for(int i=1;i<=n;i++){
//		np[i]=(nodep){p[i].x,-p[i].y};
//	}
//	solve2();
//	for(int i=1;i<=n;i++){
//		np[i]=(nodep){-p[i].x,-p[i].y};
//	}
//	solve2();
//	printf("%lld",ans);
	return 0;
}
