#include<bits/stdc++.h>
using namespace std;
const int maxn=1006;
int n,m,k,t,p[maxn],ans;
int top[maxn],num[maxn][maxn][5];
bool col[maxn][maxn];
void init(){
	ans=0;
	memset(top,0,sizeof(top));
	memset(num,0,sizeof(num));
	memset(col,-1,sizeof(col));
	return ;
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	init();
	scanf("%d%d%d%d",&n,&m,&k,&t);
	int x,y;
	for(int i=1;i<=t;i++){
		scanf("%d",&y);
		if(ans)continue;
		x=++top[y];
		col[x][y]=i%2;
		if(col[x][y-1]==col[x][y]){//L
			num[x][y][0]=num[x][y-1][0]+1;
		}
		else num[x][y][0]=1;
		if(col[x][y+1]==col[x][y]){//R 
			num[x][y][1]=num[x][y+1][1]+1;
		}
		else num[x][y][1]=1;
		if(col[x-1][y-1]==col[x][y]){//LD
			num[x][y][2]=num[x-1][y-1][2]+1;
		}
		else num[x][y][2]=1;
		if(col[x-1][y+1]==col[x][y]){//RD
			num[x][y][3]=num[x-1][y+1][3]+1;
		}
		else num[x][y][3]=1;
		if(col[x-1][y]==col[x][y]){//D
			num[x][y][4]=num[x-1][y][4]+1;
		}
		else num[x][y][4]=1;
		if(num[x][y][0]+num[x][y][1]-1>=k)ans=i;
		else if(num[x][y][2]>=k)ans=i;
		else if(num[x][y][3]>=k)ans=i;
		else if(num[x][y][4]>=k)ans=i;
	}
	printf("%d",ans);
	return 0;
}
