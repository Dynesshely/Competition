#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+7,maxs=3e6+7;
int n,a[maxn],b[maxn],mab;
long long sum[maxs*2];
long long ans;
void init(){
	memset(sum,0,sizeof(sum));
	ans=mab=0;
	return ;
}
int main(){
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	init();
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&b[i]);
		sum[b[i] +1]++;
		mab=max(mab,b[i]);
	}
	for(int i=1;i<=mab*2;i++){
		sum[i +1]+=sum[i-1 +1];
//		printf("%d ",sum[i +1]);
	}
//	putchar('\n');
	int l,r;
	for(int i=1;i<=n;i++){
		for(long long j=a[i],ad=-1;j>=0;j-=ad){
			ad+=2;
			ans=ans+(ad/2)*(sum[j +1]-sum[j-ad +1]);
		}
		for(long long j=a[i],ad=-1;j+ad-1<=mab;j+=ad){
			ad+=2;
			ans=ans+(ad/2)*(sum[j+ad-1 +1]-sum[j-1 +1]);
		}
	}
	printf("%lld",ans);
	return 0;
}
