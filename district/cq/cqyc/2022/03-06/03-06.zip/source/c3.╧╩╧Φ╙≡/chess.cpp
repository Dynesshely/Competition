#include<bits/stdc++.h>
using namespace std;
const int N=1010;
inline int read()
{
	int x=0;
	bool f=false;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
int n,m,k,t,ans,K[N],a[N][N];
int xie(int x,int y)
{
	int nx=x,ny=y,cx;
	while(a[nx-1][ny-1]==a[x][y]) nx--,ny--;
	cx=nx,nx=x,ny=y;
	while(a[nx+1][ny+1]==a[x][y]) nx++,ny++;
	if(nx-cx+1>=k) return k;
	nx=x,ny=y;
	while(a[nx+1][ny-1]==a[x][y]) nx++,ny--;
	cx=nx,nx=x,ny=y;
	while(a[nx-1][ny+1]==a[x][y]) nx--,ny++;
	return cx-nx+1;
}
int shu(int x,int y)
{
	int up=x,dn=x;
	while(a[up-1][y]==a[x][y]) up--;
	while(a[dn+1][y]==a[x][y]) dn++;
	return dn-up+1;
}
int heng(int x,int y)
{
	int lt=y,rt=y;
	while(a[x][lt-1]==a[x][y]) lt--;
	while(a[x][rt+1]==a[x][y]) rt++;
	return rt-lt+1;
}
bool check(int x,int y) {return (heng(x,y)==k)|(shu(x,y)==k)|(xie(x,y)==k);}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read();
	m=read();
	k=read();
	t=read();
	memset(a,-1,sizeof(a));
	for(int i=1,x;i<=t;i++)
	{
		x=read();
		a[x][++K[x]]=i&1;
		if(check(x,K[x])) {printf("%d\n",i);break;}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
