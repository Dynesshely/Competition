#include<bits/stdc++.h>
#define lt id<<1
#define rt id<<1|1
using namespace std;
const int N=5e5+10;
inline int read()
{
	int x=0;
	bool f=false;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
struct ok{
	int l,r,num,lazy;
}tree[N<<2];
int n,m,q,a[N];
long long ans[N];
void build(int id,int l,int r)
{
	tree[id].l=l,tree[id].r=r;
	if(l==r) return (void)(tree[id].num=tree[id].lazy=a[r]);
	int mid=l+r>>1;
	build(lt,l,mid),build(rt,mid+1,r);
}
void inc(int id)
{
	if(!tree[id].lazy) return;
	tree[lt].num=tree[id].lazy;
	tree[lt].lazy=tree[id].lazy;
	tree[rt].num=tree[id].lazy;
	tree[rt].lazy=tree[id].lazy;
	tree[id].lazy=0;
}
void change(int id,int l,int r,int x)
{
	if(tree[id].l>r||tree[id].r<l) return;
	if(tree[id].l>=l&&tree[id].r<=r)
	{
		tree[id].num=x;
		tree[id].lazy=x;
		return;
	}
	inc(id);
	change(lt,l,r,x),change(rt,l,r,x);
}
int query(int id,int l)
{
	if(!(tree[id].l<=l&&l<=tree[id].r)) return -1;
	if(tree[id].l==l&&tree[id].r==l) return tree[id].num;
	inc(id);
	return max(query(lt,l),query(rt,l));
}
int main()
{
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	build(1,1,n);
	if(n<=5e3&&m<=5e3&&q<=5e3) while(q--)
	{
		int opt=read(),l=read(),r=read(),x=read();
		if(opt==1) for(int i=l;i<=r;i++) a[i]=x;
		else for(int i=l;i<=r;i++) ans[a[i]]+=x;
	}
	else while(q--)
	{
		int opt=read(),l=read(),r=read(),x=read();
		if(opt==1) change(1,l,r,x);
		else ans[query(1,l)]+=x;
	}
	for(int i=1;i<=m;i++) printf("%lld\n",ans[i]);
	fclose(stdin);fclose(stdout);
	return 0;
}
