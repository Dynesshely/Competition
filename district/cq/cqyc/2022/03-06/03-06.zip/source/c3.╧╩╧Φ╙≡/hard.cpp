#include<bits/stdc++.h>
using namespace std;
const int N=1e6+10,M=3e6+10;
inline int read()
{
	int x=0;
	bool f=false;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return f?-x:x;
}
int n,a[N],b[N],tot[M][2];
long long ans;
long long check(int x,bool k)
{
	long long res=0;
	for(int i=1;i*i<=x;i++)
	{
		int l=max(0,x-(i+1)*(i+1)),r=x-i*i;
		if(r>0) res+=1ll*i*(tot[r][k]-tot[l][k]);
		else if(!r) res+=1ll*i*tot[r][k];
	}
	return res;
}
int main()
{
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read(),tot[a[i]][0]++;
	for(int i=1;i<=n;i++) b[i]=read(),tot[b[i]][1]++;
	for(int i=1;i<M;i++) tot[i][0]+=tot[i-1][0],tot[i][1]+=tot[i-1][1];
	for(int i=1;i<=n;i++) ans+=check(b[i],0),ans+=check(a[i],1);
	printf("%lld\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
