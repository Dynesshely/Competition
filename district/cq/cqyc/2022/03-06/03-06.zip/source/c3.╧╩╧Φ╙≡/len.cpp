#include<bits/stdc++.h>
using namespace std;
const int N=20;
int n;
bool biao[N];
long long ans=1e18,x[N],y[N];
void check()
{
	long long res=0;
	for(int i=1;i<=n;i++) for(int j=i+1;j<=n;j++) if(biao[i])
	{
		if(biao[j]) res=max(res,(x[i]-x[j])*(x[i]-x[j]));
		else res=max(res,x[i]*x[i]+y[j]*y[j]);
	}
	else
	{
		if(biao[j]) res=max(res,y[i]*y[i]+x[j]*x[j]);
		else res=max(res,(y[i]-y[j])*(y[i]-y[j]));
	}
	ans=min(ans,res);
}
void dfs(int k)
{
	if(k>n) return check();
	biao[k]=true;
	dfs(k+1);
	biao[k]=false;
	dfs(k+1);
}
int main()
{
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%lld%lld",x+i,y+i);
	dfs(1);
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
