#include<bits/stdc++.h>
using namespace std;
int n,g1[1007],g2[1007],t1,t2;
long long ans=1e18;
struct node {
	int x,y;
} d[1007],tmp[1007];
long long get(int a,int b) {
	return (tmp[a].x-tmp[b].x)*(tmp[a].x-tmp[b].x)+(tmp[a].y-tmp[b].y)*(tmp[a].y-tmp[b].y);
}
void dfs(int id) {
	if(id>n) {
		for(int i=1; i<=t1; i++) tmp[g1[i]].x=d[g1[i]].x,tmp[g1[i]].y=0;
		for(int i=1; i<=t2; i++) tmp[g2[i]].x=0,tmp[g2[i]].y=d[g2[i]].y;
		long long now=0;
		for(int i=1; i<=n; i++) {
			for(int j=i+1; j<=n; j++)	now=max(now,get(i,j));
		}
		ans=min(ans,now);
		return;
	}
	g1[++t1]=id,dfs(id+1),t1--;
	g2[++t2]=id,dfs(id+1),t2--;
}
int main() {
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; i++)	scanf("%d %d",&d[i].x,&d[i].y);
	dfs(1);
	printf("%lld",ans);
	return 0;
}
