#include<bits/stdc++.h> 
using namespace std;
int n,m,q,a[500007],c[500007];
int tr[500007];
int flag=1;
struct node
{
	int opt,l,r,x;
}qu[500007];
int main()
{
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	scanf("%d %d %d",&n,&m,&q);
	for(int i=1;i<=n;i++)	scanf("%d",&a[i]);
	for(int i=1;i<=q;i++)
	{
		int opt,l,r,x;
		scanf("%d %d %d %d",&opt,&l,&r,&x);
		if(opt==2)	for(int j=l;j<=r;j++) c[a[j]]+=x;
		else	for(int j=l;j<=r;j++) a[j]=x;
	}
	for(int i=1;i<=m;i++) printf("%d\n",c[i]);
		

	return 0;
}
