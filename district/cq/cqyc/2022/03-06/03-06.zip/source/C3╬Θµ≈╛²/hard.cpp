#include<bits/stdc++.h>
using namespace std;
int n,a[1000007],b[1000007];
long long ans=0;
int main() {
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	scanf("%d",&n);
	if(n<=2000) {
		for(int i=1; i<=n; i++)  scanf("%d",&a[i]);
		for(int i=1; i<=n; i++)  scanf("%d",&b[i]);
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++)	ans+=(int)sqrt(abs(a[i]-b[j]));
		}
		printf("%lld",ans);
		return 0;
	}
	for(int i=1; i<=n; i++) {
		int x;
		scanf("%d",&x);
		a[x]++;
	}
	for(int i=1; i<=n; i++) {
		int x;
		scanf("%d",&x);
		b[x]++;
	}
	for(int i=1; i<=2000; i++) {
		for(int j=1; j<=2000; j++)	ans+=(int)sqrt(abs(i-j))*a[i]*b[j];
	}
	printf("%lld",ans);
	return 0;
}
