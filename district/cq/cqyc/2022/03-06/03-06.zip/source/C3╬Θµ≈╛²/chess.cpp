#include<bits/stdc++.h> 
using namespace std;
int n,m,k,t,kind,col[1007][1007],ans;
int l[1007][1007],r[1007][1007],d[1007][1007];
int x1[1007][1007],x2[1007][1007],top[1007];
int x3[1007][1007],x4[1007][1007];
//l,r,d,x1,x2,x3,x4

bool ok(int a,int b)
{
	if(a>=1&&a<=n&&b>=1&&b<=n) return 1;
	return 0;
}

void solve1(int a,int b,int ad1,int ad2)
{
	int x=a+ad1,y=b+ad2;
	if(!ok(x,y)||col[x][y]!=col[a][b]) 
	{
		int tmp=r[a][b];
		while(b+1<=m&&col[a][b]==col[a][b+1]) b++,l[a][b]+=tmp;
		return;
	}
//	cout<<"here";
	l[a][b]+=l[x][y];
	while(b+1<=m&&col[a][b]==col[a][b+1]) b++,l[a][b]+=l[x][y]+1;
}

void solve2(int a,int b,int ad1,int ad2)
{
	int x=a+ad1,y=b+ad2;
	if(!ok(x,y)||col[x][y]!=col[a][b]) 
	{
		int tmp=r[a][b];
	//	cout<<"now"<<a<<" "<<b<<" "<<col[a][b]<<" "<<col[a][b-1]<<endl;
		while(b-1>=1&&col[a][b]==col[a][b-1]) 
		{
			b--,r[a][b]+=tmp;
		//	cout<<"here"<<a<<" "<<b<<" "<<r[a][b]<<endl;
		}
		return;
	}
	r[a][b]+=r[x][y];
//	
	while(b-1>=1&&col[a][b]==col[a][b-1]) 
	{
		b--,r[a][b]+=r[x][y]+1;
	//	cout<<"here"<<a<<" "<<b<<endl;
	}
}

void solve3(int a,int b,int ad1,int ad2)
{
	int x=a+ad1,y=b+ad2;
	if(!ok(x,y)||col[x][y]!=col[a][b])  return;
	d[a][b]+=d[x][y];
//	cout<<"here"<<endl;
}

void solve4(int a,int b,int ad1,int ad2)
{
	int x=a+ad1,y=b+ad2;
	if(!ok(x,y)||col[x][y]!=col[a][b]) 
	{
		int tmp=x1[a][b];
		while(a+1<=n&&b-1>=1&&col[a][b]==col[a+1][b-1]) a++,b--,x1[a][b]+=tmp;
		return;
	}
	x1[a][b]+=x1[x][y];
	while(a+1<=n&&b-1>=1&&col[a][b]==col[a+1][b-1]) a++,b--,x1[a][b]+=x1[x][y]+1;
}

void solve5(int a,int b,int ad1,int ad2)
{
	int x=a+ad1,y=b+ad2;
	if(!ok(x,y)||col[x][y]!=col[a][b]) 
	{
		int tmp=x2[a][b];
		while(a-1>=1&&b+1<=m&&col[a][b]==col[a-1][b+1]) a--,b++,x2[a][b]+=tmp;
		return;
	}
	x2[a][b]+=x2[x][y];
	while(a-1>=1&&b+1<=m&&col[a][b]==col[a-1][b+1]) a--,b++,x2[a][b]+=x2[x][y]+1;
}

void solve6(int a,int b,int ad1,int ad2)
{
	int x=a+ad1,y=b+ad2;
	if(!ok(x,y)||col[x][y]!=col[a][b]) 
	{
		int tmp=x3[a][b];
		while(a-1>=1&&b-1>=1&&col[a][b]==col[a-1][b-1]) a--,b--,x3[a][b]+=x3[x][y];
		return;
	}
	x3[a][b]+=x3[x][y];
	while(a-1>=1&&b-1>=1&&col[a][b]==col[a-1][b-1]) a--,b--,x3[a][b]+=x3[x][y]+1;
}

void solve7(int a,int b,int ad1,int ad2)
{
	int x=a+ad1,y=b+ad2;
	if(!ok(x,y)||col[x][y]!=col[a][b]) 
	{
		int tmp=x4[a][b];
		while(a+1<=n&&b+1<=m&&col[a][b]==col[a+1][b+1]) a++,b++,x4[a][b]+=tmp;
		return;
	}
	x4[a][b]+=x4[x][y];
	while(a+1<=n&&b+1<=m&&col[a][b]==col[a+1][b+1]) a++,b++,x4[a][b]+=x4[x][y]+1;
}

bool check(int a,int b)
{
	if(d[a][b]>=k||l[a][b]+r[a][b]-1>=k||x1[a][b]+x2[a][b]-1>=k||x3[a][b]+x4[a][b]-1>=k) return 1;
	return 0;
}

int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d %d %d %d",&n,&m,&k,&t);
	for(int i=1;i<=m;i++) top[i]=n;
	for(int i=1;i<=t;i++)
	{
		int x;
		scanf("%d",&x);
		if(!top[x]||ans) continue;
		l[top[x]][x]=1,r[top[x]][x]=1,d[top[x]][x]=1;
		x1[top[x]][x]=1,x2[top[x]][x]=1,col[top[x]][x]=kind+1;
		x3[top[x]][x]=1,x4[top[x]][x]=1;
		solve1(top[x],x,0,-1),solve2(top[x],x,0,1),solve3(top[x],x,1,0);
		solve4(top[x],x,1,-1),solve5(top[x],x,-1,1);
		solve6(top[x],x,-1,-1),solve7(top[x],x,1,1);
//		cout<<top[x]<<" "<<x<<" "<<endl;
//		cout<<l[top[x]][x]<<" "<<r[top[x]][x]<<" "<<d[top[x]][x]<<" ";
//		cout<<x1[top[x]][x]<<" "<<x2[top[x]][x]<<" "<<x3[top[x]][x]<<" "<<x4[top[x]][x]<<endl;
		if(check(top[x],x)) ans=i;
		top[x]--,kind=kind^1;
	}
	printf("%d",ans);
	
	return 0;
}
