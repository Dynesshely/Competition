#include<bits/stdc++.h> 
using namespace std;
long long c[2][400007],g[300007],p,m;
int cnt,tot=0;
int t;
int main()
{
	freopen("beauty.in","r",stdin);
	freopen("beauty.out","w",stdout);
	scanf("%d",&t);
	c[0][1]=1,g[++cnt]=1;
	for(int i=2;i<=1000;i++)
	{
		long long tmp=i;
		tot=tot^1;
		c[tot][1]=i,c[tot][i]=1;
		for(int j=2;j<i;j++)
		{
			c[tot][j]=c[tot^1][j-1]+c[tot^1][j];
			tmp=max(tmp,c[tot][j]);
		}
		if(tot==1) g[++cnt]=tmp;
		if(cnt==100007) break;
	}
	while(t--)
	{
		scanf("%d %d",&p,&m); 
		long long tp=1,sum=0;
		for(int j=1;j<=p;j++)
		{
			sum+=(g[j]*tp%p);
			sum=sum%p;
			tp=tp*m%p;
		}
		printf("%lld\n",sum);
	}
	
	
	return 0;
}
