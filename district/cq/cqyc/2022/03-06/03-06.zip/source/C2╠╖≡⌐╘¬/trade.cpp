#include<bits/stdc++.h>
using namespace std;
int n,m,c,a,b,sp2[30000],ans=0;
int sp3[30000],sp4[30000],sp5[30000];
vector<int> sp[30000];
void jb(int k,int bs){
	if(bs==1002) return;
	int j=0;
	for(int i=1;i<=k;i++){
		for(int y=0;y<sp[sp3[i]].size();y++){
			sp5[sp[sp3[i]][y]]=max(sp5[sp[sp3[i]][y]],sp4[i]+sp2[sp[sp3[i]][y]]);
		}
	}
	for(int i=1;i<=n;i++){
		if(sp5[i]!=0) {
			j++;
			sp3[j]=i;
			sp4[j]=sp5[i];
		}
	}
	if(sp5[1]-bs*bs*c<0&&sp5[1]!=0) return;
	ans=max(ans,sp5[1]-bs*bs*c);
	memset(sp5,0,sizeof(sp5));
	jb(j,bs+1);
	return;
}
int main(){
	freopen("trade.in","r",stdin);
	freopen("trade.out","w",stdout);
	scanf("%d%d%d",&n,&m,&c);
	for(int i=1;i<=n;i++) scanf("%d",&sp2[i]);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&a,&b);
		sp[a].push_back(b);
	}
	sp3[1]=1;
	jb(1,1);
	printf("%d\n",ans);
}
