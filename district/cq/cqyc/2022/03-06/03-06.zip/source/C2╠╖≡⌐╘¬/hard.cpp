#include<bits/stdc++.h>
using namespace std;
int n,sp[2000000],sp2[2000000];
int tong[10029231],kuai[3000211],maxn=0,minn=0,lr,rt,p,q;
long long ans=0,sum=0;
int main() {
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	cin>>n;
	for(int i=1; i<=n; i++) scanf("%d",&sp[i]),tong[sp[i]]++,maxn=max(maxn,sp[i]);
	for(int i=1; i<=n; i++) scanf("%d",&sp2[i]),kuai[sp2[i]]++,minn=max(minn,sp2[i]);
	for(int i=0; i<=10000000; i++) tong[i]=tong[i]+tong[i-1];
//	for(int i=0;i<=minn;i++) kuai[i]=kuai[i]+kuai[i-1];
	for(int i=0; i<=minn; i++) {
		if(kuai[i]!=0) {
		//	cout<<i<<endl;
			ans=0;
			q=1;
			p=3;
			lr=i+1;
			rt=i+3;
			ans=ans+(tong[rt]-tong[lr-1])*q;
		//	cout<<tong[lr-1]<<" "<<lr<<" "<<tong[rt]<<" "<<rt<<endl;
			while(rt<=maxn) {
				q++;
				p=p+2;
				lr=rt+1;
				rt=lr+p-1;
				ans=ans+(tong[rt]-tong[lr-1])*q;
			}
			cout<<ans<<endl;
			if(i>=1&&i<=3) ans=ans+tong[i-1];
			else if(i!=0) {
				q=1;
				p=3;
				rt=i-1;
				lr=i-3;
				ans=ans+(tong[rt]-tong[lr-1])*q;
				while(1==1) {
					q++;
					p=p+2;
					rt=lr-1;
					lr=rt-p+1;//rt-lr=p-1
					if(lr<=0) {
						if(rt>=0) ans=ans+tong[rt]*q;
						break;
					}
                    ans=ans+(tong[rt]-tong[lr-1])*q;
				}
			}
		//	cout<<ans<<endl;
			sum=sum+ans*kuai[i];
		}
	}
	printf("%lld\n",sum);
}
