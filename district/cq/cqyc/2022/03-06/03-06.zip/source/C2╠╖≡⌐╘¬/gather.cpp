#include<bits/stdc++.h>
using namespace std;
int n,sp[300000],j=0,q,tong[300000],l=1,r=0;
vector<int> sp2[300000];
long long sum=0,ans=0;
struct jk{
	int lr,rt;
}sp3[300000];
bool cmp(jk x,jk y){
	if(x.lr/q==y.lr/q){
		if((x.lr/q)%2==1) return x.rt<y.rt;
		else return x.rt>y.rt;
	}
	else return x.lr<y.lr;
}
int main(){
	freopen("gather.in","r",stdin);
	freopen("gather.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {
	scanf("%d",&sp[i]);	
	sp2[sp[i]].push_back(i);
	}
	for(int i=1;i<=n;i++) sp2[i].push_back(n+1);
	//	cout<<sp2[6].size();
	for(int i=1;i<=n;i++){
		//if(sp2[i].size()!=0)
		for(int y=0;y<sp2[i].size()-1;y++){
			j++;
			sp3[j].lr=sp2[i][y]+1;
			sp3[j].rt=sp2[i][y+1]-1;
			if(sp3[j].lr>sp3[j].rt) j--;
		//	cout<<1;
		}
	//	cout<<"114514"<<endl;
	}
	q=sqrt(n);
	sort(sp3+1,sp3+j+1,cmp);
//	cout<<1;
	for(int i=1;i<=j;i++){
		while(r<sp3[i].rt){
			if(++tong[sp[++r]]==1) ans++;
		}
		while(l>sp3[i].lr) {
			if(++tong[sp[--l]]==1) ans++;
		}
		while(l<sp3[i].lr){
			if(--tong[sp[l]]==0) ans--;
			l++;
		}
		while(r>sp3[i].rt){
			if(--tong[sp[r]]==0) ans--;
			r--;
		}
		sum=sum+ans;
	}
	printf("%d\n",sum);
} 
