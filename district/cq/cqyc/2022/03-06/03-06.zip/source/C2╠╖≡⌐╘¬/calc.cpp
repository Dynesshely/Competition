#include<bits/stdc++.h>
using namespace std;
int n;
long long a,b,c;
int main(){
	freopen("calc.in","r",stdin);
	freopen("calc.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a>>b>>c;
		int sum=0;
		for(int y=0;y<=a;y++){
			long long k=1,p=0;
			for(int z=1;;z++){
				if(k>b+y&&k>c+y) {
				p=7;
				break;	
				}
				if((((b+y)/k)%3)%2!=(((c+y)/k)%3)%2) break;
				k=k*3;
			}
			if(p==7) sum++;	
		}
		printf("%d\n",sum);
	}

}
