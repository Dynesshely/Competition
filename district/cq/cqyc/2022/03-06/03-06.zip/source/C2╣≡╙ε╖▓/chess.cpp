#include<bits/stdc++.h>
using namespace std;
#define N 1005
int n,m,k,t;
int a[N][N],psin[N];
int dir[8][2]={{1,0},{-1,0},{0,1},{0,-1},{1,1},{-1,-1},{-1,1},{1,-1}};
bool ok(int x,int y,int i)
{
	int tox=x+dir[i][0],toy=y+dir[i][1];
	return tox<=m&&tox>0&&toy<=n&&toy>0&&a[x][y]==a[tox][toy];
}
bool check(int sx,int sy)
{
	int js,x,y;
	for(int i=0;i<8;i++)
	{
		js=1;x=sx,y=sy;
		while(ok(x,y,i))x+=dir[i][0],y+=dir[i][1],js++;
		i++;x=sx,y=sy;
		while(ok(x,y,i))x+=dir[i][0],y+=dir[i][1],js++;
		if(js>=k)return 1;
	}
	return 0;
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&t);
	for(int i=1;i<N;i++){
		for(int j=1;j<N;j++)
			a[i][j]=-1;
	}
	int u;
	for(int i=1;i<=t;i++)
	{
		scanf("%d",&u);
		a[u][++psin[u]]=i%2;
		if(check(u,psin[u]))
		{
			printf("%d",i);
			return 0;
		}
	}
	return 0;
}
