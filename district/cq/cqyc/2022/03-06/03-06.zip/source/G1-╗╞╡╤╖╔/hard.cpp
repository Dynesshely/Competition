#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n;

ll bcka[3000006],bckb[3000006];
int stka[10004],topa;
int stkb[10004],topb;

ll bcks[3000006];
int stks[3000006],tops;

inline int read(){
	int s=0;char c=getchar();
	while(c<48||c>57) c=getchar();
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

int main(){
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	
	n=read();
	
	for(int i=1;i<=n;i++){
		int x=read();bcka[x]++;
		if(bcka[x]==1) stka[++topa]=x;
	} 
	
	for(int i=1;i<=n;i++){
		int x=read();bckb[x]++;
		if(bckb[x]==1) stkb[++topb]=x;
	}
	
	for(int i=1;i<=topa;i++){
		for(int j=1;j<=topb;j++){
			int x=stka[i],y=stkb[j];
			int Abs=abs(x-y);
			if(!bcks[Abs]) stks[++tops]=Abs;
			bcks[Abs]+=bcka[x]*bckb[y];
		}
	}
	
	ll ans=0;
	for(int i=1;i<=tops;i++) ans+=(ll)sqrt(stks[i])*bcks[stks[i]];
	printf("%lld",ans);
	
	return 0;
}

