#include<bits/stdc++.h>
using namespace std;
int n,m,k,t;
int col[1003][1003];
int num[1003];
int a[1000006];

inline int read(){
	int s=0;char c=getchar();
	while(c<48||c>57) c=getchar();
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read(),k=read(),t=read();
	for(int i=1;i<=t;i++) a[i]=read();

	for(int i=1;i<=t;i++){
		int cas=(i&1)+1;
		int x=a[i],y=(++num[a[i]]);
		col[x][y]=cas;
		
		int cnt=1;
		for(int j=1;j<k;j++){if(x+j>m||col[x+j][y]!=cas) break; cnt++;}
		for(int j=1;j<k;j++){if(x-j<1||col[x-j][y]!=cas) break; cnt++;}
		if(cnt>=k) printf("%d",i),exit(0);
		
		cnt=1;
		for(int j=1;j<k;j++){if(y-j<1||col[x][y-j]!=cas) break; cnt++;}
		if(cnt>=k) printf("%d",i),exit(0);
		
		cnt=1;
		for(int j=1;j<k;j++){if(x-j<1||y-j<1||col[x-j][y-j]!=cas) break;cnt++;}
		for(int j=1;j<k;j++){if(x+j<m||y+j<n||col[x+j][y+j]!=cas) break;cnt++;}
		if(cnt>=k) printf("%d",i),exit(0); 
	}
	
	return 0;
}
