#include<bits/stdc++.h>
#define ll long long
using namespace std;
int T;

ll jc[2000006];
ll inv[2000006];

int main(){
	freopen("beauty.in","r",stdin);
	freopen("beauty.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		ll p,m;
		scanf("%lld%lld",&p,&m);
		
		if(T<=100&&p<=1000000){
			jc[0]=1,inv[0]=inv[1]=1;
			for(int i=1;i<=2*p;i++) jc[i]=jc[i-1]*i%p;
			for(int i=2;i<p;i++) inv[i]=(p-p/i*inv[p%i])%p;
			for(int i=2;i<p;i++) inv[i]=inv[i-1]*inv[i]%p;
		
			ll power=1,ans=0;
			for(int i=0;i<p;i++){
				ans+=jc[2*i]*inv[i]%p*inv[i]%p*power%p;
				ans%=p,power=power*m%p;
			}
			printf("%lld\n",ans);
			continue;
		}
		
		if(m==1){
			if(p%3==1) puts("1");
			else if(p%3==2) printf("%lld\n",p-1);
			else puts("0");
			continue;
		}
	}
	
	return 0;
}

