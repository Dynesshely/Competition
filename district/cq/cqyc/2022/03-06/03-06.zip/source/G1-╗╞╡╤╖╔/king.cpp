#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m,q;
int a[500005];
ll tot[500005];
ll res[500005];

inline int read(){
	int s=0;char c=getchar();
	while(c<48||c>57) c=getchar();
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

void write(ll x){
	if(x>9) write(x/10);
	putchar(x%10+48);
}

struct node{int opt,l,r,x;}ask[500005];

int lan[2000005];
void pushdown(int i){lan[i<<1]+=lan[i],lan[(i<<1)+1]+=lan[i],lan[i]=0;}

void add(int i,int l,int r,int L,int R,int x){
	if(L<=l&&r<=R) {lan[i]+=x;return;}
	pushdown(i);
	int mid=l+r>>1;
	if(L<=mid) add(i<<1,l,mid,L,R,x);
	if(R>mid) add((i<<1)+1,mid+1,r,L,R,x);
}

void find(int i,int l,int r,int pos){
	if(l==r) {res[pos]+=lan[i],lan[i]=0;}
	pushdown(i);
	int mid=l+r>>1;
	if(pos<=mid) find(i<<1,l,mid,pos);
	if(pos>mid) find((i<<1)+1,mid+1,r,pos);
}


int main(){
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	
	if(n<=5000&&m<=5000&&q<=5000){
		for(int i=1;i<=q;i++){
			int opt=read(),l=read(),r=read(),x=read();
			if(opt==1) for(int j=l;j<=r;j++) tot[x]+=res[j],res[j]=0,a[j]=x;
			else{ 
				for(int j=l;j<=r;j++) 
					if(!a[j]) res[j]+=x;
					else tot[a[j]]+=x;
			}
		}
		for(int i=1;i<=m;i++) write(tot[i]),puts("");
		return 0;
	}
	
	bool k1=1,k2=1;
	for(int i=1;i<=q;i++){
		ask[i].opt=read(),ask[i].l=read(),ask[i].r=read(),ask[i].x=read();
		if(ask[i].opt==1&&ask[i].l!=ask[i].r) k1=0;
		if(ask[i].opt==2&&ask[i].l!=ask[i].r) k2=0;
	}
		
	if(k1){
		for(int i=1;i<=q;i++){
			if(ask[i].opt==1){
				int x=ask[i].x,y=ask[i].l;
				find(1,1,n,y);
				
				if(a[y]) tot[a[y]]+=res[y];
				else tot[x]+=res[y];
				res[y]=0,a[y]=x;
			}
			else add(1,1,n,ask[i].l,ask[i].r,ask[i].x);
		}
		for(int i=1;i<=n;i++){
			find(1,1,n,i);
			if(res[i]) tot[a[i]]+=res[i];
		}
		for(int i=1;i<=m;i++) write(tot[i]),puts("");
		return 0;
	}
	
	
	
	return 0;
}

