#include<bits/stdc++.h>
using namespace std;
int n;
long long ans=0x3f3f3f3f;
struct lll
{
	int x,y;
} a[100005];
int cmp(lll a,lll b)
{
	if(a.x==b.x) return a.y<b.y;
	return a.x<b.x;
}
void hanshu(int x,int l,int r,int ll,int rr)
{
	if(x==n+1)
	{
		ans=min(ans,(long long)(l-r)*(l-r)+(ll-rr)*(ll-rr));
		return;
	}
	hanshu(x+1,max(l,a[x].x),min(r,a[x].x),max(ll,0),min(rr,0));
	hanshu(x+1,max(l,0),min(r,0),max(ll,a[x].y),min(rr,a[x].y));
}
int main()
{
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; ++i) scanf("%lld%lld",&a[i].x,&a[i].y);
	hanshu(1,-0x3f3f3f3f,0x3f3f3f3f,-0x3f3f3f3f,0x3f3f3f3f);
	cout<<ans;
	return 0;
}
