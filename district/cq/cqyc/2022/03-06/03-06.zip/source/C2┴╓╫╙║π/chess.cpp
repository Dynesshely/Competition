#include<bits/stdc++.h>
using namespace std;
int n,m,k,t,i,g,ans;
vector<int> a[1005];
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&t);
	while(t--)
	{
		++ans,scanf("%d",&i);
		a[i].push_back(g),g^=1;
		int l=a[i].size();
		bool f=1;
		if(l>=k)
		{
			for(int j=l-2; j>=l-k && f; --j) if(g^1 != a[i][j]) f=0;
			if(f) cout<<ans,exit(0);
		}
		f=1;
		if(i+k<=n)
		{
			for(int j=i+1; j<=i+k && f; ++j) if(a[j].size()!=l || g^1 != a[j][l-1]) f=0;
			if(f) cout<<ans,exit(0);
		}
		f=1;
		if(i-k>0)
		{
			for(int j=i-1; j>=i-k && f; --j) if(a[j].size()!=l || g^1 != a[j][l-1]) f=0;
			if(f) cout<<ans,exit(0);
		}
	}
	return 0;
}
