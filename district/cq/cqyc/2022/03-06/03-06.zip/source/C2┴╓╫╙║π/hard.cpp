#include<bits/stdc++.h>
#define int unsigned long long
using namespace std;
int n,a[1000009],b[1000009],ans,sum;
signed main()
{
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	scanf("%llu",&n);
	for(int i=1; i<=n; ++i) scanf("%llu",&a[i]);
	for(int i=1; i<=n; ++i) scanf("%llu",&b[i]);
	for(int i=1; i<=n; ++i)
	{
		if(a[i]==a[i-1]) ans+=sum;
		else
		{
			sum=0;
			for(int j=1; j<=n; ++j) sum+=(int)sqrt((a[i]>b[j]?a[i]-b[j]:b[j]-a[i]));
			ans+=sum;
		}
	}
	printf("%llu",ans);
	return 0;
}
