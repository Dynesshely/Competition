#include<bits/stdc++.h>
using namespace std;
int n,m,q,fa[500001],ll,rr,opt,x,ans[500001];
int tree[2000001];
inline int read(){
    int xx=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){xx=(xx<<1)+(xx<<3)+(ch^48);ch=getchar();}
    return xx*f;
}
void pushdown(int now){
	if(tree[now]!=0){
	tree[now*2]=tree[now];
	tree[now*2+1]=tree[now];
}
}
void build(int id,int l,int r){
	if(l==r){
		tree[id]=fa[l];
		return ;
	}
	int mid=(l+r)/2;
	build(id*2,l,mid);
	build(id*2+1,mid+1,r);
	if(tree[id*2]==tree[id*2+1])tree[id]=tree[id*2];
}
void change(int id,int l,int r){
	if(l>=ll&&r<=rr){
		tree[id]=x;
		return ;
	}
	pushdown(id);
	int mid=(l+r)/2;
	if(mid>=ll)change(id*2,l,mid);
	if(mid<rr)change(id*2+1,mid+1,r);
	if(tree[id*2]==tree[id*2+1])tree[id]=tree[id*2];
}
void add(int id,int l,int r){
	if(l>=ll&&r<=rr&&tree[id]!=0){
		ans[tree[id]]+=x*(r-l+1);
		return ;
	}
	if(l==r&&tree[id]==0)return ;
	pushdown(id);
	int mid=(l+r)/2;
	if(mid>=ll)add(id*2,l,mid);
	if(mid<rr)add(id*2+1,mid+1,r);
	if(tree[id*2]==tree[id*2+1])tree[id]=tree[id*2];
}
int main(){
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
    n=read(),m=read(),q=read();
    for(int i=1;i<=n;i++)fa[i]=read();
      if(n<=5000&&m<=5000&&q<=5000){
    	for(int i=1;i<=q;i++){
    		scanf("%d%d%d%d",&opt,&ll,&rr,&x);
    		if(opt==1){
    			for(int j=ll;j<=rr;j++)
    				fa[j]=x;
			}else{
				for(int j=ll;j<=rr;j++)
    				ans[fa[j]]+=x;
			}
		}
	}else{
		build(1,1,n);
		for(int i=1;i<=q;i++){
    		scanf("%d%d%d%d",&opt,&ll,&rr,&x);
    		if(opt==1)change(1,1,n);
			else add(1,1,n);
		}
	}
	for(int i=1;i<=n;i++)printf("%d\n",ans[i]);
	return 0;
} 
