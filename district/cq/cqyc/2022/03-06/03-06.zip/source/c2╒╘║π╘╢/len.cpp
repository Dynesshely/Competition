#include<bits/stdc++.h>
using namespace std;
int n,x[100001],y[100001],xx[100001],yy[100001];
long long ans=LONG_LONG_MAX,maxx;
void dfs(int now){
	if(now==n+1){
		maxx=0;
		for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		maxx=max(maxx,(long long)((xx[i]-xx[j])*(xx[i]-xx[j])+(yy[i]-yy[j])*(yy[i]-yy[j])));
        ans=min(ans,maxx);
        return ;
 	}
	yy[now]=y[now];
	xx[now]=0;
	dfs(now+1);
	yy[now]=0;
	xx[now]=x[now];
	dfs(now+1);
}
int main(){
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d%d",&x[i],&y[i]);
	dfs(1);
	printf("%lld",ans);
	return 0;
} 
