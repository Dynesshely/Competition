#include<bits/stdc++.h>
using namespace std;
int n,a[1000001],b[1000001],ans;
int main(){
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	ans+=sqrt(abs(a[i]-b[j]));
	printf("%d",ans);
	return 0;
} 
