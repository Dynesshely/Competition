#include<bits/stdc++.h>
using namespace std;
long long t,p,m,kkk[100001],van,ans;
int main(){
	freopen("beauty.in","r",stdin);
	freopen("beauty.out","w",stdout);
    scanf("%lld",&t);
    for(int asd=1;asd<=t;asd++){
    	scanf("%lld%lld",&p,&m);
    	kkk[0]=1;
    	van=1;
    	ans=0;
    	for(int i=1;i<=p*2-1;i++){
    		kkk[i]=kkk[i-1]*i;
//    		cout<<i<<" ";
    		if(i%2==1){
//    			cout<<kkk[i-1]<<" "<<endl;
    			ans+=((kkk[i-1]/(kkk[(i+1)/2-1]*kkk[i/2]))*van);
			}
//			cout<<"faq\n";
			van*=m;
		}
		printf("%lld\n",ans%p);
	}
	return 0;
} 
