#include<bits/stdc++.h>
using namespace std;
int n,m,k,t,kkk,gao[1001],kd[1005][1005];
int h[1005][1005],s[1005][1005],xx[1005][1005],yy[1005][1005];
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&t);
	for(int i=1;i<=t;i++){
		scanf("%d",&kkk);
		gao[kkk]++;
		kd[kkk][gao[kkk]]=i%2;
		h[kkk][gao[kkk]]++;
		s[kkk][gao[kkk]]++;
		xx[kkk][gao[kkk]]++;
		yy[kkk][gao[kkk]]++;
		int x=kkk,y=gao[kkk],ix,iy;
		if(kd[x][y]==kd[x][y-1])h[x][y]+=h[x][y-1];
		if(kd[x][y]==kd[x-1][y])s[x][y]+=s[x-1][y];
		if(kd[x][y]==kd[x-1][y-1])xx[x][y]+=xx[x-1][y-1];
		if(kd[x][y]==kd[x-1][y+1])yy[x][y]+=yy[x-1][y+1];
		if(kd[x][y]==kd[x][y+1])h[x][y]+=h[x][y+1];
		if(kd[x][y]==kd[x+1][y])s[x][y]+=s[x+1][y];
		if(kd[x][y]==kd[x+1][y+1])xx[x][y]+=xx[x+1][y+1];
		if(kd[x][y]==kd[x+1][y-1])yy[x][y]+=yy[x+1][y-1];
		ix=x;iy=y;
		while(kd[ix][iy-1]==kd[x][y])h[ix][iy-1]=h[x][y],iy--;
		ix=x;iy=y;
		while(kd[ix-1][iy]==kd[x][y])s[ix-1][iy]=s[x][y],ix--;
        ix=x;iy=y;
		while(kd[ix-1][iy-1]==kd[x][y])xx[ix-1][iy-1]=xx[x][y],ix--,iy--;
		ix=x;iy=y;
		while(kd[ix-1][iy+1]==kd[x][y])h[ix-1][iy+1]=h[x][y],ix--,iy++;
    	ix=x;iy=y;
		while(kd[ix][iy+1]==kd[x][y])h[ix][iy+1]=h[x][y],iy++;
		ix=x;iy=y;
		while(kd[ix+1][iy]==kd[x][y])s[ix+1][iy]=s[x][y],ix++;
		ix=x;iy=y;
		while(kd[ix+1][iy+1]==kd[x][y])xx[ix+1][iy+1]=xx[x][y],ix++,iy++;
		ix=x;iy=y;
		while(kd[ix+1][iy-1]==kd[x][y])h[ix+1][iy-1]=h[x][y],ix++,iy--;
		if(h[x][y]>=k||s[x][y]>=k||xx[x][y]>=k||yy[x][y]>=k){
		    	printf("%d",i);
		    	return 0;
			}
}
	return 0;
} 
