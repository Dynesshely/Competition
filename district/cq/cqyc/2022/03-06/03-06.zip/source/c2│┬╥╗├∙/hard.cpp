#include<bits/stdc++.h>
using namespace std;
long long n,a[1000005],b[1000005],ans;
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
long long stk[30],tp;
void write(long long x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}
int main()
	{
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=n;++i)
		b[i]=read();
	for(int i=1;i<=n;++i)
	for(int j=1;j<=n;++j)
		ans=ans+long(floor(double(sqrt(abs(a[i]-b[j])))));
	write(ans);
	return 0;
	}
