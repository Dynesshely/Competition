#include<bits/stdc++.h>
using namespace std;
long long n,m,q,a[500005],opt,l,r,x,sum,num,ans[500005],js,tot;
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
long long stk[30],tp;
void write(long long x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}
int main()
	{
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=q;++i)
	{
		opt=read(),l=read(),r=read(),x=read();
		if(opt==1)
		{
			for(int j=l;j<=r;++j)
			a[j]=x;
		}
		if(opt==2)
		{
			for(int j=l;j<=r;++j)
			ans[a[j]]+=x;
		}
	}
	for(int i=1;i<=m;++i)
		printf("%ld\n",ans[i]);
	return 0;
	}
