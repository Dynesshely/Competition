#include<bits/stdc++.h>
using namespace std;
long long n,m,k,t,sum=1,num,ans,a,b,c,js[1005],tot;
long long jl[1005][1005]={-1};
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
long long stk[30],tp;
void write(long long x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}

int main()
	{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read(),k=read(),t=read();
	for(int i=1;i<=t;++i)
	{
		a=read();
		js[a]++;
		if(js[a]==k)
		{
			write(i);
			return 0;
		}
		jl[a][js[a]]=sum;
		tot=1;
		while(true)
		{
			if(jl[a-tot][js[a]]!=sum&&jl[a+tot][js[a]]!=sum&&jl[a-tot][js[a]-tot]!=sum&&jl[a-tot][js[a]+tot]!=sum&&jl[a+tot][js[a]-tot]!=sum&&jl[a+tot][js[a]+tot]!=sum)
			break;
			tot++;
			if(tot==k)
			{
				write(i);
				return 0;
			}
		}
		sum++;
		if(sum==3)
		sum=1;
	}
	return 0;
	}
