#include<bits/stdc++.h>
using namespace std;
long long n,x[100005],y[100005],tot,minn=0x3f3f3f3f;
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
long long stk[30],tp;
void write(long long x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}
int main()
	{
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	{
		x[i]=read(),y[i]=read();
		for(int j=i-1;j>=1;--j)
		minn=min(minn,min(x[i]*x[i]+y[j]*y[j],x[j]*x[j]+y[i]*y[i]));
	}
	write(minn);
	return 0;
	}
