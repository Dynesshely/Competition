#include<bits/stdc++.h>
#define N 2003
#define ll long long
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;
ll n,a[N],b[N],san,x;
int main(){//hard
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	scanf("%d",&n);
    if(n<=2000){//10
	fff(i,1,n) scanf("%lld",&a[i]);
	fff(i,1,n) scanf("%lld",&b[i]);
	fff(i,1,n)fff(j,1,n) san+=sqrt(abs(a[i]-b[j]));
}else{//20
	fff(i,1,n) scanf("%lld",&x),a[x]++;
	fff(i,1,n) scanf("%lld",&x),b[x]++;
	fff(i,1,2000)fff(j,1,2000)
		if(a[i]&&b[j]) san+=a[i]*b[j]*((ll)sqrt(abs(i-j)));
	}
    cout<<san;
    return 0; 
} 
//û����ʲô���Ǿ�ֱ��ȥ��Ȼ������            30points   15:08~15:27
