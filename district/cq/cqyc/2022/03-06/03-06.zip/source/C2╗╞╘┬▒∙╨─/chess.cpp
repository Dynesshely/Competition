#include<bits/stdc++.h>
#define N 1002
#define ll long long
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;
int n,m,k,t,x,c[N][N];
void ed(int hia){cout<<hia;exit(0);}
int main(){//chess
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&t);
	fff(i,1,t){
		scanf("%d",&x);
		int co=1,bj,sum,y;
		if(!(i%2)) co++;
		y=++c[x][0],c[x][y]=co;
//		fff(j,1,n){
//			fff(k,1,m) cout<<c[j][k]<<" ";
//			cout<<"\n";
//		}
//		cout<<"\n";
		if(y>=k){//lie
			bj=1;
			kkk(j,y,y-k)if(c[x][j]!=co) bj=0;
			if(bj) ed(i);
		}
		///////////////////////////////////////////
		sum=0,bj=1;//hang
		fff(j,x,m) 
		    if(c[j][y]==co)
			    {sum++;if(sum>=k)break;}
		    else break;
		kkk(j,x-1,1)
		    if(c[j][y]==co)
			    {sum++;if(sum>=k)break;}
		    else break;
		if(sum==k) ed(i);
		/////////////////////////////////////////////
		sum=0,bj=1;//����
		fff(j,0,m)
		    if(c[x-j][y-j]==co&&(x-j)>=1&&(y-j)>=1)
		        {sum++;if(sum>=k)break;}
		    else break;
		fff(j,1,m)
		    if(c[x+j][y+j]==co&&(x+j)<=m&&(y+j)<=n)
		        {sum++;if(sum>=k)break;}
		    else break;
		if(sum==k) ed(i);
		//////////////////////////////////////////////
		sum=0,bj=1;//����
		fff(j,0,m)
		    if(c[x-j][y+j]==co&&(x-j)>=1&&(y+j)<=n)
		        {sum++;if(sum>=k)break;}
		    else break;
		fff(j,1,m)
		    if(c[x+j][y-j]==co&&(x+j)<=m&&(y-j)>=1)
		        {sum++;if(sum>=k)break;}
		    else break;
		if(sum==k) ed(i);
	}
    return 0; 
} 
//�����÷�       14:34~14:55
