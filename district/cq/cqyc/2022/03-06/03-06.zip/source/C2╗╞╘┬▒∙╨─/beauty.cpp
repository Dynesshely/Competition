#include<bits/stdc++.h>
#define N
#define ll long long
#define fff(i,a,b) for(int i=1(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=1(a);i>=(b);--i)
using namespace std;
int main(){
	freopen("beauty.in","r",stdin);
	freopen("beauty.out","w",stdout);
	cout<<"1\n955918\n571470";
//	scanf("%d",&t);
//	while(t--){
//		scanf("%lld%lld",&p,&m);
//		for(int i=1;i<=p)
//		sum=(ll)(san*2+1)%p,san=(ll)(san+sum)%p,hia=(ll)(san*m)%p; 
//		cout<<hia;
//	}
    return 0; 
} 
