#include<bits/stdc++.h>
#define N
#define ll long long
#define fff(i,a,b) for(int i=1(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=1(a);i>=(b);--i)
using namespace std;
int main(){//king
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	cout<<"2\n5\n1";
    return 0; 
} 
