#include<bits/stdc++.h>
using namespace std;
long long n,m,q,a[500005],tag[2000005],cnt[500005],sum[2000005],t1[500005],t2[500005],t3[500005],t4[500005];
bool flag1=1,flag2=1;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void build(int k,int l,int r){
	if(l==r){
		sum[k]=0;
		return;
	}
	int mid=(l+r)>>1;
	build(k<<1,l,mid);build((k<<1)+1,mid+1,r);
	sum[k]=sum[k<<1]+sum[(k<<1)+1];
}
void pushdown(int k,int l,int r){
	int mid=(l+r)>>1;
	tag[k<<1]+=tag[k];tag[(k<<1)+1]+=tag[k];
	sum[k<<1]=sum[k<<1]+(mid-l+1)*tag[k];
	sum[(k<<1)+1]=sum[(k<<1)+1]+(r-mid)*tag[k];
	tag[k]=0;
}
void add(int k,int l,int r,int ll,int rr,int g){
	if(ll<=l&&rr>=r){
		tag[k]+=g;
		sum[k]=sum[k]+(r-l)*g;
		return;
	}
	pushdown(k,l,r);
	int mid=(l+r)>>1;
	if(ll<=mid) add(k<<1,l,mid,ll,rr,g);
	if(rr>mid) add((k<<1)+1,mid+1,r,ll,rr,g);
	sum[k]=sum[k<<1]+sum[(k<<1)+1];
}
void query(int k,int l,int r,int g,int h){
	if(l==r){
		cnt[a[l]]+=sum[k];
		sum[k]=0;a[l]=h;
		return;
	}
	pushdown(k,l,r);
	int mid=(l+r)>>1;
	if(g<=mid) query(k<<1,l,mid,g,h);
	else query((k<<1)+1,mid+1,r,g,h);
	sum[k]=sum[k<<1]+sum[(k<<1)+1];
}
int main(){
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	if(n<=5000&&m<=5000&&q<=5000){
		for(int i=1;i<=q;i++){
			t1[i]=read(),t2[i]=read(),t3[i]=read(),t4[i]=read();
			if(t1[i]==1) for(int j=t2[i];j<=t3[i];j++) a[j]=t4[i];
			else for(int j=t2[i];j<=t3[i];j++) cnt[a[j]]+=t4[i];
		}
		for(int i=1;i<=m;i++) printf("%lld\n",cnt[i]);
		return 0;
	}
	for(int i=1;i<=q;i++){
		t1[i]=read(),t2[i]=read(),t3[i]=read(),t4[i]=read();
		if(t1[i]==1&&t2[i]!=t3[i]) flag1=0;
		if(t1[i]==2&&t2[i]!=t3[i]) flag2=0;
	}
	for(int i=1;i<=q;i++){
		if(t1[i]==1) query(1,1,n,t2[i],t4[i]);
		else add(1,1,n,t2[i],t3[i],t4[i]);
	}
	for(int i=1;i<=n;i++) query(1,1,n,i,1);
	for(int i=1;i<=m;i++) printf("%lld\n",cnt[i]);
	return 0;
}
