#include<bits/stdc++.h>
using namespace std;
long long n,a[1000005],b[1000005],sum[3000005],c[2005],mx=0,mn,t1,t2,ans=0,t3;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
signed main(){
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	n=read();
	for(long long i=1;i<=n;i++) a[i]=read(),mx=max(mx,a[i]);
	for(long long i=1;i<=n;i++){
		b[i]=read();mx=max(mx,b[i]);
		sum[b[i]]++;
	} 
	for(long long i=1;i<=1733;i++){
		c[i]=i*i;
		if(c[i]>=mx){
			mn=i;
			break;
		}
	} 
	for(long long i=1;i<=mx;i++) sum[i]+=sum[i-1];
	for(long long i=1;i<=n;i++){
		for(long long j=1;j<=mn;j++){
			t1=a[i]-c[j];t2=a[i]+c[j];
			if(t1<=0&&t2>mx) break;
			if(t1>0){
				t3=a[i]-c[j+1];
				if(t3<=0) ans=ans+sum[t1]*j;
				else ans=ans+(sum[t1]-sum[t3])*j;
			}
			if(t2<=mx){
				t3=a[i]+c[j+1];
				if(t3>mx) ans=ans+(sum[mx]-sum[t2-1])*j;
				else ans=ans+(sum[t3-1]-sum[t2-1])*j;
			}
		}
	}
	printf("%lld",ans);
	return 0;
}
