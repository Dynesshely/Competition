#include<bits/stdc++.h>
using namespace std;
int n,m,k,t,a,w,ans=0,x,y,b[8],dx[8]={1,1,0,-1,-1,-1,0,1},dy[8]={0,1,1,1,0,-1,-1,-1};
vector<bool> e[1005];
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read(),k=read(),t=read();
	for(int i=1;i<=t;i++){
		a=read();
		if(ans!=0) continue;
		if(e[a].size()<n){
			w=i&1;
			e[a].push_back(w);
			for(int j=0;j<=7;j++){
				x=e[a].size()+dx[j];y=a+dy[j];b[j]=0;
				while(x>=1&&x<=n&&y>=1&&y<=m){
					if(e[y].size()<x||e[y][x-1]!=w) break;
					b[j]++;
					x+=dx[j];y+=dy[j];
				}
			}
			for(int j=0;j<=3;j++) if(b[j]+b[j+4]>=k-1) ans=i;
		}
	}
	printf("%d",ans);
	return 0;
}
