#include<bits/stdc++.h>
using namespace std;
long long t,p,m,a[300005],b[300005],c[300005],inv[300005],ans=0,w;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("beauty.in","r",stdin);
	freopen("beauty.out","w",stdout);
	t=read();
	for(int i=1;i<=t;i++){
		p=read(),m=read();
		a[1]=a[0]=1;
		for(int j=2;j<=(p*2-1);j++) a[j]=(a[j-1]*j)%p;
		b[0]=1;
		for(int j=1;j<=p;j++) b[j]=(b[j-1]*m)%p;
		inv[1]=1;
		for(int j=2;j<p;j++) inv[j]=((p-p/j)*inv[p%j]+p)%p;
		c[0]=1;
		for(int j=1;j<=p;j++){
			c[j]=(((a[j*2]*inv[a[j]])%p)*inv[a[j]])%p;
		} 
		for(int j=0;j<p;j++) ans=(ans+(c[j]*b[j])%p)%p;
		printf("%lld\n",ans);
	}
	return 0;
}

