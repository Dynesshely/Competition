#include<bits/stdc++.h>
using namespace std;
int n,tot,ans=1e9;
struct ok{
	int x,y;
}a[100005];
vector<ok> e;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs(int k){
	if(k==n+1){
		tot=0;
		for(int i=0;i<e.size();i++){
			for(int j=i+1;j<e.size();j++) tot=max(tot,(e[i].x-e[j].x)*(e[i].x-e[j].x)+(e[i].y-e[j].y)*(e[i].y-e[j].y));
		}
		ans=min(ans,tot);
		return;
	}
	e.push_back((ok){0,a[k].y});
	dfs(k+1);
	e.pop_back();
	e.push_back((ok){a[k].x,0});
	dfs(k+1);
	e.pop_back();
}
int main(){
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		a[i].x=read(),a[i].y=read();
	}
	dfs(1);
	printf("%d",ans);
	return 0;
}

