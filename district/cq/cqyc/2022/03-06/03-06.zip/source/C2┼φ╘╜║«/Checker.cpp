#include <bits/stdc++.h>
using namespace std;
int main() {
	while(1) {
		system("t2_Data_Maker.exe");
		system("hard.exe");
		system("t2st2.exe");
		if(system("fc 2.out hard.out")) break;
	}
}
