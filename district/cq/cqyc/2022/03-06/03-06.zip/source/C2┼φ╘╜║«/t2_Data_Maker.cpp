#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("hard.in","w",stdout);
	srand(time(0));
	int n=rand()%5+1;
	printf("%d\n",n);
	for(int i=1;i<=n;++i) printf("%d ",rand()%7+1);
	printf("\n");
	for(int i=1;i<=n;++i) printf("%d ",rand()%7+1); 
}
