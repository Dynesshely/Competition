#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=1005;
int n,m,k,t,a[N][N],tp[N];
int mv[4][2]={{-1,1},{-1,-1},{-1,0},{0,1}};
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
inline void __(int x){
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)pc(stk[tp--]^48);
}
inline bool Go(int X,int Y,int f) {
	int ct1=1,tx=mv[f][0],ty=mv[f][1];
	for(int x=X,y=Y;x>0&&y<=m&&x<=n&&y>0;x+=tx,y+=ty) {
//			printf("%d %d\n",x,y);
		if(a[x+tx][y+ty]==a[x][y]) {
			++ct1;
			if(ct1==k) return 1;
		}
		else break;
	}
	for(int x=X,y=Y;x>0&&y<=m&&x<=n&&y>0;x-=tx,y-=ty) {
//		printf("%d %d\n",x,y);
		if(a[x-tx][y-ty]==a[x][y]) {
			++ct1;
			if(ct1==k)	return 1;
		}
		else break;
	}
//	printf("%d \n",ct1);
	if(ct1>=k) return 1;
	return 0;
}
bool Check(int X,int Y) {
//	printf("%d %d %d\n",X,Y,a[X][Y]);
	int res=0;
	for(int i=0;i<4;++i) res|=Go(X,Y,i);
	return res;
}
int main() {
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	memset(a,-1,sizeof(a));
	n=_(),m=_(),k=_(),t=_();
	for(int i=1;i<=m;++i) {
		tp[i]=n;
	}
	for(int i=1;i<=t;++i) {
		int u=_();
		a[tp[u]][u]=i&1;
		if(Check(tp[u],u)) __(i),exit(0);
//		printf("\n");
		tp[u]--;
	}
}
//100pts
//14:30~15:10

