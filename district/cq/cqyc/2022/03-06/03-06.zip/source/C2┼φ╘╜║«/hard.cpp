#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define ll long long
using namespace std;
const int N=1e6+5;
int n,ans,mx,a[N],b[N],ta[N],tb[N];
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
inline void __(ll x){
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)pc(stk[tp--]^48);
}
int main() {
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	n=_();
	for(int i=1;i<=n;++i) a[i]=_(),mx=max(mx,a[i]);
	for(int i=1;i<=n;++i) b[i]=_(),mx=max(mx,b[i]);
	if(n<=5000) {
		for(int i=1;i<=n;++i) 
			for(int j=1;j<=n;++j) 
				ans+=sqrt(abs(a[i]-b[j]));
		__(ans);
	}
	else /*if(mx<=2000)*/ {
		for(int i=1;i<=n;++i) ++ta[a[i]],++tb[b[i]];
		for(int i=1;i<=mx;++i) 
			for(int j=1;j<=mx;++j) 
				ans+=(ll)sqrt(abs(i-j))*ta[i]*tb[j];
		__(ans);
	}
}
//30pts
//15:20~15:40(st1+st2)
