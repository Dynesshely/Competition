#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define ll long long
#define ls (x<<1)
#define rs (ls|1)
#define md ((l+r)>>1)
using namespace std;
const int N=5e5+5;
int n,m,q,a[N],xxy[N<<2],tag[N<<2];
ll ans[N];
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
inline void __(ll x){
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)pc(stk[tp--]^48);
}
void Build(int x,int l,int r) {
	if(l==r) {xxy[x]=_();return ;}
	Build(ls,l,md);
	Build(rs,md+1,r);
}
void Modify(int x,int l,int r,int L,int R,int t) {
	if(l>=L&&r<=R) {xxy[x]=t;tag[x]=t;return ;}
	if(L<=md) Modify(ls,l,md,L,R,t);
	if(R>md) Modify(rs,md+1,r,L,R,t);
}
void Modify1(int x,int l,int r,int t,int f) {
	if(l==r) {ans[xxy[x]]+=f;return ;}
	if(tag[x]) xxy[ls]=xxy[rs]=tag[x];
	if(t<=md) Modify1(ls,l,md,t,f);
	else Modify1(rs,md+1,r,t,f);
}
void Print(int x,int l,int r) {
//	printf("x:%d l:%d r:%d xxy:%d tag:%d\n",x,l,r,xxy[x],tag[x]);
	if(l==r) return ;
	Print(ls,l,md);
	Print(rs,md+1,r);
}
int main() {
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	n=_(),m=_(),q=_();
	if(n<=5000) {
		for(int i=1;i<=n;++i) a[i]=_();
		while(q--) {
			int ty=_(),l=_(),r=_(),x=_();
			if(ty==1) for(int i=l;i<=r;++i) a[i]=x;
			else for(int i=l;i<=r;++i) ans[a[i]]+=x;
		}
		for(int i=1;i<=m;++i) __(ans[i]),pc('\n');
	}
	else {
		Build(1,1,n);
		Print(1,1,n);
		while(q--) {
			int ty=_(),l=_(),r=_(),x=_();
			if(ty==1) Modify(1,1,n,l,r,x),Print(1,1,n);
			else Modify1(1,1,n,l,x);
		}
		for(int i=1;i<=m;++i) __(ans[i]),pc('\n');
	}
}
//30pts
//16:20~17:10
