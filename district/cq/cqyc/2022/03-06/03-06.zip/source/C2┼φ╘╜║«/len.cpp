#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define int long long
using namespace std;
const int N=1e5+5;
int n,ans,x[N],y[N],t[N];
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
inline void __(int x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)pc(stk[tp--]^48);
}
inline int _2(int x) {return x*x;}
inline void Update() {
	int res=0;
	for(int i=1;i<=n;++i) 
	for(int j=i+1;j<=n;++j) 
	res=max(res,_2(x[i]*t[i]-x[j]*t[j])
		+_2(y[i]*(t[i]^1)-y[j]*(t[j]^1)));
	ans=min(ans,res);
}
void DFS(int x) {
	if(x>n) {Update();return ;}
	t[x]=1,DFS(x+1),t[x]=0,DFS(x+1);
}
signed main() {
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	n=_();
	for(int i=1;i<=n;++i) x[i]=_(),y[i]=_();
	if(n<=15) {
		ans=1e18;
		DFS(1);
		__(ans);
	}
}
//30pts
//15:40~16:15
