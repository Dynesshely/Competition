#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("king.in","w",stdout);
	srand(time(0));
	int n=rand()%100+1,m=rand()%100+1,q=rand()%100+1;
	printf("%d %d %d\n",n,m,q);
	for(int i=1;i<=n;++i) printf("%d ",rand()%m+1);
	printf("\n");
	for(int i=1;i<=q;++i) {
		int opt=rand()%2+1,l=rand()%n+1,x=rand()%m+1;
		printf("%d %d %d %d\n",opt,l,l,x);
	}
} 
