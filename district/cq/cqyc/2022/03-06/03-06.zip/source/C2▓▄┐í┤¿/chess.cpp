#include <bits/stdc++.h>
using namespace std;
int n,m,k,t,sum;
int a[1003][1003];//1 w 2 b
int mx[1003];
bool hanshu(int z,int y)
{
//	cout<<z<<' '<<y<<'\n';
	int p1=0,p2=0,p3=0,p4=0,p5=0,p6=0,p7=0,p8=0;
	for(int i=1;i<k;++i)
	{
		int X=z+i,Y=y+i;
		if(X<=n)
			if(a[X][y]==a[X-1][y]&&a[X][y]!=0) p1++;
		if(Y<=n)
			if(a[z][Y]==a[z][Y-1]&&a[z][Y]!=0) p2++;
		if(X<=n&&Y<=n)
			if(a[X][Y]==a[X-1][Y-1]&&a[X][Y]!=0) p5++;
		int xx=z-i,yy=y-i;
		if(X<=n&&yy>0)
			if(a[X][yy]==a[X-1][yy+1]&&a[X][yy]!=0) p7++;
		if(Y<=n&&xx>0)
			if(a[xx][Y]==a[xx+1][Y-1]&&a[xx][Y]!=0) p8++;
		if(xx>0)
			if(a[xx][y]==a[xx+1][y]&&a[xx][y]!=0) p3++;
		if(yy>0)
			if(a[z][yy]==a[z][yy+1]&&a[z][yy]!=0) p4++;
		if(xx>0&&yy>0)
			if(a[xx][yy]==a[xx+1][yy+1]&&a[xx][yy]!=0) p6++;
	}
//	cout<<p1<<' '<<p2<<' '<<p3<<' '<<p4<<'\n';
	if(p1==k-1||p2==k-1||p3==k-1||p4==k-1||p5==k-1||p6==k-1||p7==k-1||p8==k-1) return true;
	else return false;
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&k,&t);
	for(int i=1;i<=t;++i)
	{
		int x;
		sum++;
		scanf("%d",&x);
		mx[x]++;
		if(i%2==1) a[mx[x]][x]=2;//ǰ����ż���� 
		else a[mx[x]][x]=1;
		if(hanshu(mx[x],x)) break;
	}
/*	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
			cout<<a[i][j]<<' '; 
		cout<<'\n';
	}*/
	printf("%d",sum);
}
