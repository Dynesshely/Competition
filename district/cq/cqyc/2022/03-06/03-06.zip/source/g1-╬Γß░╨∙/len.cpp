#include<cstdio>
#include<cmath>
#include<algorithm>
#define int long long
using namespace std;
const int N=1e5+5;
struct aa{
	int x,y;
}a[N];
int pf(int a){
	return a*a;
}
bool cmp(aa a,aa b){
	return a.x<b.x;
}
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int n,mal[N],mar[N],mil[N],mir[N];
bool pd(int mid){
	int r=n,l=n;
	while(ma) modife
}
signed main(){
//	freopen("len.in","r",stdin);
//	freopen("len.out","w",sdout);
	n=read();
	for(int i=1;i<=n;i++){
		a[i].x=read();
		a[i].y=read();
	}
	sort(a+1,a+1+n,cmp);
	int ans=1e18;
	mal[1]=mil[1]=a[1].y
	return 0;
}
