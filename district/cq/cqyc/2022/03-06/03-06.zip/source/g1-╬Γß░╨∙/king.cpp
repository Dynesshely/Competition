#include<cstdio>
#define int long long
#define mid ((l+r)>>1)
const int N=5e5+5;
int lx[4*N],ans[N],sum[4*N],sz[4*N],la[4*N],pd[4*N],n,m,q,vd[N],rd[N];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
void down1(int g){
	if(lx[g]){
		lx[2*g]=lx[2*g+1]=lx[g];
		lx[g]=0;
	}
}
void down2(int g){
	if(pd[g]){
		pd[2*g]=pd[2*g+1]=1;
		sum[2*g]=sum[2*g+1]=la[2*g]=la[2*g+1]=0;
		pd[g]=0;
	}
	sum[2*g]+=la[g]*sz[2*g];
	sum[2*g+1]+=la[g]*sz[2*g+1];
	la[2*g]+=la[g];
	la[2*g+1]+=la[g];
	la[g]=0;
}
void up(int g){
	sum[g]=sum[2*g+1]+sum[2*g];
}
int cl(int g,int l,int r,int v){
	if(l==r){
		return lx[g];
	}
	down1(g); 
	if(v<=mid) return cl(2*g,l,mid,v);
	return cl(2*g+1,mid+1,r,v);
}
void gg(int g,int l,int r,int ll,int rr,int lxx){
	if(ll<=l && r<=rr){
		lx[g]=lxx;
		return;
	}
	down1(g);
	if(ll<=mid) gg(2*g,l,mid,ll,rr,lxx);
	if(rr>mid) gg(2*g+1,mid+1,r,ll,rr,lxx);
}
int cs(int g,int l,int r,int l1,int r1){
	if(l1<=l && r<=r1){
		int ans=sum[g];
		pd[g]=1;
		return ans;
	}
	down2(g);
	int ans=0;
	if(l1<=mid) ans+=cs(2*g,l,mid,l1,r1);
	if(r1>mid) ans+=cs(2*g+1,mid+1,r,l1,r1);
	up(g);
	return ans;
}
void add(int g,int l,int r,int l1,int r1,int ll){
	if(l1<=l && r<=r1){
		la[g]+=ll;
		sum[g]+=sz[g]*ll;
		return;
	}
	down2(g);
	if(ll<=mid) add(2*g,l,mid,l1,r1,ll);
	if(r1>mid) add(2*g+1,mid+1,r,l1,r1,ll);
	up(g);
}
void build(int g,int l,int r){
	sz[g]=r-l+1;
	if(l==r){
		lx[l]=l;
		vd[l]=read();
		return;
	}
	build(2*g,l,mid);
	build(2*g+1,mid+1,r);
}
void down(int g,int l,int r){
	if(l==r){
		ans[vd[lx[g]]]+=sum[g];
		return;
	}
	down1(g);
	down2(g);
	down(2*g,l,mid);
	down(2*g+1,mid+1,r);
}
signed main(){
	n=read();
	m=read();
	q=read();
	build(1,1,n);
	while(q--){
		int op=0,l=0,r=0,x=0;
		op=read();
		l=read();
		r=read();
		x=read();
		if(op==2){
			add(1,1,n,l,r,x);
			continue;
		}
		rd[cl(1,1,n,l)]=l-1;
		int nl=l,nr=r;
		while(1){
			int l1=cl(1,1,n,l);
			if(rd[l1]>=r) continue;
			ans[vd[l1]]+=cs(1,1,n,l,rd[l1]);
			l=rd[l1]+1;
		}
		
	}
}
