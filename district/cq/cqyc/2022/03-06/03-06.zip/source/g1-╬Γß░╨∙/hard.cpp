#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
#define int long long
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
const int N=3e6+5;
int ma1,ma2,a[N],b[N],n;
signed main(){
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		int c=0;
		c=read();
		a[c]++;
		ma1=max(ma1,c);
	}
	for(int i=1;i<=n;i++){
		int c=0;
		c=read();
		b[c]++;
		ma2=max(ma2,c);
	}
	for(int i=1;i<=max(ma2,ma1);i++) b[i]+=b[i-1];
	int ans=0;
	for(int i=0;i<=ma1;i++){
		if(!a[i]) continue;
		for(int j=1;j*j<=i;j++){
			ans+=j*b[i-j*j]*a[i];
			if(i-((j+1)*(j+1))>=0) ans-=j*b[i-((j+1)*(j+1))]*a[i];
		}
		for(int j=1;j*j+i<=ma2;j++){
			ans+=j*b[min(ma2,(j+1)*(j+1)+i-1)]*a[i]-j*b[i+j*j-1]*a[i];
		}
	}
	printf("%lld",ans);
}
