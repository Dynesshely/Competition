#include<cstdio>
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
const int N=1e3+5;
int n,m,t,k,a[N][N],now[N];
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read();
	m=read();
	k=read();
	t=read();
	for(int i=1;i<=t;i++){
		int v;
		v=read();
		now[v]++;
		int q=(i&1)+1;
		a[now[v]][v]=q;
		int l=v,r=v;
		while(a[now[v]][l-1]==q) l--;
		while(a[now[v]][r+1]==q) r++;
		if(r-l+1>=k){
			printf("%d",i);
			return 0;
		}
		l=r=now[v];
		while(a[l-1][v]==q) l--;
		while(a[r+1][v]==q) r++;
		if(r-l+1>=k){
			printf("%d",i);
			return 0;
		}
		l=r=0;
		while(a[now[v]+r+1][v+r+1]==q) r++;
		while(a[now[v]+l-1][v+l-1]==q) l--;
		if(r-l+1>=k){
			printf("%d",i);
			return 0;
		}
		l=r=0;
		while(a[now[v]+r+1][v-r-1]==q) r++;
		while(a[now[v]+l-1][v-l+1]==q) l--;
		if(r-l+1>=k){
			printf("%d",i);
			return 0;
		}
	}
	return 0;
}
