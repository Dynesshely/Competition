#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
signed main()
{
	freopen("len.in","w",stdout);
	srand(time(0));
	int n=1000;
	cout<<n<<'\n';
	for(int i=1;i<=n;i++)
	{
		cout<<rand()%n<<" "<<rand()%n<<'\n'; 
	}
	return 0;
}
