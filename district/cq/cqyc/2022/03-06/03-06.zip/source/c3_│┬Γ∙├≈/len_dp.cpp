#include<bits/stdc++.h>
using namespace std;

int main()
{
	while(1)
	{
		system("len_datamaker.exe");
		system("len.exe");
		system("lenp.exe");
		if(system("fc len.out lenp.out")) return 0;
	}
	return 0;
}
