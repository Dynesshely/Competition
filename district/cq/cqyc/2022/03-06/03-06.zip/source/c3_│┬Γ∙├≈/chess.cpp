#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n,m,k,t,a,cnt[1010],qp[1010][1010];
bool check(int x,int y)
{
	int sum=0;
	int now;
	for(int i=x;;i--)
	{
		if(qp[i][y]!=qp[x][y])
		{
			now=i;
			break;
		}
	}
	for(int i=now+1;;i++)
	{
		if(qp[i][y]!=qp[x][y])
		{
			break;
		}
		sum++;
		if(sum>=k) return 1;
	}
	sum=0;
	for(int i=y;;i--)
	{
		if(qp[x][i]!=qp[x][y])
		{
			now=i;
			break;
		}
	}
	for(int i=now+1;;i++)
	{
		if(qp[x][i]!=qp[x][y])
		{
			break;
		}
		sum++;
		if(sum>=k) return 1;
	}
	sum=0;
	int nx,ny;
	for(int i=x,j=y;;i++,j++)
	{
		if(qp[i][j]!=qp[x][y])
		{
			nx=i,ny=j;
			break;
		}
	}
	for(int i=nx-1,j=ny-1;;i--,j--)
	{
		if(qp[i][j]!=qp[x][y])
		{
			break;
		}
		sum++;
		if(sum>=k) return 1;
	}
	sum=0;
	for(int i=x,j=y;;i++,j--)
	{
		if(qp[i][j]!=qp[x][y])
		{
			nx=i,ny=j;
			break;
		}
	}
	for(int i=nx-1,j=ny+1;;i--,j++)
	{
		if(qp[i][j]!=qp[x][y])
		{
			break;
		}
		sum++;
		if(sum>=k) return 1;
	}
	return 0;
}
signed main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read(),k=read(),t=read();
	for(int i=1;i<=t;++i)
	{
		a=read();
		qp[a][++cnt[a]]=i%2+1;
		if(check(a,cnt[a]))
		{
			cout<<i;
			return 0;
		}
	}
	return 0;
}
