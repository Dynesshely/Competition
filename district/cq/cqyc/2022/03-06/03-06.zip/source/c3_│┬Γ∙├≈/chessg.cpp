#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n,m,k,t,a,cnt[1010],qp[1010][1010];
bool check()
{
	int sum=0;
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			if(qp[j][i]==0) sum=0;
			else if(qp[j][i]!=qp[j-1][i])
			{
				sum=1;
			}
			else
			{
				sum++;
				if(sum>=k)
				{
					return 1;
				}
			}
		}
	}
	sum=0;
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			if(qp[i][j]==0) sum=0;
			else if(qp[i][j]!=qp[i][j-1])
			{
				sum=1;
			}
			else
			{
				sum++;
				if(sum>=k)
				{
					return 1;
				}
			}
		}
	}
	for(int i=1;i<=n;++i)
	{
		sum=0;
		for(int x=i,y=1;x<=n&&y<=m;x++,y++)
		{
			if(qp[x][y]==0) sum=0;
			else if(qp[x][y]!=qp[x-1][y-1])
			{
				sum=1;
			}
			else
			{
				sum++;
				if(sum>=k)
				{
					return 1;
				}
			}
		}
		sum=0;
		for(int x=1,y=i;x<=n&&y<=m;x++,y++)
		{
			if(qp[x][y]==0) sum=0;
			else if(qp[x][y]!=qp[x+1][y-1])
			{
				sum=1;
			}
			else
			{
				sum++;
				if(sum>=k)
				{
					return 1;
				}
			}
		}
		sum=0;
		for(int x=i,y=1;x<=n&&y<=m;x++,y++)
		{
			if(qp[x][y]==0) sum=0;
			else if(qp[x][y]!=qp[x-1][y-1])
			{
				sum=1;
			}
			else
			{
				sum++;
				if(sum>=k)
				{
					return 1;
				}
			}
		}
	}
	return 0;
}
signed main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read(),k=read(),t=read();
	for(int i=1;i<=t;++i)
	{
		a=read();
		qp[a][++cnt[a]]=i%2+1;
		if(check())
		{
			cout<<i;
			return 0;
		}
	}
	return 0;
}
