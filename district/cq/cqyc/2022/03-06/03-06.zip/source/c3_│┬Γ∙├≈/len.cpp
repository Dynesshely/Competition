#include<bits/stdc++.h>
#define int long long
#define ls(x) (x<<1)
#define rs(x) (x<<1|1)
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n;
struct node
{
	int x,y;
	bool operator < (const node b) const
	{
		if(y==b.y) return x<b.x;
		return y<b.y;
	}
	void debug()
	{
		cerr<<x<<" "<<y<<"\n";
	}
	void init()
	{
		x=read(),y=read();
	}
}a[100010];
int mx[1000010],mi[1000010];
void build(int x,int l,int r)
{
//	cerr<<x<<' '<<l<<" "<<r<<"b\n";
	if(l==r)
	{
		mx[x]=a[l].x,mi[x]=a[l].x;
		return;
	}
	int mid=(l+r)>>1;
	build(ls(x),l,mid);
	build(rs(x),mid+1,r);
	mx[x]=max(mx[ls(x)],mx[rs(x)]);
	mi[x]=min(mi[ls(x)],mi[rs(x)]); 
}
int qmi(int x,int L,int R,int l,int r)
{
	if(L==l&&R==r)
	{
		return mi[x];
	}
	int mid=(L+R)>>1;
	if(mid<l)
	{
		return qmi(rs(x),mid+1,R,l,r);
	}
	if(mid>=r)
	{
		return qmi(ls(x),L,mid,l,r);
	}
	return min(qmi(ls(x),L,mid,l,mid),qmi(rs(x),mid+1,R,mid+1,r));
}
int qmx(int x,int L,int R,int l,int r)
{
	if(L==l&&R==r)
	{
		return mx[x];
	}
	int mid=(L+R)>>1;
	if(mid<l)
	{
		return qmx(rs(x),mid+1,R,l,r);
	}
	if(mid>=r)
	{
		return qmx(ls(x),L,mid,l,r);
	}
	return max(qmx(ls(x),L,mid,l,mid),qmx(rs(x),mid+1,R,mid+1,r));
}
int pw(int x)
{
	return x*x;
}
signed main()
{
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	{
		a[i].init();
	}
	for(int i=1;i<=1000000;i++)
	{
		mi[i]=100000000000000000;
		mx[i]=-100000000000000000;
	}
	sort(a+1,a+n+1);
//	for(int i=1;i<=n;i++)
//	{
//		a[i].debug();
//	}
//	cerr<<"Hh\n"; 
	build(1,1,n);
	int ans=1000000000000000000;
	if(n<=1000)
	{
//		cerr<<"en\n";
		for(int i=n;i>=1;--i)
		{
			int mx=0,tot=1000000000000000000;
			for(int j=1;j<=i;j++)
			{
				mx=max(mx,pw(a[i].y-a[j].y));
				if(i<n)
				{
					tot=max(abs(qmx(1,1,n,i+1,n)),abs(qmi(1,1,n,i+1,n)));
				}
				if(j>1)
				{
					tot=max(tot,abs(qmi(1,1,n,1,j-1)));
					tot=max(tot,abs(qmx(1,1,n,1,j-1)));
				} 
				if(i==n&&j==1) continue;
				mx=max(mx,pw(tot)+pw(a[i].y));
				ans=min(ans,mx);
			}
		}
		cout<<ans<<'\n';
	}
	else
	{
		int mx=0;
		for(int i=n;i>=1;--i)
		{
			mx=pw(a[i].y-a[1].y);
			if(i<n)
			{
				mx=max(mx,pw(a[i].y)+pw(max(abs(qmx(1,1,n,i+1,n)),abs(qmi(1,1,n,i+1,n)))));
			}
			ans=min(ans,mx);
		}
		cout<<ans<<'\n';
	} 
	return 0;
}
