#include <bits/stdc++.h>
using namespace std; 
int n, m, q, a[500005], sum[500005], l, r, opt, x, ans[500005];
inline int read() {
	int x=0; char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){ x=(x<<1)+(x<<3)+(ch^48); ch=getchar();}
	return x;
}
int stk[30],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) putchar(stk[tp--]^48);
}
int main() {
	freopen("king.in", "r", stdin);
	freopen("king.out", "w", stdout);
	n=read(), m=read(), q=read();
	for(int i = 1; i <= n; ++i) a[i]=read();
	for(int i = 1; i <= q; ++i) {
		opt=read(), l=read(), r=read(), x=read();
		if(opt == 1)
			for(int i = l; i <= r; ++i)
				a[i]=x, ans[x]+=sum[i];
		else 
			for(int i = l; i <= r; ++i)
				if(!a[i]) sum[i]+=x;
				else ans[a[i]]+=x;
	}
	for(int i = 1; i <= m; ++i)
		write(ans[i]), putchar('\n');
	return 0;
}
