#include <bits/stdc++.h>
using namespace std;
int n=10000;
int main() {
	freopen("hard.in", "w", stdout);
	srand(time(0));
	cout<<n<<"\n";
	for(int i = 1; i <= n; ++i) cout<<rand()%100000<<" ";cout<<"\n";
	for(int i = 1; i <= n; ++i) cout<<rand()%100000<<" ";cout<<"\n";
	return 0;
} 
