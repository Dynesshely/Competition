#include <bits/stdc++.h>
using namespace std;
int n, a[3000005], b[3000005];
long long ans;
inline int read() {
	int x=0; char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){ x=(x<<1)+(x<<3)+(ch^48); ch=getchar();}
	return x;
}
int stk[30],tp;
void write(long long x) {
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) putchar(stk[tp--]^48);
}
int main() {
	freopen("hard.in", "r", stdin);
	freopen("hard.ans", "w", stdout);
	n=read();
	for(int i = 1; i <= n; ++i)
		a[i]=read();
	for(int i = 1; i <= n; ++i)
		b[i]=read();
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= n; ++j)
			ans+=floor(sqrt(1.0*abs(a[i]-b[j])));
	write(ans);
	return 0;
} 
