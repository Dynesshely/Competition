#include <bits/stdc++.h>
using namespace std;
int n, m, t, k, qwq, r[1003], a[1003][1003], b[15],
fx[15][2]={{0, 0}, {1, 0}, {-1, 0}, {0, -1}, {1, -1}, {1, 1}, {-1, 1}, {-1, -1}};
int main() {
	freopen("chess.in", "r", stdin);
	freopen("chess.out", "w", stdout);
	scanf("%d%d%d%d",&n,&m,&k,&t);
	for(int i = 1; i <= m; ++i) r[i]=1;
	for(int i = 1; i <= t; ++i) {
		scanf("%d", &qwq);
		int col=i%2+1/*2Ϊ��, 1Ϊ��*/, 
		x = qwq, y = r[qwq]++; a[x][y]=col;
		for(int j = 1; j <= 7; ++j) { b[j]=0;
			int X=x, Y=y; 
			for(int o = 1; o <= k; ++o) {
				X+=fx[j][0], Y+=fx[j][1];
				if(X > m || Y > n || X <= 0 || Y <= 0 || a[X][Y] != col)
					break;
				b[j]=o;
			}
		}
		if(b[1]+b[2] >= k-1 || b[3] >= k-1 || b[4]+b[6] >= k-1 || b[5]+b[7] >= k-1) {
			printf("%d\n", i);
			break;
		}
	}
	return 0;
} 
