#include <bits/stdc++.h>
using namespace std;
int n, a, b, la[3000005], ra[3000005], maxn=100000;
long long ans;
inline int read() {
	int x=0; char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){ x=(x<<1)+(x<<3)+(ch^48); ch=getchar();}
	return x;
}
int stk[30],tp;
void write(long long x) {
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) putchar(stk[tp--]^48);
}
int main() {
	freopen("hard.in", "r", stdin);
	freopen("hard.out", "w", stdout);
	n=read();
	for(int i = 1; i <= n; ++i) {
		a=read(); int gs=1;
		while(gs*gs+a <= maxn) la[a+gs*gs]+=1, ++gs;
		gs=1;
		while(a-gs*gs >= 0) ra[a-gs*gs]+=1, ++gs;
	}
	for(int i = 1; i <= maxn; ++i) la[i]+=la[i-1];
	for(int i = maxn; i >= 0; --i) ra[i]+=ra[i+1];
	for(int i = 1; i <= n; ++i)
		b=read(), ans+=1LL*la[b]+ra[b];
	write(ans);
	return 0;
} 
