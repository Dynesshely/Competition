#include <bits/stdc++.h>
using namespace std;
int n, x[20], y[20], ans=0x3f3f3f3f;
inline int read() {
	int x=0, f=1; char ch=getchar();
	while(ch<'0'||ch>'9'){ if(ch=='-') f= -1; ch=getchar();}
	while(ch>='0'&&ch<='9'){ x=(x<<1)+(x<<3)+(ch^48); ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) putchar(stk[tp--]^48);
}
void dfs(int qwq) {
	if(qwq == n+1) {
		int sum=0;
		for(int i = 1; i < n; ++i)
			for(int j = i+1; j <= n; ++j)
				sum=max(sum, (x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]));
		ans=min(ans, sum);
		return ;
	}
	int a = x[qwq], b = y[qwq];
	x[qwq]=0; dfs(qwq+1);
	x[qwq]=a, y[qwq]=0;
	dfs(qwq+1);
	y[qwq]=b;
}
int main() {
	freopen("len.in", "r", stdin);
	freopen("len.out", "w", stdout);
	n=read();
	if(n >= 20) return 0; 
	for(int i = 1; i <= n; ++i)
		x[i]=read(), y[i]=read();
	dfs(1);
	write(ans);
	return 0;
} 
