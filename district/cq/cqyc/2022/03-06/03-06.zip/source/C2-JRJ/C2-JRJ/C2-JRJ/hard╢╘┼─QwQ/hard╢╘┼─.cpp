#include <bits/stdc++.h>
using namespace std;
int main() {
	while(1) {
		system("hard����.exe");
		system("hard.exe");
		system("hard����.exe");
		if(system("fc hard.out hard.ans"))
			break; 
	}
	return 0;
} 
