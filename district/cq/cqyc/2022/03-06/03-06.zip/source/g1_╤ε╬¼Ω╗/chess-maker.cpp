#include<bits/stdc++.h>
using namespace std;
typedef long long van;
van randx() {
	return rand()*1e4+rand();
}
int main() {
	srand(time(0));
	freopen("king.in","w",stdout);
	van n=10,m=10,q=20;
	cout<<n<<" "<<m<<" "<<q<<endl;
	for (int i=1;i<=n;i++) cout<<randx()%m<<" ";cout<<endl;
	for (int i=1;i<=q;i++) {
		van l=rand()%n+1,r=rand()%(n-l+1)+l;
		cout<<rand()%2+1<<" "<<l<<" "<<r<<" "<<rand()%m<<endl;
	}
}
