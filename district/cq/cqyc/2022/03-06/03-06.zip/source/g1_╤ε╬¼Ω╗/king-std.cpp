#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
const van MaxN=5e5+10;
van n,m,t,ans[MaxN],bel[MaxN],lst[MaxN];
int main() {
	freopen("king.in","r",stdin);
//	freopen("king.ans","w",stdout);
	read(n),read(m),read(t); 
	for (int i=1;i<=n;i++) read(bel[i]);
	for (int i=1;i<=t;i++) {
		van opt,l,r,x;
		read(opt),read(l),read(r),read(x);
		for (int j=1;j<=n;j++) cout<<bel[j]<<" ";cout<<endl;
		if (opt==1) for (int j=l;j<=r;j++) bel[j]=x,ans[x]+=lst[j],lst[j]=0;
		else for (int j=l;j<=r;j++) bel[j]?ans[bel[j]]+=x:lst[j]+=x;
	} for (int i=1;i<=m;i++) print(ans[i]),putchar('\n');
	return 0;
}
