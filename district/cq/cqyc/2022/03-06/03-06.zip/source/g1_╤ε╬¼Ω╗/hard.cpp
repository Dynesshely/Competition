#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
const van MaxN=3e6+100;
van n,a[MaxN],b[MaxN],sum[MaxN],ans;
int main() {
	freopen("hard.in","r",stdin);
	read(n); for (int i=1;i<=n;i++) read(a[i]);
	for (int i=1;i<=n;i++) read(b[i]);
	for (int i=1;i<=n;i++) sum[b[i]+10]++;
	for (int i=1;i<=3e6;i++) sum[i]+=sum[i-1];
	van siz=sqrt(3e6)+1;
	for (int i=1;i<=n;i++) {
		for (int j=1;j<=siz;j++) {
			van l=max((van)-1,a[i]-(j+1)*(j+1))+10,r=max((van)-1,a[i]-j*j)+10;
			ans+=j*(sum[r]-sum[l]);
//			cout<<i<<" "<<j<<" "<<ans<<endl;
		}
	} memset(sum,0,sizeof sum);
	for (int i=1;i<=n;i++) sum[a[i]+10]++;
	for (int i=1;i<=3e6;i++) sum[i]+=sum[i-1];
	for (int i=1;i<=n;i++) {
		for (int j=1;j<=siz;j++) {
			van l=max((van)-1,b[i]-(j+1)*(j+1))+10,r=max((van)-1,b[i]-j*j)+10;
			ans+=j*(sum[r]-sum[l]);
//			cout<<i<<" "<<j<<" "<<ans<<endl;
		}
	} freopen("hard.out","w",stdout);
	print(ans);
	return 0;
}
