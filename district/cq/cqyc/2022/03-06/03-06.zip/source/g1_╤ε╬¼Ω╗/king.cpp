#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
const van MaxN=5e5+10;
van n,m,t,ans[MaxN],a[MaxN];
struct query {
	van opt,l,r,x;
}q[MaxN];
struct SGT {
	van dat[MaxN<<2],tag[MaxN<<2]; bool empty[MaxN<<2];
	void BuildTree(van p=1,van l=1,van r=n) {
		if (l==r) {dat[p]=tag[p]=empty[p]=0;return;}
		van mid=(l+r)>>1; empty[p]=0;
		BuildTree(p*2,l,mid); 
		BuildTree(p*2+1,mid+1,r);
		dat[p]=dat[p*2]+dat[p*2+1],tag[p]=0;
	}
	void spread(van p,van ls,van rs) {
		if (empty[p]) {
			dat[p*2]=0,dat[p*2+1]=0;
			tag[p*2]=0,tag[p*2+1]=0;
			empty[p]=false; empty[p*2]=true,empty[p*2+1]=true;
		}
		if (tag[p]) {
			dat[p*2]+=tag[p]*ls,dat[p*2+1]+=tag[p]*rs;
			tag[p*2]+=tag[p],tag[p*2+1]+=tag[p],tag[p]=0;
		}
	}
	void UpdateTree(van L,van R,van num,van p=1,van l=1,van r=n) {
		if (L<=l&&r<=R) {dat[p]+=num*(r-l+1),tag[p]+=num;return;}
		van mid=(l+r)>>1;spread(p,mid-l+1,r-mid);
		if (L<=mid) UpdateTree(L,R,num,p*2,l,mid);
		if (R>mid) UpdateTree(L,R,num,p*2+1,mid+1,r);
		dat[p]=dat[p*2]+dat[p*2+1]; 
	}
	void ClearTree(van L,van R,van p=1,van l=1,van r=n) {
		if (L<=l&&r<=R) {dat[p]=tag[p]=0; empty[p]=true; return;}
		van mid=(l+r)>>1; spread(p,mid-l+1,r-mid);
		if (L<=mid) ClearTree(L,R,p*2,l,mid);
		if (R>mid) ClearTree(L,R,p*2+1,mid+1,r);
		dat[p]=dat[p*2]+dat[p*2+1];
	}
	van QueryTree(van L,van R,van p=1,van l=1,van r=n) {
		if (L<=l&&r<=R) return dat[p];
		van mid=(l+r)>>1,sum=0; spread(p,mid-l+1,r-mid);
		if (L<=mid) sum+=QueryTree(L,R,p*2,l,mid);
		if (R>mid) sum+=QueryTree(L,R,p*2+1,mid+1,r);
		return sum;
	}
}T;
int main() {
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	read(n),read(m),read(t); T.BuildTree();
	for (int i=1;i<=n;i++) read(a[i]);
	for (int i=1;i<=t;i++) read(q[i].opt),read(q[i].l),read(q[i].r),read(q[i].x);
	for (int i=t;i;i--) {
		if (q[i].opt==1) {
			ans[q[i].x]+=T.QueryTree(q[i].l,q[i].r);
			T.ClearTree(q[i].l,q[i].r);
		} else T.UpdateTree(q[i].l,q[i].r,q[i].x);
	} for (int i=1;i<=n;i++) ans[a[i]]+=T.QueryTree(i,i);
	for (int i=1;i<=m;i++) print(ans[i]),putchar('\n');
	return 0;
}
