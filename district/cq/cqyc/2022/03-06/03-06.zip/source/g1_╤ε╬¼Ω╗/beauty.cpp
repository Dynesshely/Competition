#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
const van MaxN=2e6+10;
van T,m,p,inv[MaxN];
van power(van x,van b) {
	if (b<0) return 1;
	van ans=1,base=x;
	while (b) {
		if (b&1) ans*=base,ans%=p;
		base*=base,base%=p,b>>=1;
	} return ans;
}
int main() {
	freopen("beauty.in","r",stdin);
	freopen("beauty.out","w",stdout);
	read(T); for (int t=1;t<=T;t++) {
		read(p),read(m); van ans=0; inv[0]=1;
		for (int i=1;i<=p*2;i++) inv[i]=inv[i-1]*i%p,inv[i]%=p;
		for (int i=0;i<p;i++) {
			van tmp=inv[i*2]*power(inv[i],p-2)%p*power(inv[i],p-2)%p;
			ans+=power(m,i)*tmp%p,ans%=p; 
		} cout<<ans<<endl;
	}
	return 0;
}
