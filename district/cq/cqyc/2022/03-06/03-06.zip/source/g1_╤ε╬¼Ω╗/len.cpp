#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e5+10;
van n,ans=1e18; 
struct pos {
	van x,y;
	bool operator < (const pos& a) const {
		return x<a.x;
	}
}p[MaxN];
struct SGT {
	van dat[MaxN<<2];
	void BuildTree(van x=1,van l=1,van r=n) {
		if (l==r) {dat[x]=abs(p[l].y); return;}
		van mid=(l+r)>>1;
		BuildTree(x*2,l,mid);
		BuildTree(x*2+1,mid+1,r);
		dat[x]=max(dat[x*2],dat[x*2+1]);
	}
	van QueryTree(van L,van R,van x=1,van l=1,van r=n) {
		if (L>R) return 0;
		if (L<=l&&r<=R) return dat[x];
		van ans=0,mid=(l+r)>>1;
		if (L<=mid) ans=max(ans,QueryTree(L,R,x*2,l,mid));
		if (R>mid) ans=max(ans,QueryTree(L,R,x*2+1,mid+1,r));
		return ans;
	}
}T;
bool cmp(pos a,pos b) {
	return a.y<b.y;
}
int main() {
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	read(n); for (int i=1;i<=n;i++) read(p[i].x),read(p[i].y);
	sort(p+1,p+n+1,cmp);
	ans=min(ans,(p[n].y-p[1].y)*(p[n].y-p[1].y));
	sort(p+1,p+n+1); van l=n; T.BuildTree();
	for (int i=1;i<=n;i++) if (p[i].x>=0) l=i-1;
	ans=min(ans,(p[n].x-p[1].x)*(p[n].x-p[1].x));
	van maxy=0; for (int i=l+1;i<=n;i++) maxy=max(maxy,min(abs(p[i].x),abs(p[i].y)));
	for (int i=1;i<=l;i++) ans=min(ans,p[i].x*p[i].x+max(maxy,T.QueryTree(1,i-1))*max(maxy,T.QueryTree(1,i-1)));
	maxy=0; for (int i=1;i<=l;i++) maxy=max(maxy,min(abs(p[i].x),abs(p[i].y)));
	for (int i=l+1;i<=n;i++) ans=min(ans,p[i].x*p[i].x+max(maxy,T.QueryTree(i+1,n))*max(maxy,T.QueryTree(i+1,n)));
	print(ans);
	return 0;
}
