#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e3+10;
van state[MaxN][MaxN];
van n,m,t,k,h[MaxN],ans=0;
bool in(van x,van y) {
	return x>0&&y>0&&x<=n&&y<=m;
}
van num(van id,van x,van y,van dx,van dy) {
	van ans=0; 
	while (in(x+dx,y+dy)&&state[x+dx][y+dy]==id) x+=dx,y+=dy,ans++;
	return ans;
}
int main() {
	freopen("chess.in","r",stdin);
	read(n),read(m),read(k),read(t);
	for (int i=1;i<=t;i++) {
		van x; read(x); 
//		for (int j=1;j<=n;j++){for (int k=1;k<=m;k++) cout<<state[j][k];cout<<endl;}
		if (ans) continue;
		state[x][++h[x]]=i%2+1;
		van lef=num(i%2+1,x,h[x],0,-1);
		van rig=num(i%2+1,x,h[x],0,1);
		van ups=num(i%2+1,x,h[x],-1,0);
		van dow=num(i%2+1,x,h[x],1,0);
		van lup=num(i%2+1,x,h[x],-1,-1);
		van rup=num(i%2+1,x,h[x],-1,1);
		van ldo=num(i%2+1,x,h[x],1,-1);
		van rdo=num(i%2+1,x,h[x],1,1);
		if (lef+rig>=k-1) ans=i;
		if (ups+dow>=k-1) ans=i;
		if (lup+rdo>=k-1) ans=i;
		if (rup+ldo>=k-1) ans=i;
	} freopen("chess.out","w",stdout);
	print(ans);
	return 0;
}
