#include<bits/stdc++.h>
using namespace std;
int n,fx,sx,fy,sy,way=1;
long long px[100005],py[100005],nx[1000005],ny[1000005],tans,ans=1145141919810;
struct node
{
	long long x,y;
	int id;
}poi[100005];
long long sq(long long p)
{
	return p*p;
}
int main()
{
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%lld%lld",px+i,py+i);
		poi[i]=(node){px[i],py[i],i};
	}
	if(n==1)
	{
		putchar('0');
		return 0;
	}
	for(int i=1;i<=n;++i)
	{
		way=(way<<1)|1;
	}
	for(int i=0;i<=way;++i)
	{
		tans=-1;
		for(int j=1;j<=n;++j)
		{
			nx[j]=ny[j]=0;
			if((i>>(j-1))&1) nx[j]=px[j];
			else ny[j]=py[j];
		}
		for(int a=1;a<=n;++a)
		{
			for(int b=1;b<=n;++b)
			{
				tans=max(tans,sq(nx[a]-nx[b])+sq(ny[a]-ny[b]));
			}
		}
		ans=min(ans,tans);
	}
	printf("%lld",ans);
	return 0;
}

