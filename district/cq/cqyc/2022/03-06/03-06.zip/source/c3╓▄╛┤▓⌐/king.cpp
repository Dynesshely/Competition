#include<bits/stdc++.h>
#define l(p) tree[p].l
#define r(p) tree[p].r
#define ls(p) (p<<1)
#define rs(p) ((p<<1)|1)
#define dat(p) tree[p].dat
#define tag(p) tree[p].tag
#define wid(p) (r(p)-l(p)+1)
#define cl(p) tree[p].cl
using namespace std;
int n,m,q,a[500005],b[500005],op,l,r,x;
struct
{
	int l,r;
	long long dat,tag,cl;
}tree[2000005];
void build(int p,int l,int r)
{
	l(p)=l,r(p)=r;
	dat(p)=tag(p)=0;
	if(l==r)
	{
		return ;
	}
	int mid=(l+r)>>1;
	build(ls(p),l,mid);
	build(rs(p),mid+1,r);
}
inline void pushdown(int p)
{
	if(cl(p))
	{
		tag(ls(p))=tag(rs(p))=dat(ls(p))=dat(rs(p))=0;
		cl(ls(p))=cl(rs(p))=1;
		cl(p)=0;
	}
	if(tag(p))
	{
		tag(ls(p))+=tag(p);
		tag(rs(p))+=tag(p);
		dat(ls(p))+=tag(p)*wid(ls(p));
		dat(rs(p))+=tag(p)*wid(rs(p));
		tag(p)=0;
	}
}
void update(int p,int l,int r,int d)
{
	if(l<=l(p) && r(p)<=r)
	{
		tag(p)+=d;
		dat(p)+=d*wid(p);
		return ;
	}
	pushdown(p);
	int mid=(l(p)+r(p))>>1;
	if(l<=mid) update(ls(p),l,r,d);
	if(r>mid) update(rs(p),l,r,d);
	dat(p)=dat(ls(p))+dat(rs(p));
}
void clear(int p,int l,int r)
{
	if(l<=l(p) && r(p)<=r)
	{
		tag(p)=0;
		dat(p)=0;
		cl(p)=0;
		return ;
	}
	pushdown(p);
	int mid=(l(p)+r(p))>>1;
	if(l<=mid) clear(ls(p),l,r);
	if(r>mid) clear(rs(p),l,r);
	dat(p)=dat(ls(p))+dat(rs(p));
}
long long ask(int p,int l,int r)
{
	if(l<=l(p) && r(p)<=r)
	{
		return dat(p);
	}
	pushdown(p);
	int mid=(l(p)+r(p))>>1;
	long long ret=0;
	if(l<=mid) ret+=ask(ls(p),l,r);
	if(r>mid) ret+=ask(rs(p),l,r);
	return ret;
}
int main()
{
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;++i) scanf("%d",a+i);
	build(1,1,n);
	while(q--)
	{
		scanf("%d%d%d%d",&op,&l,&r,&x);
		if(op==1)
		{
			for(int i=l;i<=r;++i)
			{
				if(a[i])
				{
					b[a[i]]+=ask(1,i,i);
				}
				else
				{
					b[x]+=ask(1,i,i);
				}
				a[i]=x;
			}
			clear(1,l,r);
		}
		else
		{
			update(1,l,r,x);
		}
	}
	for(int i=1;i<=n;++i)
	{
		b[a[i]]+=ask(1,i,i);
	}
	for(int i=1;i<=m;++i)
	{
		printf("%lld\n",b[i]);
	}
	return 0;
}

