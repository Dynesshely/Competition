#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int n,m,k,t,input,nc,nx,ny,cnt,T;
int mp[1055][1055],tp[1055],opt[1000005];
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read(),k=read(),t=read();
	for(int i=1;i<=t;++i) opt[i]=read();
	for(T=1;T<=t;++T)
	{
		nc=1+(T&1);
		nx=++tp[opt[T]],ny=opt[T];
		mp[nx][ny]=nc;
		
		cnt=0;
		for(int i=((nx>(k-1))?(1-k):(-nx+1));i<=k-1;++i)
		{
			if(mp[nx+i][ny]==nc)
			{
				++cnt;
				if(cnt>=k) break ;
			}
			else cnt=0;
		}
		if(cnt>=k) break ;
		
		cnt=0;
		for(int i=((ny>(k-1))?(1-k):(-ny+1));i<=k-1;++i)
		{
			if(mp[nx][ny+i]==nc)
			{
				++cnt;
				if(cnt>=k) break ;
			}
			else cnt=0;
		}
		if(cnt>=k) break ;
		
		cnt=0;
		for(int i=((min(nx,ny)>(k-1))?(1-k):(-min(nx,ny)+1));i<=k-1;++i)
		{
			if(mp[nx+i][ny+i]==nc)
			{
				++cnt;
				if(cnt>=k) break ;
			}
			else cnt=0;
		}
		if(cnt>=k) break ;
	}
	printf("%d",T);
	return 0;
}
/*
1000 5 5 21
1 2 3 4 5 1 2 4 3 5 3 3 2 4 4 5 5 4 5 5 4
*/
