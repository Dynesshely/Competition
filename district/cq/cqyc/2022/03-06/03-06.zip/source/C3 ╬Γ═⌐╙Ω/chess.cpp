#include<bits/stdc++.h>
using namespace std;

const int Maxn=1010;
int N,M,K,T,ans=0;
bool flag=false;
vector<int> A[Maxn];

bool check1(int x,int y){
	int l=x,r=x;
	while(A[l-1].size()>y&&A[l-1][y]==A[x][y]&&l>1) l--;
	while(A[r+1].size()>y&&A[r+1][y]==A[x][y]&&r<M) r++;
	if(r-l+1==K) return 1;
	return 0;
}

bool check2(int x,int y){
	int l=y,r=y;
	while(A[x][l-1]==A[x][y]&&l) l--;
	if(r-l+1==K) return 1;
	return 0;
}

bool check3(int x,int y){
	int lx=x,ly=y,rx=x,ry=y;
	while(ly&&A[lx-1].size()>=ly&&A[lx-1][ly-1]==A[x][y]&&lx>1) lx--,ly--;
	while(A[rx+1].size()>ly+1&&A[rx+1][ry+1]==A[x][y]&&rx<M&&ry<N) rx++,ry++;
	if(rx-lx+1==K) return 1;
	return 0;
}

bool check4(int x,int y){
	int lx=x,ly=y,rx=x,ry=y;
	while(A[lx-1].size()>ly+1&&A[lx-1][ly+1]==A[x][y]&&lx>1&&ly<N) lx--,ly++;
	while(ry&&A[rx+1].size()>=ry&&A[rx+1][ry-1]==A[x][y]&&rx<M) rx++,ry--;
	if(rx-lx-1==K) return 1;
	return 0;
}

bool check(int x,int y){
	if(check1(x,y)) return 1;
	if(check2(x,y)) return 1;
	if(check3(x,y)) return 1;
	if(check4(x,y)) return 1;
	return 0;
}

int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	scanf("%d %d %d %d",&N,&M,&K,&T);
	for(int x,i=1;i<=T;i++){
		scanf("%d",&x);
		if(!flag) ans++;
		A[x].push_back(i%2+1);
		if(check(x,A[x].size()-1)) flag=true;
	}
	printf("%d",ans);
	return 0;
} 
