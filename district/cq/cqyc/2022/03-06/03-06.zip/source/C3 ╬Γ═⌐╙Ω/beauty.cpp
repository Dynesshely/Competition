#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e5+10;
int T,Mod,M,p[Maxn],jc[Maxn],ans=0;

int down(int x,int d){
	int ret=1;
	while(d){
		if(d&1) ret=ret*x%Mod;
		x=x*x%Mod; d>>=1;
	}
	return ret;
}

int main(){
	freopen("beauty.in","r",stdin);
	freopen("beauty.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(p,0,sizeof p);
		memset(jc,0,sizeof jc);
		scanf("%d %d",&Mod,&M); int tmp=1;
		p[0]=1; jc[1]=1;
		for(int i=2;i<=Mod*2;i++) jc[i]=jc[i-1]*i%Mod;
		for(int i=1;i<=Mod;i++)
			p[i]=jc[i*2]*down((jc[i]*jc[i]%Mod),Mod-2)%Mod;	
 		for(int i=0;i<Mod;i++){
			ans=(ans+p[i]*tmp%Mod)%Mod;
			tmp=tmp*M%Mod;
		}
		printf("%d\n",ans);
	}
	return 0;
} 
