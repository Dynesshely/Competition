#include<bits/stdc++.h>
using namespace std;

const int INF=0x3f3f3f3f;
const int Maxn=1e5+10;
int N,ans=INF;
struct node{
	int x,y;
}S[Maxn];

int power(int x){ return x*x; }

void Solve(){
	int ret=0;
	for(int i=1;i<=N;i++) for(int j=i+1;j<=N;j++)
		ret=max(ret,power(S[i].x-S[j].x)+power(S[i].y-S[j].y));
	ans=min(ans,ret);
}

void DFS(int x){
	if(x>N){ Solve(); return; }
	int tmp=S[x].x; S[x].x=0; DFS(x+1);
	S[x].x=tmp,tmp=S[x].y;
	S[x].y=0; DFS(x+1); S[x].y=tmp;
}

int main(){
	freopen("len.in","r",stdin);
	freopen("len.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;i++) scanf("%d %d",&S[i].x,&S[i].y);
	DFS(1);
	printf("%d",ans);
	return 0;
} 
