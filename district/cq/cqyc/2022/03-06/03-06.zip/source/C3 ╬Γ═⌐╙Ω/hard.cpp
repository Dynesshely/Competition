#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e6+10;
int N,A[Maxn],B[Maxn],ans=0; 

int main(){
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;i++) scanf("%d",A+i);
	for(int i=1;i<=N;i++) scanf("%d",B+i);
	for(int i=1;i<=N;i++) for(int j=1;j<=N;j++)
		ans+=sqrt(abs(A[i]-B[j]));
	printf("%d",ans);
	return 0;
} 
