#include<bits/stdc++.h>
using namespace std;
#define ls (x<<1)
#define rs ((x<<1)|1)
#define mid ((l+r)>>1)

const int Maxn=1e5+10;
int N,M,Q,A[Maxn],B[Maxn];
int Tree[Maxn<<2];

void Build(int x,int l,int r){
	if(l==r){
		Tree[x]=A[l];
		return;
	}
	Tree[x]=-1;
	Build(ls,l,mid); Build(rs,mid+1,r);
	if(Tree[ls]==Tree[rs]&&Tree[ls]!=-1) Tree[x]=Tree[ls];
}

void Modify(int x,int l,int r,int L,int R,int v){
	if(L<=l&&r<=R){
		Tree[x]=v;
		return;
	}
	if(L<=mid) Modify(ls,l,mid,L,R,v);
	if(R>mid) Modify(rs,mid+1,r,L,R,v);
}

int Query(int x,int l,int r,int v){
	if(l==r&&l==v) return Tree[x];
	if(v<=mid) Query(ls,l,mid,v);
	else Query(rs,mid+1,r,v);
}

int main(){
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	scanf("%d %d %d",&N,&M,&Q);
	for(int i=1;i<=N;i++) scanf("%d",A+i);
	if(N<=5000&&M<=5000&&Q<=5000){
		while(Q--){
			int sgn,l,r,x;
			scanf("%d %d %d %d",&sgn,&l,&r,&x);
			if(sgn==1) for(int i=l;i<=r;i++) A[i]=x;
			else for(int i=l;i<=r;i++) B[A[i]]+=x;
		}
		for(int i=1;i<=M;i++) printf("%d\n",B[i]);
	}
	else{
		Build(1,1,N);
		while(Q--){
			int sgn,l,r,x;
			scanf("%d %d %d %d",&sgn,&l,&r,&x);
			if(sgn==1) Modify(1,1,N,l,r,x);
			else{
				for(int i=l;i<=r;i++){
					int now=Query(1,1,N,i);
					if(now==-1) continue;
					B[now]+=x;
				}
			}
		}
		for(int i=1;i<=M;i++) printf("%d\n",B[i]);
	}
	return 0;
} 
