#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,ans=0;
int a[1000005],b[1000005];
signed main(){
	freopen("hard.in","r",stdin);
	freopen("test.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		a[i]=read();
	}
	for(register int i=1;i<=n;i++){
		b[i]=read();
	}
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			ans+=sqrt(abs(a[i]-b[j]));
		}
	}
	printf("%lld",ans);
	return 0;
}
