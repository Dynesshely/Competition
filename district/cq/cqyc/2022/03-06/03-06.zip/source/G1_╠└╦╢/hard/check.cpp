#include<bits/stdc++.h>
using namespace std;
int main(){
	while(true){
		system("maker.exe");
		system("hard.exe");
		system("test_bf.exe");
		if(system("fc test.out hard.out")) return 0;
	}
	return 0;
}
