#include<bits/stdc++.h>
using namespace std;
int main(){
	srand(time(0));
	freopen("chess.in","w",stdout);
	int n=1000,m=1000,k=9,t=100000;
	cout<<n<<" "<<m<<" "<<k<<" "<<t<<"\n";
	for(register int i=1;i<=t;i++){
		cout<<rand()%m+1<<" ";
	}
	return 0;
}
