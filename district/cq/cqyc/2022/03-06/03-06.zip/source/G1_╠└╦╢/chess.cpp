#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int stk[100],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int n,m,k,t;
int maze[1005][1005];
int pos[1005];
bool in(int x,int y){
	return 1<=x&&x<=n&&1<=y&&y<=m;
}
bool check(int x,int y){
	int nowx=x,nowy=y;
	bool flag=true;
	for(register int i=1;i<k;i++){
		nowx--; 
		if(!in(nowx,nowy)||maze[nowx][nowy]!=maze[x][y]){
			flag=false;
			break;
		}
	}
	if(flag) return true;
	flag=true; nowx=x,nowy=y;
	for(register int i=1;i<k;i++){
		nowx--,nowy++;
		if(!in(nowx,nowy)||maze[nowx][nowy]!=maze[x][y]){
			flag=false;
			break;
		}
	}
	if(flag) return true;
	flag=true; nowx=x,nowy=y;
	for(register int i=1;i<k;i++){
		nowy++;
		if(!in(nowx,nowy)||maze[nowx][nowy]!=maze[x][y]){
			flag=false;
			break;
		}
	}
	if(flag) return true;
	flag=true; nowx=x,nowy=y;
	for(register int i=1;i<k;i++){
		nowx++,nowy++;
		if(!in(nowx,nowy)||maze[nowx][nowy]!=maze[x][y]){
			flag=false;
			break;
		}
	}
	if(flag) return true;
	flag=true; nowx=x,nowy=y;
	for(register int i=1;i<k;i++){
		nowx++;
		if(!in(nowx,nowy)||maze[nowx][nowy]!=maze[x][y]){
			flag=false;
			break;
		}
	}
	if(flag) return true;
	flag=true; nowx=x,nowy=y;
	for(register int i=1;i<k;i++){
		nowx++,nowy--;
		if(!in(nowx,nowy)||maze[nowx][nowy]!=maze[x][y]){
			flag=false;
			break;
		}
	}
	if(flag) return true;
	flag=true; nowx=x,nowy=y;
	for(register int i=1;i<k;i++){
		nowy--;
		if(!in(nowx,nowy)||maze[nowx][nowy]!=maze[x][y]){
			flag=false;
			break;
		}
	}
	if(flag) return true;
	flag=true; nowx=x,nowy=y;
	for(register int i=1;i<k;i++){
		nowx--,nowy--;
		if(!in(nowx,nowy)||maze[nowx][nowy]!=maze[x][y]){
			flag=false;
			break;
		}
	}
	if(flag) return true;
	return false;
}
int main(){
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read(),k=read(),t=read();
	memset(pos,0,sizeof pos); int x;
	for(register int i=1;i<=t;i++){
		x=read(); pos[x]++;
		maze[pos[x]][x]=(i%2)+1;
		if(check(pos[x],x)){
			printf("%d",i);
			return 0;
		}
	}
	return 0;
}
