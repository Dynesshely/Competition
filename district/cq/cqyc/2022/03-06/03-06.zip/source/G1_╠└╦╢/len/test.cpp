#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int n;
long long ans=1e16,tmp=1e16;
int x[100005],y[100005];
int tx[100005],ty[100005]; 
int dir[100005];
bool can(int mid){
	for(register int i=1;i<=n;i++){
		if(dir[i]&&abs(y[i])>=mid) return false;
	}
	return true;
}
void calc(int mid){
	for(register int i=1;i<=n;i++){
		if(abs(y[i])>=mid) dir[i]=2;
	}
	for(register int i=1;i<=n;i++){
		if(dir[i]==1){
			tx[i]=0,ty[i]=y[i];
		}
		else if(dir[i]==2){
			tx[i]=x[i],ty[i]=0;
		}
		else {
			tx[i]=x[i],ty[i]=y[i];
		}
	}
	long long ret=0;
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			ret=max(ret,(tx[i]-tx[j])*(tx[i]-tx[j])+(ty[i]-ty[j])*(ty[i]-ty[j]));
		}
	}
	/*int minn_y=1e9,maxn_y=-1e9;
	int minn_x=1e9,maxn_x=-1e9;
	for(register int i=1;i<=n;i++){
		minn_y=min(minn_y,ty[i]);
		maxn_y=max(maxn_y,ty[i]);
		minn_x=min(minn_x,tx[i]);
		maxn_x=max(maxn_x,tx[i]);
	}
	long long ret=max(abs(minn_y),abs(maxn_y))*max(abs(minn_y),abs(maxn_y))+max(abs(minn_x),abs(maxn_x))*max(abs(minn_x),abs(maxn_x));
	*/
	tmp=min(tmp,ret);
}
bool check(int mid){
	memset(dir,0,sizeof dir);
	for(register int i=1;i<=n;i++){
		if(abs(x[i])>=mid) dir[i]=1;
	}
	int ly=0,ry=1e8,mid_y;
	tmp=1e18;
	while(ly<=ry){
		mid_y=(ly+ry)>>1;
		if(can(mid_y)){
			calc(mid_y);
			ly=mid_y+1;
		}
		else ry=mid_y-1;
	}
	return tmp<ans;
}
void change_ans(){
	long long sum=0;
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			sum=max(sum,(long long)(tx[i]-tx[j])*(tx[i]-tx[j])+(long long)(ty[i]-ty[j])*(ty[i]-ty[j]));
		}
	}
	ans=min(ans,sum);
}
void dfs(int now){
	if(now==n+1){
		change_ans();
		return;
	}
	tx[now]=x[now],ty[now]=0;
	dfs(now+1);
	tx[now]=0,ty[now]=y[now];
	dfs(now+1);
}
signed main(){
	//freopen("len.in","r",stdin);
	//freopen("len.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		x[i]=read(),y[i]=read();
	}
	if(n<=20){
		tx[1]=x[1],ty[1]=0;
		dfs(2);
		tx[1]=0,ty[1]=y[1];
		dfs(2);
		printf("%lld",ans);
		return 0;
	}
	else {
		int lx=0,rx=1e8,mid_x;
		check(0); check(1e8);//��ȷ��һ���� 
		while(lx<=rx){
			mid_x=(lx+rx)>>1;
			if(check(mid_x)) lx=mid_x+1,ans=min(ans,tmp);
			else rx=mid_x-1,ans=min(ans,tmp);
		}
		printf("%lld",ans);
		return 0;
	}
	
	return 0;
}
