#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("biao.txt","w",stdout);
	for(register int i=1;i<=100000;i++){
		if((long long)i*i<=4000000){
			cout<<(long long)i*i<<",";
		}
	}
	return 0;
}
