#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48); puts("");
}
int n,m,q;
int bel[500005];
int ans[500005];
int has[500005];
int main(){
	freopen("king.in","r",stdin);
	freopen("king.out","w",stdout);
	n=read(),m=read(),q=read();
	for(register int i=1;i<=n;i++){
		bel[i]=read();
	}
	int op,l,r,x;
	while(q--){
		op=read(),l=read(),r=read(),x=read();
		if(op==1){
			for(register int i=l;i<=r;i++){
				bel[i]=x;
			}
		}
		else {
			for(register int i=l;i<=r;i++){
				has[i]+=x;
			}
			for(register int i=l;i<=r;i++){
				if(bel[i]) {
					ans[bel[i]]+=has[i];
					has[i]=0;
				}
			}
		}
	}
	for(register int i=1;i<=m;i++){
		write(ans[i]);
	}
	return 0;
}
