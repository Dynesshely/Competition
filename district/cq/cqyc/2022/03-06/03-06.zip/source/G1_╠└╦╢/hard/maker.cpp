#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
	srand(time(0));
	freopen("hard.in","w",stdout);
	int n=1000000;
	cout<<n<<"\n";
	for(register int i=1;i<=n;i++){
		cout<<1<<" ";
	}
	puts("");
	for(register int i=1;i<=n;i++){
		cout<<3000000<<" ";
	}
	puts("");
	return 0;
}
