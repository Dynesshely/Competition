#include<bits/stdc++.h>
using namespace std;
int n,m,k,t,ans,l,r,mid,s,cnt,nowa,nowb,to;
int a[1000001],num[1011],vis[1011][1011];
bool las;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
} 
int stk[30],tp;
void write(int x)
{
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
bool ck()
{
	if(las)
	{
		for(int i=s;i>mid;i--) 
			vis[num[a[i]]--][a[i]]=-1;
	}
	else
	{
		for(int i=s+1;i<=mid;i++)
			vis[++num[a[i]]][a[i]]=(i&1)^1;
	}
	for(int i=1;i<=n;i++)
	{
		cnt=1;
		for(int j=1;j<=m;j++)
		{
			if(cnt>=k) return 1;
			if(vis[i][j]==-1) {cnt=1;continue;}
			if(vis[i][j]==vis[i][j-1]) cnt++;
			else cnt=1;
		}
	}
	for(int i=1;i<=m;i++)
	{
		cnt=1;
		for(int j=num[i];j>=1;j--)
		{
			if(cnt>=k) return 1;
			if(vis[j][i]==-1) {cnt=1;continue;}
			if(vis[j][i]==vis[j-1][i]) cnt++;
			else cnt=1;
		}
	}
	for(int i=2;i<=to;i++)
	{
		cnt=1;
		for(int j=1;j<i;j++)
		{
			if(cnt>=k) return 1;
			if(vis[i-j][j]==-1) {cnt=1;continue;}
			if(vis[i-j][j]==vis[i-j-1][j+1]) cnt++;
			else cnt=1;
		}
	}
	for(int i=1;i<=n;i++)
	{
		nowa=i-1,nowb=0,cnt=1;
		while(nowa<=n&&nowb<=m)
		{
			nowa++,nowb++;
			if(cnt>=k) return 1;
			if(vis[nowa][nowb]==-1) {cnt=1;continue;}
			if(vis[nowa][nowb]==vis[nowa-1][nowb-1]) cnt++;
			else cnt=1;
		}
	}
	for(int i=1;i<=m;i++)
	{
		nowa=0,nowb=i-1,cnt=1;
		while(nowa<=n&&nowb<=m)
		{
			nowa++,nowb++;
			if(cnt>=k) return 1;
			if(vis[nowa][nowb]==-1) {cnt=1;continue;}
			if(vis[nowa][nowb]==vis[nowa-1][nowb-1]) cnt++;
			else cnt=1;
		}
	}
	return 0;
}
int main()
{
	freopen("chess.in","r",stdin);
	freopen("chess.out","w",stdout);
	n=read(),m=read(),k=read(),t=read();
	to=m+n;
	memset(vis,-1,sizeof(vis));
	for(int i=1;i<=t;i++) a[i]=read();
	l=0,r=t+1;
	while(l+1<r)
	{
		mid=l+r>>1;
		if(ck()) {las=1,r=mid;}
		else {las=0,l=mid;}
		s=mid;
	}
	mid=l+r>>1;
	if(!ck()) ans=mid+1;
	write(ans);
	return 0;
}
