#include<bits/stdc++.h>
using namespace std;
int n,mid,now,lasl,lasr,l,r;
long long ans;
bool fla,flb;
int a[1000001],b[1000001],las[1000001],nxt[1000001],sqr[10001];
//317
//1733
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x)
{
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main()
{
	freopen("hard.in","r",stdin);
	freopen("hard.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) b[i]=read();
	sort(a+1,a+1+n);sort(b+1,b+1+n);
	now=1;
	for(int i=1;i<=n;i++)
	{
		if(a[i]<b[now]) nxt[i]=now;
		else 
		{
			while(now<=n&&b[now]<=a[i]) now++;
			nxt[i]=now;
		}
	}
	now=n;
	for(int i=n;i;i--)
	{
		if(a[i]>b[now]) las[i]=now;
		else 
		{
			while(now>=1&&b[now]>=a[i]) now--;
			las[i]=now;
		}
	}
	for(int i=1;i<=1733;i++) sqr[i]=i*i;
	for(int i=1;i<=n;i++)
	{
		lasl=lasr=i,fla=flb=0;
		for(int j=1;j<=1733;j++)
		{
			if(a[i]-sqr[j]<b[1]&&a[i]-sqr[j-1]<b[1]&&a[i]+sqr[j]>b[n]&&a[i]+sqr[j-1]>b[n]) break;
			if(las[i]>0&&!fla) 
			{
				if(a[i]-sqr[j]<b[1]) ans+=1ll*(lasl-1)*(j-1),fla=1;
				else
				{
					l=0,r=las[i]+1;
					while(l+1<r)
					{
						mid=l+r>>1;
						if(a[i]-b[mid]<sqr[j]) r=mid;
						else l=mid;
					}
					mid=l+r>>1;
					if(a[i]-b[mid]>=sqr[j]) mid++;
					ans+=1ll*(lasl-mid)*(j-1);lasl=mid;
				}
			}
			if(nxt[i]<=n&&!flb)
			{
				if(a[i]+sqr[j]>b[n]) ans+=1ll*(n-lasr)*(j-1),flb=1;
				else
				{
					l=nxt[i]-1,r=n+1;
					while(l+1<r)
					{
						mid=l+r>>1;
						if(b[mid]-a[i]<sqr[j]) l=mid;
						else r=mid;
					}
					mid=l+r>>1;
					if(b[mid]-a[i]>=sqr[j]) mid--;
					ans+=1ll*(mid-lasr)*(j-1);lasr=mid;
				}
			}	
		}
	}
	printf("%lld",ans);
	return 0;
}

