#include<cstdio>
#define int long long
const int M=1e9+7;
int n,m,la,ans;
int po(int b,int a=2){
	int ans=1;
	while(b){
		if(b&1) ans=ans*a%M;
		b>>=1;
		a=a*a%M;
	}
	return ans;
}
signed main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	la=1;
	if(n==1){
		printf("%lld",po(n-1)*(po(n)+1)%M);
		return 0;
	}
	for(int i=1;i<=m;i++){
		ans=(ans+la*(po(n)-1)%M*po(n-1)%M*po((m-i)*2*n)%M)%M;
		la=la*po(n)%M*po(n-1)%M;
	}
	ans=(ans+la)%M;
	printf("%lld",ans);
	return 0;
}
