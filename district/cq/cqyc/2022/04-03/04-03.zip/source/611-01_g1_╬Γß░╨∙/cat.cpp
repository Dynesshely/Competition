#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=1005;
char v[5],a[N];
int T,le,dp[N][2],la[N][4];
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main(){
	v[2]='A';
	v[3]='T';
	T=read();
	while(T--){
		scanf("%s",a+1);
		le=strlen(a+1);
		bool pd=1;
		for(int i=1;i<=le;i++) if(a[i]=='C') pd=0;
		if(pd){
			int ans=0,la=0;
			for(int i=1;)
		}
		for(int i=1;i<=le;i++){
			la[i][1]=la[i-1][1];
			la[i][2]=la[i-1][2];
			la[i][3]=la[i-1][3];
			if(a[i]=='C') la[i][1]=i;
			if(a[i]=='A') la[i][2]=i;
			if(a[i]=='T') la[i][3]=i;
		}
		for(int i=1;i<=le;i++){
			if(a[i]!='T'){
				dp[i][0]=dp[i-1][0];
				dp[i][1]=dp[i-1][1];
				continue;
			}
			dp[i][0]=max(dp[i-1][1]+1,dp[la[la[i][2]][1]][0]);
			dp[i][1]=max(dp[la[i][2]][0],dp[la[la[i][2]][1]][1]+1);
		}
		write(dp[le][1]);
		putchar('\n');
	}
	return 0;
}
