#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
#define int long long
#define mid ((l+r)>>1)
const int N=5e5+5;
int ma[4*N],sum[N],a[N],n,q,t,ans;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[105],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
void build(int g,int l,int r){
	if(l==r){
		ma[g]=a[l]-sum[l-1];
		return;
	}
	build(2*g,l,mid);
	build(2*g+1,mid+1,r);
	ma[g]=max(ma[2*g],ma[2*g+1]);
	return;
}
int ef(int g,int l,int r,int l1,int v){
	if(ma[g]<v) return 0;
	if(l==r) return l;
	if(l<l1){
		if(l1<=mid){
			int nl=ef(2*g,l,mid,l1,v);
			if(nl) return nl;
		}
		return ef(2*g+1,mid+1,r,l1,v);
	}
	int n1=ef(2*g,l,mid,l1,v);
	if(n1) return n1;
	return ef(2*g,mid+1,r,l1,v);
}
signed main(){
	n=read();
	q=read();
	t=read();
	n++;
	for(int i=1;i<n;i++) a[i]=read();
	a[n]=2e18;
	for(int i=1;i<n;i++) sum[i]=read()+sum[i-1];
	build(1,1,n);
	for(int i=1;i<=q;i++){
		int l=0,r=0,x=0;
		l=read();
		r=read();
		x=read();
		l=(l^(t*ans));
		r=(r^(t*ans));
		x=(x^(t*ans));
		int v=ef(1,1,n,l,x-sum[l-1]);
		if(v>r) write(sum[r]+x-sum[l-1]);
		else write(sum[v-1]+x-sum[l-1]);
		putchar('\n');
	}
	return 0;
}
