#include<cstdio>
int n,t,r;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp,la,v;
void write(int x){
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int wo(int i){
	int b=0;
	while(i<n){
		int a=0;
		if(v){
			a=v;
			v=0;
		}
		else a=read();
		if(a-la>r){
			v=a;
			break;
		}
		i++;
		b=a;
	}
	la=b;
	return i;
}
int main(){
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read();
	t=read();
	r=read();
	int j=0;
	for(int i=1;i<=t;i++){
		j++;
		la=read();
		j=wo(j);
		j=wo(j);
		if(j==n) break;
	}
	write(j);
	return 0;
}
