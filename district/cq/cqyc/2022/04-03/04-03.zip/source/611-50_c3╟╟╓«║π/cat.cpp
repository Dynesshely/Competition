#include <bits/stdc++.h>
using namespace std;
int T,n;
char st[2000010];
bool ol[2000010];
int sta[2000010],ind;
set<int> se;
int main() {
	scanf("%d",&T);
	int lowe,ans;
	for(int u=1;u<=T;u++) {
		scanf("%s",st+1);
		n=strlen(st+1);
		for(int i=1;i<=n;i++) ol[i]=0;
		ind=0;ans=0;
		se.clear();se.insert(1e9);
		for(int i=n;i>=1;i--) {
			if(st[i]=='T') se.insert(i);
			if(st[i]=='A') sta[++ind]=i;
			if(st[i]=='C'&&ind) {
				lowe=*se.lower_bound(sta[ind]);
				if(lowe==1e9) continue;
				ol[i]=ol[lowe]=ol[sta[ind]]=1;
				se.erase(lowe);ind--;ans++;
			}
		}
		se.clear();ind=0;
		for(int i=n;i>=1;i--) if(st[i]=='A'&&!ol[i]) sta[++ind]=i;
		for(int i=1;i<=n;i++) if(st[i]=='T'&&!ol[i]) se.insert(i),cout << i << endl;;
		for(int i=1;i<=n;i++) {
			if(ol[i]) continue;
			if(st[i]=='A') ind--;
			if(st[i]=='T') se.erase(i);
			if(st[i]=='T'&&ind) {
				lowe=*se.end();
				if(lowe<sta[ind]) continue;
				ol[i]=ol[lowe]=ol[sta[ind]]=1;
				cout << i << " " << sta[ind] << " "<< lowe << endl;
				se.erase(lowe);ind--;ans++;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
