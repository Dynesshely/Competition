#include <bits/stdc++.h>
using namespace std;
int n,t,r,x[7600000];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main() {
	scanf("%d%d%d",&n,&t,&r);
	for(int i=1;i<=n;i++) x[i]=read();
	int cur,now=1,ans=0;
	while(t) {
		for(int i=now;i<=n;i++) {
			if(x[i]-x[now]>r) break;
			cur=i;
		}
		for(int i=cur;i<=n;i++) {
			if(x[i]-x[cur]>r) break;
			now=i;
		}
		t--;ans=now;
		if(now==n) break;
		now++;
	}
	printf("%d\n",ans);
	return 0;
}
