// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
double time1=(double)clock()/CLOCKS_PER_SEC;
//
const ll MOD=1e9+7,N=1e6;
ll jc[N+10],inv[N+10],a[N+10];
//
ll ksm(ll a,ll b){
	ll rt=1,la=a;
	while(b){
		if(b&1) rt=rt*la%MOD;
		la=la*la%MOD;
		b>>=1;
	}
	return rt;
}
inline ll C(ll a,ll b){
	if(a>b) return 0;
	return jc[b]*inv[a]%MOD*inv[b-a]%MOD;
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	double time2=(double)clock()/CLOCKS_PER_SEC;
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	ll n=gt(),m=gt();
	jc[0]=1; FOR(i,1,m) jc[i]=jc[i-1]*i%MOD;
	inv[m]=ksm(jc[m],MOD-2);
	inv[0]=1; ROF(i,m-1,1) inv[i]=inv[i+1]*(i+1)%MOD;
	a[1]=1; ll aba=1;
	FOR(i,1,m){
		ROF(j,i,1){
			a[j+1]+=a[j]+(C(j-1,i-1)*aba%MOD);
			a[j+1]%=MOD;
		}
		aba=aba*2%MOD;
	}
	aba=1; ll ans=0;
	FOR(i,1,m+1){
//		printf("%lld ",a[i]);
		ans=ans+aba*a[i]%MOD;
		ans%=MOD;
		aba=aba*((1ll<<n)-1)%MOD;
	}
//	printf("\n");
	ans=ans*ksm(2,(n-1)*m)%MOD;
	printf("%lld",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



