// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
double time1=(double)clock()/CLOCKS_PER_SEC;
//
struct node{
	ll x,y,z;
};
const ll N=1e5;
ll poh[N+10],pol[N+10],costh[N+10],costl[N+10];
node b[N+10];
ll vis[N+10],vis2[N+10];
ll ans=0,tox; bool lb=0;
//
bool cmp(node a,node b){
	return a.z<b.z;
}
void dfs(ll po,ll op){
	if(vis2[po]) return;
	vis2[po]=1;
	if(op==1) dfs(pol[b[po].y],2);
	else dfs(poh[b[po].x],1);
}
void dfs1(ll uppo,ll po,ll op){
	if(po==tox) return;
	if(op==1){
		poh[b[po].x]=uppo;
		vis[po]=vis[uppo];
		vis[uppo]=1;
		if(vis[po]==2) pol[b[po].y]=po;
		dfs1(po,pol[b[po].y],2);
	}
	else{
		pol[b[po].y]=uppo;
		vis[po]=vis[uppo];
		vis[uppo]=2;
		if(vis[po]==1) poh[b[po].x]=po;
		dfs1(po,poh[b[po].x],1);
	}
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	double time2=(double)clock()/CLOCKS_PER_SEC;
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	ll n=gt(),m=gt(),cnt=0;
	FOR(i,1,n){
		FOR(j,1,m){
			ll t=gt();
			b[++cnt]=(node){i,j,t};
		}
	}
	sort(b+1,b+cnt+1,cmp);
	ll ans=0;
	FOR(i,1,cnt){
		if(!poh[b[i].x]){
			vis[i]=1;
			ans+=b[i].z;
			poh[b[i].x]=i;
		}
		else if(!pol[b[i].y]){
			vis[i]=2;
			ans+=b[i].z;
			pol[b[i].y]=i;
		}
	}
	FOR(i,1,cnt){
		if(!vis[i]){
//			printf("i:%lld\n",i);
			memset(vis2,0,sizeof(vis2));
			dfs(poh[b[i].x],1);
			ll lans=0;
			FOR(j,1,cnt){
				if(vis2[j]){
					if(lans>b[i].z-b[j].z){
						lans=b[i].z-b[j].z;
						tox=j;
					}
				} 
			}
			if(lans<0){
				ans+=lans;
//				printf("%lld\n",tox);
				dfs1(i,poh[b[i].x],1);
			}
		}
	}
	printf("%lld",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



