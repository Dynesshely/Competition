// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
double time1=(double)clock()/CLOCKS_PER_SEC;
//
const ll N=1e7;
ll x[N+10];
//
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=gc();
	while(!isdigit(v))f|=(v=='-'),v=gc();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=gc();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	double time2=(double)clock()/CLOCKS_PER_SEC;
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	ll n=gt(),t=gt(),r=gt();
	FOR(i,1,n) x[i]=gt();
	ll to=1,last=1;
	FOR(i,1,t){
		while(to<n&&x[to+1]-r<=x[last]) ++to;
		last=to;
//		printf("%lld\n",to);
		while(to<n&&x[to+1]-r<=x[last]) ++to;
//		printf("%lld\n",to);
		++to;
		last=to;
		if(to>n) break;
	}
	printf("%lld",last-1);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



