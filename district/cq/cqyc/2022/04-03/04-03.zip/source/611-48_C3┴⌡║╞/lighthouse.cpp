#include<bits/stdc++.h>
using namespace std;
const int maxn=7500003;
int n,t,ans;
long long r,x[maxn];
void init(){
	ans=0;
	return ;
}
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int main(){
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	init();
//	scanf("%d%d%lld",&n,&t,&r);
	n=read(),t=read(),r=read();
	for(int i=1;i<=n;i++){
//		scanf("%lld",&x[i]);
		x[i]=read();
	}
	x[n+1]=1e18;
	int l=1;
	for(int i=1;i<=n;i++){
		if(!t)break;
		if(x[i]-x[l]<=r&&x[i+1]-x[l]>r&&t){
			for(int j=i;j<=n+1;j++){
				l=j;
				if(x[j]-x[i]>r)break;
			}
			t--;
			ans=l-1;
			i=l-1;
		}
	}
	printf("%d\n",ans);
	return 0;
}
