#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+3;
int n,Q,t;
long long a[maxn],b[maxn];
int main(){
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&t);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%lld",&b[i]);
	}
	int l,r;
	long long x;
	for(int i=1;i<=Q;i++){
		scanf("%d%d%lld",&l,&r,&x);
		for(int j=l;j<=r;j++){
			if(x>a[j])x+=b[j];
		}
		printf("%lld\n",x);
	}
	return 0;
}
