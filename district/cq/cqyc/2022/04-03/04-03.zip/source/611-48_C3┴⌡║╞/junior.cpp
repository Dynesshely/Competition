#include<bits/stdc++.h>
using namespace std;
//const int maxn=56,maxs=51*51,maxm=1e6+3;
//const long long inf=1e9;
//int n,m;
//int S,T;
//int cnt,hed[maxs],now[maxs];
//long long d[maxn],dis[maxn];
//bool vis[maxn];
//struct nodeE{
//	int nxt,to;
//	long long val,val2;
//}e[maxm];
//struct cos{
//	int flow,cost;
//	cos operator + (const cos &A)const{
//		return (cos){flow+A.flow,cost+A.cost};
//	}
//};
//void init(){
//	memset(hed,0,sizeof(hed));
//	cnt=1;
//	S=1,T=1+n*m+n+m+1;
//	return ;
//}
//void add(int u,int v,long long w,long long w2){
//	e[++cnt]=(nodeE){hed[u],v,w,w2};
//	hed[u]=cnt;
//	now[u]=hed[u];
//	return ;
//}
//queue<int>q;
//void SPFA(){
//	int x,v;
//	for(int i=S;i<=T;i++){
//		dis[i]=inf;
//		vis[i]=0,d[i]=0;
//	}
//	while(!q.empty())q.pop();
//	q.push(S);
//	dis[S]=0,d[S]=0,vis[S]=1
//	while(!q.empty()){
//		x=q.front();
//		for(int i=hed[x];i;i=e[i].nxt){
//			if(!e[i].val)continue;
//			if(dis[v]>dis[x]+e[i].val2){
//				dis[v]=dis[x]+e[i].val2;
//				if(!vis[v]){
//					q.push(v);
//					vis[v]=1,d[v]=d[x]+1;
//				}
//			}
//		}
//		vis[q.front()]=0;
//		q.pop();
//	}
//	return ;
//}
//bool check(){
//	SPFA();
//	return dis[T]!=inf;
//}
//give dinic(int x,int get){
//	if(x==T)return (cos){ret,0};
//	int v;
//	cos give,newgive;
//	for(int i=now[x];i;i=e[i]].nxt){
//		now[x]=i;
//		v=e[i].to;
//		if(d[v]==d[x]+1){
//			newgive=dinic(v,min(get,e[i].w));
//			e[i].w-=newgive.flow;
//			e[i^1].w+=newgive.flow;
//			give+=newgive.cost;
//		}
//	}
int main(){
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	printf("3316884270\n");
//	scanf("%d%d",&n,&m);
//	init();
//	long long w;
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=m;j++){
//			scanf("%lld",&w);
//			add(S,(m*(i-1)+j+1),1,w);
//			add((m*(i-1)+j+1),S,0,-w)
//		}
//	}
	return 0;
}
