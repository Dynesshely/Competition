#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+3;
int T,n;
int ans;
char s[maxn];
vector<int>s_t;
queue<int>q1,q2;
void init(){
	memset(s,0,sizeof(s));
	return ;
}
void reinit(){
	for(int i=1;i<=n;i++)s[i]=0;
	ans=0;
	s_t.clear();
	return ;
}
int check(int i){
	int ret=0,sum=0;
	for(int j=0;j<i;j++){
		s[s_t[j]]='C';
	}
	for(int j=1;j<=n;j++){
		if(s[j]=='C')q1.push(j);
		if(s[j]=='A'){
			if(!q1.empty()){
				q1.pop();
				q2.push(j);
			}
		}
		if(s[j]=='T'){
			if(!q2.empty()){
				q2.pop();
				sum++;
			}
		}
	}
	ret=max(ans,sum);
	for(int j=0;j<i;j++){
		s[s_t[j]]='T';
	}
	while(!q1.empty())q1.pop();
	while(!q2.empty())q2.pop();
	return ret;
}
int main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	scanf("%d",&T);
	init();
	int l,r,lmid,rmid,lans,rans;
	while(T--){
//		scanf("%d",&n);
		reinit();
		scanf("%s",s+1);
		n=0;
		while(s[n+1]!=0)n++;
//		printf("n=%d\n",n);
//		for(int i=1;i<=n;i++)putchar(s[i]);
//		putchar('\n');
		for(int i=1;i<=n;i++){
			if(s[i]=='T')s_t.push_back(i);
		}
//		for(int i=0;i<s_t.size();i++){
//			printf("%d ",s_t[i]);
//		}putchar('\n');
		l=0,r=s_t.size();
		while(l+2<=r){
			lmid=l+(r-l+1)/2-1;
			rmid=r-(r-l+1)/2+1;
			lans=check(lmid),rans=check(rmid);
			if(lans<rans)l=lmid+1;
			else r=rmid-1;
		}
		for(int i=l;i<=r;i++){
			ans=max(ans,check(i));
		}
		printf("%d\n",ans);
	}		
	return 0;
}
