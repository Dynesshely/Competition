#include<bits/stdc++.h>
using namespace std;
int n,q,t,l,r;
long long a[1005],b[1005],x;
int main()
{
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;++i) scanf("%lld",a+i);
	for(int i=1;i<=n;++i) scanf("%lld",b+i);
	while(q--)
	{
		scanf("%d%d%lld",&l,&r,&x);
		for(int i=l;i<=r;++i)
		{
			if(x>a[i]) x+=b[i];
		}
		printf("%lld\n",x);
	}
	return 0;
}

