#include<bits/stdc++.h>
using namespace std;
int T,n,st;
long long cat[1005][4],tat[1005][4],ans,c[1005],t[1005],ta[1005][3];
string s;
int main()
{
	freopen("cat2.in","r",stdin);
	freopen("cat.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		cin>>s;
		
		reverse(s.begin(),s.end());
		
		n=s.size();
		s=' '+s;
		memset(cat,0,sizeof(cat));
		memset(tat,0,sizeof(tat));
		
		memset(c,0,sizeof(c));
		memset(t,0,sizeof(t));
		memset(ta,0,sizeof(ta));
		
		for(int i=1;i<=n;++i)
		{
			if(s[i]=='T')
			{
				ta[i][1]=1;
			}
			for(int j=1;j<i;++j)
			{
				if(s[i]=='A')
				{
					if(s[j]=='T' && ta[j][1])
					{
						ta[j][1]=0;
						ta[i][2]=1;
						break;
					}
				}
				if(s[i]=='C')
				{
					if(s[j]=='A' && ta[j][2])
					{
						ta[j][2]=0;
						c[i]=1;
						break;
					}
				}
				if(s[i]=='T')
				{
					if(s[j]=='A' && ta[j][2]>0)
					{
						ta[i][1]=0;
						ta[j][2]=0;
						t[i]=1;
						break;
					}
				}
			}
		}
		ans=0;
		for(int i=1;i<=n;++i)
		{
//			if(cat[i][3] || tat[i][3]) ++ans;
//			ans+=(cat[i][3]+tat[i][3]);
			ans+=(t[i]+c[i]);
		}
		printf("%lld\n",ans);
	}
	
	
	return 0;
}
//puts("CAT:");
//for(int i=1;i<=3;++i)
//{
//	cout<<i<<":    ";
//	for(int j=1;j<=n;++j)
//	{
//		cout<<cat[j][i]<<" ";
//	}
//	puts("");
//}
//puts("TAT:");
//for(int i=1;i<=3;++i)
//{
//	cout<<i<<":    ";
//	for(int j=1;j<=n;++j)
//	{
//		cout<<tat[j][i]<<" ";
//	}
//	puts("");
//}

//if(s[i]=='T') ++tat[i][1];
//if(s[i]=='C') ++cat[i][1];
//for(int j=1;j<i;++j)
//{
//	if(s[i]=='T')
//	{
//		if(s[j]=='A')
//		{
//			cat[i][3]+=cat[j][2];
//			tat[i][3]+=tat[j][2];
//		}
//	}
//	if(s[i]=='A')
//	{
//		if(s[j]=='T')
//		{
//			tat[i][2]+=tat[j][1];
//		}
//		if(s[j]=='C')
//		{
//			cat[i][2]+=cat[j][1];
//		}
//	}
//}
