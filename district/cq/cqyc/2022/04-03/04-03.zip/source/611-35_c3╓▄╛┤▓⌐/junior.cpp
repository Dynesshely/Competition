#include<bits/stdc++.h>
#define id(x,y) (x*m+y)
#define inf LONG_LONG_MAX
using namespace std;
int n,m;
long long a[100005],mn1[100005],mn2[100005],ans1=0,ans2=0,dp[100005];
int main()
{
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(mn1,0x3f3f3f3f,sizeof(mn1));
	memset(mn2,0x3f3f3f3f,sizeof(mn2));
	
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			scanf("%lld",&a[id(i,j)]);
			mn1[id(i,j)]=min(mn1[id(i,j-1)],a[id(i,j)]);//��i��ǰj�� 
		}
	}
	for(int i=1;i<=m;++i)
	{
		for(int j=1;j<=n;++j)
		{
			mn2[id(i,j)]=min(mn2[id(i,j-1)],a[id(j,i)]);//��i��ǰj�� 
		}
	}
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			dp[id(i,j)]=dp[id(i-1,j)]+mn1[id(i,j)];
		}
	}
	for(int i=1;i<=m;++i)
	{
		for(int j=1;j<=n;++j)
		{
			dp[id(j,i)]=dp[id(j,i-1)]+mn2[id(j,i)];
		}
	}
	printf("%lld",dp[id(n,m)]);
	return 0;
}

