#include<bits/stdc++.h>
using namespace std;
int n,t,r,x[7500005],tmp;
bitset<7500005> lit;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("lighthouse.in","r",stdin);
//	freopen("lighthouse.out","w",stdout);
	memset(x,0x3f3f3f,sizeof(x));
	n=read(),t=read(),r=read();
	for(int i=1;i<=n;++i)
	{
		x[i]=read();
	}
	r=min(r,x[n]-x[1]);
	lit.reset();
	for(int i=1;i<=n && t;)
	{
		if(!lit[i])
		{
			tmp=i;
			for(;x[i]<=x[tmp]+r;++i)
			{
				lit[i]=1;
			}
			tmp=i-1;
			for(;x[i]<=x[tmp]+r;++i)
			{
				lit[i]=1;
			}
			--t;
		}
	} 
	printf("%d",(int)lit.count());
	return 0;
}
