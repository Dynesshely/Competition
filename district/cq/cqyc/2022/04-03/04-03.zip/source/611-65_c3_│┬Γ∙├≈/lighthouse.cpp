#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=0;
	char c=getchar();
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n,t,r,x[10000010];
signed main()
{
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	for(int i=1;i<=n;i++)
	{
		x[i]=read();
	}
	int lst=x[1];
	x[n+1]=1e9;
	for(int i=2;i<=n+1;i++)
	{
		if(x[i]-lst>r)
		{
			lst=x[i];
			int tot=i-1;
//			cerr<<i<<"tot\n";
			for(;i<=n+1;i++)
			{
//				cerr<<i<<'\n';
				if(x[i]-x[tot]>r)
				{
					lst=x[i];
					break;
				}
			}
			t--;
		}
		if(t==0)
		{
			cout<<i-1<<'\n';
			return 0;
		}
	}
	cout<<n<<'\n'; 
	return 0;
} 
