#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	int x=0,f=0;
	char c=getchar();
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
const int MOD=1e9+7;
int quick_pow(int x,int t)
{
	if(t==0) return 1;
	if(t==1) return x;
	int tot=quick_pow(x,t>>1);
	if(t%2==0) return tot*tot%MOD;
	return tot*tot%MOD*x%MOD; 
}
int n,m;
signed main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read(),m=read();
	cout<<(quick_pow(2,(n+1)*m)-quick_pow(2,(n+1)*(m-1)+1)+quick_pow(2,n*(m-1))+MOD)%MOD*quick_pow(2,(n-1)*m)%MOD;
	return 0;
} 
