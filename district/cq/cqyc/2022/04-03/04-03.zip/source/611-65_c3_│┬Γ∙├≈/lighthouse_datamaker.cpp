#include<bits/stdc++.h>
using namespace std;
int MX=1000;
signed main()
{
	freopen("lighthouse.in","w",stdout);
	srand(114514);
	int n=1000,t=rand()%n+1,r=rand()%MX+1,x=0;
	cout<<n<<" "<<t<<' '<<r<<'\n';
	for(int i=1;i<=n;i++)
	{
		x+=(rand()%MX+1);
		cout<<x<<' ';
	}
	return 0;
 } 
