#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=0;
	char c=getchar();
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n,cnt[100000];
signed main()
{
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	n=7;
	for(int i=0;i<=n;i++)
	{
		for(int j=0;j<=n;j++)
		{
			for(int x=0;x<=n;x++)
				for(int y=0;y<=n;y++)
					cnt[i^j^x^y]++;
//			cerr<<i<<" "<<j<<'\n';
		}
	}
	int sum;
	for(int i=0;i<=n;i++)
	{
		cout<<i<<' '<<cnt[i]<<"\n";
		sum+=cnt[i]*(i+1);
		cout<<sum<<'\n';
	}
	return 0;
} 
