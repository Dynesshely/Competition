#include<bits/stdc++.h>
#define p 1000000007ll
#define ll long long
#define N 1000600
using namespace std;

int n,m;
ll ans;
ll jc[N],inv[N];

ll quick_power(ll base,ll power){
	ll s=1;
	while(power){
		if(power&1) s=s*base%p;
		base=base*base%p,power>>=1;
	}
	return s;
}

ll c(ll x,ll y){return jc[x]*inv[y]%p*inv[x-y]%p;}

int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	
	scanf("%d%d",&n,&m);

	jc[0]=1;for(int i=1;i<=n;i++) jc[i]=jc[i-1]*i%p;
	inv[0]=inv[1]=1;for(int i=2;i<=n;i++) inv[i]=(p-p/i*inv[p%i]%p)%p;
	for(int i=2;i<=n;i++) inv[i]=inv[i-1]*inv[i]%p;
	
	ll l0,l1,r0,r1;
	l0=1;
	l1=quick_power(2,n)-1;
	r0=0; for(int i=0;i<=n;i+=2) r0+=c(n,i); r0%=p;
	r1=(quick_power(2,n)-r0+p)%p;
	
	ll sum=1;
	for(int i=m;i>=1;i--){
		ans+=sum*l1%p*r0%p*quick_power(2,2ll*n*(i-1))%p;
		sum=sum*(r0*l0%p+r1*l1%p)%p;
	}
	
	ans+=sum;
	ans%=p;
	
	printf("%lld",ans);
	return 0;
}

