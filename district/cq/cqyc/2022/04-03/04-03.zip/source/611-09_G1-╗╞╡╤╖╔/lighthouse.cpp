#include<bits/stdc++.h>
using namespace std;

int n,t,r,ans;
int a[7500010];
int stk[7500010],top;
inline int read(){
	int s=0;char c=getchar();
	while(c<48||c>57) c=getchar();
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

int main(){
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	
	n=read(),t=read(),r=read();
	for(int i=1;i<=n;i++) a[i]=read();
	
	for(int i=1;i<=n;i++){
		if(!t) break;
		if(top&&a[i]-a[stk[1]]>r) {
			int j=i; while(j<=n&&a[j]-a[i-1]<=r) j++;
			t--,top=0,ans=j-1,i=j-1;
		}
		else stk[++top]=i;
	}
	if(t&&top) ans=n;
	
	printf("%d",ans);
	return 0;
}
