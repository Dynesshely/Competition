#include<bits/stdc++.h>
#define N 1000106
using namespace std;

int T;
string a;
int dp[55][55][55];

int main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	
	scanf("%d",&T);
	for(int t=1;t<=T;t++){
		cin>>a;
		int ans=0,n=a.size();
		
		for(int i=0;i<=n;i++)
			for(int j=0;j<=i;j++)
				for(int k=0;k<=i;k++)
					dp[i][j][k]=-1;
		
		dp[0][0][0]=0;
		for(int i=0;i<n;i++){
			for(int j=0;j<=i;j++){
				for(int k=0;k<=i;k++){
					if(dp[i][j][k]==-1) continue;
					dp[i+1][j][k]=max(dp[i+1][j][k],dp[i][j][k]);
					if(a[i]=='C'||a[i]=='T') dp[i+1][j+1][k]=max(dp[i+1][j+1][k],dp[i][j][k]);
					if(a[i]=='A'&&j) dp[i+1][j-1][k+1]=max(dp[i+1][j-1][k+1],dp[i][j][k]);
					if(a[i]=='T'&&k) dp[i+1][j][k-1]=max(dp[i+1][j][k-1],dp[i][j][k]+1);
				}
			}
		}
		
		
		for(int i=0;i<=n;i++)
			for(int j=0;j<=i;j++)
				for(int k=0;k<=i;k++)
				 	ans=max(ans,dp[i][j][k]);
				 	
		printf("%d\n",ans);
	}
	
	return 0;
}

