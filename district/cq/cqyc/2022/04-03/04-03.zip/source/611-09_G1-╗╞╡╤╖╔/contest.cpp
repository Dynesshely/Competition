#include<bits/stdc++.h>
#define ll long long
#define N 500100
using namespace std;

int n,q,t;
ll a[N],b[N];

inline ll read(){
	ll s=0,w=1;char c=getchar();
	while(c<48||c>57){if(c=='-') w=-1;c=getchar();}
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s*w;
}

void write(ll x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+48);
}

int main(){
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	
	n=read(),q=read(),t=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) b[i]=read();
	
	if(n<=1000&&q<=1000){
		ll ans=0;
		while(q--){
			int l=read(),r=read(); ll x=read();
			if(t) l^=ans,r^=ans,x^=ans;
			for(int i=l;i<=r;i++) if(x>a[i]) x+=b[i];
			write(ans=x),puts("");
		}
		return 0;
	}
	
	
	
	
	return 0;
}

