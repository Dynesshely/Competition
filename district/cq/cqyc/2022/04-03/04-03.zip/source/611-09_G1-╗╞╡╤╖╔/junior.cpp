#include<bits/stdc++.h>
#define ll long long
#define N 100100
#define maxn 0x3f3f3f3f3f3f3f3f
using namespace std;
int n,m;
ll ans=maxn,a[N];

int x,y;
void Get(int num){x=(num-1)/m+1,y=(num-1)%m+1;}

bool vis[N];
void check(ll tot){
	for(int j=1;j<=m;j++){
		ll Min=maxn;
		for(int i=1;i<=n;i++)
			if(!vis[(i-1)*m+j]) 
				Min=min(Min,a[(i-1)*m+j]);
		if(Min==maxn) return;
		tot+=Min;
	}
	ans=min(ans,tot);
}

void dfs(int x,ll tot){
	if(x==n+1) {check(tot);return;}
	for(int j=1;j<=m;j++){
		int num=(x-1)*m+j;
		vis[num]=1;
		dfs(x+1,tot+a[num]);
		vis[num]=0;
	}
}

int main(){
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n*m;i++) scanf("%d",&a[i]);
	
	if(n<=5&&m<=5) dfs(1,0),printf("%lld",ans),exit(0);
	
	
	
	return 0;
}

