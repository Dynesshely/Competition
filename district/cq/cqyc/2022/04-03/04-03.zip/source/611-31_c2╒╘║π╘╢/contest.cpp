#include<bits/stdc++.h>
using namespace std;
int n,q,t,a[500001],b[500001],ans,l,r,x;
int main(){
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)scanf("%d",&b[i]);
	for(int i=1;i<=q;i++){
		scanf("%d%d%d",&l,&r,&x);
		l=l^(t*ans);
		r=r^(t*ans);
		x=x^(t*ans);
		for(int j=l;j<=r;j++)
			if(x>a[j])x+=b[j];
		ans=x;
		printf("%d\n",ans);
	}
	return 0;
}
