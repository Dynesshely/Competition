#include<bits/stdc++.h>
using namespace std;
inline int read(){
int x=0,f=1;
char ch=getchar();
while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
return x*f;
}
int T,ans,kkk,tib;
bool bj[1000001];
char fa[1000001];
int main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	T=read();
	for(int wdnmd=1;wdnmd<=T;wdnmd++){
		ans=0;
		scanf("%s",fa);
		for(int i=strlen(fa)-1;i>=0;i--){
			if(fa[i]=='T'&&bj[i]==0){
//				cout<<a.front()<<" "<<t.front()<<endl;
				bj[i]=1;
				kkk=i;
			    while(1){
			    if(kkk<0||(fa[kkk]=='A'&&bj[kkk]==0))break;
				kkk--;
			}
				tib=kkk;
			    while(1){
			    if(kkk<0||((fa[kkk]=='C')&&bj[kkk]==0))break;
				kkk--;
			}
			    if(kkk<0){
			    	kkk=tib;
			   	while(1){
			    if(kkk<0||((fa[kkk]=='T')&&bj[kkk]==0))break;
				kkk--;
			}
				}
				if(kkk>=0){
					ans++;
				bj[tib]=1;
				bj[kkk]=1;
			}
		}
	}	
	printf("%d\n",ans);
		for(int i=0;i<strlen(fa);i++)
			bj[i]=0;
}
	return 0;
}
