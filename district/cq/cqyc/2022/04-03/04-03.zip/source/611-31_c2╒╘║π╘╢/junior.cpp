#include<bits/stdc++.h>
using namespace std;
long long n,m,fa[51][51],bj[51][51];
long long ans,mmin=1145141919810;
void dfs(int now){
	if(now>n+m){
		mmin=min(mmin,ans);
		return ;
	}
	if(now<=n){
		for(int i=1;i<=m;i++){
			if(bj[now][i]==0){
			ans+=fa[now][i];
			bj[now][i]=1;
			dfs(now+1);
			bj[now][i]=0;
			ans-=fa[now][i];
		}
		}
	}else{
		for(int i=1;i<=n;i++){
			if(bj[i][now-n]==0){
			ans+=fa[i][now-n];
			bj[i][now-n]=1;
			dfs(now+1);
			bj[i][now-n]=0;
			ans-=fa[i][now-n];
		}
		}
	} 
} 
int main(){
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	scanf("%lld",&fa[i][j]);
	dfs(1);
	printf("%lld",mmin);
	return 0;
}
