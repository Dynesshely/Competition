#include<bits/stdc++.h>
using namespace std;
int n,t,r,fa[7500001],ans;
bool bj[7500001];
inline int read(){
int x=0,f=1;
char ch=getchar();
while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
return x*f;
}
int main(){
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	scanf("%d%d%d",&n,&t,&r);
	for(int i=1;i<=n;i++)fa[i]=read();
	bj[0]=1;
	for(int i=1;i<=n;i++){
		if(t==0)break;
		if(fa[i+1]-fa[i]>r&&fa[i]-fa[i-1]>r){
			ans=i;
			bj[i]=1;
			t--;
			i++;
			continue;
		}
		if(bj[i-1]==0&&fa[i]-fa[i-1]>r)break;
		if(bj[i-1]==0&&fa[i]-fa[i-1]<=r){
			bj[i-1]=1;
			bj[i]=1;
			ans=i;
			t--;
			if(fa[i+1]-fa[i]<=r){
				bj[i+1]=1;
				ans=i+1;
			}
			continue;
		}
		if(fa[i+1]-fa[i]<=r&&bj[i-1]==1)continue;
		if(fa[i+1]-fa[i]>r){
			continue;
		}
	}
	printf("%d",ans);
	return 0;
}
