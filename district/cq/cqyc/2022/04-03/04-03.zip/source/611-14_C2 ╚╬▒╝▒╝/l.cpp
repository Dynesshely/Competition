#include <bits/stdc++.h>
#define int __int128
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i(k) ; i <= n ; i += p )
#define ROF(i,k,n,p) for(int i(k) ; i >= n ; i -= p )
using namespace std ;
const int N = 1e7+5 ;
int n,m,mx(1),top,top2,ans ;
int all[N],sm[N],tr[N],us[N] ;
inline void read(int &x)
{
	x = 0 ; int f(0) ; char c(gc()) ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
int stk[30],tp;
inline void print(int x){
	if(x < 0) pc('-'),x = -x ;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
inline void check()
{
	int res1(0),res2(0) ;
	FOR(i,1,n,1) res1 |= all[i],res2 ^= all[i] ;
	us[++top] = res1,sm[top] = res2 ;
}
inline void find(int x)
{
	if(x == n+1)
	{
		check() ;
		return ;
	}
	FOR(i,0,mx-1,1)
	{
		all[x] = i ;
		find(x+1) ;
	}
}
inline void add(int x)
{
	while(x <= mx*2) tr[x]++,x += -x&x ;
}
inline int ask(int x)
{
	int res(0) ;
	while(x) res += tr[x],x -= -x&x ;
	return res ;
}
signed main()
{
//	freopen(".in","r",stdin) ;
//	freopen(".out","w",stdout) ;
//	read(n),read(m) ;
	for(n = 1 ; n <= 5 ; ++n) for(m = 1 ; m <= 5 ; ++m)
	{
		print(n),space,print(m),pc(':') ;
		memset(tr,0,sizeof(tr)) ;
		mx = 1,top = 0,ans = 0  ;
		FOR(i,1,m,1) mx *= 2 ; 
		find(1) ;
		FOR(i,1,top,1) add(sm[i]+1) ;
		FOR(i,1,top,1) ans += ask(us[i]+1) ;
		print(ans),space  ;
		FOR(i,2,ans,1)
		{
			int k = 0 ; 
			while(ans%i == 0) 
			{
				++k ;
				ans/=i ;
				if(ans%i != 0)
				{ 
					break ;
				 	print(i) ;
				 	if(k > 1) printf("^"),print(k) ;
				 	space ;
				 	
				}
			} 
			if(ans%i != 0) break ;
		}
		print(ans) ;
		enter ;
	}
	
	return 0 ;
}

