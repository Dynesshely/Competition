#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i(k) ; i <= n ; i += p )
#define ROF(i,k,n,p) for(int i(k) ; i >= n ; i -= p )
using namespace std ;
const int N = 7e6+5e5+5 ;
int n,t,r,las(1),ans ;
int pl[N],vis[N] ;
inline void read(int &x)
{
	x = 0 ; int f(0) ; char c(gc()) ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
int stk[30],tp;
inline void print(int x){
	if(x < 0) pc('-'),x = -x ;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main()
{
	freopen("lighthouse.in","r",stdin) ;
	freopen("lighthouse.out","w",stdout) ;
	read(n),read(t),read(r) ;
	FOR(i,1,n,1) read(pl[i]) ;
	++n,pl[n] = 0x3f3f3f3f3f3f3f ;
	FOR(i,1,n,1)
	{
		if(vis[i]) continue ;
		FOR(j,i+1,n,1)
		{
			if(pl[j]-pl[i] > r)
			{
				t-- ;
				FOR(k,i,j-1,1) vis[k] = 1 ;
				FOR(k,j,n,1)
				{
					if(pl[k]-pl[j-1] > r) break ;
					vis[k] = 1 ;
				}
				break ;
			}
		}
		if(!t) break ;
	}
	FOR(i,1,n,1) ans += (vis[i] > 0) ;
//	FOR(i,1,n,1) print(vis[i]),space ;
	print(ans) ;
	return 0 ;
}

