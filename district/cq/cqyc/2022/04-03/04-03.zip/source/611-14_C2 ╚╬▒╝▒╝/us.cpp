#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i(k) ; i <= n ; i += p )
#define ROF(i,k,n,p) for(int i(k) ; i >= n ; i -= p )
using namespace std ;
int n ;
inline void read(int &x)
{
	x = 0 ; int f(0) ; char c(gc()) ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
int stk[30],tp;
inline void print(int x){
	if(x < 0) pc('-'),x = -x ;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main()
{
//	freopen(".in","r",stdin) ;
//	freopen(".out","w",stdout) ;
	read(n) ;
	int k(1) ;
	FOR(i,2,n,1)
	{
		while(n%i == 0) print(i),space,n/=i,k *= i ;
	}
	print(k) ;
	return 0 ;
}

