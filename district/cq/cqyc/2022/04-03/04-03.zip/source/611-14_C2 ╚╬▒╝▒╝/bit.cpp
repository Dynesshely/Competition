#include <bits/stdc++.h>
#define int long long
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i(k) ; i <= n ; i += p )
#define ROF(i,k,n,p) for(int i(k) ; i >= n ; i -= p )
using namespace std ;
const int MOD = 1e9+7 ;
int n,m ;
inline void read(int &x)
{
	x = 0 ; int f(0) ; char c(gc()) ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
int stk[30],tp;
inline void print(int x){
	if(x < 0) pc('-'),x = -x ;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
inline int fast_pow(int x,int k)
{
	int res(1) ;
	while(k)
	{
		if(k&1) res = (res*x)%MOD ;
		x = (x*x)%MOD,k >>= 1 ; 
	}
	return res ;
}
signed main()
{
//	freopen(".in","r",stdin) ;
//	freopen(".out","w",stdout) ;
	read(n),read(m) ;
	print(((fast_pow(2,(n-1)+(2*n-1)*(m-1)))%MOD)*(((fast_pow(2,n+1)-2)%MOD)*(fast_pow(2,m-2)))) ; 
	return 0 ;
}

