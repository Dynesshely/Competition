#include<bits/stdc++.h>
using namespace std;
const int N=1010;
int n,q,t,a[N],b[N];
int main()
{
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++) scanf("%d",a+i);
	for(int i=1;i<=n;i++) scanf("%d",b+i);
	int l,r;
	long long x;
	while(q--)
	{
		scanf("%d%d%lld",&l,&r,&x);
		for(;l<=r;l++) if(a[l]<x) x+=b[l];
		printf("%lld\n",x);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
