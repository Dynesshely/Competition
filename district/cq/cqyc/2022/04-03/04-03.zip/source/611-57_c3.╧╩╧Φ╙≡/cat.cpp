#include<bits/stdc++.h>
using namespace std;
const int N=1e6+10;
int t,n,ans,A,T,TT,stknt[N],stka[N],stkt[N];
char a[N];
bool biao[N];
int main()
{
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%s",a+1);
		n=strlen(a+1);
		ans=A=T=TT=0;
		for(int i=n;i;i--)
		{
			if(a[i]=='C')
			{
				if(!A||!T) continue;
				ans++,biao[i]=biao[stka[A--]]=biao[stkt[T--]]=true;
			}
			else if(a[i]=='T') stknt[++TT]=i;
			else if(a[i]=='A'&&TT) stka[++A]=i,stkt[++T]=stknt[TT--];
		}
		A=T=0;
		for(int i=n;i;i--)
		{
			if(biao[i]) continue;
			if(a[i]=='T')
			{
				if(A&&T) A--,T--,ans++;
				else T++;
			}
			else if(a[i]=='A'&&T>A) A++;
		}
		printf("%d\n",ans);
		for(int i=1;i<=n;i++) biao[i]=false;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
