#include<bits/stdc++.h>
using namespace std;
const int N=55;
const double down=0.996;
int n,m,hang[N],lie[N],a[N][N];
bool biao[N][N];
long long ans,nowans;
void fire()
{
	double t=5000;
	while(t>=1e-12)
	{
		bool k=rand()&1;
		int x=rand()%n+1,y=rand()%m+1;
		if(biao[x][y]) goto L;
		biao[x][y]=true;
		nowans+=a[x][y];
		if(k) swap(hang[x],y);
		else swap(lie[y],x);
		nowans-=a[x][y];
		biao[x][y]=false;
		if(nowans<ans) ans=nowans;
		else if((exp(nowans-ans)/t)<t/RAND_MAX)
		{
			biao[x][y]=true;
			nowans+=a[x][y];
			if(k) swap(hang[x],y);
			else swap(lie[y],x);
			biao[x][y]=false;
			nowans-=a[x][y];
		}
L:		t*=down;
	}
	return;
}
int main()
{
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) scanf("%d",a[i]+j);
	for(int i=1;i<n;i++) hang[i]=1,ans+=a[i][1],biao[i][1]=true;
	for(int i=2;i<=m;i++) lie[i]=1,ans+=a[1][i],biao[1][i]=true;
	hang[n]=m,ans+=a[n][m],biao[n][m]=true;
	lie[1]=n,ans+=a[n][1],biao[n][1]=true;
	nowans=ans;
	int k=1000;
	while(k--) fire();
	printf("%lld\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
