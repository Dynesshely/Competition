#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e6+10,mod=1e9+7;
int n,m,dan,tot,ans,shuang,fac[N],inv[N];
bool biao[N];
int ksm(int x,int y)
{
	int res=1;
	while(y)
	{
		if(y&1) res=res*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return res;
}
void check()
{
	int sum=0,k;
	for(int i=0;i<m;i++) sum+=biao[i];
	k=sum;
	sum=ksm(dan,k)*ksm(shuang,m-k)%mod*ksm(tot,k)%mod;
	for(int i=0;i<m;i++) if(!biao[i]) sum=sum*tot%mod*ksm(tot+1,i)%mod;
	ans=(ans+sum)%mod;
}
void dfs(int x)
{
	if(x==m) return check();
	biao[x]=true;
	dfs(x+1);
	biao[x]=false;
	dfs(x+1);
}
signed main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	fac[1]=1;
	for(int i=2;i<=n;i++) fac[i]=i*(fac[i-1])%mod;
	inv[n]=ksm(fac[n],mod-2);
	for(int i=n;i>1;i--) inv[i-1]=i*inv[i]%mod;
	for(int i=1;i<=n;i+=2) dan=(dan+fac[n]*inv[i]%mod*inv[n-i]%mod)%mod;
	for(int i=2;i<=n;i+=2) shuang=(shuang+fac[n]*inv[i]%mod*inv[n-i]%mod)%mod;
	tot=(dan+shuang)%mod;
	dfs(0);
	printf("%lld\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
