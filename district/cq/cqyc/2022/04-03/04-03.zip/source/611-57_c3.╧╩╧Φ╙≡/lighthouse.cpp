#include<bits/stdc++.h>
using namespace std;
const int N=7.5e6+10;
int n,t,r,ans,a[N];
inline int read()
{
	int x=0;
	bool f=false;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return f?-x:x;
}
int main()
{
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	for(int i=1;i<=n;i++) a[i]=read();
	int L=1;
	for(int i=1;i<=n&&t;t--)
	{
		while(a[i]-a[L]<=r&&i<=n) i++;
		int R=(--i);
		while(a[R]-a[i]<=r&&R<=n) R++;
		ans=R-1,L=i=R;
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
