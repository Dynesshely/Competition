#include <bits/stdc++.h>
using namespace std;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
const int N=100010;
int n,q,t,lsans=0;
int a[N],b[N];
int main() {
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	n=read(),q=read(),t=read();
	for(int i=1; i<=n; ++i) a[i]=read();
	for(int i=1; i<=n; ++i) b[i]=read();
	while(q--){
		int l=read(),r=read(),x=read();
		l=l^(t*lsans),r=r^(t*lsans);
		for(int i=l;i<=r;++i)
			if(x>a[i]) x+=b[i];
		printf("%d\n",x);
	}
	return 0;
}
