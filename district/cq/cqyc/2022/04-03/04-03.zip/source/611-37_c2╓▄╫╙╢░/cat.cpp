#include <bits/stdc++.h>
using namespace std;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int sb(char a) {
	if(a=='C')return 1;
	if(a=='A') return 2;
	if(a=='T')return 3;
	return 114514;
}
const int inf=0x3f3f3f3f;
int q;
set<int> jh[4];//1 c 2 a 3 t
int main() {// cat tat
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	q=read();
	while(q--) {
		int ans=0;
		string ch;
		cin>>ch;
		for(int i=1; i<=3; ++i) {
			jh[i].clear();
			jh[i].insert(inf);
		}
		for(int i=0; i<ch.size(); ++i) {
			int sf=sb(ch[i]);
			if(sf!=114514) jh[sf].insert(i);
		}
		set<int>::iterator ddq,x,xx,fa,cnm;
		ddq=jh[1].begin();
//		cout<<endl;
//		for(int i=1; i<=3; ++i) {
//			cnm=jh[i].begin();
//			while(*cnm!=inf) {
//				cout<<*cnm<<" ";
//				cnm++;
//			}
//			cout<<endl;
//		}
//		cout<<endl;
		while(1) {
//			cout<<*ddq<<endl;
			x=jh[2].upper_bound(*ddq);
			if(*x==inf) break;
			xx=jh[3].upper_bound(*x);
			if(*xx==inf) break;
			ans++;
			jh[2].erase(x);
			jh[3].erase(xx);
			fa=ddq;
//			cout<<*ddq<<" "<<*jh[1].end()<<endl;
			++ddq;
			if(*ddq==inf) {
//				jh[1].erase(fa);
				break;
			}
			jh[1].erase(fa);
		}
//		cout<<"\n :: "<<ans<<endl;
		ddq=jh[3].begin();
		while(1) {
//			cout<<*ddq<<endl;
			x=jh[2].upper_bound(*ddq);
			if(*x==inf) break;
			xx=jh[3].upper_bound(*x);
			if(*xx==inf) break;
			ans++;
			jh[2].erase(x);
			jh[3].erase(xx);
			fa=ddq;
//			cout<<*ddq<<" "<<*jh[1].end()<<endl;
			++ddq;
			if(*ddq==inf) break;
			jh[3].erase(fa);
		}
//		cout<<"ans: "<<ans<<endl;
		printf("%d\n",ans);
	}
	return 0;
}

