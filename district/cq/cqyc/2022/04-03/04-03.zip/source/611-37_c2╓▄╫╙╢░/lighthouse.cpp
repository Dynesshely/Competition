#include <bits/stdc++.h>
using namespace std;
const int N=7500010;
int n,t,r,ans=0,tot=0,ls,wd;
int p[N];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main() {
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	if(t==0){
		cout<<0<<endl;
		return 0;
	} 
	for(int i=1; i<=n; ++i) p[i]=read();
	wd=1;
	p[n+1]=0x3f3f3f3f;
	for(int i=1; i<=n; ++i) {
		ls=p[i+1]-p[wd];
//		cout<<i<<": "<<ls<<" "<<tot<<" "<<wd<<endl;
		if(tot==t) break;
		if(ls>r&&tot+1<=t) {
			int x=i;
			while(i+1<=n){
				if(p[i+1]-p[x]>r) break;
				++i;
			}
			wd=i+1;
			ans=i;
			tot++;	
//			cout<<wd<<" "<<tot<<endl;
		}
	}
	if(wd==1) ans=1;
//	cout<<wd<<endl;;
	printf("%d",ans);
	return 0;
}
/*
5 1 114514
1 3 4 9 11

5 1 1
1 3 4 9 11

2 5 6
1154 191981

3 1 2
1 2 5

3 1 3
1 2 5

5 2 10
1 10 18 28 38
*/
