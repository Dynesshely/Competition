#include <bits/stdc++.h>
#define int long long
using namespace std;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
const int N=55;
int n,m,ans=(long long)1919810114514;
int jz[N][N],hf[N],sf[N],bj[N][N];
void check() {
	int shit=0;
	bool flag=1;
	for(int i=1;i<=n;++i) cout<<hf[i]<<" ";
	cout<<endl;
	for(int i=1;i<=m;++i) cout<<sf[i]<<" ";
	cout<<endl;
	cout<<endl;
	for(int i=1; i<=n; ++i) {
		if(hf[i]!=1) {
			flag=0;
			break;
		}
	}
	for(int i=1; i<=m; ++i)
		if(sf[i]!=1) {
			flag=0;
			break;
		}
	if(flag==0) return;
	for(int i=1; i<=n; ++i) {
		for(int j=1; j<=m; ++j) {
			shit+=(bj[i][j]==1?jz[i][j]:0);
		}
	}
	ans=min(shit,ans);
	cout<<ans<<endl;
}
void dfs(int x,int y) {
//	cout<<x<<" "<<y<<endl;
	if(x==n+1) {
		check();
		return;
	}
	int nx,ny;
	if(y==m) nx=x+1,ny=1;
	else nx=x,ny=y+1;
	int yx=hf[x],yy=sf[y];
	dfs(nx,ny);
	hf[x]=1;
	bj[x][y]=1;
	dfs(nx,ny);
	hf[x]=yx;
	sf[y]=1;
	dfs(nx,ny);
	sf[y]=yy;
	bj[x][y]=0;
}
signed main() {
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	n=read(),m=read();
	for(int i=1; i<=n; ++i) hf[i]=0;
	for(int i=1; i<=m; ++i) sf[i]=0;
	for(int i=1; i<=n; ++i) {
		for(int j=1; j<=m; ++j)
			jz[i][j]=read(),bj[i][j]=0;
	}
	dfs(1,1);
	printf("%d",ans);
	return 0;
}

