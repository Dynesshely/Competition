#include<bits/stdc++.h>
using namespace std;
int n,t,r,a[7500005],x=1,ans;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}

int main()
{
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	for(int i=1; i<=n; ++i) a[i]=read();
	for(int i=1; i<=n; ++i)
	{
		int sum=1;
		for(int j=i-1; a[i]-a[j]<=r && j>0; --j) ++sum;
		for(int j=i+1; a[j]-a[i]<=r && j<=n; ++j) ++sum;
		ans=max(ans,sum);
	}
	cout<<ans;
	return 0;
}
