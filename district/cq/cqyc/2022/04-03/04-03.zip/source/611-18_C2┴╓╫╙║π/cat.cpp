#include<bits/stdc++.h>
using namespace std;
int t,ans;
char a[1000006],b[1000006];
bool f=0;
int main()
{
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		memset(a,0,sizeof a),memset(b,0,sizeof b),cin>>a+1;
		int len=strlen(a+1),x=1,y;
		for(int cnt=0,i=1; i<=len; ++i) if(a[i]=='C' || a[i]=='A' || a[i]=='T') b[++cnt]=a[i],f=(a[i]=='C');
//		if(!f)
//		{
//			len=strlen(b+1);
//			int sum=0,num=0;
//			for(int i=1; i<=len; ++i)
//			{
//				
//			}
//		}
		ans=0,y=strlen(b+1);
		while(x<=y)
		{
			while(x+2<=y && ((b[x]=='C' && b[x+1]=='A' && b[x+2]=='T') || (b[x]=='T' && b[x+1]=='A' && b[x+2]=='T')))
				++ans,x+=3;
			while(b[y]!='T') --y;
			while(b[x]=='A') ++x;
			if(b[x]=='C' && b[x+1]=='A') --y,++x,++ans;
			else if(b[x]=='T' && b[x+1]=='A') --y,++x,++ans;
			++x;
		}
		printf("%d\n",ans);
	}
	return 0;
}
