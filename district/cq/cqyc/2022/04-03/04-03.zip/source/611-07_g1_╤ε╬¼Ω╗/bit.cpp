#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
} van n,m;
const van mod=1e9+7;
van power(van a,van b) {
	van ans=1,base=a;
	while (b) {
		if (b&1) ans*=base,ans%=mod;
		base*=base,base%=mod,b>>=1;
	} return ans;
}
van inv(van a) {return power(a,mod-2);}
int main() {
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	read(n),read(m);
	van or1=power(2,n)-1,or0=1,xor1=0,xor0=0;
	van now=n; xor1+=now;
	for (int i=3;i<=n;i+=2) {
		now*=(n-i+2)*(n-i+1)%mod,now%=mod;
		now*=inv(i)*inv(i-1)%mod,now%=mod;
		xor1+=now,xor1%=mod;
	} xor0=power(2,n)-xor1;
	van base=1,pre=0; van ans=0;
	pre=or1*xor1%mod+or0*xor0%mod,pre%=mod;
	for (int i=1;i<=m;i++) {
		van tmp=power(pre,m-i)*or1%mod*xor0%mod; tmp%=mod;
		tmp*=power(or1+or0,i-1)*power(xor0+xor1,i-1)%mod; tmp%=mod;
		ans+=tmp; ans%=mod;
	} ans+=power(pre,m),ans%=mod;
	print(ans);
	return 0;
}

