#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
} van n,q,t;
const van MaxN=5e5+10;
van a[MaxN],b[MaxN],lstans=0;
int main() {
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	read(n),read(q),read(t);
	for (int i=1;i<=n;i++) read(a[i]);
	for (int i=1;i<=n;i++) read(b[i]);
	for (int qq=1;qq<=q;qq++) {
		van l,r,x; read(l),read(r),read(x);
		l^=(t*lstans),r^=(t*lstans),x^=(t*lstans);
		van ans=x; for (int i=l;i<=r;i++) {
			if (ans>a[i]) ans+=b[i];		
		} print(ans),putchar('\n'); lstans=ans;
	}
	return 0;
}

