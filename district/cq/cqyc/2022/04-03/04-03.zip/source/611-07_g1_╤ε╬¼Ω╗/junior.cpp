#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
} const van MaxN=50;
van n,m,ans=1e18,c[MaxN][MaxN];
bool used[MaxN][MaxN];
void DFS(van now,van cost) {
	if (now>n+m){ans=min(ans,cost); return;}
	if (now<=n) for (int i=1;i<=m;i++) {
		if (!used[now][i]) used[now][i]=1,DFS(now+1,cost+c[now][i]),used[now][i]=0;
	} else for (int i=1;i<=n;i++) {
		if (!used[i][now-n]) used[i][now-n]=1,DFS(now+1,cost+c[i][now-n]),used[i][now-n]=0;
	}
}
int main() {
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	read(n);read(m);
	for (int i=1;i<=n;i++) for (int j=1;j<=m;j++) read(c[i][j]);
	DFS(1,0); print(ans);
	return 0;
}

