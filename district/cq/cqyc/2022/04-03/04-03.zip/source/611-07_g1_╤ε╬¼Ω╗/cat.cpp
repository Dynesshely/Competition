#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
} const van MaxN=2e6+10;
string x; char m[MaxN]; van n,T;
bool used[MaxN]; van wh[4];
van numT[MaxN]; van fal[MaxN],far[MaxN];
van lef[MaxN]; van bakfal[MaxN],bakfar[MaxN];
van getfal(van x) {
	if (x<=0) return -1e18;
	return x==fal[x]?x:fal[x]=getfal(fal[x]);
}
van getfar(van x) {
	if (x>n) return 1e18;
	return x==far[x]?x:far[x]=getfar(far[x]);
}
int main() {
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	read(T); for (int tt=1;tt<=T;tt++) {
		cin>>x; n=x.size();
		for (int i=0;i<n;i++) m[i+1]=x[i];
		memset(used,0,sizeof used); 
		memset(fal,0,sizeof fal);
		memset(far,0,sizeof far); 
		memset(lef,0,sizeof lef);
		for (int i=1;i<=n;i++) fal[i]=m[i]=='T'?i:getfal(i-1);
		for (int i=n;i;i--) far[i]=m[i]=='T'?i:getfar(i+1);
		van now=1,ans=0; for (int i=1;i<=n;i++) {
			if (m[i]=='C'&&now==1) {
				now++,used[i]=1,wh[1]=i;
			} else if (m[i]=='T'&&now==3) {
//				cout<<i<<endl;
				now=1,ans++,used[i]=1,wh[3]=i;
				fal[i]=getfal(i-1);
				far[i]=getfar(i+1);
			} else if (m[i]=='A'&&now==2) now++,used[i]=1,wh[2]=i;
		} for (int i=1;i<now;i++) used[wh[i]]=0; // cout<<"mid: "<<ans<<endl;
		memcpy(bakfal,fal,sizeof bakfal); memcpy(bakfar,far,sizeof bakfar);
		for (int i=1;i<=n;i++) if (m[i]=='A'&&getfal(i)!=-1e18) {
//			cout<<"d: "<<i<<" "<<getfal(i)<<" "<<getfar(i)<<endl;
			lef[i]=getfal(i); van del=lef[i];
			fal[del]=getfal(del-1); far[del]=getfar(del+1);
		} memcpy(fal,bakfal,sizeof fal); memcpy(far,bakfar,sizeof far);
		for (int i=n;i>=1;i--) if (m[i]=='A'&&lef[i]!=0) {
			if (getfar(i)!=1e18) { ans++;
				van del=lef[i]; fal[del]=getfal(del-1); far[del]=getfar(del+1);
				del=getfar(i); fal[del]=getfal(del-1); far[del]=getfar(del+1);
			}
		} print(ans); putchar('\n');
	} while(1) ;
	return 0;
}

