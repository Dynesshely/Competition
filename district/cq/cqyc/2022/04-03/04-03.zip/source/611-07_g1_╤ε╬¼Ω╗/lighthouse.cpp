#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
} const van MaxN=8e6+10;
van n,t,d; van x[MaxN];
struct area {
	van l,r,id;
	bool operator < (const area& a) const {
		
	}
}A[MaxN];
int main() {
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	read(n),read(t),read(d);
	for (int i=1;i<=n;i++) read(x[i]);
	van ll=1,rr=1; for (int i=1;i<=n;i++) {
		while (x[i]-x[ll]>d) ll++;
		while (x[rr]-x[i]<=d&&rr<=n) rr++; rr--;
		A[i].l=ll,A[i].r=rr;
	} if (t==0) {print(0); return 0;} van ans=0;
	for (int i=1;i<=n;i++) if (A[i].l!=1) break; else ans=max(ans,A[i].r);
	van max_=ans,now=1; for (int i=2;i<=t;i++) {
		while (A[now].l<=ans+1) max_=max(max_,A[now].r),now++;
		ans=max(ans,max_);
	} print(ans);
	return 0;
}

