#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e7+10;
int N,t,r,x[Maxn],lst=1,now=1,ans;

int main(){
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	scanf("%d %d %d",&N,&t,&r);
	for(int i=1;i<=N;i++) scanf("%d",x+i);
	while(lst<=N){
		while(x[now+1]-x[lst]<=r&&now<N) ++now;
		--t; lst=now;
		while(x[lst+1]-x[now]<=r&&lst<N) ++lst;
		if(!t||lst==N||now==N){ ans=lst; break; }
		++lst; now=lst;
	}
	printf("%d",min(N,ans));
	return 0;
}
/*
3 1 2
1 2 5
2

3 1 3
1 2 5
3

5 3 3 
2 3 5 7 9
5

4 3 2
1 4 5 7
4

4 3 4
1 7 15 21
3

7 1 4
2 3 4 5 7 8 9
7
*/
