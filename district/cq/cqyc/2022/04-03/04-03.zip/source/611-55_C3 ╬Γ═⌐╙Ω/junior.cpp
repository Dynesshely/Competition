#include<bits/stdc++.h>
using namespace std;

const long long INF=1e18+10;
const int Maxn=5010;
long long ans=INF;
int A[Maxn][Maxn],N,M;
bool Vis[Maxn][Maxn];

void DFS(int x,int goal){
	if(x>goal){
		long long ret=0;
		for(int i=1;i<=N;i++) for(int j=1;j<=M;j++)
			if(Vis[i][j]) ret+=A[i][j];
		ans=min(ans,ret);
		return;
	}
	if(x<=N){
		for(int i=1;i<=M;i++){
			Vis[x][i]=true;
			DFS(x+1,goal);
			Vis[x][i]=false;
		}
	}
	else{
		int tmp=x-N;
		for(int i=1;i<=N;i++){
			if(Vis[i][tmp]) continue;
			Vis[i][tmp]=true;
			DFS(x+1,goal);
			Vis[i][tmp]=false;
		}
	}
}

int main(){
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	scanf("%d %d",&N,&M);
	for(int i=1;i<=N;i++) for(int j=1;j<=M;j++)
		scanf("%d",A[i]+j);
	DFS(1,N+M);
	printf("%lld",ans);
	return 0;
}
/*
5 5
158260522 877914575 602436426 24979445 861648772
623690081 433933447 476190629 262703497 211047202
971407775 628894325 731963982 822804784 450968417
430302156 982631932 161735902 880895728 923078537
707723857 189330739 910286918 802329211 404539679

2727801006
*/
