#include<bits/stdc++.h>
using namespace std;
#define int long long

const int Maxn=5e5+10;
int N,Q,t,A[Maxn],B[Maxn],lstans;
int C[Maxn],D[Maxn],cnt,nxt,Sum[Maxn],lst;
struct node{
	int l,r,x,ans,id;
}P[Maxn];
bool flag;

bool cmp1(node a,node b){ return a.x<b.x; }
bool cmp2(node a,node b){ return a.id<b.id; }

signed main(){
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	scanf("%lld %lld %lld",&N,&Q,&t);
	for(int i=1;i<=N;i++) scanf("%lld",A+i);
	for(int i=1;i<=N;i++) scanf("%lld",B+i);
	for(int i=1;i<=Q;i++){
		scanf("%lld %lld %lld",&P[i].l,&P[i].r,&P[i].x);
		P[i].id=i;
		if(P[i].l!=1||P[i].r!=N) flag=true;
	}
	if(N<=5000||flag||t){
		for(int i=1;i<=Q;i++){
			int l=P[i].l,r=P[i].r,x=P[i].x;  
			l=l^(t*lstans),r=r^(t*lstans);
			for(int i=l;i<=r;i++) if(x>A[i]) x+=B[i];
			printf("%lld\n",x); lstans=x;
		}
		return 0;
	}
	C[1]=A[1],D[1]=B[1];
	while(nxt<N){
		while(nxt<=N&&C[cnt]+D[cnt]>=A[nxt]) D[cnt]+=B[nxt],nxt++;
		C[++cnt]=A[nxt]; D[cnt]=B[nxt]; ++nxt;
	}
	for(int i=1;i<=cnt;i++) Sum[i]=Sum[i-1]+D[i];
	sort(P+1,P+N+1,cmp1);
	for(int i=1;i<=Q;i++){
		if(P[i].x<=C[lst]-Sum[lst-1]) P[i].ans=Sum[lst-1]+P[i].x;
		else {
			while(lst<cnt&&P[i].x>C[lst]-Sum[lst-1]) lst++;
			P[i].ans=Sum[lst-1]+P[i].x;
		}
	}
	sort(P+1,P+N+1,cmp2);
	for(int i=1;i<=Q;i++) printf("%lld\n",P[i].ans);
	return 0;
}
/*
4 3 0
2 4 7 5
1 3 1 2
1 4 3
1 4 4
2 4 3

4
11
3

7 7 0
3 6 7 4 2 5 9
2 1 1 2 3 1 1
1 7 1
1 7 2
1 7 3
1 7 4
1 7 5
1 7 6
1 7 7

1
2
7
13
16
17
18
*/
