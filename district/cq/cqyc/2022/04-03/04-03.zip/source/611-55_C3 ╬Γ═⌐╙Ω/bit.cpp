#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e6+10;
const int Mod=1e9+7;
int N,M,A[Maxn];
long long ans;

inline void DFS(int x,int goal){
	if(x>goal){
		int ret1=0,ret2=0;
		for(int i=1;i<=N;i++) ret1|=A[i],ret2^=A[N+i];
		if(ret1>=ret2) ans++;
		if(ans>=Mod) ans-=Mod;
		return;
	}
	for(int i=0;i<(1<<M);i++) A[x]=i,DFS(x+1,goal);
}

int main(){
//	freopen("bit.in","r",stdin);
//	freopen("bit.out","w",stdout);
	scanf("%d %d",&N,&M);
	DFS(1,N*2);
	printf("%lld",ans);
	return 0;
}
/*
3 3
233472

2 6
12648448

2 7
*/
