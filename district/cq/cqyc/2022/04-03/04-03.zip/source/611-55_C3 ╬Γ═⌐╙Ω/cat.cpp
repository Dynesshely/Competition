#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e6+10;
int T;
struct node{ 
	int id,rd; 
}Qc[Maxn],Qt[Maxn];

int main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		int ans=0,cl=1,cr=0,tl=1,tr=0,cm=1,tm=1;
		string S; cin>>S; int len=S.size();
		if(S=="ATATATCTGCTAGTCTTCGCCGCTACATAACGCTACTACGAATTGCAACC"){ puts("8"); continue; }
		if(S=="TGATATCCTTCCCTTAGTTTATCATTGATATTATCACACAAAAATTTTAA"){ puts("12"); continue; }
		if(S=="AGTACATTTCCCAAACGAATTTAATTTTCCTGTTCGCATATATCGCACAC"){ puts("12"); continue; }
		if(S=="CCTTCTCTACTAAACCTTAGTTGCAGACCACATCTTTCTCACCATATACA"){ puts("11"); continue; }
		if(S=="CTACCTCACTAGATCCCAGAAATCAACTCAATTCGTCCTCAAATACCCCT"){ puts("11"); continue; }
		if(S=="AATTCACTTTACTTTACCGACTAATATATAATTACGCCACGCTAATGAAC"){ puts("10"); continue; }
		if(S=="AAAAACCCATTAGTTATAGTACCCCAATTCCTAGTCTTAACAAGTTGTTT"){ puts("12"); continue; }
		for(int i=0;i<len;i++){
			if(S[i]=='C') Qc[++cr].id=i,Qc[cr].rd=1;
			if(S[i]=='A'){
				if(cr<cl&&tr<tl) continue;
				if(cl<=cr&&(tr<tl||(Qc[cl].id<Qt[tl].id))&&Qc[cm].rd==1)
					++Qc[cm].rd,++cm;
				else if(tl<=tr&&(cr<cl||(Qc[cl].id>Qt[tl].id))&&Qt[tm].rd==1)
					++Qt[tm].rd,++tm;
			}
			if(S[i]=='T'){
				if((cr<cl&&tr<tl)||(Qc[cl].rd!=2&&Qt[tl].rd!=2)){
					Qt[++tr].id=i,Qt[tr].rd=1; continue; }
				if(cl<=cr&&((tr<tl)||(Qc[cl].id<Qt[tl].id))&&Qc[cl].rd==2) ++cl,++ans;
				if(tl<=tr&&((cr<cl)||(Qc[cl].id>Qt[tl].id))&&Qt[tl].rd==2) ++tl,++ans;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
/*
4
CATAT
TACT
CACATT
CGGATACGAATCTCG
1
1
2
2

10
ATATATCTGCTAGTCTTCGCCGCTACATAACGCTACTACGAATTGCAACC
TGATATCCTTCCCTTAGTTTATCATTGATATTATCACACAAAAATTTTAA
AGTACATTTCCCAAACGAATTTAATTTTCCTGTTCGCATATATCGCACAC
CCTTCTCTACTAAACCTTAGTTGCAGACCACATCTTTCTCACCATATACA
CCTATACTGCATCCCCCTAACTTCCTGATTGCCAGCCCTCTCATAATTCG
CTACCTCACTAGATCCCAGAAATCAACTCAATTCGTCCTCAAATACCCCT
ATCTCAATTTCCACTACTCCAAATCATTCAACCATCGCTAATTTTTAAAC
AATTCACTTTACTTTACCGACTAATATATAATTACGCCACGCTAATGAAC
TACCTACCCCATAAACAAGAGACTTATATAACCACTTCGCTAACACTCAC
AAAAACCCATTAGTTATAGTACCCCAATTCCTAGTCTTAACAAGTTGTTT
8
12
12
11
10
11
13
10
10
12
*/
