#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,t,r;
int x[7500005];
int l[7500005],ri[7500005];
bool vis[7500005];
int pos[7500005],tot=0;
int main(){
	n=read(),t=read(),r=read();
	for(register int i=1;i<=n;i++){
		x[i]=read(); l[i]=i;
	}
	int tmp=2;
	while(x[tmp]-x[1]<=r) tmp++;
	ri[1]=--tmp;
	for(register int i=2;i<=n;i++){
		l[i]=l[i-1],ri[i]=ri[i-1];
		while(x[i]-x[l[i]]>r) l[i]++;
		while(ri[i]<=n&&x[ri[i]]-x[i]<=r) ri[i]++;
		ri[i]--;
	}
	for(register int i=1;i<=n;i++){
		if(ri[i]>ri[i-1]) pos[++tot]=i;
	}
	int ans=0;
	for(register int i=1;i<=tot;i++){
		ans=max(ans,ri[pos[min(tot,i+t-1)]]-l[pos[i]]+1);
	}
	cout<<ans;
	return 0;
}
