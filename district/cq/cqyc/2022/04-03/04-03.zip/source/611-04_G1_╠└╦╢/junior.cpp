#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
const int INF=1e18;
int n,m,s,t;
int depth[400005];
int head[400005],to[1600005],val[1600005],nxt[1600005],tot=1;
void add(int u,int v,int w){
	to[++tot]=v;
	val[tot]=w;
	nxt[tot]=head[u];
	head[u]=tot;
}
bool bfs(){
	memset(depth,0,sizeof depth); depth[s]=1;
	queue<int> q; q.push(s);
	while(!q.empty()){
		int x=q.front(); q.pop();
		for(register int i=head[x];i;i=nxt[i]){
			int u=to[i];
			if(val[i]&&!depth[u]){
				depth[u]=depth[x]+1;
				q.push(u);
			}
		}
	}
	return depth[t];
}
int dfs(int now,int flow){
	if(now==t) return flow;
	int out_flow=0;
	for(register int i=head[now];i&&flow;i=nxt[i]){
		int u=to[i];
		if(val[i]&&depth[u]==depth[now]+1){
			int tmp=dfs(u,min(val[i],flow));
			val[i]-=tmp,val[i^1]+=tmp;
			flow-=tmp,out_flow+=tmp;
		}
	}
	if(out_flow==0) depth[now]=0;
	return out_flow;
}
int Dinic(){
	int ans=0;
	while(bfs()) ans+=dfs(s,INF);
	return ans;
}
int calc(int x,int y){
	return m*(x-1)+y;
}
void add_edge(int u,int v,int w){
	add(u,v,w),add(v,u,0);
}
signed main(){
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	n=read(),m=read();
	s=0,t=4*n*m+1; int value,cnt=n*m;
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			value=read();
			add_edge(s,calc(i,j),value);
			add_edge(calc(i,j),++cnt,value);
			add_edge(cnt,n*m+i,value);
			//for(register int k=1;k<=n;k++){
			//	if(k!=j) add_edge(cnt,calc(i,k)+3*n*m,INF);
			//	else add_edge(cnt,calc(i,j)+3*n*m,value);
			//}
			add_edge(calc(i,j),++cnt,value);
			add_edge(cnt,n*m+n+j,value);
			//for(register int k=1;k<=n;k++){
			//	if(k!=i) add_edge(cnt,calc(k,j)+3*n*m,INF);
			//	else add_edge(cnt,calc(i,j)+3*n*m,value);
			//}
		}
	}
	for(register int i=1;i<=n;i++){
		add_edge(n*m+i,t,INF);
	}
	for(register int i=1;i<=m;i++){
		add_edge(n*m+n+i,t,INF);
	}
	cout<<Dinic();
	return 0;
}
