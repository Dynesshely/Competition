#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,t,r;
int x[7500005];
int l[7500005],ri[7500005];
bool vis[7500005];
int pos[7500005],tot=0;
int main(){
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	if(t==0){
		cout<<0;
		return 0;
	}
	for(register int i=1;i<=n;i++){
		x[i]=read(); l[i]=i;
	}
	int tmp=2;
	while(x[tmp]-x[1]<=r) tmp++;
	ri[1]=--tmp;
	for(register int i=2;i<=n;i++){
		l[i]=l[i-1],ri[i]=ri[i-1];
		while(x[i]-x[l[i]]>r) l[i]++;
		while(ri[i]<=n&&x[ri[i]]-x[i]<=r) ri[i]++;
		ri[i]--;
	}
	for(register int i=1;i<=n;i++){
		if(l[i]==1) continue;
		pos[++tot]=i-1;
		break;
	}
	for(register int i=pos[1];i<=n;i++){
		while(i<=n&&l[i]-1<=ri[pos[tot]]) i++;
		i--;
		pos[++tot]=i;
	}
	int ans=0;
	for(register int i=1;i<=tot;i++){
		ans=max(ans,ri[pos[min(tot,i+t-1)]]-l[pos[i]]+1);
	}
	cout<<ans;
	return 0;
}
