#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,m;
int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read(),m=read();
	cout<<(1<<m);
	return 0;
}
