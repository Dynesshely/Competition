#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int T;
int a[1000005],tota=0,posa=0;
int c[1000005],totc=0,posc=0;
int t[1000005],tott=0,post=0;
bool visa[1000005],visc[1000005],vist[1000005];
string s;
void init(){
	for(register int i=1;i<=tota;i++) visa[i]=0;
	for(register int i=1;i<=totc;i++) visc[i]=0;
	for(register int i=1;i<=tott;i++) vist[i]=0;
	tota=totc=tott=posa=posc=post=0;
}
int main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	T=read();
	while(T--){
		visa[0]=visc[0]=vist[0]=true;
		cin>>s; int n=s.size();
		for(register int i=0;i<n;i++){
			if(s[i]=='A') a[++tota]=i+1;
			else if(s[i]=='C') c[++totc]=i+1;
			else if(s[i]=='T') t[++tott]=i+1;
		}
		int ans=0;
		posa=posc=post=0;
		for(register int i=1;i<=totc;i++){
			while(posa<=tota&&a[posa]<c[i]) posa++;
			while(posa<=tota&&visa[posa]) posa++;
			while(post<=tott&&t[post]<a[posa]) post++;
			while(post<=tott&&vist[post]) post++;
			if(a[posa]>c[i]&&t[post]>a[posa]&&!visa[posa]&&!vist[post]){
				visc[i]=visa[posa]=true,vist[post]=true;
				ans++;
			}
			else break;
		}
		posa=tota;
		int tmp=tott;
		for(register int i=tott;i>=1;i--){
			if(!vist[i]){
				while(posa>0&&a[posa]>t[i]) posa--;
				while(posa>0&&visa[posa]) posa--;
				while(tmp>0&&t[tmp]>a[posa]) tmp--;
				while(tmp>0&&vist[tmp]) tmp--;
				if(t[tmp]<a[posa]&&a[posa]<t[i]&&!vist[tmp]&&!visa[posa]){
					vist[i]=vist[tmp]=visa[posa]=true;
					ans++;
				}
				else break;
			}
		}
		cout<<ans<<"\n";
		init();
	}
	return 0;
}
