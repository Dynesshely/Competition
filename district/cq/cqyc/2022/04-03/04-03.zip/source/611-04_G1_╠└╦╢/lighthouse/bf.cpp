#include<bits/stdc++.h>
using namespace std;
int n,t,r,ans=0;
int x[7500005];
bool vis[7500005];
bool light[7500005];
void check(){
	memset(light,0,sizeof light);
	for(register int i=1;i<=n;i++){
		if(vis[i]){
			for(register int j=1;j<=n;j++){
				if(abs(x[j]-x[i])<=r) light[j]=true;
			}
		}
	}
	for(register int i=1;i<=n;i++){
		if(light[i]){
			int j=i;
			while(light[j]) j++;
			ans=max(ans,j-i);
			i=j-1;
		}
	}
}
void dfs(int now,int cnt){
	if(now==n+1||cnt==t){
		check();
		return;
	}
	vis[now]=true;
	dfs(now+1,cnt+1);
	vis[now]=false;
	dfs(now+1,cnt);
}
int main(){
	freopen("lighthouse.in","r",stdin);
	freopen("test.out","w",stdout);
	cin>>n>>t>>r;
	for(register int i=1;i<=n;i++){
		cin>>x[i];
	}
	vis[1]=true;
	dfs(2,1);
	vis[1]=false;
	dfs(2,0);
	cout<<ans;
	return 0;
}
