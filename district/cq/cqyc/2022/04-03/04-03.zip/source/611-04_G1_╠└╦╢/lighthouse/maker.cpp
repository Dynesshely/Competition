#include<bits/stdc++.h>
using namespace std;
int x[75000005];
int main(){
	srand(time(0));
	freopen("lighthouse.in","w",stdout);
	int n=7.5e6,t=rand()%(n-1)+1,r=rand()%515+1;
	cout<<n<<" "<<t<<" "<<r<<"\n";
	for(register int i=1;i<=n;i++){
		x[i]=x[i-1]+rand()%515+1;
		cout<<x[i]<<" ";
	}
	return 0;
}
