#include<bits/stdc++.h>
#define int unsigned long long
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,q,t;
int a[100005],b[100005];
signed main(){
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	n=read(),q=read(),t=read();
	for(register int i=1;i<=n;i++) a[i]=read();
	for(register int i=1;i<=n;i++) b[i]=read();
	int lastans=0;
	while(q--){
		int l=read()^(t*lastans),r=read()^(t*lastans),x=(int)abs(read())^(t*lastans);
		for(register int i=l;i<=r;i++){
			if(x>a[i]) x+=b[i];
		}
		cout<<x<<"\n";
	}
	return 0;
}
