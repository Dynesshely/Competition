#include<bits/stdc++.h>
using namespace std;
int main(){
	while(true){
		system("maker.exe");
		system("lighthouse.exe");
		system("bf.exe");
		if(system("fc lighthouse.out test.out")) return 0;
	}
	return 0;
}
