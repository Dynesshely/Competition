#include<bits/stdc++.h>
//#define int long long
#define N 2000000
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	int cnt=0;char f[40];
	if(!x)
		putchar('0');
	if(x<0){
		putchar('-');
		x=-x;
	}
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
	putchar('\n');
}
int T,sz,ans,lt,now,id[N],tot,r[N];
int que[N],L,R;
bitset<N> vis,see;
char c[N];
signed main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	T=read();
	while(T--){
		scanf("%s",c+1);
		sz=strlen(c+1);
		lt=R=ans=tot=0;
		now=L=1;
		for(int i=sz;i;--i){
			r[i]=see[i]=0;
			vis[i]=0;
			if(c[i]=='T')
				que[++R]=i;
			if(c[i]=='A'&&L<=R){
				r[i]=que[L++];
				vis[i]=1;
			}
		}
		for(int i=sz-1;i>1;--i)
			if(vis[i])
				id[++tot]=i;
		reverse(id+1,id+1+tot);
		for(int i=1;i<=sz;++i){
			if(id[now]==i)
				++now;
			if(!see[i]&&(c[i]=='C'||c[i]=='T')&&now<=tot){
				++ans;
				see[id[now]]=see[r[id[now]]]=1;
				++now;
			}
			if(now>tot)
				break;
		}
		write(ans);
	}
	return 0;
}
