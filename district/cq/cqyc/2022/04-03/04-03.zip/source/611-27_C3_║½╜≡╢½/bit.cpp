#include<bits/stdc++.h>
#define int long long
#define N 2000000
#define ri register
#define ct const register
#define mod 1000000007
using namespace std;
inline int read(){
	ri int x=0,f=1;ri char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(ri int x){
	ri int cnt=0;ri char f[40];
	if(!x)
		putchar('0');
	if(x<0){
		putchar('-');
		x=-x;
	}
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,m,a[N],b[N],ans;
inline void dfs2(ct int k){
	if(k>n){
		ri int res1=0,res2=0;
		for(ri int i=1;i<=n;++i){
			res1|=a[i];
			res2^=b[i];
		}
		if(res1>=res2)
			++ans;
		return;
	}
	for(ri int i=0;i<m;++i){
		b[k]=i;
		dfs2(k+1);
	}
}
inline void dfs1(ct int k){
	if(k>n){
		dfs2(1);
		return;
	}
	for(ri int i=0;i<m;++i){
		a[k]=i;
		dfs1(k+1);
	}
}
signed main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read();m=1<<read();
	dfs1(1);
	write(ans);
	return 0;
}
