#include<bits/stdc++.h>
#define int long long
#define N 1000000
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	int cnt=0;char f[40];
	if(!x)
		putchar('0');
	if(x<0){
		putchar('-');
		x=-x;
	}
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
	putchar('\n');
}
int n,q,t,la,a[N],b[N],l,r,x,tot,L,R,y[N];
signed main(){
	freopen("ex_contest2.in","r",stdin);
	freopen("contest2.out","w",stdout);
	n=read();q=read();t=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=n;++i)
		b[i]=read();
	if(n>1000||q>1000){
		y[0]=-1e18;
		for(int i=1;i<=n;++i){
			b[i]+=b[i-1];
			y[i]=max(y[i-1],a[i]-b[i-1]);
		}
		while(q--){
			l=read()^(t*la);r=read()^(t*la);x=read()^(t*la);
			L=1;R=n;
			while(L<=R){
				int mid=(L+R)>>1;
				if(x>y[mid])
					L=mid+1;
				else
					R=mid-1;
			}
			write(x+b[L-1]);
		}
		return 0;
	}
	while(q--){
		l=read()^(t*la);r=read()^(t*la);x=read()^(t*la);
		for(int i=l;i<=r;++i)
			if(x>a[i])
				x+=b[i];
		la=x;
		write(x);
	}
	return 0;
}
