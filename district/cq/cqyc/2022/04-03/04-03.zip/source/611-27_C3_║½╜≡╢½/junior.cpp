#include<bits/stdc++.h>
#define int long long
#define N 100
#define ri register
#define ct const register
#define down 0.996
using namespace std;
inline int read(){
	ri int x=0,f=1;ri char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(ri int x){
	ri int cnt=0;char f[40];
	if(!x)
		putchar('0');
	if(x<0){
		putchar('-');
		x=-x;
	}
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,m,a[N][N],ans=1e18,res;
bitset<N> vis[N];
inline void dfs2(ct int k){
	if(res>=ans)
		return;
	if(k>m){
		ans=res;
		return;
	}
	for(ri int i=1;i<=n;++i)
		if(!vis[i][k]){
			vis[i][k]=1;
			res+=a[i][k];
			dfs2(k+1);
			res-=a[i][k];
			vis[i][k]=0;
		}
}
inline void dfs1(ct int k){
	if(res>=ans)
		return;
	if(k>n){
		dfs2(1);
		return;
	}
	for(ri int i=1;i<=m;++i){
		vis[k][i]=1;
		res+=a[k][i];
		dfs1(k+1);
		res-=a[k][i];
		vis[k][i]=0;
	}
}
signed main(){
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	n=read();m=read();
	for(ri int i=1;i<=n;++i)
		for(ri int j=1;j<=m;++j)
			a[i][j]=read();
	dfs1(1);
	write(ans);
	return 0;
}
