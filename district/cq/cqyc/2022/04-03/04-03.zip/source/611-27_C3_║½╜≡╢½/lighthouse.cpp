#include<bits/stdc++.h>
#define int long long
#define N 10000000
using namespace std;
//bool ppp;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	int cnt=0;char f[40];
	if(!x)
		putchar('0');
	if(x<0){
		putchar('-');
		x=-x;
	}
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,t,r,x[N],now=1;
//bool pppp;
signed main(){
//	cerr<<(&ppp-&pppp)/1024.0/1024.0;
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read();t=read();r=read();
	for(int i=1;i<=n;++i)
		x[i]=read();
	while(now<=n&&t--){
		int ow=now+1;
		while(x[ow]<=x[now]+r&&ow<=n)
			++ow;
		now=ow-1;
		while(x[ow]<=x[now]+r&&ow<=n)
			++ow;
		now=ow;
	}
	write(now-1);
	return 0;
}
