#include<bits/stdc++.h>
using namespace std;
int n,t,r,sp[8000000];
int main() {
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	cin>>n>>t>>r;
	//t++;
	for(int i=1; i<=n; i++) cin>>sp[i];
	int k=sp[1]+r;
	for(int i=1; i<=n; i++) {
		if(sp[i]<=k&&((sp[i+1]>k)||i==n)) {
			//cout<<i<<endl;
			t--;
			k=sp[i]+r;
		//	cout<<k<<endl;
			for(int y=i; y<=n; y++) {
				if(y==n) i=y;
				else if(sp[y]<=k&&sp[y+1]>k) {
					i=y;
					break;
				}
				//cout<<i<<endl;
			}	
			k=sp[i+1]+r;
				if(t==0) {
					cout<<i<<endl;
					return 0;
				}
		}
	}
}
