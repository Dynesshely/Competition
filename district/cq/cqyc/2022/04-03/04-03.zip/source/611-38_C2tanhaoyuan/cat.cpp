#include<bits/stdc++.h>
using namespace std;
int n,t,r,sp[8000000],sum=0,ans=0,san=0,j=0;
string S;
int main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>S;
		for(int i=0;i<S.size();i++){
		//	if(S[i]=='C') ans++;
			if(S[i]=='T') ans++;
		}
		for(int i=0;i<S.size();i++){
		    if(S[i]=='C')  sum++;
			if(S[i]=='T') {
				if(j<ans) ans--,sum++;
				else j--;
			}	
			if(S[i]=='A'){
				if(ans>0&&sum>0) {
				san++;	
				ans--;
				sum--;
				j++;
				}
			}
		}
		cout<<san<<endl;
		ans=sum=san=j=0;
	}
}
// ATATATCTCTATCTTCCCCTACATAACCTACTACAATTCAACC
