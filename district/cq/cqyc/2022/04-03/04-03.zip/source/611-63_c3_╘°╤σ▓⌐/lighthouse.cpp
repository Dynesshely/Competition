#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=7500005;
int n,t,r,b,c,x,ans,a[N];
signed main() {
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	for(int i=1;i<=n;++i) a[i]=read();
	b=a[1];
	for(int i=1;i<=n;++i) {
		if(t==0) break;
		while(a[i]-b<=r&&i<=n) ++i;
		--t,c=a[i-1];
		while(a[i]-c<=r&&i<=n) ++i;
		ans=i-1;
		b=a[i],--i;
	}
	cout<<ans;
	return 0;
}
/*
3 1 2
1 2 5

2

3 1 3
1 2 5

3
*/
