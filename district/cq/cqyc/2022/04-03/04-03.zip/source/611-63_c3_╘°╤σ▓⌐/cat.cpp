#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=1000005;
int n,c[N],a[N],t[N],tc,ta,tt,ec,et,el,cc,ct,cl,ans;
char s[N];
bitset<N> vis,v;
signed main() {
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	int _=read();
	while(_--) {
		scanf("%s",s+1);
		n=strlen(s+1);
		tc=ta=tt=0;
		for(int i=1;i<=n;++i) {
			if(s[i]=='C') c[++tc]=i;
			if(s[i]=='A') a[++ta]=i;
			if(s[i]=='T') t[++tt]=i;
		}
		ec=et=el=1,ans=0,cc=ct=0,cl=tt;
		for(int i=1;i<=ta;++i) {
			while(ec<=tc&&c[ec]<a[i]) ++ec,++cc;
			while(et<=tt&&t[et]<a[i]) ct+=(vis[et]==0?1:0),++et,el=max(el,et),--cl;
			if(cl&&cc&&el<=tt) vis[el]=1,v[i]=1,++el,--cc,--cl,++ans;
		}
		et=1,el=tt,ct=0;
		for(int i=1;i<=ta;++i) {
			if(v[i]==1) continue;
			while(et<el&&t[et]<a[i]) ct+=(vis[et]==0?1:0),++et;
			while(el&&vis[el]==1) --el;
			if(ct&&el&&t[el]>a[i]) vis[el]=1,--el,--ct,++ans;
		}
		for(int i=1;i<=tt;++i) vis[i]=0;
		for(int i=1;i<=ta;++i) v[i]=0;
		printf("%d\n",ans);
	}
	return 0;
}
/*
4
CATAT
TACT
CACATT
CGGATACGAATCTCG

1
1
2
2

10
ATATATCTGCTAGTCTTCGCCGCTACATAACGCTACTACGAATTGCAACC
TGATATCCTTCCCTTAGTTTATCATTGATATTATCACACAAAAATTTTAA
AGTACATTTCCCAAACGAATTTAATTTTCCTGTTCGCATATATCGCACAC
CCTTCTCTACTAAACCTTAGTTGCAGACCACATCTTTCTCACCATATACA
CCTATACTGCATCCCCCTAACTTCCTGATTGCCAGCCCTCTCATAATTCG
CTACCTCACTAGATCCCAGAAATCAACTCAATTCGTCCTCAAATACCCCT
ATCTCAATTTCCACTACTCCAAATCATTCAACCATCGCTAATTTTTAAAC
AATTCACTTTACTTTACCGACTAATATATAATTACGCCACGCTAATGAAC
TACCTACCCCATAAACAAGAGACTTATATAACCACTTCGCTAACACTCAC
AAAAACCCATTAGTTATAGTACCCCAATTCCTAGTCTTAACAAGTTGTTT

8
12
12
11
10
11
13
10
10
12

TATATTTTTTTTTAAAATAA
9
*/
