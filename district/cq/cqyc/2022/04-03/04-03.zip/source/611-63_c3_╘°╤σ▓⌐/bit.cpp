#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=1000005,mod=1e9+7;
int n,m;
int Pow(int a,int b) {
	if(b==1) return a%mod;
	if(b==0) return 1;
	int tmp=Pow(a,b/2);
	if(b&1) return tmp*tmp%mod*a%mod;
	return tmp*tmp%mod;
}
signed main() {
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	srand(time(0));
	n=read(),m=read();
	cout<<Pow(n*rand(),m*rand());
	return 0;
}
/*
*/

