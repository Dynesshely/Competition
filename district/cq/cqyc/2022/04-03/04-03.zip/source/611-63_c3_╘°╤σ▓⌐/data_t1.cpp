#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int n=20,a=10;
signed main() {
	freopen("lighthouse.in","w",stdout);
	srand(time(0));
	cout<<n<<" "<<rand()%n+1<<" "<<rand()%a+1<<"\n";
	int lst=0;
	for(int i=1;i<=n;++i) {
		int x=lst+rand()%a+1;
		cout<<x<<" ";
		lst=x;
	}
	return 0;
}
/*
*/

