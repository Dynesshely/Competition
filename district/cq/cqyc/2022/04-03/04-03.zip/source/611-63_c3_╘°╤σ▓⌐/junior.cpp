#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=55;
int n,m,a[N][N],ans=1e18;
bool vis[N][N];
bool h[N],l[N];
map<int,int> mp[15];
void dfs(int t,int sum) {
	if(sum>=ans||mp[t][sum]==1) return;
	mp[t][sum]=1;
	if(t>n+m) {
		ans=min(ans,sum);
		return;
	}
	for(int i=1;i<=n;++i) if(h[i]==0)
		for(int j=1;j<=m;++j)
			if(vis[i][j]==0) {
				h[i]=1,vis[i][j]=1;
				dfs(t+1,sum+a[i][j]);
				h[i]=0,vis[i][j]=0;
			}
	for(int j=1;j<=m;++j) if(l[j]==0)
		for(int i=1;i<=n;++i)
			if(vis[i][j]==0) {
				l[j]=1,vis[i][j]=1;
				dfs(t+1,sum+a[i][j]);
				l[j]=0,vis[i][j]=0;
			}
}
void bl() {
	dfs(1,0);
	cout<<ans;
	exit(0);
}
signed main() {
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i)
	for(int j=1;j<=m;++j)
		a[i][j]=read();
	if(max(n,m)<=5) bl();
	return 0;
}
/*
5 5
158260522 877914575 602436426 24979445 861648772
623690081 433933447 476190629 262703497 211047202
971407775 628894325 731963982 822804784 450968417
430302156 982631932 161735902 880895728 923078537
707723857 189330739 910286918 802329211 404539679

2727801006
*/
