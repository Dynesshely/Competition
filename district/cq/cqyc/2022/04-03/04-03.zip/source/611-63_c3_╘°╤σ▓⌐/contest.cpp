#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=500005,Q=200005;
int n,q,t,a[N],b[N];
void bl() {
	while(q--) {
		int l=read(),r=read(),x=read();
		for(int i=l;i<=r;++i)
			if(x>a[i]) x+=b[i];
		printf("%lld\n",x);
	}
	exit(0);
}
signed main() {
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	n=read(),q=read(),t=read();
	for(int i=1;i<=n;++i) a[i]=read();
	for(int i=1;i<=n;++i) b[i]=read();
	if(n<=1000&&q<=1000&&t==0) bl();
	return 0;
}
/*
4 3 0
2 4 7 5
1 3 1 2
1 4 3
1 4 4
2 4 3

4
11
3
*/
