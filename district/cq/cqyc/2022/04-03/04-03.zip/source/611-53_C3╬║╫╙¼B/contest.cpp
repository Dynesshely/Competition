#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=100005;
ll n,q,t,lst,l,r,x; 
ll a[N],b[N];
int main()
{
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	scanf("%lld%lld%lld",&n,&q,&t);
	for(int i=1;i<=n;i++)
	scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++)
	scanf("%lld",&b[i]);
	while(q--)
	{
		scanf("%lld%lld%lld",&l,&r,&x);
		int w=t*lst;
		l=l^t,r=r^t,x=x^t;
		for(int i=l;i<=r;i++)
		if(x>a[i]) x+=b[i];
		printf("%lld\n",x);
		lst=x;
	}
}
