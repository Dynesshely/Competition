#include<bits/stdc++.h>
using namespace std;
const int N=7500005;
int n,t,r,cnt;
int x[N],w[N],ans;
int main()
{
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	scanf("%d%d%d",&n,&t,&r);
	for(int i=1;i<=n;i++)
	scanf("%d",&x[i]);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	if(abs(x[j]-x[i])<=r) w[i]++;
	
	for(int i=1;i<=n;i++)
	ans=max(ans,w[i]);
	printf("%d",ans);
	/*for(int i=1;i<=n;i++)
	{
		cnt++,w[cnt]=1,z[cnt]=y[cnt]=i;
		for(int j=i;j<=n;j++)
		{
			i=j;
			if(x[j+1]-x[j]<=r) 
			w[cnt]++,y[cnt]=j+1;
			else break;
		}
	}*/
	 
}
/*
3 1 2
1 2 5

7 2 1 
1 2 5 6 7 9 10

7 1 2 
1 2 5 6 7 9 10

3 1 3
1 2 5
*/
