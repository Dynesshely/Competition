for(int i=1;i<=cnt;i++)
	for(int j=z[i];j<=y[i];j++)
	{
		int hd=j,tl=j;
		if(fhd==1)
		{
			cost[i]++;
			for(int k=j;k<=y[i];k++)
			{
				j=k;
				if(x[k]-x[tl]>r) {fhd=0;break;}
				hd=k;
			}
			cout<<"hd:"<<hd<<endl;
		}
		cout<<"??"<<j<<endl;
		for(int k=hd;k<=y[i];k++)
		{
			//cout<<"!!"<<k<<endl;
			if(x[k]-x[hd]>r) {fhd=1;break;}
			//cout<<"hd:"<<hd<<"K:"<<k<<endl;
			j=k;
		}
		if(fhd==0) cost[i]=1;
		tl=j;cout<<"j:"<<j<<endl; 
	}
