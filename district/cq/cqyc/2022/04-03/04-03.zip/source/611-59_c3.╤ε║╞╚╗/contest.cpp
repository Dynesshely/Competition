#include<bits/stdc++.h>
using namespace std;
int n,q,l,r,p;
long long t,x,ans;
pair<long long,long long> a[500001];
long long num[500001],sum[500001];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
inline long long lread()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(long long x)
{
	if(x<0) putchar('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
	putchar('\n');
}
int main()
{
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	n=read(),q=read(),t=lread();
	for(int i=1;i<=n;i++) a[i].first=lread();
	for(int i=1;i<=n;i++) a[i].second=lread();
	if(n<=1000)
	{
		while(q--)
		{
			l=read(),r=read(),x=lread();
			for(int i=l;i<=r;i++)
				if(x>a[i].first) x+=a[i].second;
			write(x);
		}
	}
	else
	{
		sort(a+1,a+1+n);
		for(int i=1;i<=n;i++) sum[i]=sum[i-1]+a[i].second;
		for(int i=1;i<=n;i++) 
			num[i]=max(num[i-1],a[i].first-sum[i-1]);
		while(q--)
		{
			l=read(),r=read(),x=lread();
			l^=t*ans,r^=t*ans,x^=t*ans;
			p=lower_bound(num+1,num+1+n,x)-num-1;
			ans=sum[p]+x;
			write(ans);
		}
	}
	return 0;
}

