#include<bits/stdc++.h>
using namespace std;
bool ppp;
int n,t,r,cnt,hd,tl,ans,p,sz,foo,q;
int a[7500001],st[7500001],id[7500001],an[7500001],en[7500001],las[7500001];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
} 
int stk[30],tp;
void write(int x)
{
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
bool pppp;
int main()
{
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
//	printf("%f\n",(&pppp-&ppp)/1024.0/1024.0);
	n=read(),t=read(),r=read();
	for(int i=1;i<=n;i++) a[i]=read();
	hd=1,tl=0;
	for(int i=1;i<=n;i++)
	{
		while(hd<=tl&&a[st[hd]]+r<a[i]) hd++;
		if(hd>tl) id[i]=++cnt;
		else
		{
			if(!id[hd]) id[i]=++cnt;
			else id[i]=id[hd];
			en[id[i]]=i,las[i]=hd,an[i]=hd-tl+1;
		}
		st[++tl]=i;
	}
	while(hd<=tl) an[st[hd]]+=n-hd,hd++;
	for(int i=1;i<=cnt;i++)
	{
		sz=0,p=0;
		for(int j=en[i];j;j=las[j]) st[++sz]=j,p+=an[j];
		if(sz/2<=t) ans=max(ans,p);
		else 
		{
			foo=0,q=p;
			for(int j=st[1];(sz-foo)/2>t;j=las[j]) q-=an[j],foo++;
			ans=max(q,ans);
			foo=0,q=p;
			for(int j=st[sz-t+(t&1)];(sz-foo)/2>t;j=las[j]) q-=an[j],foo++;
			ans=max(q,ans);
		}
	}
	write(ans);
	return 0;
}
