#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
	inline int in(){
	    int x=0,f=1;
	    char ch=getchar();
	    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	    return x*f;
	}
	int stk[30],tp;
	void out(int x){
	    do stk[++tp]=x%10,x/=10;while(x);
	    while(tp)putchar(stk[tp--]^48);
	}
}
using fastio::in;
using fastio::out;

const int N = 7500005;
int x[N];
int n,t,r;

int main(){
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n = in(),t = in(),r = in();
	for(int k=1;k<=n;k++)
		x[k] = in();
	if(!t){
		puts("0");
		return 0;
	}
	int k = 2,cnt = 0;
	for(;k<=n;k++){
		cnt += x[k]-x[k-1];
		if(cnt>r){
			if(!t)
				break;
			t--;
			cnt = x[k]-x[k-1];
			if(!t&&cnt>r)
				break;
		}
	}
	out(k-1);
	return 0;
} 
