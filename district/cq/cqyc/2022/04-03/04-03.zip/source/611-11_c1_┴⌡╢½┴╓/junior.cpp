#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int N = 55,M = N*N;
bool b[N][N];
int a[N][N];
int n,m;

signed main(){
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int k=1;k<=n;k++)
		for(int j=1;j<=m;j++)
			scanf("%lld",a[k]+j);
	int ans = 0x3f3f3f3f3f3f3f3f;
	for(int i=(1<<(n+m+1));i<(1<<(n+m+2));i++){
		for(int k=1;k<=n;k++)
			for(int j=1;j<=m;j++)
				b[k][j] = i>>((j-1)*m+k-1)&1;
	
		bool flag = false;
		for(int k=1;k<=n;k++){
			flag = true;
			for(int j=1;j<=m;j++)
				if(b[k][j]){
					flag = false;
					break;
				}
			if(flag)
				break;
		}
		if(flag)
			continue;
		for(int j=1;j<=m;j++){
			flag = true;
			for(int k=1;k<=n;k++)
				if(b[k][j]){
					flag = false;
					break;
				}
			if(flag)
				break;
		}
		if(flag)
			continue;
		int tmpans = 0;
		for(int k=1;k<=n;k++)
			for(int j=1;j<=m;j++)
				if(b[k][j])
					tmpans += a[k][j];
		ans = min(ans,tmpans);
	}
	printf("%lld",ans);
	return 0;
}
