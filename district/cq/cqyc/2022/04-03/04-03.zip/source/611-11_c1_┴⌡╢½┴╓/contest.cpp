#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
	inline int in(){
	    int x=0,f=1;
	    char ch=getchar();
	    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	    return x*f;
	}
	int stk[30],tp;
	void out(int x){
	    do stk[++tp]=x%10,x/=10;while(x);
	    while(tp)putchar(stk[tp--]^48);
	}
}
using fastio::in;
using fastio::out;

const int N = 500005;
int a[N],b[N];
int n,q,t;

namespace stb1{
	class siki{
		public:
			int num,idx;
			inline bool operator < (const siki &tmp)const{
				return num<tmp.num;
		}
	}qus[N];
	class Kamisato{
		private:
			class Ayaka{
				public:
					int l,r,num,lazy;
			}tr[N*4];
			inline void pushup(int wei){
				tr[wei].num = tr[wei<<1].num+tr[wei<<1|1].num;
			}
		public:
			void build(int wei,int l,int r){
				if(l==r){
					tr[wei].num = qus[l].num;
					return;
				}int mid = (l+r)>>1;
				build(wei<<1,l,mid);
				build(wei<<1|1,mid+1,r);
				pushup(wei);
			}
			int seach(int wei,int l,int r,int x){
				if(l==r)
					return l;
				int mid = (l+r)>>1;
				
			}
	};
	int main(){
		for(int k=1;k<=q;k++){
			in(),in();
			qus[k].num = in();
			qus[k].num = k;
		}
		sort(qus+1,qus+1+q);
		return 0;
	}
}

signed main(){
//	freopen("contest.in","r",stdin);
//	freopen("contest.out","w",stdout);
	n = in(),q = in(),t = in();
	if(n>1000)
		return stb1::main();
	for(int k=1;k<=n;k++)
		a[k] = in();
	for(int k=1;k<=n;k++)
		b[k] = in();
	int lasans = 0;
	while(q--){
		int l=in(),r=in(),x=in();
		if(t){
			l ^= lasans;
			r ^= lasans;
			x ^= lasans;
		}
		for(int k=l;k<=r;k++)
			if(x>a[k])
				x += b[k];
		printf("%lld\n",x);
	}
	return 0;
}
