#include <iostream>
#include <set>
#include <cstring>
#include <algorithm>
using namespace std;

set<int> C,T;
string s;
int n;

int main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	int q;
	scanf("%d",&q);
	while(q--){
		cin >> s;
		n = s.size();
		C.clear();
		T.clear();
		for(int k=0;k<n;k++)
			if(s[k]=='C')
				C.insert(k);
			else if(s[k]=='T')
				T.insert(k);
		int ans = 0;
		for(int k=0;k<n;k++){
			if(s[k]=='A'){
				auto r = T.upper_bound(k+1);
				if(r==T.end())
					continue;
				auto l = T.begin();
				if((*l)<k){
					T.erase(l);
					T.erase(r);
					ans++;
					continue;
				}
				l = C.begin();
				if(l!=C.end()&&(*l)<k){
					C.erase(l);
					T.erase(r);
					ans++;
					continue;
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
/*
10
ATATATCTGCTAGTCTTCGCCGCTACATAACGCTACTACGAATTGCAACC
TGATATCCTTCCCTTAGTTTATCATTGATATTATCACACAAAAATTTTAA
AGTACATTTCCCAAACGAATTTAATTTTCCTGTTCGCATATATCGCACAC
CCTTCTCTACTAAACCTTAGTTGCAGACCACATCTTTCTCACCATATACA
CCTATACTGCATCCCCCTAACTTCCTGATTGCCAGCCCTCTCATAATTCG
CTACCTCACTAGATCCCAGAAATCAACTCAATTCGTCCTCAAATACCCCT
ATCTCAATTTCCACTACTCCAAATCATTCAACCATCGCTAATTTTTAAAC
AATTCACTTTACTTTACCGACTAATATATAATTACGCCACGCTAATGAAC
TACCTACCCCATAAACAAGAGACTTATATAACCACTTCGCTAACACTCAC
AAAAACCCATTAGTTATAGTACCCCAATTCCTAGTCTTAACAAGTTGTTT

1
CGGATACGAATCTCG
*/
