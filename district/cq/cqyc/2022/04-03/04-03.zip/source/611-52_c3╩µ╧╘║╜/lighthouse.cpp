#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	register int x=0,f=0; register char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int stk[30],tp;
void put(int x) {
	do stk[++tp]=x%10,x/=10; while(x);
	while(tp)putchar(stk[tp--]^48);
}
int n,t,r;
int a[7500010];
signed main() {
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	for(register int i=1;i<=n;++i) a[i]=read();
	register int lst=a[1],p=0;
	for(register int i=2;i<=n;++i) {
		if(p) {
			if(a[i]-p<=r) continue;
			if(t) lst=i;
			else {put(i-1);return 0;}
			continue;
		}
		if(a[i]-lst>r) --t,p=a[--i];
	}
	put(n);
	return 0;
}

