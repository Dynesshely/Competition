#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	register int x=0,f=0;
	register char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int stk[30],tp;
void put(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
const int Maxn=2e6+10;
int T,n,q1[Maxn],q2[Maxn],q3[Maxn],q4[Maxn];
string s;
struct node {
	int l,r,d;
} a[Maxn];
bitset<Maxn> vis;
signed main() {
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	T=read();
	while(T--) {
		string o;
		s=" ",cin>>o,n=o.size(),s+=o;
		register int cnt=0,l=1,r=0,ll=1,rr=0,lll,rrr,res,p,llll,rrrr;
		for(register int i=1; i<=n; ++i) {
			vis[i]=0;
			if(s[i]=='C') q1[++r]=i;
			if(s[i]=='T') q2[++rr]=i;
			if(s[i]=='A') {
				if(l<=r) a[++cnt]=(node) {q1[l++],i},vis[a[cnt].l]=1;
				else if(ll<=rr) a[++cnt]=(node) {q2[ll++],i},vis[a[cnt].l]=1;
			}
		}
		l=1,r=0,ll=1,rr=0,lll=1,rrr=0,res=cnt,p=n,llll=1,rrrr=0;
		for(register int i=cnt,d; i; --i) {
			while(p>a[i].r) {
				if(s[p]=='T'&&!vis[p]) q1[++r]=p;
				--p;
			}
			if(l<=r||(ll<=rr&&q2[ll]>a[i].r)||(llll<=rrrr&&q4[llll]>a[i].r)) {
				if(l<=r&&(ll<=rr&&q2[ll]>a[i].r)&&(llll<=rrrr&&q4[llll]>a[i].r)) {
					if(q1[l]>q2[ll]&&q1[l]>q4[llll]) a[i].d=q1[l++];
					else if(q2[ll]>q1[l]&&q2[ll]>q4[llll]) a[i].d=q2[ll++];
					else a[i].d=q4[llll++];
				} else {
					if(l<=r&&(ll<=rr&&q2[ll]>a[i].r)) {
						if(q1[l]>q2[ll]) a[i].d=q1[l++];
						else a[i].d=q2[ll++];
					} else {
						if(l<=r&&(llll<=rrrr&&q4[llll]>a[i].r)) {
							if(q1[l]>q4[llll]) a[i].d=q1[l++];
							else a[i].d=q4[llll++];
						} else {
							if((ll<=rr&&q2[ll]>a[i].r)&&(llll<=rrrr&&q4[llll]>a[i].r)) {
								if(q2[ll]>q4[llll]) a[i].d=q2[ll++];
								else a[i].d=q4[llll++];
							}else {
								if(l<=r) a[i].d=q1[l++];
								else if((ll<=rr&&q2[ll]>a[i].r)) a[i].d=q2[ll++];
								else a[i].d=q4[llll++];
							}
						}
					}
				}
			} else {
				--res;
				if(lll<=rrr) swap(a[i].d,a[q3[lll]].d),q2[++rr]=a[q3[lll]].l,++lll;
				else if(s[a[i].l]=='T') q2[++rr]=a[i].l;
			}
			if(a[i].d&&s[a[i].l]=='T') q3[++rrr]=i;
		}
		put(res),putchar('\n');
	}
	return 0;
}

