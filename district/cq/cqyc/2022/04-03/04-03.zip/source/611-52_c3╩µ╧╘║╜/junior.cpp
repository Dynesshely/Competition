#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	register int x=0,f=0; register char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int stk[30],tp;
void put(int x) {
	do stk[++tp]=x%10,x/=10; while(x);
	while(tp)putchar(stk[tp--]^48);
}
const int Maxn=1e5+10;
int n,m,res1,res2;
int a[Maxn],b[Maxn];
signed main() {
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	n=read(),m=read();
	memset(a,0x3f,sizeof a);
	memset(b,0x3f,sizeof b);
	for(register int i=1,x;i<=n;++i) {
		for(register int j=1;j<=m;++j) {
			x=read();
			a[i]=min(a[i],x);
			b[j]=min(b[j],x);
		}
	}
	for(register int i=1;i<=n;++i) res1+=a[i];
	for(register int i=1;i<=m;++i) res2+=b[i];
	put(min(res1,res2));
	return 0;
}

