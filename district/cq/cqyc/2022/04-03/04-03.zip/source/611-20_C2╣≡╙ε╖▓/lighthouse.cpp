#include<bits/stdc++.h>
using namespace std;
#define N 100000
int n,t,r;
int x[N];
int ans[N];
int main()
{
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	scanf("%d%d%d",&n,&t,&r);
	for(int i=1;i<=n;i++)
		scanf("%d",&x[i]);
	x[0]=-1000;
	for(int i=1;i<=n;i++)
	{
		int j=i-1;
		while(x[i]-x[j]<=r)ans[i]++;
		j=i+1;
		while(x[j]-x[i]<=r)ans[i]++;
	}
	int p=0;
	for(int i=1;i<=n;i++)
		p=max(p,ans[i]);
	cout<<p;
	return 0;
}
