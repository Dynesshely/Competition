#include<bits/stdc++.h>
using namespace std;
int x[8000000];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main() {
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	int n,r,t,js=1,ans=-1,sum=1;
	n=read();t=read();r=read();
	for(int i=1; i<=n; i++) x[i]=read();
    for(int i=1;i<=n;){
    	if(x[i]+r>=x[i+1]){
    		int j=i;
    		for(;x[i+1]<=x[j]+r&&i<n;i++){
    			js++;
			}
		}
		else {	
			if(sum<t){
			    i++;sum++;js++;
			    int j=i;
			 	for(;x[i+1]<=x[j]+r&&i<n;i++){
    		    	js++;
			    }
			}
			if(sum>=t) break;
	    }
	    if(i==n) break;
	}
	write(js);
	return 0;
}
