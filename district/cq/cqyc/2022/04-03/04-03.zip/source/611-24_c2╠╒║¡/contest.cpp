#include<bits/stdc++.h>
using namespace std;
long long a[500005],b[500005];
int main(){
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout); 
	int n,q,t;
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++) scanf("%lld",&b[i]);
	long long lastans=0;
	if(n<=1000&&q<=1000){
		for(int i=1;i<=q;i++){
			long long l,r,x;
			scanf("%lld%lld%lld",&l,&r,&x);
			long long l1=l^(t*lastans),r1=r^(t*lastans),x1=x^(t*lastans);
			for(int j=l;j<=r;j++){
				if(x1>a[j]) x1+=b[j];
			}
			lastans=x1;
			printf("%lld\n",lastans);
		}
	}
}
