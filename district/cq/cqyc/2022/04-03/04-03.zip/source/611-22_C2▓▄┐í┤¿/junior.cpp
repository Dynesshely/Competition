#include<bits/stdc++.h>
using namespace std;
int n,m;
int a[1003][1003];
int b[1003][1003];
void dfs(int x,int y)
{
	
}
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int main()
{
//	freopen("junior.in","r",stdin);
//	freopen("junior.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
		{
			a[i][j]=read();
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			
		}
	cout<<114514; 
}
