#include<bits/stdc++.h>
using namespace std;
int n,t,r;
int a[7500000];
int b[7500000];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int main()
{
	//freopen("lighthouse.in","r",stdin);
	//freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	int x;
	for(int i=1;i<=n;++i) x=read(),a[x]=1;
	int sum=1,ans=0; 
	for(int i=1;i<n;++i)
	{
		sum=0;
		int z=i-r;
		if(i-r<0) z=0;
		for(int j=z;j<=i+r;j++) 
			if(a[j]!=0) sum++;
		ans=max(sum,ans);
	}
	printf("%d",sum);
}
