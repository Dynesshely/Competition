#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
const int mod = 1e9+7; 
int n,m;
int q_pow(int x,int k){
	if(k==0) return 1;
	if(k==1) return x;
	int l = q_pow(x,k/2);
	l = (l*l)%mod;
	if(k&1) return (l*x)%mod;
	return l;
}
signed main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n = read(),m = read();
	printf("%lld",q_pow(q_pow(2,n+1),m)%mod*(n*8*2+1)%mod);
	return 0;
}

