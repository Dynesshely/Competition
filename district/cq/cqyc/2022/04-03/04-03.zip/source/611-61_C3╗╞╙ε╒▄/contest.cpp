#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
const int MAX =5e5+10;
int n,q,t,l,r,x,lat;
int a[MAX],b[MAX];
signed main(){
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	n = read(),q = read(),t = read();
	for(int i = 1;i<=n;i++) a[i] = read();
	for(int i = 1;i<=n;i++) b[i] = read();
	while(q--){
		l = read()^(t*lat),r = read()^(t*lat),x = read()^(t*lat);
		for(int i = l;i<=r;i++) if(x>a[i]) x+=b[i];
		printf("%lld\n",lat=x);
	}
	return 0;
}

