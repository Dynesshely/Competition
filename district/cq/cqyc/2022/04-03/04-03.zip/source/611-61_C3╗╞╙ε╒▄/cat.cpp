#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
const int MAX = 1e6+10;
struct node{
	int x,y;
}t[MAX];
int T,n,ans,l1,l2,l3,l4,l5,l6;
int q1[MAX],q2[MAX];
bool vis[MAX],vis1[MAX];
char a[MAX],b[MAX];
void init(){
	for(int i = 0;i<n;i++) vis[i]=0;
	scanf("%s",b);
	ans = 0,l1 = 1,l2 = 0,l3 = 0,l4 = 1,n = strlen(b);
	for(int i = n-1;i>=0;i--) a[n-i-1]=b[i];
	return; 
}
signed main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	T = read();
	while(T--){
		init();
		for(int i = 0;i<n;i++){
			if(a[i]=='A' and l2>=l1) t[++l3]=(node){i,q1[l1]},vis[q1[l1]]=1,l1++;
			if(a[i]=='T') q1[++l2]=i;
		}
//		for(int i = 0;i<n;i++){
//			if(vis[i]) continue;
//			if((a[i]=='T' or a[i]=='C') and l4<=l3 and t[l4].x<i) vis[i]=1,ans++,l4++;
//		}
		for(int i = 0;i<n;i++){
			if(vis[i]) continue;
			if((a[i]=='T' or a[i]=='C') and l4<=l3 and t[l4].x<i) vis[i]=1,ans++,l4++;
		}
		l5 = l4+1;
		for(int i = l4;i<=l3;i++){
//			cout<<t[i].y<<" "<<t[i].x<<endl;
			if(t[i].y==-1) continue;
			while(l5<=l3){
				if(t[l5].y>t[i].x) {
					ans++,t[l5].y=-1,l5++;
					break;
				}
				l5++;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}

