#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f; 
} 
const int MAX = 8e6+10,inf = 2e9;
int n,t,r,ans,l=1,p;
int a[MAX];
signed main(){
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n = read(),t = read(),r = read();
	for(int i = 1;i<=n;i++) a[i] = read();
	p = a[1];
	for(int i = 1;i<=t;i++){
		while(l<=n and a[l]<=p+r) l++;
		l--,p=a[l]+r;
		if(l==n) break;
	}
	for(int i = 1;i<=n;i++)
		if(a[i]<=p) ans++;
		else break;
	printf("%d",ans);
	return 0;
}
