#include <bits/stdc++.h>
#define NNN 7500003
using namespace std;
inline int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x;
}
int n,t,r,x[NNN],go[NNN],dist[NNN],ans;
int main(){
	freopen("lighthouse.in","r",stdin); 
	freopen("lighthouse.out","w",stdout); 
	n=read();t=read();r=read();
	for(int i=1;i<=n;i++){x[i]=read();}
	for(int i=1;i<n;i++){dist[i]=x[i+1]-x[i];}
	int adder=0;ans=1;
	for(;ans<=n;){
		while(adder<=r){
//			cout << adder << ' ' << ans << ' ' << dist[ans] << endl;
			adder+=dist[ans];
			ans++;
			if(ans>n) break;
		}
		ans--;
		if(ans>n) break;
		t--;
//		cout << "TAT\n" << t << endl;
		adder=0;
		if(t<0) break;
	}
	if(ans>=n) ans=n;
	printf("%d",ans);
	return 0;
}
