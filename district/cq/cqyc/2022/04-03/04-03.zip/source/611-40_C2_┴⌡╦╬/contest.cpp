#include <bits/stdc++.h>
using namespace std;
int n,q,l,r,t;
long long x,a[500003],b[500003];
int main(){
	freopen("contest.in","r",stdin); 
	freopen("contest.out","w",stdout); 
	scanf("%d%d%d",&n,&q,&t);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++) scanf("%lld",&b[i]);
	for(;q;q--){
		scanf("%d%d%lld",&l,&r,&x);
		for(int i=l;i<=r;i++){
			if(x>a[i]) x+=b[i];
		}
		printf("%lld\n",x);
	}
	return 0;
}
