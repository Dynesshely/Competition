#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
using namespace std;
const int N=7.5e6+5;
int n,t,r,lst,now,tot,ans,x[N],rt[N];
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x; 
}
inline void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
int main() {
	/*Ϊʲô����������QAQAQAQAQAQ*/
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=_(),t=_(),r=_(),lst=1;
	for(int i=1;i<=n;++i) {
		x[i]=_();
		while(x[i]-x[lst]>r) {
			rt[lst]=i-1;
//			lt[i-1]=lst;
			++lst;
		} 
	}
	while(lst<=n) rt[lst++]=n;
//	for(int i=1;i<=n;++i) pt("%d ",rt[i]);
//	pc('\n');
	now=0;
	for(int i=1;i<=n&&i;) {
		if(now) {
//			printf("%d ",i);
			--t;
			if(!t) {
				ans=rt[i];
				break;
			}
		}
		//�����ˣ��������У� 
		if(now) i=rt[i]+1;
		else i=rt[i];
		now^=1;
	}
	__(ans);
	return 0;
} 
//8:15~8:50 
