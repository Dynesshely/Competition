#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define it __int128
using namespace std;
const int N=5e5+5;
int n,q,t,a[N],b[N];
inline it _() {
	it x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x; 
}
inline void __(it x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
signed main() {
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
//	freopen("ex_contest2.in","r",stdin);
//	freopen("ex_contest2.out","w",stdout);
	n=_(),q=_(),t=_();
	for(int i=1;i<=n;++i) a[i]=_();
	for(int i=1;i<=n;++i) b[i]=_();
	it lst=0;
	for(int i=1;i<=q;++i) {
		int l=_()^lst,r=_()^lst;
		it x=_()^lst;
//		__(l),pc(' '),__(r),pc(' '),__(x),pc('\n');
		for(int j=l;j<=r;++j) 
			if(x>a[j]) x+=b[j];
		__(x),pc('\n');
		lst=t?x:0;
	}
	return 0;
} 
//9:30~10:10
