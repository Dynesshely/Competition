#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
#define pb push_back
#define ll long long
using namespace std;
const int N=1e5+5;
int n,m;
ll sum,ans;
vector<int> a[N],vis[N];
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x; 
}
inline void __(ll x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void Column(int x) {
	if(sum>ans) return ;
	if(x==m) {ans=min(ans,sum);return ;}
	for(int i=1;i<=n;++i) {
		if(!vis[i][x]) {
			vis[i][x]=1;
			sum+=a[i][x];
			Column(x+1);
			sum-=a[i][x];
			vis[i][x]=0;
		}
	}
}
void Line(int x) {
	if(sum>ans) return ;
	if(x>n) {Column(0);return ;}
	for(int i=0;i<m;++i) {
		if(!vis[x][i]) {
			vis[x][i]=1;
			sum+=a[x][i];
			Line(x+1);
			sum-=a[x][i];
			vis[x][i]=0;
		}
	}
}
int main() {
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	n=_(),m=_(),ans=1e18;
	for(int i=1;i<=n;++i) {
		for(int j=1;j<=m;++j) {
			a[i].pb(_());
			vis[i].pb(0);
		}
	}
	Line(1);
	__(ans);
	return 0;
} 
//10:20~10:40
