#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt printf
using namespace std;
const int N=1005;
int T,n,ans,sum,vis[N];
int ct,hd[N],nt[N*N],to[N*N];
char s[N];
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x; 
}
inline void __(int x) {
	int stk[30],tp=0;
	if(x<0) x=-x,pc('-');
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void DFS(int x) {
//	printf("x=%d vis=%d sum=%d\n",x,vis[x],sum);
	if(x>n) {ans=max(ans,sum);return ;}
	if(vis[x]||x==n||s[x]=='A') DFS(x+1);
	else {
		for(int u,i=hd[x];i;i=nt[i]) {//ѡx 
			if(!vis[u=to[i]]) {
				for(int v,j=hd[u];j;j=nt[j]) {
					if(!vis[v=to[j]]) {
//						pt("Found<%d %d %d> with sum:%d\n",
//						x,u,v,sum);
						vis[x]=vis[u]=vis[v]=1;
						++sum;
						DFS(x+1);
						--sum;
						vis[x]=vis[u]=vis[v]=0;
					}
				}
			}
		}
		DFS(x+1);//��ѡx 
	}
}
inline void Merge(int x,int y) {
	nt[++ct]=hd[x],to[ct]=y,hd[x]=ct;
}
inline void Init() {
	memset(hd,0,sizeof(hd));
	memset(vis,0,sizeof(vis));
	ct=0;sum=0;ans=0;
}
int main() {
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	T=_();
	while(T--) {
		Init();
		scanf("%s",s+1);
		n=strlen(s+1);
//		pt("n=%d\n",n);
		for(int i=1;i<=n;++i) {
			if(s[i]!='C'&&s[i]!='A'&&s[i]!='T') {
				vis[i]=1;continue;
			}
			char fc=s[i]=='C'||s[i]=='T'?'A':'T';
			for(int j=i+1;j<=n;++j) {
				if(s[j]==fc) Merge(i,j);
			}
		}
//		pt("ct=%d\n",ct);
		DFS(1);
		__(ans),pc('\n');
	}
	return 0;
} 
/*
1
CATAT
*/
//8:50~9:10
//10:40~11:30
