#include<bits/stdc++.h>
using namespace std;
int n,t,r,x[8000007];
int las=1,now=1,q[8000007],h[8000007];
int main()
{
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	scanf("%d %d %d",&n,&t,&r);
	for(int i=1;i<=n;i++)	scanf("%d",&x[i]);
	for(int li=1,ri=1;li<=n&&ri<=n;ri++)
	{
		while(x[ri]-x[li]>r) li++;
		q[ri]=li;
	}
	for(int li=n,ri=n;li>=1&&ri>=1;li--)
	{
		while(x[ri]-x[li]>r) ri--;
		h[li]=ri;
	}
	for(int i=1;i<=t&&las<=n;i++)
	{
		while(now<n&&q[now+1]<=las) now++;
		las=h[now]+1,now=las; 
	}
	printf("%d",min(n,las-1));
	return 0;
 } 
