#include<bits/stdc++.h>
using namespace std;
int n,q,t,l,r;
long long x,las=0;
long long a[500007],b[500007];
int main()
{
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	scanf("%d %d %d",&n,&q,&t);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++) scanf("%lld",&b[i]);
	for(int i=1;i<=q;i++)
	{
		scanf("%d %d %lld",&l,&r,&x);
		l=l|(t*las),r=r|(t*las),x=x|(t*las);
	//	cout<<l<<" "<<r<<" "<<x<<endl;
		for(int j=l;j<=r;j++)	if(x>a[j]) x+=b[j];
		printf("%lld\n",x),las=x;
	}
	
	return 0;
 } 
