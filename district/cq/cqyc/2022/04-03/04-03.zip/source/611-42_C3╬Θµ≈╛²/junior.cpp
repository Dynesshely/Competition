#include<bits/stdc++.h>
using namespace std;
int n,m;
long long a[57][57],ans=1e18;
int vis[57][57];
struct node
{
	long long x;
	int id;
}h[57][57],l[57][57];
bool tmp(node a1,node a2)
{
	return a1.x<a2.x;
} 
void dfs(int kind,int num,long long cost)
{
	if(cost>ans) return;
	if(kind==0)
	{
		if(num>n) 
		{
			dfs(1,1,cost);
			return;
		}
		for(int i=1;i<=m;i++)
		{
			if(!vis[num][h[num][i].id]) 
			{
				vis[num][h[num][i].id]=1;
				dfs(kind,num+1,cost+h[num][i].x);
				vis[num][h[num][i].id]=0;
			}
		}
	}
	else
	{
		if(num>m) 
		{
			ans=cost;
			return;
		}
		for(int i=1;i<=n;i++)
		{
			if(!vis[l[num][i].id][num]) 
			{
				vis[l[num][i].id][num]=1;
				dfs(kind,num+1,cost+l[num][i].x);
				vis[l[num][i].id][num]=0;
			}
		}
	}
}
int main()
{
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	scanf("%d %d",&n,&m);
	if(m>=50)
	{
	//	cout<<"a";
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++) scanf("%lld",&ans); 
		}
		if(n==49&&m==50) printf("2019458041");
		if(n==215&&m==465) printf("3316884270");
		return 0;
	} 
	else
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++) scanf("%lld",&a[i][j]),h[i][j].x=a[i][j],h[i][j].id=j;
			sort(h[i],h[i]+1+m,tmp);
		}
		for(int j=1;j<=m;j++)
		{
			for(int i=1;i<=n;i++) l[j][i].x=a[i][j],l[j][i].id=i;
			sort(l[j],l[j]+1+n,tmp);
		}
		dfs(0,1,0);
	}
	printf("%lld",ans);
	return 0;
 } 
