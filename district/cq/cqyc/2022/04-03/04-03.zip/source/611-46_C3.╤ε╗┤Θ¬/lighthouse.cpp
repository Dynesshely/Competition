#include<bits/stdc++.h>
using namespace std;
int n,t,r,t1,x[2],ans;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	if(t==0){
		printf("0");
		return 0;
	}
	x[1]=read();
	for(int i=2;i<=n;i++){
		x[i&1]=read();
		if(x[i&1]-x[(i&1)^1]>r) ans++;
		if(ans==t){
			printf("%d",i-1);
			return 0;
		}
	}
	printf("%d",n);
	return 0;
}
