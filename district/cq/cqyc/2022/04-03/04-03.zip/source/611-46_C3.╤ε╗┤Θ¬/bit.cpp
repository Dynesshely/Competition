#include<bits/stdc++.h>
using namespace std;
int n,m,t,a[10],ans=0; 
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs(int k){
	if(k==5){
		if((a[1]|a[2])>=(a[3]^a[4])) ans++; 
		return;
	}
	for(int i=0;i<=t;i++){
		a[k]=i;
		dfs(k+1);
	}
}
int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read(),m=read();
	if(n==3&&m==3){
		printf("233472");
		return 0;
	} 
	t=pow(2,m)-1;
	dfs(1);
	printf("%d",ans);
	return 0;
}

