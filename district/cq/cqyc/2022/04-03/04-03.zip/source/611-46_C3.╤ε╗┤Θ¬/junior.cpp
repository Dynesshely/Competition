#include<bits/stdc++.h>
using namespace std;
long long n,m,a[100005],ans=1e18,cnt=0,tt;
vector<int> t1[100005],t2[100005];
bitset<1000005> v;
bool cmp(int x,int y){
	return a[x]<a[y];
}
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
long long js(long long x,long long y) {return (x-1)*m+y;}
void dfs(long long k,long long g){
	cnt++;
	if(cnt>=185000000) return;
	if(g>=ans) return;
	if(k==(n+m+1)){
		ans=min(ans,g);
		tt=cnt;
		return;
	}
	if(k<=n){
		for(long long i=0;i<(int)t1[k].size();i++){
			if(v[t1[k][i]]) continue;
			v[t1[k][i]]=1;
			dfs(k+1,g+a[t1[k][i]]);
			v[t1[k][i]]=0;
		}
	}
	else{
		for(long long i=0;i<(int)t2[k-n].size();i++){
			if(v[t2[k-n][i]]) continue;
			v[t2[k-n][i]]=1;
			dfs(k+1,g+a[t2[k-n][i]]);
			v[t2[k-n][i]]=0;
		}
	}
}
signed main(){
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	n=read(),m=read();
	for(long long i=1;i<=n;i++){
		for(long long j=1;j<=m;j++){
			a[js(i,j)]=read();
			t1[i].push_back(js(i,j));
			t2[j].push_back(js(i,j));
		} 
	}
	for(long long i=1;i<=n;i++) sort(t1[i].begin(),t1[i].end(),cmp);
	for(long long i=1;i<=m;i++) sort(t2[i].begin(),t2[i].end(),cmp);
	dfs(1,0);
	printf("%lld",ans);
	return 0;
}

