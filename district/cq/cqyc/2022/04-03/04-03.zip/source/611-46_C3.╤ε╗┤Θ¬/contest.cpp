#include<bits/stdc++.h>
using namespace std;
long long n,q,t,a[500005],b[500005],t1,t2,t3,ans;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
long long stk[20],tp;
void write(long long x){
	if(x<0) x=-x,putchar('-'); 
do stk[++tp]=x%10,x/=10;while(x);
while(tp)putchar(stk[tp--]^48);
}
signed main(){
	freopen("contest.in","r",stdin);
	freopen("contest.out","w",stdout);
	n=read(),q=read(),t=read();
	for(long long i=1;i<=n;i++) a[i]=read();
	for(long long i=1;i<=n;i++) b[i]=read();
	for(long long i=1;i<=q;i++){
		t1=read()^(t*ans);
		t2=read()^(t*ans);
		t3=read()^(t*ans);
		for(long long j=t1;j<=t2;j++) if(t3>a[j]) t3+=b[j];
		write(t3);
		putchar('\n');
		ans=t3;
	}
	return 0;
}

