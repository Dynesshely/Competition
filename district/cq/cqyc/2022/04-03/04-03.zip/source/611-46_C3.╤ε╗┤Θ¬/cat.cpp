#include<bits/stdc++.h>
using namespace std;
int T,sz,ans,t,tt,ttt,cnt;
char s[1000005];
vector<int> q1,q2,w;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[10],tp;
inline void write(int x){
do stk[++tp]=x%10,x/=10;while(x);
while(tp)putchar(stk[tp--]^48);
}

int main(){
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	T=read();
	for(int i=1;i<=T;i++){
		scanf("%s",s+1);
		sz=strlen(s+1);
		ans=cnt=0;
		for(int j=sz;j>=1;j--){
			if(s[j]=='T') q1.push_back(j);
			if(s[j]=='A'&&q2.size()<q1.size()) q2.push_back(j);
		}
		while(q1.size()>q2.size()) q1.pop_back();
		t=tt=q2.size()-1;ttt=0;
		if(t<0){
			putchar('0');
			putchar('\n');
			continue;
		}
		for(int j=1;j<=sz;j++){
			if(j==q2[t]){
				if(cnt){
					cnt--;ans++;t--;
					q2.pop_back();
					if(t<0) break; 
				}
				else{
					w.push_back(t);t--;
					q2.pop_back();
					if(t<0) break;
				}
			}
			else if(j==q1[tt]){
				if((int)w.size()>ttt&&tt==w[ttt]){
					cnt++;ttt++;
				}
				tt--;
				q1.pop_back();
			}
			else if(s[j]=='C'||s[j]=='T') cnt++;
		}
		while(q1.size()) q1.pop_back();
		while(q2.size()) q2.pop_back();
		while(w.size()) w.pop_back();
		write(ans);
		putchar('\n');
	}
	return 0;
}

