#include<bits/stdc++.h>
using namespace std;
int t,sum,num,ans,wz,wzz;
string a;
bool pd=false,jl[1000005],pdd,jll,jlll,h;
inline int read()
	{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
int stk[30],tp;
void write(int x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}
int main()
	{
	freopen("cat.in","r",stdin);
	freopen("cat.out","w",stdout);
	t=read();
	while(t--)
	{
		ans=0;
		memset(jl,0,sizeof(jl));
		cin>>a;
		for(int i=a.size()-1;i>=0;--i)
		{
			jll=false;
			jlll=false;
			pdd=false;
			pd=false;
			if(a[i]=='T'&&jl[i]==false)
			{
				jl[i]=true;
				for(int j=i-1;j>=0;--j)
				{
					if(a[j]=='A'&&jl[j]==false)
					{
						wz=j;
						jl[j]=true;
						pd=true;
						break;
					}
				}
				if(pd==true)
				{
					for(int j=wz-1;j>=0;--j)
					{
						if(a[j]=='C'&&jl[j]==false&&jll==false)
						{
							pdd=true;
							jll=true;
							jl[j]=true;
						}
						if(a[j]=='T'&&jl[j]==false&&jlll==false)
						{
							pdd=true;
							jlll=true;
							wzz=j;
							jl[j]=true;
						}
					}
					if(jll==true&&jlll==true)
					jl[wzz]=false;
					if(pdd==true)
					ans++;
					if(pdd==false)
					jl[wz]=false,jl[i]=false;
				}
				else
				jl[i]=false;
			}
		}
		write(ans);
		printf("\n");
	}
	return 0;
	}
