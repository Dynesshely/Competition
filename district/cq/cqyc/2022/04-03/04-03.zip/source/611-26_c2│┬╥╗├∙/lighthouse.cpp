#include<bits/stdc++.h>
using namespace std;
int n,t,r,x[7500005],num,ans;
inline int read()
	{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
int stk[30],tp;
void write(int x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}
void dfs(int wz,int zb,int sum)
	{
	ans=wz;
	if(sum==t||wz>=n)
		return;
	for(int i=wz; i<=n; ++i)
		{
			if(x[i+1]-zb>r)
			{
				for(int j=i+1;j<=n;++j)
				{
					ans=j;
					if(x[j]-x[i]>r)
					dfs(j-1,x[j],sum+1);
				}
			}
		}
	}
int main()
	{
	freopen("lighthouse.in","r",stdin);
	freopen("lighthouse.out","w",stdout);
	n=read(),t=read(),r=read();
	for(int i=1; i<=n; ++i)
		x[i]=read();
	dfs(1,x[1],0);
	write(ans);
	return 0;
	}
