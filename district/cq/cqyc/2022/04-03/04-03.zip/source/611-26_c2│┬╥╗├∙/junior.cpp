#include<bits/stdc++.h>
using namespace std;
long long n,m,ans,a,minn_h[100005],minn_l[100005];
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
long long stk[30],tp;
void write(long long x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}
int main()
	{
	freopen("junior.in","r",stdin);
	freopen("junior.out","w",stdout);
	n=read(),m=read();
	memset(minn_h,0x3f3f3f3f,sizeof(minn_h));
	memset(minn_l,0x3f3f3f3f,sizeof(minn_l));
	for(int i=1;i<=n;++i)
	for(int j=1;j<=m;++j)
	{
		a=read();
		minn_h[i]=min(minn_h[i],a);
		minn_l[j]=min(minn_l[j],a);
	}
	for(int i=1;i<=n;++i)
	ans+=minn_h[i];
	for(int i=1;i<=m;++i)
	ans+=minn_l[i];
	write(ans);
	return 0;
	}
