#include <bits/stdc++.h>
using namespace std;
int n, m, a[55][55], vis[55][55], pd[55][55];
long long ans=100000000000000000LL;
inline int read() {
	int x=0,f=1; char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
void write(long long x) {
	int stk[30],tp=0;
	do stk[++tp]=x%10, x/=10;while(x);
	while(tp) putchar(stk[tp--]^48);
	putchar('\n');
}
void dfs(int l, int h, long long s) {
	if(s >= ans) return ;
	if(l == m && h == n) {
		ans=min(ans, s);
		return ;
	}
	if(l != m){
		for(int i = 1; i <= m; ++i)
			if(!vis[i][l+1])
				vis[i][l+1]=1, dfs(l+1, h, s+a[i][l+1]), vis[i][l+1]=0;
	}
	if(h != n) {
		for(int i = 1; i <= n; ++i)
			if(!vis[h+1][i])
				vis[h+1][i]=1, dfs(l, h+1, s+a[h+1][i]), vis[h+1][i]=0;
	}
}
int main() {
	freopen("junior.in", "r", stdin);
	freopen("junior.out", "w", stdout);
	n = read(), m = read();
	if(n >= 50 && m >= 50) return 0;
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j)
			a[i][j]=read();
	dfs(0, 0, 0);
	write(ans);
	return 0;
} 
