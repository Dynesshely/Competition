#include <bits/stdc++.h>
using namespace std;
int T, len, ans, nxt, nnxt, vis[1000005], pd[1000005], cnt;
char miao[1000005], spcl[1000005];
inline int read() {
	int x=0,f=1; char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
void write(int x) {
	int stk[30],tp=0;
	do stk[++tp]=x%10, x/=10;while(x);
	while(tp) putchar(stk[tp--]^48);
	putchar('\n');
}
int main() {
	freopen("cat.in", "r", stdin);
	freopen("cat.out", "w", stdout);
	T = read();
	while(T--) {
		ans=0;
		scanf("%s", miao+1);
		len=strlen(miao+1);
		for(int i = 1; i <= len; ++i)
			vis[i]=pd[i]=0;
		for(int i = 1; i <= len; ++i)
			if(miao[i] == 'C') {//����CAT 
				nxt=nnxt=0;
				for(int j = i+1; j <= len; ++j)
					if(miao[j] == 'A' && vis[j] == 0) {
						nxt=j;
						break;
					}
				if(nxt == 0) continue;
				for(int j = nxt+1; j <= len; ++j)
					if(miao[j] == 'T' && vis[j] == 0) {
						nnxt=j;
						break;
					}
				if(nnxt == 0 || nxt > nnxt) continue;
				++ans, vis[i]=vis[nxt]=vis[nnxt]=1;
//				cout<<i<<" "<<nxt<<" "<<nnxt<<"\n";
			}
		cnt=0;
		for(int i = 1; i <= len; ++i)//����TAT
			if((miao[i] == 'T' || miao[i] == 'A') && vis[i] == 0)
				spcl[++cnt]=miao[i];
		int sum = 0;
		for(int i = cnt; i >= 1; --i) {
			if(spcl[i] == 'T' && pd[i] == 0)
				++sum;
			if(spcl[i] == 'A' && sum) {
				nnxt=0;
				for(int j = i-1; j >= 1; --j)
					if(!pd[j] && spcl[j] == 'T') {
						nnxt=j;
						break;
					}
				if(!nnxt) continue;
				++ans, vis[nnxt]=1, --sum;
			}
		}
		write(ans);
	}
	return 0;
} 
