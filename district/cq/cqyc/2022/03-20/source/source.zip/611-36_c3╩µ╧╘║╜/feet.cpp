#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0; char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int Maxn=1e5+10;
int n,res; 
int a[Maxn],b[Maxn],x[Maxn],y[Maxn];
signed main() {
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;++i) a[i]=read(),b[i]=read(),++x[a[i]],++y[b[i]];
	for(register int i=1;i<=n;++i) res+=(x[a[i]]-1)*(y[b[i]]-1);
	put(res);
	return 0;
}

