#include<bits/stdc++.h>
using namespace std;
const int Maxn=2010;
int w,s,n; 
int a[Maxn],id[Maxn];
double t[Maxn],res=1e9;
struct node {int v; double t;}b[Maxn];
bool cp(node x,node y) {return x.t>y.t;}
bool cmp1(int x,int y) {return t[x]<t[y];}
bool cmp2(int x,int y) {return a[x]>a[y];}
double solve() {
	double ans=0;
	int W=0,cnt=0;
	for(register int i=1;i<=n;++i) {
		if(W+a[id[i]]<=w) W+=a[id[i]],b[++cnt]=(node) {a[id[i]],t[id[i]]};
		else {
			sort(b+1,b+cnt+1,cp),ans+=b[cnt].t;
			for(register int j=1;j<=cnt;++j) b[j].t-=b[cnt].t;
			while(cnt&&b[cnt].t==0) W-=b[cnt].v,--cnt;
		}
	} 
	if(cnt) sort(b+1,b+cnt+1,cp),ans+=b[1].t;
	return ans;
}
signed main() {
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	cin>>w>>s>>n;
	for(register int i=1;i<=n;++i) cin>>a[i]>>t[i],t[i]=s/t[i],id[i]=i;
	sort(id+1,id+n+1,cmp1),res=min(res,solve());
	sort(id+1,id+n+1,cmp2),res=min(res,solve());
	printf("%.2f",res); 
	return 0;
}

