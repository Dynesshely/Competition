#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x=0,f=0; char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int Maxn=2e5+10;
int n,m;
int c[Maxn],v[Maxn],cnt[Maxn],ma[Maxn];
signed main() {
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n=read(),m=read();
	register int op,s,k;
	register long long res;
	for(register int i=1;i<=n;++i) c[i]=read(),v[i]=read();
	while(m--) {
		op=read(),s=read(),k=read(),res=0;
		if(op==1) c[s]=k,v[s]=read();
		else{
			for(register int i=s;i<=n;++i) {
				k-=(cnt[c[i]]>0);if(k<0) break; ++cnt[c[i]];
				res-=ma[c[i]],ma[c[i]]=max(ma[c[i]],v[i]),res+=ma[c[i]];
			} 
			for(register int i=s;i<=n;++i) cnt[c[i]]=ma[c[i]]=0;
			put(res),putchar('\n');
		}
	}
	return 0;
}

