#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0; char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int mod=10007;
int q,x,a[5010],k;
int Pow(int x,int y) {
	int res=1;
	for(;y;y>>=1) {if(y&1) res=(res*x)%mod;x=x*x%mod;}
	return res;
}
signed main() {
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	q=read(),x=read();
	for(register int i=1;i<=5002;++i) a[i]=(a[i-1]*2+2)%mod;
	while(q--) k=read(),put((x*Pow(2,k)+a[k%5003])%mod),putchar(' ');
	return 0;
}
