#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int x=0,f=0; char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
int n,m,res;
int a,b,c,d;
int head[110],nxt[6010],to[6010],w[6010],cnt=1;
int dis[110][110];
int lj[100000][110],_lj[100000][110],tot,_tot;
int cot[100000],_cot[100000],l[110],cl;

void add(int u,int v,int orz) {
	to[++cnt]=v,w[cnt]=orz,nxt[cnt]=head[u],head[u]=cnt;
}
void dfs(int x) {
	if(x==b) {
		cot[++tot]=cl;
		for(register int i=1;i<=cl;++i) lj[tot][i]=l[i];
		return;
	} 
	for(register int i=head[x];i;i=nxt[i]) {
		int v=to[i],orz=w[i];
		if(dis[a][x]+orz==dis[a][v]&&dis[a][v]<=dis[a][b]) {
			l[++cl]=v|1,dfs(v),--cl;
		}
	}
}
void _dfs(int x) {
	if(x==d) {
		_cot[++_tot]=cl;
		for(register int i=1;i<=cl;++i) _lj[_tot][i]=l[i];
		return;
	} 
	for(register int i=head[x];i;i=nxt[i]) {
		int v=to[i],orz=w[i];
		if(dis[c][x]+orz==dis[c][v]&&dis[c][v]<=dis[c][d]) l[++cl]=i|1,dfs(v),--cl;
	}
}
signed main() {
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	n=read(),m=read();
	a=read(),b=read(),c=read(),d=read();
	memset(dis,0x3f,sizeof dis);
	for(register int i=1;i<=n;++i) dis[i][i]=0;
	for(register int i=1;i<=m;++i) {
		int u=read(),v=read(),w=read();
		add(u,v,w),add(v,u,w),dis[u][v]=dis[v][u]=w;
	}
	for(register int k=1;k<=n;++k) 
		for(register int i=1;i<=n;++i) 
			for(register int j=1;j<=n;++j) 
				dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
	cl=0,dfs(a);
	cl=0,_dfs(b);
	for(register int i=1;i<=tot;++i) {
		for(register int j=1;j<=_tot;++j) {
			register int p=1,_p=1,ans=0;
			sort(lj[i]+1,lj[i]+cot[i]+1);
			sort(_lj[j]+1,_lj[j]+_cot[j]+1);
			while(p<=cot[i]&&_p<=_cot[j]) {
				if(lj[i][p]>_lj[j][_p]) {++_p;continue;}
				if(lj[i][p]<_lj[j][_p]) {++p;continue;}
				if(lj[i][p]==_lj[j][_p]) {ans+=w[lj[i][p]],++_p,++p;continue;}
			}
			res=max(res,ans);
		}
	}
	put(res);
	return 0;
}

