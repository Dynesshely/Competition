#include <bits/stdc++.h>
#define NN 100003
#define ll long long
using namespace std;
int n,xxxx,yyyy,mxx;
struct node{
	int x,y;
}p[NN],a[NN],b[NN];
bool cmp1(const node &xxx,const node &yyy){
	if(xxx.x!=yyy.x) return xxx.x<yyy.x;
	return xxx.y<yyy.y;
}
bool cmp2(const node &xxx,const node &yyy){
	if(xxx.y!=yyy.y) return xxx.y<yyy.y;
	return xxx.x<yyy.x;
}
vector<int> vx[NN],vy[NN];
ll ans;
ll play(int gx){
	ll ret=0;int len=vx[gx].size(),u,llen;
//	cout << "GGG" << endl;
//	cout << len << endl;
	for(int i=0;i<len;i++){
		u=vx[gx][i];llen=vy[a[u].y].size();
//		cout << i << ' ' << u << ' ' << llen << endl;
//		cout << a[u].x <<' '<<a[u].y<<endl;
		ret+=1ll*(llen-1)*(len-1);
	}
//	cout << "##" << ret << endl;
	return ret;
}
int main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&xxxx,&yyyy);
		p[i].x=a[i].x=b[i].x=xxxx;
		p[i].y=a[i].y=b[i].y=yyyy;
		mxx=max(mxx,xxxx);
	}
	sort(a+1,a+n+1,cmp1);
	sort(b+1,b+n+1,cmp2);
	for(int i=1;i<=n;i++){
		vx[a[i].x].push_back(i);
		vy[b[i].y].push_back(i);
	}
	for(int i=1;i<=mxx;i++){
		if(vx[i].size()>1){
//			cout << i << ' ' << ans << endl;
			ans+=play(i);
//			cout << ans << endl << endl;
		}
	}
	cout << ans;
	return 0;
}
