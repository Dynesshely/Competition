#include <bits/stdc++.h>
#define ll long long
#define mod 10007
using namespace std;
ll q,x,n;
ll qpow(ll di,ll zhi){
	ll ret=1;
	for(;zhi;zhi>>=1){
		if(zhi&1) ret=ret*di%mod;
		di=di*di%mod;
	}
	return ret;
}
ll calc(){
	ll r=qpow(2,n)%mod;
	return (x%mod*r%mod+r*2%mod-2+mod)%mod;
}
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%lld%lld",&q,&x);
	for(;q;q--){
		scanf("%lld",&n);
		printf("%lld ",calc());
	}
	return 0;
}
