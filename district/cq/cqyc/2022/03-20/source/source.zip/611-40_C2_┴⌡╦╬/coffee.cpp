#include <bits/stdc++.h>
#define NN 2003
using namespace std;
int W,S,n,w[NN],sumw[NN],g[NN][NN][2];
double v[NN],ans=1073741819.00,f[NN][NN];
int main(){
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d%d%d",&W,&S,&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&w[i]);cin >> v[i];
		v[i]=S/v[i];
		sumw[i]=sumw[i-1]+w[i];
		for(int j=1;j<=n;j++) f[i][j]=1073741819.00;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
//			printf("##ij:%d %d\n",i,j);
			if(i==1) g[0][j][0]=1;
			if(sumw[i]-sumw[g[i-1][j][0]-1]<=W){
//				printf("P1 %d %d %d\n",sumw[i],g[i-1][j][0],sumw[g[i-1][j][0]-1]);
				if(max(f[i-1][j],v[i])<f[i][j]){
//					printf("OK ");cout << f[i-1][j]<<' '<<v[i]<<' '<<f[i][j]<<endl;
					f[i][j]=max(f[i-1][j],v[i]);
					g[i][j][0]=g[i-1][j][0];
					g[i][j][1]=i;
				}
			}
			if(j>1){
//				printf("P2\n");
				if(f[i-1][j-1]+v[i]<f[i][j]){
//					printf("OK ");cout << f[i-1][j-1]<<' '<<v[i]<<' '<<f[i][j]<<endl;
					f[i][j]=f[i-1][j-1]+v[i];
					g[i][j][0]=g[i][j][1]=i;
				}
			}
		}
	}
//	puts("qwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuiop");
	for(int j=1;j<=n;j++) ans=min(ans,f[n][j]);
	cout << fixed << setprecision(2) << ans;
	return 0;
}
