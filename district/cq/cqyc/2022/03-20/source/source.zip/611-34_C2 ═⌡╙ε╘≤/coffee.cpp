#include<bits/stdc++.h>
using namespace std;
const int maxn=2010;
int n,w;
double m[maxn][maxn][2],s,min_v,max_v,dp[maxn],ans;
struct people {
	int v;
	double h;
} f[maxn];
int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) if(ch=='-') f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
int main() {
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	w=read();
	cin>>s;
	n=read();
	for(int i=1; i<=n; i++) {
		f[i].v=read();
		cin>>f[i].h;
	}
	for(int i=1; i<=n; i++) {
		min_v=1e9,max_v=0;
		for(int j=i; j<=n; j++) {
			max_v+=f[j].v;
			min_v=min(min_v,f[j].h);
			m[i][j][0]=min_v,m[i][j][1]=max_v;
		}
	}
	for(int i=1; i<=n; i++)	for(int j=i; j<=n; j++) dp[j]=1e8;
	for(int i=1; i<=n; i++) {
		for(int j=i; j<=n; j++) {
			if(m[i][j][1]<=w) dp[j]=min(dp[j],dp[i-1]+(double)(s/m[i][j][0]));
		}
	}
	ans=dp[n];
	printf("%.2lf ",ans);
	return 0;
}
