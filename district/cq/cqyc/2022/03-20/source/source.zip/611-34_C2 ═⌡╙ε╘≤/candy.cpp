#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=10007;
int q,x,n;
int a[10000];
int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) if(ch=='-') f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
signed main() {
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	q=read(),x=read();
	a[0]=x;
	for(int i=1; i<=5003; i++) a[i]=((a[i-1]+1)%mod*2)%mod;
	for(int i=1; i<=q; i++) {
		n=read();
		n=n%5003;
		printf("%lld  ",a[n]);
	}
	return 0;
}
