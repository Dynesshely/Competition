#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
int n,js,sm;
long long ans;
struct dean {
	int x,y,sumx,sumy;
} f[maxn];
int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) if(ch=='-') f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
int cmpx(dean xa,dean xb) {
	return xa.x<xb.x;
}
int cmpy(dean xa,dean xb) {
	return xa.y<xb.y;
}
int main() {
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n=read();
	for(int i=1; i<=n; i++) f[i].x=read(),f[i].y=read();
	sort(f+1,f+n+1,cmpx);
	js=0,sm=1;
	for(int i=2; i<=n+1; i++) {
		if(f[i].x!=f[i-1].x) {
			for(int j=sm; j<=i-1; j++) f[j].sumx=js;
			js=0,sm=i;
			continue;
		}
		js++;
	}
	sort(f+1,f+n+1,cmpy);
	js=0,sm=1;
	for(int i=2; i<=n+1; i++) {
		if(f[i].y!=f[i-1].y) {
			for(int j=sm; j<=i-1; j++) f[j].sumy=js;
			js=0,sm=i;
			continue;
		}
		js++;
	}
	ans=0;
	for(int i=1; i<=n; i++)	ans+=f[i].sumx*f[i].sumy;
	printf("%lld ",ans);
	return 0;
}
