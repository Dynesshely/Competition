#include<bits/stdc++.h>
using namespace std;
const int maxn=2007;
const double inf=1e9;
int W,n;
double S;
int q[maxn];
double v[maxn];
double dp[maxn];
int main(){
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d%lf%d",&W,&S,&n);
	for(int i=1;i<=n;i++){
		scanf("%d%lf",&q[i],&v[i]);
		v[i]=S/v[i];
	}
	dp[0]=0;
	double tim;
	int wei;
	for(int i=1;i<=n;i++){
		dp[i]=inf;
		wei=0;
		tim=0;
		for(int j=i;j>=1;j--){
			wei+=q[j];
			tim=max(tim,v[j]);
			if(wei>W)break;
			dp[i]=min(dp[i],dp[j-1]+tim);
		}
	}
	printf("%.2lf",dp[n]);
	return 0;
}
