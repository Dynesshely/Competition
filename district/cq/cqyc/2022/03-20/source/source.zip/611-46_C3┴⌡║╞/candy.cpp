#include<bits/stdc++.h>
using namespace std;
const long long mod=10007;
int q;
long long cx,n,sum;
long long quick_pow(long long x,long long p){
	long long ret=1;
	while(p){
		if(p%2)ret*=x,ret%=mod;
		x*=x,x%=mod;
		p/=2;
	}
	return ret;
}
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d%lld",&q,&cx);
	for(int i=1;i<=q;i++){
		scanf("%lld",&n);
		sum=quick_pow(2ll,n);
		printf("%lld",((sum*cx)%mod+sum*2-2)%mod);
		putchar(' ');
	}
	return 0;
}
