#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+7;
int n,ans;
long long bak[maxn][2];
struct node{
	int x,y;
}p[maxn];
void init(){
	ans=0;
	memset(bak,0,sizeof(bak));
	return ;
}
int main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	init();
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&p[i].x,&p[i].y);
		bak[p[i].x][0]++;
		bak[p[i].y][1]++;
	}
	for(int i=1;i<=n;i++){
		ans+=(bak[p[i].x][0]-1)*(bak[p[i].y][1]-1);
	}
	printf("%lld",ans);
	return 0;
}
