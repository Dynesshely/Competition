#include<bits/stdc++.h>
using namespace std;
const int maxn=1007,maxm=6007;
int n,m;
int as,at,bs,bt;
long long lena,lenb,dis[maxn][4],ndis[maxn],ans;
int cnt,hed[maxn],nxt[maxm],to[maxm],val[maxm];
struct node{
	int x;
	long long d;
	bool operator < (const node &A)const{
		return d>A.d;
	}
};
priority_queue<node>q;
void init(){
	cnt=1;
	memset(hed,0,sizeof(hed));
	memset(nxt,0,sizeof(nxt));
	ans=0;
	return ;
}
void add(int u,int v,int w){
	nxt[++cnt]=hed[u];
	hed[u]=cnt;
	to[cnt]=v;
	val[cnt]=w;
	return ;
}
void dijkstra(int S){
	memset(ndis,0x3f3f3f3f,sizeof(ndis));
	while(!q.empty())q.pop();
	q.push((node){S,ndis[S]=0});
	int x,v;
	while(!q.empty()){
		x=q.top().x;
		q.pop();
		for(int i=hed[x];i;i=nxt[i]){
			v=to[i];
			if(ndis[v]>ndis[x]+val[i]){
				ndis[v]=ndis[x]+val[i];
				q.push((node){v,ndis[v]});
			}
		}
	}
	return ;
};
int main(){
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	init();
	scanf("%d%d",&n,&m);
	scanf("%d%d%d%d",&as,&at,&bs,&bt);
	int u,v,w;
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&u,&v,&w);
		add(u,v,w);
		add(v,u,w);
	}
	dijkstra(as);
	for(int i=1;i<=n;i++)dis[i][0]=ndis[i];
	lena=ndis[at];
	dijkstra(at);
	for(int i=1;i<=n;i++)dis[i][1]=ndis[i];
	dijkstra(bs);
	for(int i=1;i<=n;i++)dis[i][2]=ndis[i];
	lenb=ndis[bt];
	dijkstra(bt);
	for(int i=1;i<=n;i++)dis[i][3]=ndis[i];
	for(int i=1;i<=n;i++){
		dijkstra(i);
		for(int j=1;j<=n;j++){
			if(i==j)continue;
//	printf("BOOM\n");
			if(min(dis[i][0]+dis[j][1],dis[i][1]+dis[j][0])+ndis[j]==lena&&
			   min(dis[i][2]+dis[j][3],dis[i][3]+dis[j][2])+ndis[j]==lenb){
				ans=max(ans,ndis[j]);
			}
		}
	}
	printf("%lld",ans);
	return 0;
}
