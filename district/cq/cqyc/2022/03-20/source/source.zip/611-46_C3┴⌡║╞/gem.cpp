#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+7;
const int inf=1e9;
int n,m;
int cnt,w[maxn];
long long sum[maxn];
struct nodep{
	int id,c;
	long long v;
	bool operator < (const nodep &A)const{
		return id<A.id;
	}
	bool operator > (const nodep &A)const{
		return id>A.id;
	}
}p[maxn];
struct segtree{
	int l,r,ls,rs,mi;
}t[maxn<<2];
struct node{
	int sc,ma;
};
set<nodep>s[maxn];
set<nodep>::iterator it;
vector<node>fix;
void init(){
	memset(sum,0,sizeof(sum));
	return ;
}
void build(int x,int l,int r){
	t[x].l=l,t[x].r=r;
	t[x].mi=n+1;
	if(l==r){
		t[x].ls=t[x].rs=0;
		return ;
	}
	t[x].ls=(x<<1),t[x].rs=(x<<1|1);
	int mid=(t[x].l+t[x].r)/2;
	build(t[x].ls,l,mid);
	build(t[x].rs,mid+1,r);
	t[x].mi=min(t[t[x].ls].mi,t[t[x].rs].mi);
	return ;
}
void modify(int x,int p,int v){
	if(t[x].l==t[x].r){
		t[x].mi=v;
		return ;
	}
	int mid=(t[x].l+t[x].r)/2;
	if(p<=mid)modify(t[x].ls,p,v);
	else modify(t[x].rs,p,v);
	t[x].mi=min(t[t[x].ls].mi,t[t[x].rs].mi);
	return ;
}
void update(int x,int v){
	for(int i=x;i<=n;i+=(i&-i)){
		sum[i]+=v;
	}
	return ;
}
long long cha(int x){
	if(x==0)return 0;
	long long ret=0;
	for(int i=x;i;i-=(i&-i)){
		ret+=sum[i];
	}
	return ret;
}
int query(int x,int l,int r){
	if(t[x].l==l&&t[x].r==r){
		return t[x].mi;
	}
	int mid=(t[x].l+t[x].r)/2;
	if(l>mid)return query(t[x].rs,l,r);
	else if(r<=mid)return query(t[x].ls,l,r);
	else return min(query(t[x].ls,l,mid),query(t[x].rs,mid+1,r));
}
int main(){
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	init();
	scanf("%d%d",&n,&m);
//	for(int i=1;i<=n;i++){
//		s[i].insert((nodep){0,n+1,1ll});
//	}
	for(int i=1;i<=n;i++){
		scanf("%d%lld",&p[i].c,&p[i].v);
		p[i].id=i;
		s[p[i].c].insert(p[i]);
		update(i,p[i].v);
	}
	build(1,1,n);
	int nw,w;
	long long nsum,ans;
//	printf("nw:");
	for(int i=1;i<=n;i++){
//		for(it=s[p[i].c].begin();it!=s[p[i].c].end();it++)printf("lalla %d %d \n",i,it->id);
		it=s[p[i].c].find(p[i]);
		it++;
		if(it==s[p[i].c].end())nw=n+1;
		else nw=it->id;
		modify(1,i,nw);
//		printf("%d ",nw);
	}
//	putchar('\n');
	int ty,a,b,c,la,ra,lb,rb;
	for(int i=1;i<=m;i++){
		scanf("%d",&ty);
		if(ty==1){
			scanf("%d%d%d",&a,&b,&c);
			it=s[p[a].c].find(p[a]);
			if(it==s[p[a].c].begin())la=0;
			else {
				it--;
				la=it->id;
				it++;
			}
			it++;
			if(it==s[p[a].c].end())ra=n+1;
			else{
				ra=it->id;
			}
			it--;
			s[p[a].c].erase(p[a]);
			update(a,c-p[a].v);
			p[a].c=b,p[a].v=c;
			s[b].insert(p[a]);
			it=s[p[a].c].find(p[a]);
			if(it==s[p[a].c].begin())lb=0;
			else {
				it--;
				lb=it->id;
				it++;
			}
			it++;
			if(it==s[p[a].c].end())rb=n+1;
			else{
				rb=it->id;
			}
			it--;
			if(la)modify(1,la,ra);
			modify(1,a,rb);
			modify(1,ra,a);
		}
		else{
//			printf("newquery!\n");
			scanf("%d%d",&a,&b);
			nsum=ans=0;
			fix.clear();
			for(int j=1;j<=b+1;j++){
				w=query(1,a,n);
				ans=max(ans,cha(w-1)-cha(a-1)-nsum);
				if(w==n+1)break;
				it=s[p[w].c].find(p[w]);
				it--;
				nw=it->id;
				fix.push_back((node){nw,w});
				modify(1,nw,n+1);
				nsum+=p[nw].v;
//				printf("%d %d\n",nw,w);
			}
			for(int j=0;j<fix.size();j++){
				modify(1,fix[j].sc,fix[j].ma);
//				printf("sc %d ma %d\n",fix[j].sc,fix[j].ma);
			}
			printf("%lld",ans);
			putchar('\n');
		}
	}		
	return 0;
}
