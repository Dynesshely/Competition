#include<bits/stdc++.h>
using namespace std;
int n,sz,num,sum;
vector<int> nx[100001],ny[100001];
vector<int>::iterator it;
pair<int,int> a[100001];
long long ans;
inline int read()
{
	int x(0);char ch=getchar();
	while(ch<48||ch>57) ch=getchar();
	while(ch>=48&&ch<=57) x=x*10+(ch^48),ch=getchar();
	return x;
}
int main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) 
	{
		a[i].first=read(),a[i].second=read();
		nx[a[i].first].push_back(a[i].second),ny[a[i].second].push_back(a[i].first);
	}
	for(int i=1;i<=100000;i++) sort(nx[i].begin(),nx[i].end()),sort(ny[i].begin(),ny[i].end());
	for(int i=1;i<=100000;i++) 
	{
		sum=0,sz=nx[i].size();if(sz<2) continue;
		for(it=nx[i].begin();it!=nx[i].end();++it) sum+=ny[*it].size()-1;
		ans+=1ll*sum*(sz-1);
	}
	printf("%lld",ans);
	return 0;
}

