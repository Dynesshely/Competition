#include<bits/stdc++.h>
using namespace std;
int w,s,n,l,r;
double ans=1e9,f[2001][2001],mn[2001][2001],sum[2001];
pair<int,double> a[2001]; 
inline int read()
{
	int x(0);char ch=getchar();
	while(ch<48||ch>57) ch=getchar();
	while(ch>=48&&ch<=57) x=x*10+(ch^48),ch=getchar();
	return x;
}
int main()
{
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	w=read(),s=read(),n=read();
	for(int i=1;i<=n;i++)
	{
		scanf("%d%lf",&a[i].first,&a[i].second);
		sum[i]=sum[i-1]+a[i].first;
		for(int j=1;j<=n;j++) f[i][j]=1e9;
		f[i][i]=s/a[i].second;
	}
	for(int i=1;i<=n;i++)
	{
		for(int l=1;l<=n;l++)
		{
			r=l+i;if(r>n) break;
			if(sum[r]-sum[l-1]<=w)
			{
				if(a[l].second>a[l+1].second) f[l][r]=f[l+1][r];
				else f[l][r]=s/a[l].second+mn[l+1][r];
				if(a[r].second>a[r-1].second) f[l][r]=f[l][r-1];
				else f[l][r]=s/a[r].second+mn[l][r-1];
				printf("%d %d %f\n",l,r,sum[r]-sum[l-1]);
			}
			else
			{
				for(int z=l;z<=r;z++) 
				{
					if(sum[z]-sum[l-1]<=w) 
					{
						if(a[l].second>a[l+1].second) f[l][r]=min(f[l][r],f[l+1][z]+f[z][r]);
						else f[l][r]=min(f[l][r],s/a[l].second+mn[l+1][r]);
						if(a[r].second>a[r-1].second) f[l][r]=min(f[l][r],f[l][z]+f[z][r-1]);
						else f[l][r]=min(f[l][r],s/a[r].second+mn[l][r-1]);
					}
				}
				for(int z=r;z>=l;z--) 
				{
					if(sum[r]-sum[z-1]<=w) 
					{
						if(a[l].second>a[l+1].second) f[l][r]=min(f[l][r],f[l+1][z]+f[z][r]);
						else f[l][r]=min(f[l][r],s/a[l].second+mn[l+1][r]);
						if(a[r].second>a[r-1].second) f[l][r]=min(f[l][r],f[l][z]+f[z][r-1]);
						else f[l][r]=min(f[l][r],s/a[r].second+mn[l][r-1]);
					}
				}
			}
			mn[l][r]=min(mn[l+1][r],mn[l][r-1]);
		}
	}
	ans=f[1][n];
	printf("%.2f",ans);
	return 0;
}

