#include<bits/stdc++.h>
using namespace std;
int q,n,ans;
inline int read()
{
	int x(0);char ch=getchar();
	while(ch<48||ch>57) ch=getchar();
	while(ch>=48&&ch<=57) x=x*10+(ch^48),ch=getchar();
	return x;
}
void write(int x)
{
	if(x>=10) write(x/10);
	putchar(x%10^48);
}
int qpow(int x)
{
	long long s=1,ss=2;
	while(x)
	{
		if(x&1) s=s*ss%10007;
		ss=ss*ss%10007;
		x>>=1;
	}
	return s;     
}
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	int x;
	q=read(),x=read();
	while(q--)
	{
		n=read();
		ans=(x*qpow(n)%10007+qpow(n+1)-2+10007)%10007;
		write(ans);putchar(' ');
	}
	return 0;
}
