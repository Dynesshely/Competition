#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int mod=10007;
int q,x,n;
int Pow(int a,int b) {
	if(b==1) return a%mod;
	if(b==0) return 1;
	int tmp=Pow(a,b/2)*Pow(a,b/2)%mod;
	if(b&1) return tmp*a%mod;
	return tmp;
}
signed main() {
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	q=read(),x=read();
	while(q--) {
		n=read();
		printf("%lld\n",(x*Pow(2,n)%mod+Pow(2,n+1)-2+mod)%mod);
	}
	return 0;
}
/*
3 
1 
3 2 1

22 10 4

3 
7 
300 200 100

8152 9100 2051
*/
