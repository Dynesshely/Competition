#include <bits/stdc++.h>
#define int long long
#define double long double
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=2005;
int w,s,n,q[N];
double v[N],t[N],dp[N];
signed main() {
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	w=read(),s=read(),n=read();
	for(int i=1;i<=n;++i) cin>>q[i]>>v[i],t[i]=s*1.0/v[i];
	for(int i=1;i<=n;++i) {
		double ma=t[i];
		int sum=q[i];
		dp[i]=1e18;
		for(int j=i-1;j>=0;--j) {
			dp[i]=min(dp[i],dp[j]+ma);
			ma=max(ma,t[j]);
			sum+=q[j];
			if(sum>w) break;
		}
	}
	cout<<fixed<<setprecision(2)<<dp[n];
	return 0;
}
/*
800 300 4
53 5.0
59 3.0
38 2.0
69 2.0

150.00
*/
