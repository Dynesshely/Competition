#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=200005;
int n,m,c[N],v[N],a[N];
void bl() {
	while(m--) {
		int op=read();
		if(op==1) {
			int x=read(),cc=read(),vv=read();
			c[x]=cc,v[x]=vv;
		}
		else {
			int s=read(),K=read(),ans=0,k=0;
			for(int i=1;i<=n;++i) a[i]=0;
			for(int i=s;i<=n;++i) {
				if(a[c[i]]==0) ans+=v[i],a[c[i]]=v[i];
				else {
					++k;
					if(k>K) break;
					if(a[c[i]]<v[i]) ans+=v[i]-a[c[i]],a[c[i]]=v[i];
				}
			}
			printf("%lld\n",ans);
		}
	}
	exit(0);
}
vector<int> ve;
signed main() {
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i) c[i]=read(),v[i]=read();
	bl();
	return 0;
}
/*
5 6
1 3
2 4
3 1
2 2
3 5
2 1 0
2 1 1
2 1 2
1 4 3 3
2 3 1
2 2 2

8
8
12
3
9
*/
