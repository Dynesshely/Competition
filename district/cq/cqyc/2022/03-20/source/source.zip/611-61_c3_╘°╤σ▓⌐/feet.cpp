#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=100005;
int n,ans,x[N],y[N],tx[N],ty[N];
signed main() {
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) x[i]=read(),y[i]=read(),++tx[x[i]],++ty[y[i]];
	for(int i=1;i<=n;++i) ans+=(tx[x[i]]-1)*(ty[y[i]]-1);
	cout<<ans;
	return 0;
}
/*
5
1 2
2 1
2 2
2 3
3 2

4

6 
10 10
20 10
10 20
20 20
30 20
30 30

8
*/
