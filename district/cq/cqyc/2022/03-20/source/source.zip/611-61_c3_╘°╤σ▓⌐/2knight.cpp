#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
signed main() {
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	cerr<<"%%%%%%%%%%%%%%%%%%%\n";
	cerr<<"%sto 1234huang orz%\n";
	cerr<<"%sto charming  orz%\n";
	cerr<<"%sto  zuishuai orz%\n";
	cerr<<"%sto   y200    orz%\n";
	cerr<<"%sto    ZJB    orz%\n";
	cerr<<"%sto   tkon    orz%\n";
	cerr<<"%sto  qiaozh   orz%\n";
	cerr<<"%sto shadowYYH orz%\n";
	cerr<<"%%%%%%%%%%%%%%%%%%%\n";
	puts("3");
	return 0;
}
