#include <bits/stdc++.h>
using namespace std;
signed main() {
	system("fc gem.out gem2.out");
	return 0;
}
