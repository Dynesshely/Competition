#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define ll long long
#define zzdshishen 0
const int N=1e5+5;
int n,x[N],y[N],cx[N],cy[N];
ll ans;
using namespace std;
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
inline void __(ll x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
int main() {
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n=_();
	for(int i=1;i<=n;++i) {
		x[i]=_(),y[i]=_();
		cx[x[i]]++,cy[y[i]]++;
	}
	for(int i=1;i<=n;++i) {
		ans+=(ll)(cx[x[i]]-1)*(cy[y[i]]-1);
	}
	__(ans);
	return zzdshishen;
}
//15:00~15:05
