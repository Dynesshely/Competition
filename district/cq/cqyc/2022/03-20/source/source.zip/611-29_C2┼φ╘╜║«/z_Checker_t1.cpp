#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("result.txt","w",stdout);
	while(1) {
		system("z_Make_Data_t1.exe");
		system("candy.exe");
		system("z_candy_1.exe");
		if(system("fc candy.out candy.ans")) {
			printf("Clock=%d Wrong Answer!",clock());
			break;
		}
		if(clock()>1e7) {
			printf("Clock=%d Accepeted!",clock());
			break;
		}
	}
}
