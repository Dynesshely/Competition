#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int zzd=10007;
int q,x,d,s;
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
inline void __(int x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
inline int Mul(int a,int b) {return (long long)a*b%zzd;}
inline int Quick_Power(int x,int b) {
	int s=1;
	while(b) {
		if(b&1) s=Mul(s,x);
		x=Mul(x,x),b>>=1;
	}
	return s;
}
int main() {
	freopen("candy.in","r",stdin);
	freopen("candy.ans","w",stdout);
	q=_(),x=_();
	while(q--) {
		d=_();
		s=x;
		for(int i=1;i<=d;++i) {
			s=Mul(2,s+1);
		}
		__(s),pc(' ');
	}
}
//14:15~14:
