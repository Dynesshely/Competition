#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=1505,M=3005;
int n,m,X1,Y1,X2,Y2,ans,vis[N],dis[N],fa[N],rd[N];
int ct,hd[N],nt[M],to[M],cs[M],fg[M];
struct Node {
	int i,d;
	bool operator <(const Node &A) const{
		return d<A.d;
	}
};
priority_queue<Node> Q;
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
inline void __(int x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void Merge(int t,int y,int x) {
	nt[++ct]=hd[x],to[ct]=y,cs[ct]=t,hd[x]=ct;
	nt[++ct]=hd[y],to[ct]=x,cs[ct]=t,hd[y]=ct;
}
void Dijkstra(int s) {
	memset(vis,0,sizeof(vis));
	memset(dis,0x3f,sizeof(dis));
	memset(fa,0,sizeof(fa));
	dis[s]=0;
	Q.push((Node){s,0});
	while(!Q.empty()) {
		int x=Q.top().i;Q.pop();
		if(vis[x]) continue;
		vis[x]=1;
		for(int v,i=hd[x];i;i=nt[i]) {
			if(dis[v=to[i]]>dis[x]+cs[i]) {
				dis[v]=dis[x]+cs[i];
				fa[v]=x,rd[v]=i;
				Q.push((Node){v,dis[v]});
			}
		}
	}
}
inline void Paint(int s,int t) {
	while(t!=s) fg[rd[t]]++,t=fa[t];//,printf("%d ",t);
//	printf("\n");
}
int main() {
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	n=_(),m=_();
	X1=_(),Y1=_(),X2=_(),Y2=_();
	for(int i=1;i<=m;++i) {
		Merge(_(),_(),_());
	}
	Dijkstra(X1);
	Paint(X1,Y1);
//	for(int i=1;i<=n;++i) {
//		printf("<%d> %d %d %d\n",i,dis[i],fa[i],rd[i]);
//	}
	Dijkstra(X2);
	Paint(X2,Y2);
//	for(int i=1;i<=n;++i) {
//		printf("<%d> %d %d %d\n",i,dis[i],fa[i],rd[i]);
//	}
	for(int i=1;i<=ct;++i) if(fg[i]==2) ans+=cs[i];
	__(ans);
}
//15:55~16:30
