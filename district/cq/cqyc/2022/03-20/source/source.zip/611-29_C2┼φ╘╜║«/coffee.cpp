#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define pt(a) printf("%.2lf",a)
#define zzdshishen 0
using namespace std;
const int N=1005;
int W,S,n,w[N],p[N];
double sum,ans,t[N],mx[N][N],dp[N];
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
inline void __(int x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void DFS(int x) {
//	printf("%d %lf\n",x,sum);
	if(sum>ans) return ;
	if(x>n) {ans=min(ans,sum);return ;}
	for(int i=x;i<=n;++i) {
		if(p[i]-p[x-1]>W) break;
		sum+=mx[x][i];
//		printf("%d %.0lf ",x,mx[x][i]);
		DFS(i+1);
		sum-=mx[x][i];
	}
}
int main() {
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	W=_(),S=_(),n=_();
	for(int i=1;i<=n;++i) {
		double v;
		w[i]=_();scanf("%lf",&v);
		t[i]=S/v;
		p[i]=p[i-1]+w[i];
		for(int j=i;j;--j) {
			mx[j][i]=max(mx[j+1][i],t[j]);
		}
		dp[i]=1e9;
	}
	if(n<=20) {
		ans=1e9;
		DFS(1);
		pt(ans);
	}
	else {
		for(int i=1;i<=n;++i) {
			for(int j=i;j>=1;--j) {
				if(p[i]-p[j-1]>W) break;
				dp[i]=min(dp[i],dp[j-1]+mx[j][i]);
			}
		}
		pt(dp[n]);
	}
	return zzdshishen;
}
//16:30~16:55(st1_20pts)
//16:55~17:10(100pts)
