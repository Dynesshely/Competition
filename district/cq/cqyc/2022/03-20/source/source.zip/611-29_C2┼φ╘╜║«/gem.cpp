#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
#define ll long long
#define zzdshishen 0
using namespace std;
const int N=2e5+5;
int n,Q,cnt,c[N],v[N],fg[N];
ll sum;
inline int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
inline void __(ll x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
int main() {
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n=_(),Q=_();
	for(int i=1;i<=n;++i) c[i]=_(),v[i]=_();
	while(Q--) {
		if(_()==1) {
			int x=_(),xc=_(),xv=_();
			c[x]=xc,v[x]=xv;
		}
		else {
			int s=_(),k=_();
			memset(fg,0,sizeof(fg));sum=cnt=0;
			//fg:ǰһ�γ��ֵ�λ�� 
			for(int i=s;i<=n;++i) {
				int l=fg[c[i]];
				if(l) {
					if(cnt==k) break;
					if(v[l]<v[i]) sum+=v[i]-v[l];
					cnt++;
				}
				else sum+=v[i];
				fg[c[i]]=i;
			}
			__(sum),pc('\n');
		}
	}
	return zzdshishen;
}
//15:05~15:35(st2_30pts)
