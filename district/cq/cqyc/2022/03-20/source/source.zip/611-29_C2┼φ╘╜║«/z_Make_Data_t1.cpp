#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("candy.in","w",stdout);
	srand(time(0));
	int q=rand()%100+1,x=rand()%10+1;
	printf("%d\n%d\n",q,x);
	for(int i=1;i<=q;++i) {
		printf("%d ",rand()%100000000+1);
	}
}
