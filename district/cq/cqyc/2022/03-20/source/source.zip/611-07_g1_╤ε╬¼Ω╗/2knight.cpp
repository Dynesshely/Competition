#include<bits/stdc++.h>
#define x1 bedwsbjhcxbs
#define y1 hbackjzsandsz
#define x2 jivsanlkcds
#define y2 BCKJSczalcd
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
const van MaxN=1500+10;
van n,m;
van x1,y1,x2,y2;
vector<pair<van,van> > g[MaxN];
van d[MaxN][MaxN]; 
van dis[MaxN]; bool used[MaxN];
void Dijkstra(van s) {
	for (int i=1;i<=n;i++) used[i]=0;
	for (int i=1;i<=n;i++) dis[i]=1e18;
	dis[s]=0; priority_queue<pair<van,van> > q;
	q.push(make_pair(-dis[s],s));
	while (!q.empty()) {
		van now=q.top().second; q.pop();
		if (used[now]==1) continue; used[now]=1;
		for (int i=0;i<g[now].size();i++) {
			van to=g[now][i].first,c=g[now][i].second;
			if (dis[to]>dis[now]+c) {
				dis[to]=dis[now]+c;
				q.push(make_pair(-dis[to],to));
			}
		}
	} for (int i=1;i<=n;i++) d[s][i]=dis[i];
} van ans=0;
int main() {
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	read(n),read(m);
	read(x1),read(y1); read(x2),read(y2);
	for (int i=1;i<=m;i++) {
		van a,b,c; read(a),read(b),read(c);
		g[a].push_back(make_pair(b,c));
		g[b].push_back(make_pair(a,c));
	} for (int i=1;i<=n;i++) Dijkstra(i);
	van goala=d[x1][y1],goalb=d[x2][y2];
	for (int i=1;i<=n;i++) {
		for (int j=1;j<=n;j++) {
			van same=d[i][j]; 
			if (d[x1][i]+d[i][j]+d[j][y1]>goala&&d[x1][j]+d[j][i]+d[i][y1]>goala) continue;
			if (d[x2][i]+d[i][j]+d[j][y2]>goalb&&d[x2][j]+d[j][i]+d[i][y2]>goalb) continue;
			ans=max(ans,same);
		}
	} print(ans);
	return 0;
}

