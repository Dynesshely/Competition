#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
const van mod=10007;
van power(van a,van b) {
	van ans=1,base=a;
	while (b) {
		if (b&1) ans*=base,ans%=mod;
		base*=base,base%=mod,b>>=1;
	} return ans;
}
int main() {
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	van q,x; read(q),read(x);
	for (int qq=1;qq<=q;qq++) {
		van n; read(n);
		print((x*power(2,n)%mod+(power(2,n+1)+mod-2)%mod)%mod);
		putchar(' ');
	}
	return 0;
}

