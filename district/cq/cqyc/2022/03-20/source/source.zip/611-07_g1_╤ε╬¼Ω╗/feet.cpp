#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
const van MaxN=1e5+10;
struct pos {
	van x,y,id;
}p[MaxN]; van ans=0;
van x[MaxN],y[MaxN];
int main() {
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	van n; read(n); for (int i=1;i<=n;i++) read(p[i].x),read(p[i].y),p[i].id=i;
	for (int i=1;i<=n;i++) x[p[i].x]++,y[p[i].y]++;
	for (int i=1;i<=n;i++) ans+=(x[p[i].x]-1)*(y[p[i].y]-1);
	print(ans);
	return 0;
}

