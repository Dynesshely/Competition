#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
van randx() {
	return rand()*1e4+rand();
}
int main() {
	freopen("gem.in","w",stdout);
	van n=2e5,m=2e5; srand(time(0));
	cout<<n<<" "<<m<<endl;
	for (int i=1;i<=n;i++) cout<<randx()%n+1<<" "<<randx()<<endl;
	for (int i=1;i<=m;i++) {
		van type=rand()%2+1;
		if (type==1) cout<<1<<" "<<randx()%n+1<<" "<<randx()%n+1<<" "<<randx()<<endl;
		else cout<<2<<" "<<rand()%n+1<<" "<<rand()%10+1<<endl;
	}
	return 0;
}

