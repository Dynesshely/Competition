#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[51]={0},k=0;
	while (x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
	return;
}
const van MaxN=2e3+10;
double w,s,n; 
double q[MaxN]; double v[MaxN];
double qsum[MaxN]; double dp[MaxN];
double t[MaxN]; 
struct SGT {
	double dat[MaxN<<2];
	void BuildTree(van p=1,van l=1,van r=n) {
		if (l==r){dat[p]=t[l]; return;}
		van mid=(l+r)>>1;
		BuildTree(p*2,l,mid);
		BuildTree(p*2+1,mid+1,r);
		dat[p]=max(dat[p*2],dat[p*2+1]);
	}
	double QueryTree(van L,van R,van p=1,van l=1,van r=n) {
		if (L<=l&&r<=R) return dat[p];
		double ans=0; van mid=(l+r)>>1;
		if (L<=mid) ans=max(ans,QueryTree(L,R,p*2,l,mid));
		if (R>mid) ans=max(ans,QueryTree(L,R,p*2+1,mid+1,r));
		return ans;
	}
}T;
int main() {
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	cin>>w>>s>>n;
	for (int i=1;i<=n;i++) cin>>q[i]>>v[i];
	for (int i=1;i<=n;i++) qsum[i]=qsum[i-1]+q[i];
	for (int i=1;i<=n;i++) dp[i]=1e18;
	for (int i=1;i<=n;i++) t[i]=double(s)/v[i];
	T.BuildTree(); dp[0]=0.0; 
	for (int i=1;i<=n;i++) { 
		for (int j=i-1;j>=0;j--) {
			if (qsum[i]-qsum[j]>w) break;
			dp[i]=min(dp[i],dp[j]+T.QueryTree(j+1,i));
		} 
	} cout<<fixed<<setprecision(2)<<dp[int(n)]<<endl;
//	van now=n; while (now!=0) {
//		cout<<now<<" "; now=min_[now];
//	}
	return 0;
}

