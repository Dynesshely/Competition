#include<bits/stdc++.h>
using namespace std;
int n,up[100007],dow[100007],lef[100007],ri[100007];
int x[100007],y[100007];
vector<pair<int,int> > xi[100007],yi[100007];
long long ans=0;
int main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d %d",&x[i],&y[i]);
		xi[x[i]].push_back(make_pair(y[i],i));
		yi[y[i]].push_back(make_pair(x[i],i));
	}
	for(int i=1;i<=100000;i++)
	{
		sort(xi[i].begin(),xi[i].end());
		sort(yi[i].begin(),yi[i].end());
	}
	for(int i=1;i<=100000;i++)
	{
		for(int j=0;j<xi[i].size();j++)
		{
			dow[xi[i][j].second]=j;
			up[xi[i][j].second]=xi[i].size()-j-1;
		}
		for(int j=0;j<yi[i].size();j++)
		{
			ri[yi[i][j].second]=j;
			lef[yi[i][j].second]=yi[i].size()-j-1;
		}
	}
	for(int i=1;i<=n;i++)
	{
	//	printf("%d %d %d %d\n",dow[i],up[i],ri[i],lef[i]);
		ans+=(long long)(dow[i]+up[i])*(ri[i]+lef[i]);
	}
	printf("%lld",ans);
	return 0;
}
