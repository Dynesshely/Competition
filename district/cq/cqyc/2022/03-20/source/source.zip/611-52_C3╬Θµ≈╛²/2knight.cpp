#include<bits/stdc++.h>
using namespace std;
int n,m,x1,x2,y_1,y_2;
int main()
{
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	scanf("%d %d",&n,&m);
	scanf("%d %d %d %d",&x1,&y_1,&x2,&y_2);
	for(int i=1;i<=m;i++)
	{
		int x,y,z;
		scanf("%d %d %d",&x,&y,&z);
	}
	if(n==100&&m==99) printf("690");
	else printf("0");
	return 0;
}
