#include<bits/stdc++.h>
using namespace std;
int wi[2007],w,s,n;
double dp[2007][2007],f[2007],slow[2007][2007],x[2007];
double ans=-1.0;
int main()
{
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d %d %d",&w,&s,&n);
	for(int i=1;i<=n;i++)	scanf("%d %lf",&wi[i],&x[i]);	
	for(int i=1;i<=n;i++)
	{
		wi[i]+=wi[i-1];
		slow[i][i]=(double)s/x[i];
		for(int j=i+1;j<=n;j++)	slow[i][j]=max(slow[i][j-1],(double)s/x[j]);	
	}
	for(int i=1;i<=n;i++)
	{	f[i]=-1.0;
		for(int j=1;j<=n;j++)	dp[i][j]=-1.0;	
	}
	for(int i=1;i<=n;i++) 	if(wi[i]<=w) dp[1][i]=slow[1][i],f[i]=dp[1][i];
	for(int i=2;i<=n;i++)
	{
		for(int j=i;j<=n;j++)
		{
			if(wi[j]-wi[i-1]>w||f[i-1]==-1.0) continue;
			dp[i][j]=f[i-1]+slow[i][j];
			if(f[j]==-1.0) f[j]=dp[i][j];
			else f[j]=min(f[j],dp[i][j]);
			
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(dp[i][n]==-1.0) continue;
		if(ans==-1.0) ans=dp[i][n];
		else ans=min(ans,dp[i][n]);
	}
	printf("%.2lf",ans);
	return 0;
}
