#include<bits/stdc++.h>
using namespace std;
int n,m,c[200007],vis[200007],opt,xi,ci,si,ki;
long long v[200007];
long long vi,ans;
int main()
{
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)	scanf("%d %lld",&c[i],&v[i]);
	for(int i=1;i<=m;i++)
	{
		scanf("%d",&opt);
		if(opt==1)
		{
			scanf("%d %d %lld",&xi,&ci,&vi);
			c[xi]=ci,v[xi]=vi;
		}
		else
		{
			ans=0;
			scanf("%d %d",&si,&ki);
			for(int j=1;j<=n;j++) vis[j]=0;
			for(int j=si;j<=n&&ki>=0;j++)
			{
				ki--;
				if(!vis[c[j]]) ki++,vis[c[j]]=j,ans+=v[j];
				else if(ki>=0&&v[vis[c[j]]]<v[j]) ans-=v[vis[c[j]]],ans+=v[j],vis[c[j]]=j;
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
