#include<bits/stdc++.h>
using namespace std;
const int mod=10007;
int q,x,s[100007];
int ti[100007],sum=1,ans;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d %d",&q,&x);
	for(int i=1;i<=100000;i++)
	{
		sum=sum*2%mod;
		ans=(ans+sum)%mod;
		ti[i]=ans+x*sum%mod; 
		ti[i]=ti[i]%mod;
	}
	for(int i=1;i<=q;i++) scanf("%d",&s[i]);
	for(int i=1;i<=q;i++) printf("%d ",ti[s[i]]);
	return 0;
}
