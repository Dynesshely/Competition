#include<bits/stdc++.h>
using namespace std;
long long q,x,n,van,kkk1,kkk2,ass;
long long ksm(long long now){
	ass=1,kkk1=2;
	while(now){
		if((now&1)==1){
			ass=(ass*kkk1)%10007;
		}
		now/=2;
		kkk1=(kkk1*kkk1)%10007;
	}
	return ass;
}
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%lld",&q);
	scanf("%lld",&x);
	for(int i=1;i<=q;i++){
		scanf("%lld",&n);
		van=ksm(n);
		printf("%lld\n",(van*x+van*2-2)%10007);
	}
	return 0;
} 
