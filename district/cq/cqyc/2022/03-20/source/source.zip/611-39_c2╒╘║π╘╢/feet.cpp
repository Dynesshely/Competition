#include<bits/stdc++.h>
using namespace std;
int n,xsum[100001],ysum[100001],x[100001],y[100001];
long long ans;
int main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&x[i],&y[i]);
		xsum[x[i]]++;
		ysum[y[i]]++;
	}
	for(int i=1;i<=n;i++){
		if(xsum[x[i]]-1>0&&ysum[y[i]]-1>0){
		ans+=(long long)(xsum[x[i]]-1)*(long long)(ysum[y[i]]-1);
//		xsum[x[i]]--;
//		ysum[y[i]]--;
	}
	}
	printf("%lld",ans);
	return 0;
} 
