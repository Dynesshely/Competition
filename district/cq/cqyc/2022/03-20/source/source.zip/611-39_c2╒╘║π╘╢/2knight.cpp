#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,c,d,xxx,yyy,vvv,ass[1501],kkk,ojbk,op,las;
int way1[1501],way2[1501],way3[1501],way4[1501],dep,far,ans[100001],cnt,wdnmd,mmax;
bool vis[1501],bj[1501],ok[100001];
struct jkl{
	int nxt,val;
};
vector<jkl>fa[1501];
vector<int>ddf[1501][1501];
priority_queue<pair<int,int> >van; 
void dij(int now){
	for(int i=1;i<=n;i++){
		vis[i]=0;
		ass[i]=INT_MAX;
	}
	ass[now]=0;
	van.push(make_pair(0,now));
	while(!van.empty()){
		now=van.top().second;
		van.pop();
		if(vis[now])continue;
		vis[now]=1;
		for(int i=0;i<fa[now].size();i++){
			if(ass[fa[now][i].nxt]>ass[now]+fa[now][i].val)
				ass[fa[now][i].nxt]=ass[now]+fa[now][i].val;
			van.push(make_pair(fa[now][i].val,fa[now][i].nxt));
		}
	}
}
void dfs1(int now){
	for(int i=0;i<fa[now].size();i++){
		if(fa[now][i].nxt==las){
			way3[cnt]=now;
			way4[cnt]=i;
		}
	}
	if(now==b){
		wdnmd++;
		for(int i=1;i<=cnt;i++){
	    ddf[way1[i]][way2[i]].push_back(wdnmd);
	    ddf[way3[i]][way4[i]].push_back(wdnmd);
	}
		return ;
	}
	bj[now]=1;
	for(int i=0;i<fa[now].size();i++){
		if(bj[fa[now][i].nxt]==1||far+fa[now][i].val>kkk)continue;
		cnt++;
		way1[cnt]=now;
		way2[cnt]=i;
		far+=fa[now][i].val;
		las=now;
		dfs1(fa[now][i].nxt);
		far-=fa[now][i].val;
		way1[cnt]=0;
		way2[cnt]=0;
		cnt--;
	}
	bj[now]=0;
}
void dfs2(int now){
	if(now==d){
	for(int j=1;j<=wdnmd;j++)
		mmax=max(mmax,ans[j]);	
	return ;
}
    bj[now]=1;
	for(int i=0;i<fa[now].size();i++){
		if(bj[fa[now][i].nxt]==1||far+fa[now][i].val>kkk)continue;
		far+=fa[now][i].val;
		for(int j=0;j<ddf[now][i].size();j++)
		ans[ddf[now][i][j]]+=fa[now][i].val;
		las=now;
		dfs2(fa[now][i].nxt);
		for(int j=0;j<ddf[now][i].size();j++)
		ans[ddf[now][i][j]]-=fa[now][i].val;
		far-=fa[now][i].val;
	}
	bj[now]=0;
}
int main(){
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	scanf("%d%d",&n,&m);
	scanf("%d%d%d%d",&a,&b,&c,&d);
	for(int i=1;i<=m;i++){
	scanf("%d%d%d",&xxx,&yyy,&vvv);
	fa[xxx].push_back({yyy,vvv});
	fa[yyy].push_back({xxx,vvv});
}	
    dij(a);
    kkk=ass[b];
    dfs1(a);
    ojbk=0,far=0,las=0;
    for(int i=1;i<=n;i++){
    	bj[i]=0;
    	way1[i]=0;
    	way2[i]=0;
	}
    dij(c);
    kkk=ass[d];
    dfs2(c);
    printf("%d",mmax);
	return 0;
} 
