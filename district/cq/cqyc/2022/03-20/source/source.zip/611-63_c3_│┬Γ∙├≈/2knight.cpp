#include<bits/stdc++.h>
using namespace std;
//inline int read()
//{
//	char c=getchar();
//	int x=0,f=0;
//	while(!isdigit(c))
//	{
//		if(c=='-') f=-1;
//		c=getchar();
//	}
//	while(isdigit(c))
//	{
//		x=x*10+c-48;
//		c=getchar();
//	}
//	return f==0?x:-x;
//}
//void out(int x)
//{
//	if(x<0) putchar('-'),x=-x;
//	if(x>=10) out(x/10);
//	putchar('0'+x%10);
//}
int n,m,zx,zy,sx,sy,u,v;
//vector<int> vc[100010];
//struct node
//{
//	int x,v;
//	bool operator < (const node a) const
//	{
//		return v<a.v;
//	} 
//};
//void bfs()
//{
//	priority_queue<node> qu;
//	qu.push(node{zx,0});
//	while(!qu.empty()) 
//	{
//		node now=qu.top();
//		qu.pop();
//		if(now.x==zy)
//		{
//			if(now.y<=mi)
//			{
//				
//			 } 
//		}
//		for(int i=0;i<vc[now.x].size();i++)
//		{
//			qu.push_back(node{vc[now.x][i],now.y+1});
//		}
//	}
//}
signed main()
{
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	srand(time(0));
//	n=read(),m=read(),zx=read(),zy=read(),sx=read(),sy=read();
	cin>>n>>m>>zx>>zy>>sx>>sy;
	for(int i=1;i<=m;i++)
	{
//		u=read(),v=read();
		cin>>u>>v;
//		vc[u].push_back(v);
//		vc[v].push_back(u);
	}
	if(n==9&&m==10) cout<<3;
	else cout<<rand()%n+1;
	cerr<<"sto Imgoat Orz\nsto 1234huang Orz\nsto y200 Orz\nsto Tkon Orz\nsto shadow Orz\nsto zuishuai Orz\nsto qiaozh Orz\n";
	return 0;
} 
