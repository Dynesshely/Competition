#include<bits/stdc++.h>
using namespace std;
int ttt;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>=10) out(x/10);
	putchar('0'+x%10);
}
int w,s,n;
struct node
{
	int q;
	double v;
	void init()
	{
		q=read();
		cin>>v;
	}
}a[2010];
double dp[2010];
//int tttt;
signed main()
{
//	printf("%.4lf\n",(&tttt-&ttt)/1024.0/1024.0);
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	w=read(),s=read(),n=read();
	for(int i=1;i<=n;i++)
	{
		a[i].init();
	}
	for(int i=1;i<=n;i++)
	{
		dp[i]=1e9;
	}
	dp[1]=s/a[1].v;
	for(int i=2;i<=n;i++)
	{
		double mx=0;
		int sum=0;
		for(int j=i;j>=1;j--)
		{
			sum+=a[j].q;
			mx=max(mx,s/a[j].v);
			if(sum>w) break;
			dp[i]=min(dp[i],dp[j-1]+mx);
		}
	}
	cout<<fixed<<setprecision(2)<<dp[n];
	return 0;
} 
