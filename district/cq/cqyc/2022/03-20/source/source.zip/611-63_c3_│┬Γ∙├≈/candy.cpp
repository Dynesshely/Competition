#include<bits/stdc++.h>
#define int long long
const int MOD=10007;
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>=10) out(x/10);
	putchar('0'+x%10);
}
int quick_pow(int x,int t)
{
	if(t==0) return 1;
	if(t==1) return x;
	int tot=quick_pow(x,t>>1);
	if(t%2==0) return tot*tot%MOD;
	return tot*tot%MOD*x%MOD;
}
int q,x,a;
signed main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	q=read(),x=read();
	for(int i=1;i<=q;i++)
	{
		a=read();
		out((x*quick_pow(2,a)+quick_pow(2,a+1)-2)%MOD);
		putchar(' ');
	}
	return 0;
} 
