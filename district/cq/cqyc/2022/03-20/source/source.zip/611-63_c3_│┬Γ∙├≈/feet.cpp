#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>=10) out(x/10);
	putchar('0'+x%10);
}
int n,x[100010],y[100010],sumx[100010],sumy[100010],ans;
signed main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		x[i]=read(),y[i]=read();
		sumx[x[i]]++;
		sumy[y[i]]++;
	}
	for(int i=1;i<=n;i++)
	{
		ans+=(sumx[x[i]]-1)*(sumy[y[i]]-1);
	}
	cout<<ans;
	return 0;
} 
