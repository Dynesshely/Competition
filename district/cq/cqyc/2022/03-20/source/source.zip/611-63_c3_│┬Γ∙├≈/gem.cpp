#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>=10) out(x/10);
	putchar('0'+x%10);
}
int n,m,c[200010],v[200010],op,a,b,d;
int vis[200010];
signed main()
{
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++)
	{
		c[i]=read(),v[i]=read();
	}
	for(int i=1;i<=m;i++)
	{
		op=read(),a=read(),b=read();
		if(op==1)
		{
			d=read();
			c[a]=b;
			v[a]=d; 
		}
		if(op==2)
		{
			int tot=0,ans=0;
			for(int j=1;j<=n;j++)
			{
				vis[j]=0;
			}
			for(int j=a;j<=n;j++)
			{
				if(vis[c[j]]!=0) tot++;
				if(tot==b+1) break;
				vis[c[j]]=max(vis[c[j]],v[j]);
			}
			for(int j=1;j<=n;j++)
			{
				ans+=vis[j];
			}
			cout<<ans<<'\n';
		}
	}
	return 0;
}
