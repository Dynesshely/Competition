#include <bits/stdc++.h>
using namespace std;
int n;
long long ton[100005], sum[100005], qwq[100005], ans; 
struct pnt{
	int x, y;
}a[100005];
bool comp(pnt A, pnt B) {
	return A.x < B.x;//�Ų���y����νo��o 
}
int main() {
	freopen("feet.in", "r", stdin);
	freopen("feet.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i)
		scanf("%d %d", &a[i].x, &a[i].y), 
		++ton[a[i].x];//ͳ��ͬ�и��� 
	sort(a+1, a+1+n, comp); //���� 
	for(int i = 1; i <= n; ++i) {//����� 
		ans+=(ton[a[i].x]-1)*sum[a[i].y]+qwq[a[i].y];
		qwq[a[i].y]+=ton[a[i].x]-1;
		++sum[a[i].y];
	}
	cout<<ans<<'\n';
	return 0;
} 
