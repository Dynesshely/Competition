/*Begin Again.*/ 
#include <bits/stdc++.h>
using namespace std;
int w, s, n, vis[2005];
double ans;
struct peo{
	int hvy;
	double v;
}a[2005];
bool comp(peo A, peo B) { if(A.v == B.v) return A.hvy < B.hvy; return A.v < B.v; }
int main() {
	freopen("coffee.in", "r", stdin);
	freopen("coffee.out", "w", stdout);
	scanf("%d%d%d", &w, &s, &n);
	for(int i = 1; i <= n; ++i)
		scanf("%d %lf", &a[i].hvy, &a[i].v);
//	sort(a+1, a+1+n, comp);
	for(int i = 1; i <= n; ++i) {
		if(vis[i]) continue;
		vis[i]=1;
		int ws=a[i].hvy;
		double mx=(1.000*s)/a[i].v;
		for(int j = i+1; j <= n; ++j)
			if(ws+a[j].hvy <= w)
				ws+=a[j].hvy, mx=max(mx, (1.000*s)/a[j].v), vis[j]=1;
			else break;
		ans+=mx;
	}
	printf("%.2lf", ans);
	return 0;
} 
