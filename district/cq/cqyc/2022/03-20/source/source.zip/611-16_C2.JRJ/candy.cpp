#include <bits/stdc++.h>
using namespace std;
const int mod=10007;//ȡģ!!! 
int q, x, n;
int main() {
	freopen("candy.in", "r", stdin);
	freopen("candy.out", "w", stdout);
	scanf("%d\n%d", &q, &x);
	while(q--) {
		scanf("%d", &n);
		int qwq=n, qvq=1, ovo=2;
		while(qwq > 0) {//������ 
			if(qwq & 1) qvq = qvq*ovo%mod;//ȡģ!!! 
			ovo = ovo*ovo%mod;//ȡģ!!! 
			qwq >>= 1;
		}
		cout<<((qvq*x)%mod+(qvq*2)%mod-2)%mod<<" ";//ȡģ!!! 
	}
	return 0;
} 
