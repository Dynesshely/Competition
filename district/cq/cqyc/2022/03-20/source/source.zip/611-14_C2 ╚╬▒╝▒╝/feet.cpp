#include <bits/stdc++.h>
#define re register
#define int long long
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(re int i(k) ; i <= n ; i += p)
#define ROF(i,k,n,p) for(re int i(k) ; i >= n ; i -= p)
using namespace std ;
const int N = 1e5+5 ;
int n,ans ;
int a[N],b[N] ;
struct L{int x,y ;}f[N] ;
inline void read(int &x)
{
	x = 0 ; re int f(0) ; re char c= gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
 }
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
signed main()
{
	freopen("feet.in","r",stdin) ;
	freopen("feet.out","w",stdout) ;
	read(n) ;
	FOR(i,1,n,1)
	{
		read(f[i].x),read(f[i].y) ;
		a[f[i].x]++,b[f[i].y]++ ;
	 } 
	FOR(i,1,n,1) ans += (a[f[i].x]-1)*(b[f[i].y]-1) ;
	print(ans) ;
	return 0 ;
}

