#include <bits/stdc++.h>
#define int long long
#define re register
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(re int i(k) ; i <= n ; i += p)
#define ROF(i,k,n,p) for(re int i(k) ; i >= n ; i -= p)
using namespace std ;
const int N = 2e3+5 ;
int w,s,n ;
double dp[N],ans ;
struct per
{
	int q ;
	double v ;
}a[N] ;
inline void read(int &x)
{
	x = 0 ; re int f(0) ; re char c= gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
 }
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
inline int cmp(per x,per y)
{
	return x.v > y.v ;
}
signed main()
{
	freopen("coffee.in","r",stdin) ;
	freopen("coffee.out","w",stdout) ;
	read(w),read(s),read(n) ;
	FOR(i,1,n,1) read(a[i].q),scanf("%lf",&a[i].v) ;
	FOR(i,1,n,1) dp[i] = 1e9+7 ;	
	dp[0] = 0 ;
	FOR(i,1,n,1)
	{
		int sum(0) ;
		double mx(1e9+7) ; 
		ROF(j,i,1,1)
		{
			sum += a[j].q ;
			if(a[j].v < mx) mx = a[j].v ;
			if(sum > w) break ;
			dp[i] = min(dp[i],dp[j-1]+s/mx) ;
		}
	}
	printf("%.2lf",dp[n]) ;
	return 0 ;
}

