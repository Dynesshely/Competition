#include <bits/stdc++.h>
#define re register
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(re int i(k) ; i <= n ; i += p)
#define ROF(i,k,n,p) for(re int i(k) ; i >= n ; i -= p)
#define pb push_back
using namespace std ;
const int N = 1e3+505 ;
int n,m ;
int Xa,Ya,Xb,Yb ;
int t[3][N],le[N],ans[N] ;
struct edge
{
	int x,w; 
	bool operator < (const edge &A) const
	{
		return A.w < w ;
	 } 
} ;
priority_queue<edge>q ;
queue<int>p ; 
vector<edge>e[N] ;
inline void read(int &x)
{
	x = 0 ; re int f(0) ; re char c= gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
 }
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
inline void tg(int x,int f)
{
	FOR(i,0,e[x].size()-1,1)
	{
		int v = e[x][i].x ;
		if(le[v] == le[x]-e[x][i].w) 
		{
			if(f == 1) ans[v] = max(ans[v],ans[x]) ;
			if(f == 1 && t[0][v]) ans[v] = max(ans[v],ans[x]+e[x][i].w) ;
			t[f][v] = 1,tg(v,f) ;
		}
	}
}
inline int find(int st,int ed,int f)
{
	memset(le,0x3f,sizeof(le)) ;
	q.push((edge){st,0}),le[st] = 0 ;
	while(!q.empty())
	{
		edge x = q.top() ;
		q.pop() ;
		if(x.w > le[x.x]) continue ;
		FOR(j,0,e[x.x].size()-1,1)
		{
			int v= e[x.x][j].x ;
			if(le[v] <= x.w+e[x.x][j].w) continue ;
			le[v] = x.w+e[x.x][j].w ;
			q.push((edge){v,le[v]}) ;
		 } 
	}
//	FOR(i,1,n,1) print(le[i]),space ;
//	enter ;
	tg(ed,f) ;
}
//inline void take(int x,int ed,int len)
//{
//	if(x == ed)
//	{
//		ans = max(ans,len) ;
//		return 0 ;
//	}
//	FOR(i,0,e[x].size()-1,1)
//	{
//		int v = e[x][i] ;
//		if(!t[1][v]) continue ;
//		if(t[0][v]) take(v,ed,len+1) ;
//		else take(v,ed,len) ;
//	}
//}
int main()
{
	freopen("2knight.in","r",stdin) ;
	freopen("2knight.out","w",stdout) ;
	read(n),read(m) ;
	read(Xa),read(Ya),read(Xb),read(Yb) ;
	FOR(i,1,m,1)
	{
		int u,v,l ;
		read(u),read(v),read(l) ;
		e[u].pb((edge){v,l}),e[v].pb((edge){u,l}) ; 
	}
	
	find(Xa,Ya,0) ; 
	find(Xb,Yb,1) ;
//	enter,enter ;
//	FOR(i,1,n,1) print(t[1][i]),space ;
//	enter ;
//	FOR(i,1,n,1) print(t[0][i]),space ;
//	enter ;
//	FOR(i,1,n,1) print(ans[i]),space ;
	print(ans[Xb]-1) ;
	return 0 ;
}

