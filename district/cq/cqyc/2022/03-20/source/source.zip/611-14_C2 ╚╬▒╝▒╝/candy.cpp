#include <bits/stdc++.h>
#define int long long
#define re register
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(re int i(k) ; i <= n ; i += p)
#define ROF(i,k,n,p) for(re int i(k) ; i >= n ; i -= p)
using namespace std ;
const int MOD = 1e4+7 ;
int n,q,x,ans ;
inline void read(int &x)
{
	x = 0 ; re int f(0) ; re char c= gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
 }
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
inline int fast_pow(int p,int k)
{
	int sum(1) ;
	p %= MOD ;
	while(k)
	{
		if(k&1) sum = (sum*p)%MOD ;
		p = (p*p)%MOD,k >>= 1 ;
	}
	return sum ;
}
signed main()
{
	freopen("candy.in","r",stdin) ;
	freopen("candy.out","w",stdout) ;
	read(q),read(x) ;
	while(q--)
	{
		read(n) ;
		ans = ((fast_pow(2,n)*x)%MOD+fast_pow(2,n+1)-2+MOD*10)%MOD ;
		print(ans),space ;
	}
	return 0 ;
}

