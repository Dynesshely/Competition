#include <bits/stdc++.h>
#define int long long
#define re register
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(re int i(k) ; i <= n ; i += p)
#define ROF(i,k,n,p) for(re int i(k) ; i >= n ; i -= p)
using namespace std ;
const int N = 1e3+5 ;
int n,m,sum,ans ;
int t[N],mx[N] ;
struct L{int col,val ;}a[N];
inline void read(int &x)
{
	x = 0 ; re int f(0) ; re char c= gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
 }
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
signed main()
{
	freopen("gem.in","r",stdin) ;
	freopen("gem.out","w",stdout) ;
	read(n),read(m) ;
	FOR(i,1,n,1) read(a[i].col),read(a[i].val) ;
	while(m--)
	{
		int op ; read(op) ;
		if(op == 1)
		{
			int x,c,v ;
			read(x),read(c),read(v) ;
			a[x].col = c,a[x].val = v ;
		}
		else 
		{
			int s,k ;
			memset(t,0,sizeof(t)) ;
			memset(mx,0,sizeof(mx)) ;
			sum = ans = 0 ;
			read(s),read(k) ;
			FOR(i,s,n,1)
			{
				t[a[i].col]++ ;
				if(t[a[i].col] > 1) sum++ ;
				if(sum > k) break ;
				ans -= mx[a[i].col] ;
				mx[a[i].col] = max(mx[a[i].col],a[i].val) ;
				ans += mx[a[i].col] ;
			}
			print(ans),enter ;
		 } 
	}
	return 0 ;
}

