#include <bits/stdc++.h>
using namespace std;
int q,x,n,mo=10007;
int qpow(int a) {
	if(a==0) return 1; 
	int b=qpow(a/2);b=b*b;b%=mo;
	if(a%2) {b*=2;b%=mo;}
	return b;
}
int main() {
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d%d",&q,&x);
	for(int i=1;i<=q;i++) {
		scanf("%d",&n);
		printf("%d\n",((qpow(n)*x)%mo+qpow(n+1)+mo-2)%mo);
	}
	return 0;
} 
