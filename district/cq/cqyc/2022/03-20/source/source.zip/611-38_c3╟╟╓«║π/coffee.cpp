#include <bits/stdc++.h>
using namespace std;
int W,S,n;
int w[2020];
double v[2020];
double dp[2020];
int main() {
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d%d%d",&W,&S,&n);
	for(int i=1;i<=n;i++) scanf("%d%lf",&w[i],&v[i]);
	for(int i=1;i<=n;i++) {
		double minn=1e9;dp[i]=1e9;int weigh=0;
		for(int j=i;j>=1;j--) {
			minn=min(minn,v[j]);weigh+=w[j];
			if(weigh>W) break;
			dp[i]=min(dp[i],dp[j-1]+(S/minn));
		}
	}
	printf("%d.",(int)dp[n]);
	printf("%d%d\n",(int)(dp[n]*10)%10,(int)(dp[n]*100)%10);
	return 0;
}
