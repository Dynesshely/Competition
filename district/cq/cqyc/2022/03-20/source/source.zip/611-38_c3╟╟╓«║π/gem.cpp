#include <bits/stdc++.h>
using namespace std;
int n,m;
int col[200010],val[200010];
int ton[200010];
int main() {
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d%d",&col[i],&val[i]);
	int op,a,b,c;
	for(int i=1;i<=m;i++) {
		scanf("%d",&op);
		if(op==1) {
			scanf("%d%d%d",&a,&b,&c);
			col[a]=b;val[a]=c;
		} else {
			scanf("%d%d",&a,&b);
			for(int j=1;j<=n;j++) ton[j]=0;
			int yi=0;
			long long ans=0;
			for(int j=a;j<=n;j++) {
				if(ton[col[j]]) yi++;
				if(yi>b) break;
				ans-=ton[col[j]];ton[col[j]]=max(ton[col[j]],val[j]);
				ans+=ton[col[j]];
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
