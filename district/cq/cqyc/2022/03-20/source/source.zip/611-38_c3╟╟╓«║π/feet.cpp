#include <bits/stdc++.h>
using namespace std;
struct poi {
	int x,y;
} f[100010];
int n;
long long Gx[100010],Gy[100010];
int main() {
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d%d",&f[i].x,&f[i].y);
	for(int i=1;i<=n;i++) Gx[f[i].x]++,Gy[f[i].y]++;
	long long ans=0;
	for(int i=1;i<=n;i++) {
		ans+=(Gx[f[i].x]-1)*(Gy[f[i].y]-1);
	}
	printf("%lld\n",ans);
	return 0;
}
