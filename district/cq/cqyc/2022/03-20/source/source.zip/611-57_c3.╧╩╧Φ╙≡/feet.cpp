#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
struct ok{
	int x,y;
}a[N];
int n,x[N],y[N];
long long ans;
int main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&a[i].x,&a[i].y);
		x[a[i].x]++,y[a[i].y]++;
	}
	for(int i=1;i<=n;i++) ans+=1ll*(x[a[i].x]-1)*(y[a[i].y]-1);
	printf("%lld\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
