#include<bits/stdc++.h>
using namespace std;
const int N=1510,M=6010,inf=0x3f3f3f3f;
struct ok{
	int x,y;
	bool operator <(const ok &A) const{return y>A.y;}
};
int n,m,ans,x[2],y[2],dis[N][N];
int first[N],to[M],nxt[M],lth[M],cnt;
bool biao[N][2];
queue<int>q;
vector<int>from[N];
priority_queue<ok>dijkstra;
inline void inc(int x,int y,int l) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt,lth[cnt]=l;}
void Dijkstra1(bool k)
{
	for(int i=1;i<=n;i++) dis[x[k]][i]=inf;
	dis[x[k]][x[k]]=0;
	dijkstra.push((ok){x[k],0});
	while(!dijkstra.empty())
	{
		int t=dijkstra.top().x,l=dijkstra.top().y;
		dijkstra.pop();
		if(dis[x[k]][t]!=l) continue;
		for(int i=first[t],v;i;i=nxt[i]) if(dis[x[k]][v=to[i]]>dis[x[k]][t]+lth[i])
		{
			from[v].clear();
			from[v].push_back(t);
			dis[x[k]][v]=dis[x[k]][t]+lth[i];
			dijkstra.push((ok){v,dis[x[k]][v]});
		}
		else if(dis[x[k]][v]==dis[x[k]][t]+lth[i]) from[v].push_back(t);
	}
	q.push(y[k]);
	biao[y[k]][k]=true;
	while(!q.empty())
	{
		int t=q.front(),siz=from[t].size();
		q.pop();
		for(int i=0;i<siz;i++)
		{
			biao[from[t][i]][k]=true;
			q.push(from[t][i]);
		}
		from[t].clear();
	}
}
void Dijkstra2(int k)
{
	for(int i=1;i<=n;i++) dis[k][i]=inf;
	dis[k][k]=0;
	dijkstra.push((ok){k,0});
	while(!dijkstra.empty())
	{
		int t=dijkstra.top().x,l=dijkstra.top().y;
		dijkstra.pop();
		if(dis[k][t]!=l) continue;
		for(int i=first[t],v;i;i=nxt[i]) if(dis[k][v=to[i]]>dis[k][t]+lth[i])
		{
			dis[k][v]=dis[k][t]+lth[i];
			dijkstra.push((ok){v,dis[k][v]});
		}
	}
}
int main()
{
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<2;i++) scanf("%d%d",x+i,y+i);
	while(m--)
	{
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		inc(u,v,w),inc(v,u,w);
	}
	Dijkstra1(0),Dijkstra1(1);
	for(int i=1;i<=n;i++) if(i!=x[0]&&i!=x[1]) Dijkstra2(i);
	for(int i=1;i<=n;i++) if(biao[i][0]&&biao[i][1])
	for(int j=1;j<=n;j++) if(biao[j][0]&&biao[j][1]) ans=max(ans,dis[i][j]);
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
