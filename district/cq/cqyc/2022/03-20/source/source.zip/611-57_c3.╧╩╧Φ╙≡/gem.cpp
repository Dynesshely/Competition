#include<bits/stdc++.h>
using namespace std;
const int N=1010;
int n,m,c[N],v[N],biao[N];
long long ans;
int main()
{
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d%d",c+i,v+i);
	while(m--)
	{
		int opt,x,C,V;
		scanf("%d%d%d",&opt,&x,&C);
		if(opt==1)
		{
			scanf("%d",&V);
			c[x]=C,v[x]=V;
		}
		else
		{
			memset(biao,0,sizeof(biao));
			ans=0;
			int tot=0;
			for(;x<=n;x++)
			{
				tot+=(biao[c[x]]>0);
				if(tot>C) break;
				if(v[x]>biao[c[x]]) ans+=v[x]-biao[c[x]],biao[c[x]]=v[x];
			}
			printf("%lld\n",ans);
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
