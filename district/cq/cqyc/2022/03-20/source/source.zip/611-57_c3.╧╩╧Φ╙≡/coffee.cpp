#include<bits/stdc++.h>
using namespace std;
const int N=2010,K=32800;
struct ok{
	int q;
	double v;
	bool operator <(const ok &A) const{return v<A.v;}
}a[N];
int w,n;
double s,k,ans=1e9,dp[N][K];
int main()
{
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d%lf%d",&w,&s,&n);
	for(int i=1;i<=n;i++) scanf("%d%lf",&a[i].q,&a[i].v);
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++) for(int j=0;j<=w;j++) dp[i][j]=1e9;
	dp[1][a[1].q]=s/a[1].v;
	for(int i=2;i<=n;i++)
	{
		dp[i][a[i].q]=k+s/a[i].v;
		k=1e9;
		for(int j=w;j>a[i].q;j--)
		{
			dp[i][j]=min(dp[i][j],dp[i-1][j-a[i].q]);
			k=min(k,dp[i][j]);
		}
	}
	for(int i=0;i<=w;i++) ans=min(ans,dp[n][i]);
	printf("%.2lf\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
