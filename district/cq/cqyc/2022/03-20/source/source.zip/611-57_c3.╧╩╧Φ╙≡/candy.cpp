#include<bits/stdc++.h>
using namespace std;
const int N=5010,K=5003,mod=10007;
int q,n,x,a[N];
int ksm(int k,int y)
{
	int res=1;
	while(y)
	{
		if(y&1) res=res*k%mod;
		k=k*k%mod;
		y>>=1;
	}
	return res;
}
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d%d",&q,&x);
	for(int i=1,p=0;i<=K;i++)
	{
		p=((p+1)<<1)%mod;
		a[i]=p;
	}
	a[0]=a[K];
	while(q--)
	{
		scanf("%d",&n);
		int k=(ksm(2,n)*x+a[n%K])%mod;
		printf("%d\n",k);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
