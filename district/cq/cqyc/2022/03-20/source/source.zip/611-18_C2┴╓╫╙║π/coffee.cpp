#include<bits/stdc++.h>
using namespace std;
int w,s,n,sum,q,l,h;
double ans;
bool fl[2005];
struct ll
{
	int q;
	double v;
} a[2005];
int cmp(ll a,ll b)
{
	if(a.v==b.v) return a.q<b.q;
	return a.v<b.v;
}
int main()
{
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d%d%d",&w,&s,&n),q=w;
	for(int i=1; i<=n; ++i) scanf("%d%lf",&a[i].q,&a[i].v),a[i].v=s*1.0/a[i].v;
	sort(a+1,a+1+n,cmp);
	for(int i=n; i>0; --i)
		if(!fl[i])
		{
			q=0,h=0;
			int j=i;
			while(q+a[j].q<=w && j>0) fl[j]=1,h=h>a[j].v?h:a[j].v,q+=a[j].q,--j;
			ans+=h;
		}
	printf("%.2lf",ans);
	return 0;
}
