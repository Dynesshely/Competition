#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[100005],x,y,ans;
queue<int> q[100005];
signed main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1; i<=n; ++i) scanf("%lld%lld",&x,&y),q[x].push(y),++a[y];
	for(int i=1; i<=100000; ++i)
	{
		int len=q[i].size();
		while(q[i].size()) ans+=(a[q[i].front()]-1)*(len-1),q[i].pop();
	}
	cout<<ans;
	return 0;
}
