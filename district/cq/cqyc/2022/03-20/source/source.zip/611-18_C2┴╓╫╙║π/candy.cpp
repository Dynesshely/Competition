#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=10007;
int q,x,n,g,i;
signed main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%lld%lld",&q,&x);
	while(q--)
	{
		scanf("%lld",&n),g=2;
		for(i=1; i*2<=n; i*=2) g=(g*g)%mod;
		while(i!=n) g=(g*2)%mod,++i;
		cout<<(g*x+g*2-2)%mod<<" ";
	}
	return 0;
}
