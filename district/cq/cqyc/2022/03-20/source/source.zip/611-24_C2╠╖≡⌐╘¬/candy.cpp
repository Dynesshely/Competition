#include<bits/stdc++.h>
using namespace std;
int n,x,sp[1208641],j=0,q;
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>n>>x;
	if(x%2==1) sp[0]=x;
	else sp[0]=1;
	for(int i=1;;i++){
		j++;
		if((sp[j-1]+1)*2%10007==sp[0]) break;
		sp[j]=(sp[j-1]+1)*2%10007;
		//cout<<sp[j]<<endl;
	}
//	cout<<j<<endl;
	for(int i=1;i<=n;i++){
		cin>>q;
		printf("%d ",sp[q%j]);
	}
    //for(int i=1;i<=100;i++) x=(x+1)*2%10007;
    //cout<<x<<endl;
	//for(int i=0;;i++){
	//	if(sp[i]==0){
	//		sp[i]=(sp[i-1]+1)
	//	}
	//}
}
