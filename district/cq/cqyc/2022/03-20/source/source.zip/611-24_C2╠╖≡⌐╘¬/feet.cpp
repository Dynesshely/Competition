#include<bits/stdc++.h>
using namespace std;
int n,x[200000],y[200000];
long long xh[300000],yh[300000];
long long ans=0;
int main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
	scanf("%d%d",&x[i],&y[i]); 
		xh[x[i]]++;
		yh[y[i]]++;
	} 
	for(int i=1;i<=n;i++){
		ans=ans+(xh[x[i]]-1)*(yh[y[i]]-1);
	}
	cout<<ans<<endl;
}
