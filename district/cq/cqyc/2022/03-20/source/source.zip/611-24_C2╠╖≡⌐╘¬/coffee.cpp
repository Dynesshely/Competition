#include<bits/stdc++.h>
using namespace std;
int w,s,n,j,sp3[30000],q=0;
double ans=0,minn,sum=0;
int sp2[30000];
struct jk {
	int wz;
	double vi;
} sp[300000];
bool cmp(jk x,jk y) {
	return double(x.wz)/y.vi<double(y.wz)/x.vi;
}
int main() {
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	cin>>w>>s>>n;
	for(int i=1; i<=n; i++) cin>>sp[i].wz>>sp[i].vi,sp3[i]=114;
	for(int i=1; i<=n; i++) sp[i].vi=double(s)/sp[i].vi,sum=sum+sp[i].vi;
	sort(sp+1,sp+n+1,cmp);
	
	
//	for(int i=1; i<=n; i++) cout<<sp[i].wz<<" "<<sp[i].vi<<endl;
	for(int i=1; i<=n; i++) {
		if(w>=sp[i].wz) {
			sp3[i]=1;
			w=w-sp[i].wz;
			j=i;
		} else break;
	}
	for(int i=j; i<=n;) {
		minn=111451419.0;
		for(int y=1; y<=i; y++) if(sp3[y]==1) minn=min(minn,sp[y].vi);
		for(int y=1; y<=i; y++) if(sp3[y]==1) {
				sp[y].vi=sp[y].vi-minn;
				if(sp[y].vi==0) {
				sp3[y]=0;	
				q++;
				w=w+sp[y].wz;
				}
			}
	//	cout<<minn<<endl;
		ans=ans+minn;
		while(w>=sp[i].wz&&i<n) {
			i++;
			w=w-sp[i].wz;
			sp3[i]=1;
		}
		//if(i==n) break;
		for(int z=1; z<=n; z++) {
			if(sp3[z]==1||sp3[z]==114) break;
			else if(z==n) {
			//	cout<<ans<<" "<<q<<" "<<sum<<endl;
			printf("%.2llf",ans);
				return 0;
			}
		}
	}
}
