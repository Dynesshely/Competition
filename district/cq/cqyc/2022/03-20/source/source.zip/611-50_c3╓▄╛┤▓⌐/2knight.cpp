#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("2knight.in","r",stdin);
//	freopen("2knight.out","w",stdout);
	return 0;
}

