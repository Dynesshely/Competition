#include<bits/stdc++.h>
using namespace std;
int n,x[100010],y[100010];
long long ans=0,cx[100010],cy[100010];
int main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%d%d",x+i,y+i);
		++cx[x[i]];
		++cy[y[i]];
	}
	for(int i=1;i<=n;++i)
	{
		ans+=(cx[x[i]]-1)*(cy[y[i]]-1);
	}
	printf("%lld",ans);
	return 0;
}
