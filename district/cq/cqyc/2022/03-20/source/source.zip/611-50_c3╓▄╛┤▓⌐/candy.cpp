#include<bits/stdc++.h>
#define mod 10007
using namespace std;
int q,x,n;
int ppw[105];//ppw[i]=2^(2^i) %10007
inline int pow2(int b)
{
	int ret=1;
	for(int i=0;b;++i)
	{
		if(b&1) ret*=ppw[i],ret%=mod;
		b>>=1;
	}
	return ret;
}
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	ppw[0]=2;
	for(int i=1;i<=100;++i)
	{
		ppw[i]=ppw[i-1]*ppw[i-1] % mod;
	}
	scanf("%d%d",&q,&x);
	while(q--)
	{
		scanf("%d",&n);
		//ans=2^n*x+2^(n+1)-2
		printf("%d ",(pow2(n)*(x+2)-2)%mod);
	}
	return 0;
}
