#include<bits/stdc++.h>
using namespace std;
int n,m,op,s,c,k,nc[200005],nv[200005],lst[200005],nxt[200005];
unordered_map<int,int> clst,cnxt;
int main()
{
	freopen("gem.in","r",stdin);
//	freopen("gem.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",nc+i);
	}
	for(int i=1;i<=n;++i)
	if(n<=1000)
	{
		while(m--)
		{
			scanf("%d",op);
			if(op==1)
			{
				scanf("%d%d%d",&s,&c,&k);
				
			}
		}
	}
	return 0;
}

