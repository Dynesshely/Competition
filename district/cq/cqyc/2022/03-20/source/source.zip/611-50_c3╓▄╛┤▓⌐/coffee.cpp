#include<bits/stdc++.h>
using namespace std;
int w,s,n,q[2005],wei[2005][2005];
double ans=1e9,v[2005],tim[2005][2005],mn[2005],dp[2005][2005];//ǰi���ˣ���ǰ��������Ϊj 
int main()
{
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d%d%d",&w,&s,&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%d%lf",q+i,v+i);
	}
	for(int i=1;i<=n;++i)
	{
		mn[i]=1e9;
		tim[i][i]=v[i];
		wei[i][i]=q[i];
		for(int j=i+1;j<=n;++j)
		{
			tim[i][j]=min(tim[i][j-1],v[j]);
			wei[i][j]=wei[i][j-1]+q[j];
		}
	}
	for(int i=1;i<=n;++i)
	{
		for(int j=i;j<=n;++j)
		{
			tim[i][j]=s*1.0/tim[i][j];
		}
	}

	for(int i=1;i<=n;++i)
	{
		mn[i]=dp[i][1]=tim[i][i]+mn[i-1];//�Գ�һ��
		for(int j=i-1;j>=1;--j)
		{
			if(wei[j][i]>w) break;
			mn[i]=min(mn[i],dp[i][i-j+1]=tim[j][i]+mn[j-1]);//�͵�j�������Ժ�һ�� 
		}
	}
	for(int i=1;i<=n;++i)
	{
		if(wei[n-i+1][n]>w) break;
		ans=min(ans,dp[n][i]);
	}
	cout<<fixed<<setprecision(2)<<ans;
	return 0;
}

