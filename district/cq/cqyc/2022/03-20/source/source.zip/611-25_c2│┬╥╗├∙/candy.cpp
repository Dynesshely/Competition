#include<bits/stdc++.h>
using namespace std;
long long q,x,sum,num,mod=10007,js,tot=1;
struct zxy{
	long long n,ans,id;
}jl[100005];
inline long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
bool cmp_1(zxy a,zxy b)
{
	return a.n<b.n;
}
bool cmp_2(zxy a,zxy b)
{
	return a.id<b.id;
}
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	q=read(),x=read();
	for(int i=1;i<=q;++i)
		jl[i].n=read(),jl[i].id=i;
	sort(jl+1,jl+q+1,cmp_1);
	sum=x;
	num=1;
	for(int i=1;i<=jl[q].n;++i)
	{
		sum*=2;
		sum%=mod;
		num*=2;
		num%=mod;
		if(i==jl[tot].n)
		{
			jl[tot].ans=sum+num*2-2;
			jl[tot].ans%=mod;
			tot++;
		}
	}
	sort(jl+1,jl+q+1,cmp_2);
	for(int i=1;i<=q;++i)
	printf("%ld ",jl[i].ans);
	return 0;
}
