#include<bits/stdc++.h>
using namespace std;
long long n,ans,yl[100005];
struct zxy{
	long long x,y;
}d[100005];
vector < long long > xl[100005];
inline long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	{
		d[i].x=read(),d[i].y=read();
		xl[d[i].x].push_back(d[i].y);
		yl[d[i].y]++;
	}
	for(int i=1;i<=n;++i)
		for(int j=0;j<xl[d[i].x].size();++j)
		{
			if(d[i].y==xl[d[i].x][j])
			continue;
			ans+=yl[xl[d[i].x][j]]-1;
		}
	printf("%ld",ans);
	return 0;
}
