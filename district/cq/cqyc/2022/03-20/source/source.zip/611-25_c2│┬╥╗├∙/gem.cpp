#include<bits/stdc++.h>
using namespace std;
long long n,m,x,cc,vv,s,k,tp,c[200005],v[200005],ans;
inline long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i)
		c[i]=read(),v[i]=read();
	for(int i=1;i<=m;++i)
	{
		tp=read();
		if(tp==1)
		{
			x=read(),cc=read(),vv=read();
			c[x]=cc,v[x]=vv;
		}
		if(tp==2)
		{
			s=read(),k=read();
			bool jl[200005]={false};
			ans=0;
			for(int j=s;j<=n;++j)
			{
				if(jl[c[j]]==false)
				ans+=v[j],jl[c[j]]=true;
			}
			printf("%ld\n",ans);
		}
	}
	return 0;
}
