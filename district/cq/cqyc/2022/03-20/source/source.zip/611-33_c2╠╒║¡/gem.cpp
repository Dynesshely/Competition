#include<bits/stdc++.h>
using namespace std;
struct zsl{
	int c,v;
}a[200005];
bool b[100005];
int main(){
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout); 
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d%d",&a[i].c,&a[i].v);
	for(int i=1;i<=m;i++){
		int op;
		scanf("%d",&op);
	    if(op==1){
	    	int x,c,v;
	    	scanf("%d%d%d",&x,&c,&v);
	    	a[x].c=c;a[x].v=v;
		}
		if(op==2){
			int s,k;
			long long ans=0;
			scanf("%d%d",&s,&k);
			for(int i=s;i<=n;i++){
				if(b[a[i].c]==1) break;
				b[a[i].c]=1;
				ans+=a[i].v;
			}
			printf("%d\n",ans);
			memset(b,0,sizeof(b));
		}
	}
}
