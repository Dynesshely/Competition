#include<bits/stdc++.h>
using namespace std;
long long quick_power(long long a,long long b){
	long long ans=1,sum=1;
	while(b){
		if(b&1){
			ans=((ans%10007)*(a%10007))%10007; 
		}
		a=((a%10007)*(a%10007))%10007;
		b>>=1;
	}
	return ans;
}
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	int q;
	long long n;
	long long x;
	scanf("%d%lld",&q,&x);
	for(int i=1;i<=q;i++){
		scanf("%lld",&n);
		long long now=quick_power(2,n-1);
		long long b=now*2-1;
		long long www=((2*now*x)%10007+(2*b%10007))%10007;
		printf("%lld ",www);
	}
} 
