#include<bits/stdc++.h>
using namespace std;
struct zsl{
	int x,y,c1,c2;
}a[100005];
bool comp(zsl a,zsl b){
	return a.x<b.x;
}
bool comp1(zsl a,zsl b){
	return a.y<b.y;
}
int main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout); 
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&a[i].x,&a[i].y);
	}
	sort(a+1,a+n+1,comp);
	int js=1;
	int now=1;
	for(int i=1;i<=n;i++){
		if(a[i].x!=a[i+1].x){
			for(int j=now;j<=i;j++) a[j].c1=js;
			now=i+1;
			js=1;
		}
		else{
		    js++;	
		}
	}
	js=1;now=1;
	sort(a+1,a+n+1,comp1);
	for(int i=1;i<=n;i++){
		if(a[i].y!=a[i+1].y){
			for(int j=now;j<=i;j++) a[j].c2=js;
			now=i+1;
			js=1;
		}
		else{
		    js++;	
		}
	}
	long long ans=0;
	for(int i=1;i<=n;i++) ans+=(a[i].c1-1)*(a[i].c2-1);
	printf("%lld",ans);
}
