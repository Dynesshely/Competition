#include<bits/stdc++.h>
using namespace std;
#define mod 10007
int q;
int x;
int n;
int fast_pow(int a,int p)
{
	int ret=1;
	while(p)
	{
		if(p&1)ret=(ret*a)%mod;
		a=(a*a)%mod;
		p>>=1;
	}
	return ret;
}
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d%d",&q,&x);
	while(q--)
	{
		scanf("%d",&n);
		int a=fast_pow(2,n);
		int b=(a*2)%mod;
		int ans=(a*x+b)%mod;
		ans-=2;
		if(ans<0)ans=mod+ans;
		printf("%d ",ans);
	}
	return 0;
}
