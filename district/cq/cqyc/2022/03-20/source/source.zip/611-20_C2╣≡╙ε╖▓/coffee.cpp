#include<bits/stdc++.h>
using namespace std;
#define N 2005
int w,s,n;
int vis[N];
double ans;
struct node{
	int q;
	double v;
}p[N];
int cmp(node a,node b){return a.v<b.v;}
int main()
{
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d%d%d",&w,&s,&n);
	for(int i=1;i<=n;i++)
		cin>>p[i].q>>p[i].v;
	sort(p+1,p+n+1,cmp);
	int w_=w;
	double sp;
	for(int i=1;i<=n;i++)
	{
		if(vis[i])continue;
		w=w_,sp=1e9;
		for(int j=i;j<=n;j++)
		{
			if(p[j].q>w||vis[j])continue;
			w-=p[j].q;
			sp=min(sp,p[j].v);
			vis[j]=1;
		}
		cout<<w<<endl;
		ans+=s*1.0/sp;
	}
	printf("%.2lf",ans);
	return 0;
}
