#include<bits/stdc++.h>
using namespace std;
#define N 100005
int n;
long long ans;
int x[N],y[N];
struct node{
	int x,y;
}pt[N];
int main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&pt[i].x,&pt[i].y);
		x[pt[i].x]++,y[pt[i].y]++;
	}
	for(int i=1;i<=n;i++)
		ans+=(x[pt[i].x]-1)*(y[pt[i].y]-1);
	printf("%d",ans);
	return 0;
}
