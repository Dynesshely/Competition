// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
struct node{
	ll x,z,ord;
};
const ll N=3e2;
vector<node> side[N+10],side2[N+10];
vector<ll> short1[N+10],short2[N+10];
ll n,m,x1,y1,x2,y2,ans=0;
ll lth[N+10],in[N+10];
node ansi[N+10];
bool vis[N+10],viss1[N+10],viss2[N+10];
priority_queue<node> q;
bool operator <(node a,node b){
	return a.z>b.z;
}
//
void tbsort(){
	memset(lth,0,sizeof(lth));
	queue<ll> tbq;
	FOR(i,1,n) if(!in[i]) tbq.push(i);
	while(tbq.size()){
		ll po=tbq.front(); tbq.pop();
		ans=max(ans,lth[po]);
		for(int i=0; i<side2[po].size(); ++i){
			ll tox=side2[po][i].x,toz=side2[po][i].z;
			lth[tox]=max(lth[tox],lth[po]+toz);
			--in[tox];
			if(!in[tox]) tbq.push(tox);
		}
	}
}
void dfs1(ll po){
//	printf("dfs1:%lld\n",po);
	vis[po]=1;
	for(int i=0; i<short1[po].size(); ++i){
		ll aba=short1[po][i];
//		printf("aba%lld\n",aba);
		viss1[aba]=1;
		aba^=1;
		ll toi=ansi[aba].ord,tx=ansi[aba].x;
//		printf("toi%lld tx%lld\n",toi,tx);
		if(!vis[side[po][toi].x]) dfs1(side[po][toi].x);
	}
}
void dfs2(ll po){
//	printf("dfs2:%lld\n",po);
	vis[po]=1;
	for(int i=0; i<short2[po].size(); ++i){
		ll aba=short2[po][i];
//		printf("aba%lld\n",aba);
		viss2[aba]=1;
		aba^=1;
		ll toi=ansi[aba].ord,tx=ansi[aba].x;
//		printf("toi%lld tx%lld\n",toi,tx);
		if(!vis[side[po][toi].x]) dfs2(side[po][toi].x);
	}
}
void csh(){
	memset(lth,0x3f,sizeof(lth));
	memset(vis,0,sizeof(vis));
	q.push((node){x1,0,0});
	lth[x1]=0;
	vis[x1]=1;
	while(q.size()){
		ll po=q.top().x; q.pop();
//		printf("%lld\n",po);
		if(!vis[po]) continue;
		vis[po]=0;
		for(int i=0; i<side[po].size(); ++i){
			ll tox=side[po][i].x,toz=side[po][i].z,toord=side[po][i].ord;
			if(lth[tox]>lth[po]+toz){
				lth[tox]=lth[po]+toz;
				short1[tox].clear();
				short1[tox].pb(toord);
				q.push((node){tox,lth[tox],0});
				vis[tox]=1;
			}
			else if(lth[tox]==lth[po]+toz){
				short1[tox].pb(toord);
			}
		}
	}
//	FOR(i,1,n) printf("%lld ",lth[i]);
//	printf("\n");
	memset(vis,0,sizeof(vis));
	dfs1(y1);
	memset(lth,0x3f,sizeof(lth));
	memset(vis,0,sizeof(vis));
	q.push((node){x2,0,0});
	lth[x2]=0;
	vis[x2]=1;
	while(q.size()){
		ll po=q.top().x;  q.pop();
		if(!vis[po]) continue;
		vis[po]=0;
		for(int i=0; i<side[po].size(); ++i){
			ll tox=side[po][i].x,toz=side[po][i].z,toord=side[po][i].ord;
			if(lth[tox]>lth[po]+toz){
				lth[tox]=lth[po]+toz;
				short2[tox].clear();
				short2[tox].pb(toord);
				q.push((node){tox,lth[tox],0});
				vis[tox]=1;
			}
			else if(lth[tox]==lth[po]+toz){
				short2[tox].pb(toord);
			}
		}
	}
	memset(vis,0,sizeof(vis));
	dfs2(y2);
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	n=gt(),m=gt();
	x1=gt(),y1=gt(),x2=gt(),y2=gt();
	FOR(i,1,m){
		ll t1=gt(),t2=gt(),t3=gt();
		side[t1].pb((node){t2,t3,(i<<1)});
		ansi[(i<<1)]=(node){t1,(ll)side[t1].size()-1,(ll)side[t1].size()-1};
		side[t2].pb((node){t1,t3,(i<<1)|1});
		ansi[(i<<1)|1]=(node){t2,(ll)side[t2].size()-1,(ll)side[t2].size()-1};
	}
	csh();
	FOR(i,1,(m<<1)|1){
		if(viss1[i]){
			ll aba,toi,tox,x,toz;
			aba=i;
			toi=ansi[aba].ord,x=ansi[aba].x;
			tox=side[x][toi].x,toz=side[x][toi].z;
//			printf("%lld %lld %lld\n",x,tox,toz);
			ll t=i/2;
//			if(viss1[t*2]&&viss1[t*2+1]){
//				printf("G1\n");
//				return 0;
//			}
//			if(viss2[t*2]&&viss2[t*2+1]){
//				printf("G2\n");
//				return 0;
//			}
			if(viss2[t*2]){
				aba=t*2;
				toi=ansi[aba].ord,x=ansi[aba].x;
				tox=side[x][toi].x,toz=side[x][toi].z;
				side2[x].pb((node){tox,toz,aba});
				++in[tox];
			}
			if(viss2[t*2+1]){
				aba=t*2+1;
				toi=ansi[aba].ord,x=ansi[aba].x;
				tox=side[x][toi].x,toz=side[x][toi].z;
				side2[x].pb((node){tox,toz,aba});
				++in[tox];
			}
		}
	}
//	printf("\n");
//	FOR(i,1,(m<<1)|1){
//		if(viss2[i]){
//			ll aba=i;
//			ll toi=ansi[aba].ord,x=ansi[aba].x;
//			ll tox=side[x][toi].x,toz=side[x][toi].z;
//			printf("%lld %lld %lld\n",x,tox,toz);
//		}
//	}
	tbsort();
	printf("%lld",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



