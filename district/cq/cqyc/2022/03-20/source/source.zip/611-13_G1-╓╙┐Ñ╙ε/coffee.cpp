// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define ld long double
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
struct node{
	ll q;
	ld v;
};
const ll N=2e3,W=32767;
ld dp[N+10];
node peo[N+10];
//
bool cmp(node a,node b){
	return a.v>b.v;
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	ll w=gt(),s=gt(),n=gt();
	FOR(i,1,n){
		ll q=gt(); ld v;
		scanf("%Lf",&v);
		peo[i]=(node){q,v};
	} 
	FOR(i,1,n) dp[i]=1e18;
	dp[0]=0;
	FOR(i,1,n){
		ll wtot=0;
		ld minv=1e18;
		FOR(j,i,n){
			wtot+=peo[j].q;
			if(wtot>w) break; 
			minv=min(minv,peo[j].v);
			ld t=s; t/=minv;
//			printf("i%lld j%lld\n",i,j);
//			printf("%.2Lf %.2Lf\n",dp[i],dp[i-1]+t);
			dp[j]=min(dp[j],dp[i-1]+t);
		}
	}
//	FOR(i,1,n){
//		printf("%.2Lf ",dp[i]);
//	}
	printf("%.2Lf",dp[n]);
	
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



