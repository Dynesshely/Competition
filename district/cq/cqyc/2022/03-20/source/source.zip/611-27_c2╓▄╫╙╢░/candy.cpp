#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=(long long)1e9,mod=(long long)10007;
int q,x;
signed main() {
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%lld%lld",&q,&x);
	while(q--) {
		int n,ans=0;
		scanf("%lld",&n);
		if(n<=1e6) {//o(n) 80pts
			int k=1,b=0;
			while(b<n) {
				++b;
				k*=2;
				k%=mod;
				ans+=k;
				ans%=mod;
			}
			x%=mod;
			k*=x;
			k%=mod;
			ans+=k;
			ans%=mod;
			printf("%lld ",ans%mod);
			continue;
		}
		
	}
	return 0;
}
