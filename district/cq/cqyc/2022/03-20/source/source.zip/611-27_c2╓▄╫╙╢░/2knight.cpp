//#include <bits/stdc++.h>
//using namespace std;
//const int N=100010,inf=0x3f3f3f3f;
//int n,m,x,xx,y,yy,cnt1=1,cnt2=1;
//vector<int> cti[N],ctw[N];
//vector<int> lj1[N],lj2[N],zz1[N],zz2[N];
//int dis1[N],dis2[N];
//void djstl1() {
//	for(int i=1; i<=n; ++i) dis1[i]=inf;
//	priority_queue<pair<int,int> > dl;
//	dl.push(make_pair(0,x));
//	while(!dl.empty()) {
//		int f=dl.top().second,w=0-dl.top().first;cout<<f<<" "<<w<<endl;
//		dl.pop();
//		for(int i=0; i<cti[f].size(); ++i) 	cout<<ctw[f][i]<<endl;
//		for(int i=0; i<cti[f].size(); ++i) {
//			int ff=cti[f][i];
//			cout<<ctw[f][i]<<endl;
//			int ww=ctw[f][i];
//			cout<<114514<<endl;
//			if(dis1[ff]>dis1[f]+ww) {
//				dis1[ff]=dis1[f]+ww;
//				zz1[ff].clear();
//				zz1[ff].push_back(f);
//				dl.push(make_pair(-dis1[ff],ff));
//			}
//			if(dis1[ff]==dis1[f]+ww) {
//				zz1[ff].push_back(f);
//			}
//		}
//	}
//}
//void djstl2() {
//	for(int i=1; i<=n; ++i) dis2[i]=inf;
//	priority_queue<pair<int,int> > dl;
//	dl.push(make_pair(0,y));
//	while(!dl.empty()) {
//		int f=dl.top().second,w=0-dl.top().first;
//		
//		dl.pop();
//		for(int i=0; i<cti[f].size(); ++i) {
//			int ff=cti[f][i],ww=ctw[f][i];
//			if(dis2[ff]>dis2[f]+ww) {
//				dis2[ff]=dis2[f]+ww;
//				zz2[ff].clear();
//				zz2[ff].push_back(f);
//				dl.push(make_pair(-dis2[ff],ff));
//			}
//			if(dis2[ff]==dis2[f]+ww) {
//				zz2[ff].push_back(f);
//			}
//		}
//	}
//}
//void dfs1(int x) {
//	cnt1*=zz1[x].size();
//	for(int i=0; i<zz1[x].size(); ++i) {
//		dfs1(zz1[x][i]);
//	}
//	for(int i=0; i<cnt1; ++i)
//		lj1[i].push_back(x);
//}
//void dfs2(int x) {
//	cnt2*=zz2[x].size();
//	for(int i=0; i<zz2[x].size(); ++i) {
//		dfs2(zz2[x][i]);
//	}
//	for(int i=0; i<cnt2; ++i)
//		lj2[i].push_back(x);
//}
//int main() {
//	scanf("%d%d%d%d%d%d",&n,&m,&x,&xx,&y,&yy);
//	for(int i=1; i<=m; ++i) {
//		int u,v,w;
//		scanf("%d%d%d",&u,&v,&w);
//		cti[u].push_back(v);
//		ctw[v].push_back(w);
//		cti[v].push_back(u);
//		ctw[v].push_back(w);
//	}
//	djstl1();cout<<114514<<endl;
//	djstl2();
//	
//	dfs1(xx);
//	dfs2(yy);
//	cout<<endl;
//	for(int i=0; i<cnt1; ++i) {
//		for(int j=0; j<lj1[i].size(); ++j) {
//			cout<<lj1[i][j]<<" ";
//		}
//		cout<<endl;
//	}
//	cout<<endl;
//	cout<<endl;
//	for(int i=0; i<cnt2; ++i) {
//		for(int j=0; j<lj2[i].size(); ++j) {
//			cout<<lj2[i][j]<<" ";
//		}
//		cout<<endl;
//	}
//	cout<<endl;
//	return 0;
//}
