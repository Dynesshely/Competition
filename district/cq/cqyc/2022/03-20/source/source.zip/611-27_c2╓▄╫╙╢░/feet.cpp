#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=100100;
int n,ans=0;
int x[N],y[N],tx[N],ty[N];
signed main() {
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%lld",&n);
	for(int i=0; i<=1e5; ++i) tx[i]=ty[i]=0;
	for(int i=1; i<=n; ++i) {
		scanf("%lld%lld",&x[i],&y[i]);
		tx[x[i]]++,ty[y[i]]++;
	}
	for(int i=1; i<=n; ++i) {
		int sx=tx[x[i]]-1,sy=ty[y[i]]-1;
		ans+=(sx*sy);
	}
	printf("%lld",ans);
	return 0;
}
