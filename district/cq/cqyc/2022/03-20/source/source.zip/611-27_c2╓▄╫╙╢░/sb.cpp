#include <bits/stdc++.h>
using namespace std;
int a[1000000001];
int main(){

	return 0;
}
