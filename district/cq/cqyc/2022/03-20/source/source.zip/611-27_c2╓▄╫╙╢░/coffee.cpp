#include <bits/stdc++.h>
#define dou double
using namespace std;
const int N=2001,S=32768;
int n,w,s,q[N];
int gs[N];
//struct {
//	dou val;
//	int zy;
//} dp[N][N];
//int sum[N];//ÿ������ܺ�
//dou mn[N];//ÿ����С
dou ans=1000000000.0;
dou v[N];
//struct Why_you_bully_me {
//	int q/*,pos*/;//q ���� pos ����
//	dou v;//�ٶ�
//} p[N];
//int check(){
//	int sum=0;
//	dou mn[N];
//
//}
//void th() {
//	dou t=100.0;
//	while(t>1e-8){
//		int x=rand()%n+1,y=rand()%n+1;
//		if(x==y) continue;
//		if(sum[p[y].pos]+p[x].q<=w) swap(x,y);
//		if(sum[p[x].pos]+p[y].q>w) continue;
//		int gs=p[y].pos;
//		p[y].pos=p[x].pos;
//		sum[p[x].pos]+=p[y].q,sum[gs]-=p[y].q;
//		dou tot=check(),tep=tot-ans;
//		if(tep>0)
//			if(exp(t)/tep<=RAND_MAX)
//				p[y].pos=gs,sum[p[x].pos]-=p[y].q;
//		t*=0.97;
//	}
//}
void check() {
	dou jj=0.0;
	dou mn[N];
	int sum[N];
	for(int i=1; i<=n; ++i)sum[i]=0,mn[i]=-1.0;
	for(int i=1; i<=n; ++i) {
		mn[gs[i]]=max(v[i],mn[gs[i]]);
		sum[gs[i]]+=q[i];
		if(sum[gs[i]]>w) return;
	}
	for(int i=1; i<=n; ++i) {
		if(mn[i]==-1.0) continue;
		jj+=mn[i];
	}
//	cout<<endl;
//	for(int i=1;i<=n;++i){
//		cout<<i<<": "<<gs[i]<<" "<<mn[gs[i]]<<" "<<sum[gs[i]]<<endl;
//	}
//	cout<<"ans: "<<jj<<endl;
	ans=min(ans,jj);
}
void dfs(int x) {
	if(x==n+1) {
		check();
		return ;
	}
	for(int i=1; i<=n; ++i) {
		gs[x]=i;
		dfs(x+1);
	}
}
int main() {
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
//	srand(time(0));
//	srand((rand()-114+514));
//	srand((rand()-114+514));
//	srand((rand()-114+514));
//	srand((rand()-114+514));
//	cout<<sizeof(dp)/1024/1024+sizeof(p)/1024/1024;
	scanf("%d%d%d",&w,&s,&n);
	dou ss=double(s);
	cout<<ss;
	for(int i=1; i<=n; ++i) {
		cin>>q[i]>>v[i];
		v[i]=ss/v[i];
	}
	dfs(1);
	printf("%.2f",ans);
//		vis[i]=0,p[i].pos=i;
//		int a;
//		dou b;
//		scanf("%d",&a);
//		cin>>b;
//		b=b*((dou)(s));
//		ans+=b;
//		p[i].q=a,p[i].v=b/*,sum[i]+=a*/;
//	}
//	mn[0]=0.0;
//	for(int i=1; i<=n; ++i) {
//		for(int j=1; j<=i; ++j) {
//			cout<<mn[j-1]<<" "<<v[i]<<" "<<mn[j-1]+v[i]<<endl;
//			dp[i][j].val=mn[j-1]+v[i];
//			dp[i][j].zy=q[i];
//			if(dp[i-1][j].zy+q[i]<=w) {
//				int tot=min(dp[i-1][j].val,v[i]);
//				if(tot<dp[i][j].val)
//					dp[i][j].val=tot,dp[i][j].zy=dp[i-1][j].zy+q[i];
//			}
//			mn[j]=min(mn[j],dp[i][j].val);
//			cout<<i<<" "<<j<<" "<<dp[i][j].val<<" "<<dp[i][j].zy<<endl;
//		}
//	}
//	for(int i=1; i<=n; ++i)
//		ans=min(ans,dp[n][i].val);
//	cout<<ans;
//	int ss=clock();
//	while(clock()-ss<=700) {
//		for(int i=1;i<=n;++i) sum[i]=p[i].q,p[i].pos=i;
//		th();
//	}
	return 0;
}
