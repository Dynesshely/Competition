#include <bits/stdc++.h>
using namespace std;
const int N=2e5;
int n,q;
int c[N],v[N];
bool vis[N];
int main(){
		freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;++i) cin>>c[i]>>v[i];
	while(q--){
		int op,x,y,z;
		cin>>op;
		if(op==1){
			cin>>x>>y>>z;
			c[x]=y,v[x]=z;
		}
		if(op==2){
			int sum=0;
			cin>>x>>y;
			for(int i=1;i<=n;++i) vis[i]=0;
			for(int i=x;i<=n;++i){
				if(!vis[c[i]]) sum+=v[i],vis[c[i]]=1;
				else break;
			}
			cout<<sum<<endl;
		}
	}
	return 0;
}
