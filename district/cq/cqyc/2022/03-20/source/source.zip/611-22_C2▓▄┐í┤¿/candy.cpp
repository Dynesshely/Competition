#include<bits/stdc++.h>
using namespace std;
int q,x;
int a[100005];
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>q>>x;
	a[0]=x;
	for(int i=1;i<=100009;++i)
	{
		a[i]=((a[i-1]+1)*2)%10007;
	}
	for(int i=1;i<=q;++i)
	{
		int n;
		scanf("%d",&n); 
		printf("%d ",a[n]);
	}
} 
