#include <bits/stdc++.h>
using namespace std;
int n,ans;
int x[100005],y[100005];
bool hanshu(int a,int b,int c)
{
	if(x[a]==x[b]&&(y[a]==y[c]||y[b]==y[c])) return true;
	if(x[a]==x[c]&&(y[a]==y[b]||y[b]==y[c])) return true;
	if(x[b]==x[c]&&(y[a]==y[c]||y[b]==y[a])) return true;
	return false; 
}
int main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;++i)
		scanf("%d%d",&x[i],&y[i]);
	for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j)
			for(int o=j+1;o<=n;++o)
				if(hanshu(i,j,o)) ans++;
	printf("%d",ans); 
}
