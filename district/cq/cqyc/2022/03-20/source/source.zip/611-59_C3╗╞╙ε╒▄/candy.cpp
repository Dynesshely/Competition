#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod = 1e4+7;
int q,l,n,ans;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
int q_pow(int x,int k)
{
	if(k==0) return 1;
	if(k==1) return x;
	int l = q_pow(x,k/2);
	l = (l*l)%mod;
	if(k&1) return (l*x)%mod;
	return l;
}
signed main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	q = read(),l = read();
	while(q--)
	{
		n = read(),ans = (q_pow(2,n)*l+q_pow(2,n+1)-2)%mod;
		while(ans<0) ans+=mod;
		printf("%lld ",ans);
	}
	return 0;
} 
