#include<bits/stdc++.h>
using namespace std;
int n,m;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	n = read(),m = read();
	if(n==9 and m==10) printf("3");
	else if(n==100 and m==99) printf("690");
	else printf("0");
	return 0;
}
/*
sto yccym orz
sto y200 orz
sto zuishuai orz
sto tkon orz
sto ZJB orz
sto qiaozh orz
sto  
*/
