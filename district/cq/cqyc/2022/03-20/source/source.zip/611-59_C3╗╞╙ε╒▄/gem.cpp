#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 2e5+10;
int n,m,op,l,k,ans;
int c[MAX],v[MAX],vis[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n = read(),m = read();
	for(int i = 1;i<=n;i++) c[i]=read(),v[i]=read();
	while(m--)
	{
		op = read(),l = read(),k = read();
		if(op==1) c[l]=k,v[l]=read();
		else
		{
			memset(vis,0,sizeof(vis));
			ans = 0;
			for(int i = l;i<=n;i++)
			{
				if(!vis[c[i]]) ans+=v[i],vis[c[i]]=v[i];
				else if(k>=1) ans-=vis[c[i]],vis[c[i]]=max(v[i],vis[c[i]]),ans+=vis[c[i]],k--;
				else break;
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}

