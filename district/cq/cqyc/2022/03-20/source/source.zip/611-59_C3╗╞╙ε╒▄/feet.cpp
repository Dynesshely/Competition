#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 1e5+10;
struct node{
	int x,y;
}a[MAX];
int n,ans;
int cx[MAX],cy[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n = read(); 
	for(int i = 1;i<=n;i++)
	{
		a[i]=(node){read(),read()};
		cx[a[i].x]++,cy[a[i].y]++;
	}
	for(int i = 1;i<=n;i++) ans+=(cx[a[i].x]-1)*(cy[a[i].y]-1);
	printf("%lld",ans);
	return 0;
}

