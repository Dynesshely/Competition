#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 2e3+10,W = 4e4,inf = 1e18;
int w,s,n,su;
int q[N];
double ans,ma;
double v[N],dp[N];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	w = read(),s = read(),n = read();
	for(int i = 1;i<=n;i++) 
	{
		cin>>q[i]>>v[i];
		v[i] = (double)s/v[i];
	}
	for(int i = 1;i<=n;i++)
	{
		ma = v[i],su = 0,dp[i] = inf;
		for(int j = i;j>=1;j--)
		{
			ma = max(v[j],ma),su += q[j];
			if(su>w) break;
			dp[i] = min(dp[i],ma+dp[j-1]);
		}
	}
	printf("%.2f",dp[n]);
	return 0;
}

