#include<cstdio>
const int M=1e4+7;
int q,x;
int po(int a,int b){
	int ans=1;
	while(b){
		if(b&1) ans=ans*a%M;
		a=a*a%M;
		b>>=1;
	}
	return ans;
}
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d %d",&q,&x);
	while(q--){
		int a=0;
		scanf("%d",&a);
		printf("%d ",((x*po(2,a)%M+po(2,a+1)-2)%M+M)%M);
	}
	return 0;
}
