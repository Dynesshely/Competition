#include<cstdio>
#include<cstring>
#include<map>
using namespace std;
const int N=1005;
int a[N],b[N],n,m,c[N];
int main(){
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d %d",&a[i],&b[i]);
	for(int i=1;i<=m;i++){
		int pd=0,s=0,u=0,v=0,an=0;
		scanf("%d %d %d",&pd,&s,&u);
		if(pd==1){
			scanf("%d",&v);
			a[s]=u;
			b[s]=v;
			continue;
		}
		long long ans=0;
		memset(c,0,sizeof(c));
		for(int j=s;j<=n;j++){
			if(c[a[j]]){
				if(an==u) break;
				if(b[j]>c[a[j]]){
					ans+=b[j]-c[a[j]];
					c[a[j]]=b[j];
				}
				an++;
			}
			else{
				ans+=b[j];
				c[a[j]]=b[j];
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
