#include<cstdio>
const int N=1e5+5;
int a[N],b[N],n,x[N],y[N];
long long ans;
int main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d %d",&x[i],&y[i]);
		a[x[i]]++;
		b[y[i]]++;
	}
	for(int i=1;i<=n;i++) ans+=1ll*(a[x[i]]-1)*(b[y[i]]-1);
	printf("%lld",ans);
	return 0;
}
