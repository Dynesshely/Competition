#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=1<<15;
int w,s,n,q[15],pd[15];
double dp[N],v[15],sum[N];
int main(){
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d %d %d",&w,&s,&n);
	for(int i=0;i<n;i++) scanf("%d %lf",&q[i],&v[i]);
	for(int i=1;i<(1<<n);i++){
		int ans=0;
		for(int j=0;j<n;j++){
			if((1<<j)&i) ans+=q[j],sum[i]=max(sum[i],s/v[j]);
		}
		if(ans<=w) pd[i]=1;
	}
	for(int i=1;i<(1<<n);i++){
		dp[i]=1e9;
		if(pd[i]) dp[i]=sum[i];
		for(int j=((i-1)&i);j;j=((j-1)&i)){
			if(pd[j]) dp[i]=min(dp[i],sum[j]+dp[i^j]);
		}
	}
	printf("%.2lf",dp[(1<<n)-1]);
	return 0;
}
