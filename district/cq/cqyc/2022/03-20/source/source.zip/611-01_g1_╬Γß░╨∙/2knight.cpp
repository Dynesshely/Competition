#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
const int N=1e4+5;
struct aa{
	int a,b,c;
	aa(){
	}
	aa(int a1,int b1,int c1){
		a=a1;
		b=b1;
		c=c1;
	}
}tu1[N],tu5[N];
int tu2[N],tu6[N],ana[N],anb[N],daa[N],dab[N],an[N],n,m,fra,frb,toa,tob,a[N],b[N],c[N];
struct _a{
	int a,b;
	_a(){
	}
	_a(int a1,int b1){
		a=a1;
		b=b1;
	}
};
struct cmp{
	bool operator ()(_a a,_a b){
		return a.b>b.b;
	}
};
void add(aa* tu1,int *tu2,int a,int b,int c){
	tu1[++tu2[0]]=aa(b,tu2[a],c);
	tu2[a]=tu2[0];
}
void dij(int fr,aa* tu1,int* tu2,int* ans){
	priority_queue<_a,vector<_a>,cmp> no;
	no.push(_a(fr,0));
	ans[fr]=0;
	while(!no.empty()){
		_a now=no.top();
		no.pop();
		if(now.b!=ans[now.a]) continue;
		for(int i=tu2[now.a];i;i=tu1[i].b){
			if(ans[now.a]+tu1[i].c<ans[tu1[i].a]){
				ans[tu1[i].a]=ans[now.a]+tu1[i].c;
				no.push(_a(tu1[i].a,ans[tu1[i].a]));
			}
		}
	}
}
int main(){
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	memset(ana,0x3f,sizeof(ana));
	memset(anb,0x3f,sizeof(anb));
	memset(daa,0x3f,sizeof(daa));
	memset(dab,0x3f,sizeof(dab));
	memset(an,0x3f,sizeof(an));
	scanf("%d %d",&n,&m);
	scanf("%d %d %d %d",&fra,&toa,&frb,&tob);
	for(int i=1;i<=m;i++){
		scanf("%d %d %d",&a[i],&b[i],&c[i]);
		add(tu1,tu2,a[i],b[i],c[i]);
		add(tu1,tu2,b[i],a[i],c[i]);
	}
	dij(fra,tu1,tu2,ana);
	dij(frb,tu1,tu2,anb);
	dij(toa,tu1,tu2,daa);
	dij(tob,tu1,tu2,dab);
	int ann=ana[toa]+anb[tob];
	for(int i=1;i<=m;i++){
		if(ana[a[i]]+anb[a[i]]+daa[b[i]]+dab[b[i]]+c[i]*2==ann) add(tu5,tu6,a[i],b[i],-c[i]);
		if(ana[b[i]]+anb[b[i]]+daa[a[i]]+dab[a[i]]+c[i]*2==ann) add(tu5,tu6,b[i],a[i],-c[i]);
	}
	for(int i=1;i<=n;i++) if(ana[i]+anb[i]+daa[i]+dab[i]==ann) add(tu5,tu6,n+1,i,0);
	dij(n+1,tu5,tu6,an);
	int ans=0;
	for(int i=1;i<=n;i++) ans=max(ans,-an[i]);
	memset(tu5,0,sizeof(tu5));
	memset(an,0x3f,sizeof(an));
	swap(frb,tob);
	for(int i=1;i<=n;i++) swap(anb[i],dab[i]);
	ann=ana[toa]+anb[tob];
	for(int i=1;i<=m;i++){
		if(ana[a[i]]+anb[a[i]]+daa[b[i]]+dab[b[i]]+c[i]*2==ann) add(tu5,tu6,a[i],b[i],-c[i]);
		if(ana[b[i]]+anb[b[i]]+daa[a[i]]+dab[a[i]]+c[i]*2==ann) add(tu5,tu6,b[i],a[i],-c[i]);
	}
	for(int i=1;i<=n;i++) if(ana[i]+anb[i]+daa[i]+dab[i]==ann) add(tu5,tu6,n+1,i,0);
	dij(n+1,tu5,tu6,an);
	for(int i=1;i<=n;i++) ans=max(ans,-an[i]);
	printf("%d",ans);
	return 0;
}
