#include<bits/stdc++.h>
using namespace std;
int main(){	
	srand(time(0));
	freopen("2knight.in","w",stdout);
	int n=1500,m=3000;
	cout<<n<<" "<<m<<"\n";
	int s1=rand()%1499+1,t1=rand()%1499+1,s2=rand()%1499+1,t2=rand()%1499+1;
	cout<<s1<<" "<<t1<<" "<<" "<<s2<<" "<<t2<<"\n";
	pair<int, int> e[1000005];
	map<pair<int, int>, bool> h;
	for(int i = 1; i < n; ++i){
	    int fa = abs(rand())%i + 1;
	    e[i] = make_pair(fa, i + 1);
	    h[e[i]] = h[make_pair(i + 1, fa)] = 1;
	}
	//������ʣ���m-n+1����
	for(int i = n; i <= m; ++i){
	    int x, y;
	    do{
	        x=abs(rand())%n + 1, y = abs(rand())%n + 1;
		}while(x == y || h[make_pair(x, y)]);
	    e[i] = make_pair(x, y);
	    h[e[i]] = h[make_pair(y, x)] = 1;
	}
	//����������
	random_shuffle(e + 1, e + m + 1);
	for(int i = 1; i <= m; ++i)
    	printf("%d %d %d\n", e[i].first, e[i].second, abs(rand())%5+1);
}
