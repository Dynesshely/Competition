#include<bits/stdc++.h>
using namespace std;
int main(){
	while(true){
		system("candy.exe");
		system("test.exe");
		system("maker.exe");
		if(system("fc candy.out test.out")) return 0;
	}
	return 0;
}
