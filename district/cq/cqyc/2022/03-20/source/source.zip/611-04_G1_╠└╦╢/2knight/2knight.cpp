#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,m;
int s1,t1,s2,t2;
bool vis[100005];
int in[100005],dis[100005];
int head[100005],to[100005],val[100005],nxt[100005],tot=0;
void add(int u,int v,int w){
	to[++tot]=v;
	val[tot]=w;
	nxt[tot]=head[u];
	head[u]=tot;
}
int head2[100005],to2[100005],val2[100005],nxt2[100005],tot2=0;
void add2(int u,int v,int w){
	to2[++tot2]=v;
	val2[tot2]=w;
	nxt2[tot2]=head2[u];
	head2[u]=tot2;
}
int dist[15005][6];
struct node{
	int dis,pos;
	bool operator<(const node& x)const{
		return x.dis<dis;
	}
};
void Dijkstra(int sta,int num){
	memset(vis,false,sizeof vis);
	priority_queue<node> q;
	q.push((node){0,sta}); dist[sta][num]=0;
	while(!q.empty()){
		int x=q.top().pos; q.pop();
		if(vis[x]) continue;
		vis[x]=true;
		for(register int i=head[x];i;i=nxt[i]){
			int u=to[i],v=val[i];
			if(dist[u][num]>dist[x][num]+v){
				dist[u][num]=dist[x][num]+v;
				if(!vis[u]) q.push((node){dist[u][num],u});
			}
		}
	}
}
void top_sort(){
	memset(dis,0,sizeof dis);
	stack<int> q;
	for(register int i=1;i<=n;i++){
		if(!in[i]) q.push(i);
	}
	while(!q.empty()){
		int x=q.top(); q.pop();
		for(register int i=head2[x];i;i=nxt2[i]){
			int u=to2[i],v=val2[i];
			dis[u]=max(dis[u],dis[x]+v);
			in[u]--; if(!in[u]) q.push(u);
		}
	}
}
int main(){
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	n=read(),m=read(); int u,v,w;
	s1=read(),t1=read(),s2=read(),t2=read();
	for(register int i=1;i<=m;i++){
		u=read(),v=read(),w=read();
		add(u,v,w); add(v,u,w);
	}
	memset(dist,0x3f,sizeof dist);
	Dijkstra(s1,1);
	Dijkstra(t1,2);
	Dijkstra(s2,3);
	Dijkstra(t2,4);
	for(register int x=1;x<=n;x++){
		for(register int i=head[x];i;i=nxt[i]){
			int u=to[i],v=val[i];
			if(dist[x][1]+v+dist[u][2]==dist[t1][1]&&dist[x][3]+v+dist[u][4]==dist[t2][3]){
				add2(x,u,v); in[u]++;
			}
		}
	}
	top_sort();
	int ans=0;
	for(register int i=1;i<=n;i++){
		ans=max(ans,dis[i]);
	}
	memset(dis,0,sizeof dis); memset(in,0,sizeof in);
	memset(head2,-1,sizeof head2); tot2=1;
	for(register int x=1;x<=n;x++){
		for(register int i=head[x];i;i=nxt[i]){
			int u=to[i],v=val[i];
			if(dist[x][1]+v+dist[u][2]==dist[t1][1]&&dist[x][4]+v+dist[u][3]==dist[t2][3]){
				add2(x,u,v); in[u]++;
			}
		}
	}
	top_sort();
	for(register int i=1;i<=n;i++){
		ans=max(ans,dis[i]);
	}
	printf("%d",ans);
	return 0;
}
