#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
const int mod=10007;
int T,n,x,num;
int ksm(int a,int base){
    int ans=1;
    while(base){
    	if(base%2) ans=ans*a%mod;
    	a=a*a%mod;
    	base>>=1;
	}
	return ans%mod;
}
signed main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	T=read(),x=read();
	while(T--){
		n=read(); num=x;
		printf("%lld ",(ksm(2,n+1)+num*ksm(2,n)-2)%mod);
	}
	return 0;
}
