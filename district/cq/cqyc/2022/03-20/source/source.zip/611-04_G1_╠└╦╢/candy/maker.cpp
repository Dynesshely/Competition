#include<bits/stdc++.h>
using namespace std;
int main(){
	srand(time(0));
	freopen("candy.in","w",stdout);
	int T=1000;
	cout<<T<<"\n";
	int n=1e4;
	cout<<n<<"\n";
	for(register int i=1;i<=T;i++){
		cout<<rand()%9+1<<" ";
	}
	return 0;
}
