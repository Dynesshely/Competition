#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n;
long long ans=0;
int cntx[1000005],cnty[1000005];
struct node{
	int x,y;
}a[100005];
signed main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		a[i].x=read(),a[i].y=read();
		cntx[a[i].x]++;
		cnty[a[i].y]++;
	}
	for(register int i=1;i<=n;i++){
		ans+=(long long)(cntx[a[i].x]-1)*(cnty[a[i].y]-1);
	}
	printf("%lld",ans);
	return 0;
}
