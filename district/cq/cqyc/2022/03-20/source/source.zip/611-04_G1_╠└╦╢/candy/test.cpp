#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=10007;
int T,n,x;
int ksm(int a,int b){
	int ret=1;
	for(register int i=1;i<=b;i++){
		ret=ret*a%mod;
	}
	return ret;
}
signed main(){
	freopen("candy.in","r",stdin);
	freopen("test.out","w",stdout);
	cin>>T>>x;
	while(T--){
		cin>>n; int a=x;
		printf("%lld ",(ksm(2,n+1)+a*ksm(2,n)-2)%mod);
	}
	return 0;
}
