#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,m;
int s1,t1,s2,t2;
bool vis[1505];
int head[100005],to[100005],val[100005],nxt[100005],tot=0;
int dist[1505][1505];
int dis[100005],in[100005];
int head2[100005],to2[100005],val2[100005],nxt2[100005],tot2=1;
struct node{
	int dis,pos;
	bool operator<(const node& x)const{
		return x.dis<dis;
	}
};
void add(int u,int v,int w){
	to[++tot]=v;
	val[tot]=w;
	nxt[tot]=head[u];
	head[u]=tot;
}
void add_top(int u,int v,int w){
	to2[++tot2]=v;
	val2[tot2]=w;
	nxt2[tot2]=head2[u];
	head2[u]=tot2;
}
void Dijkstra(int sta){
	memset(vis,false,sizeof vis);
	priority_queue<node> q; q.push((node){0,sta});
	dist[sta][sta]=0;
	while(!q.empty()){
		int x=q.top().pos; q.pop();
		if(vis[x]) continue;
		vis[x]=true;
		for(register int i=head[x];i;i=nxt[i]){
			int u=to[i],v=val[i];
			if(dist[sta][u]>dist[sta][x]+v){
				dist[sta][u]=dist[sta][x]+v;
				if(!vis[u]) q.push((node){dist[sta][u],u});
			}
		}
	}
}
void top_sort(){
	memset(dis,0,sizeof dis);
	stack<int> q;
	for(register int i=1;i<=n;i++){
		if(!in[i]) q.push(i);
	}
	while(!q.empty()){
		int x=q.top(); q.pop();
		for(register int i=head2[x];i;i=nxt2[i]){
			int u=to2[i],v=val2[i];
			dis[u]=max(dis[u],dis[x]+v);
			in[u]--; if(!in[u]) q.push(u);
		}
	}
}
int main(){
	freopen("2knight.in","r",stdin);
	freopen("test.out","w",stdout);
	n=read(),m=read(); int u,v,w;
	s1=read(),t1=read(),s2=read(),t2=read();
	for(register int i=1;i<=m;i++){
		u=read(),v=read(),w=read();
		add(u,v,w); add(v,u,w);
	}
	memset(dist,0x3f,sizeof dist);
	for(register int i=1;i<=n;i++){
		Dijkstra(i);
	}
	for(register int x=1;x<=n;x++){
		for(register int i=head[x];i;i=nxt[i]){
			int u=to[i];
			if(dist[s1][x]+dist[x][u]+dist[u][t1]==dist[s1][t1]&&dist[s2][x]+dist[x][u]+dist[u][t2]==dist[s2][t2]){
				add_top(x,u,dist[x][u]); in[u]++;
			}
		}
	}
	top_sort();
	int ans=0;
	for(register int i=1;i<=n;i++){
		ans=max(ans,dis[i]);
	}
	memset(dis,0,sizeof dis); memset(in,0,sizeof in);
	memset(head2,-1,sizeof head2); tot2=1;
	for(register int x=1;x<=n;x++){
		for(register int i=head[x];i;i=nxt[i]){
			int u=to[i];
			if(dist[s1][x]+dist[x][u]+dist[u][t1]==dist[s1][t1]&&dist[t2][x]+dist[x][u]+dist[u][s2]==dist[s2][t2]){
				add_top(x,u,dist[x][u]); in[u]++;
			}
		}
	}
	top_sort();
	for(register int i=1;i<=n;i++){
		ans=max(ans,dis[i]);
	}
	printf("%d",ans);
	return 0;
}
