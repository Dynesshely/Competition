#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,m;
int sum=0;
int op,x,c,v,s,k;
struct node{
	int color,value;
}a[200005];
bool check(int l,int r){
	int tmp=2e9;
	for(register int i=l;i<r;i++){
		if(a[i].color==a[r].color) tmp=min(tmp,a[i].value);
	}
	if(tmp<2e9&&k==0) return false;
	if(tmp<2e9){
		k--;
		if(a[r].value>=tmp){
			sum=sum+a[r].value-tmp;
		}
		return false;
	}
	return true;
}
int main(){
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n=read(),m=read();
	for(register int i=1;i<=n;i++){
		a[i].color=read(),a[i].value=read();
	}
	while(m--){
		op=read();
		if(op==1){
			x=read(),c=read(),v=read();
			a[x].color=c,a[x].value=v;
		}
		else {
			s=read(),k=read(); sum=0;
			for(register int i=s;i<=n;i++){
				if(check(s,i)) sum+=a[i].value;
			}
			printf("%d\n",sum);
		}
	}
	return 0;
}
