#include<bits/stdc++.h>
using namespace std;
int main(){
	while(true){
		system("maker.exe");
		system("2knight.exe");
		system("δ����4.exe");
		if(system("fc 2knight.out test.out")) return 0;
	}
	return 0;
}
