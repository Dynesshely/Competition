#include<bits/stdc++.h>
using namespace std;
int main(){
	srand(time(0));
	freopen("test.in","w",stdout);
	int n=100000; cout<<n<<"\n";
	for(register int i=1;i<=n/2;i++){
		cout<<1<<" "<<i<<"\n";
	}
	for(register int i=1;i<=n/2;i++){
		cout<<i+1<<" "<<1<<"\n";
	}
	return 0;
}
