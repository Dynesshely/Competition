#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n;
long long ans=0;
int cntx[1000005],cnty[1000005];
struct node{
	int x,y;
}a[100005];
int calc(int sx,int sy,int ex,int ey){
	return (sx-ex)*(sx-ex)+(sy-ey)*(sy-ey);
}
signed main(){
//	freopen("test.in","r",stdin);
//	freopen("bf.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		a[i].x=read(),a[i].y=read();
	}
	for(register int i=1;i<=n;i++){
		for(register int j=i+1;j<=n;j++){
			for(register int k=j+1;k<=n;k++){
				int a1=calc(a[i].x,a[i].y,a[j].x,a[j].y);
				int a2=calc(a[i].x,a[i].y,a[k].x,a[k].y);
				int a3=calc(a[k].x,a[k].y,a[j].x,a[j].y);
				if(a1+a2==a3||a1+a3==a2||a2+a3==a1) ans++;
			}
		}
	}
	printf("%lld",ans);
	return 0;
}
