#include<bits/stdc++.h>
using namespace std;
const int mod=10007;
const int mx=100001;
int q,x,n,p[100005];
long long ans;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	p[0]=1;
	for(int i=1;i<=mx;i++)
	p[i]=(p[i-1]*2)%mod;
	scanf("%d%d",&q,&x);
	while(q--)
	{
		scanf("%d",&n);
		long long pw=p[n];
		ans=((x*pw)%mod+(pw*2)-2)%mod;
		printf("%lld\n",ans);
	}
	return 0;
}
