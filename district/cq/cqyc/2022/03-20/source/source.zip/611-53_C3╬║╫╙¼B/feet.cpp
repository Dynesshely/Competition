#include<bits/stdc++.h>
using namespace std;
int n,x[100005],y[100005];
int sum[100005];
vector<int> a[100005];
long long ans;
int main()
{
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&x[i],&y[i]);
		sum[y[i]]++;a[x[i]].push_back(i);
	}
	for(int i=1;i<=n;i++)
	for(int j=0;j<a[x[i]].size();j++)
	{
		if(i==a[x[i]][j]) continue;
		ans+=(sum[y[i]]+sum[y[a[x[i]][j]]]-2);
	}
	printf("%lld",ans/2);
	return 0;
}
