#include<bits/stdc++.h>
using namespace std;
struct node{
	int q;
	double v;
}a[2005];
int w,s,n,wh;
double x,ans=1e9,sum,ti;
bool flag;
int main()
{
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d%d%d",&w,&s,&n);
	for(int i=0;i<n;i++)
	{
		cin>>a[i].q>>x;
		a[i].v=(double)s/x;
	}
	int mx=(1<<n)-1;
	for(int i=0;i<=mx/2;i++)
	{
		wh=0,ti=0,sum=0,flag=0;
		for(int j=0;j<=n;j++)
		{
			if(j==0) wh=a[j].q,ti=a[j].v;
			if(j==n) {sum+=ti;break;}
			if((j>0 && (i>>j&1)!=(i>>(j-1)&1)))
			wh=a[j].q,sum+=ti,ti=a[j].v;
			else 
			{
				wh+=a[j].q;
				if(wh>w){flag=1;break;}
				ti=max(ti,a[j].v);
			}
		}
		if(flag==0) ans=min(ans,sum);
	}
	printf("%.2lf",ans);
	return 0;
}
/*
800 300 4
53 5.3
59 3.4
38 2.1
69 2.1
*/
