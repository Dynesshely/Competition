#include<bits/stdc++.h>
using namespace std;
#define int long long

const int Maxn=5e4+10;
int N,M,Vis[Maxn];
struct node{
	int c,v;
}Gem[Maxn];

void Solve(int S,int k){
	int ans=0;
	memset(Vis,0,sizeof Vis);
	for(int i=S;;i++){
		int c=Gem[i].c,v=Gem[i].v;
		if(Vis[c]){
			if(!k) break;
			--k;
			if(Gem[Vis[c]].v<v)
				ans=ans-Gem[Vis[c]].v+v,Vis[c]=i;
		}else Vis[c]=i,ans+=Gem[i].v;
	}
	printf("%lld\n",ans);
}

signed main(){
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	scanf("%lld %lld",&N,&M);
	for(int i=1;i<=N;i++)
		scanf("%lld %lld",&Gem[i].c,&Gem[i].v);
	while(M--){
		int sgn; scanf("%lld",&sgn);
		if(sgn==1){
			int x,c,v; scanf("%lld %lld %lld",&x,&c,&v);
			Gem[x].c=c,Gem[x].v=v;
		}else{
			int S,k; scanf("%lld %lld",&S,&k);
			if(!k){
				int ans=0;
				memset(Vis,0,sizeof Vis);
				for(int i=S;;i++){
					if(Vis[Gem[i].c]) break;
					Vis[Gem[i].c]=i,ans+=Gem[i].v;
				}
				printf("%lld\n",ans);
			}
			else Solve(S,k);
		}
	}
	return 0;
}
