#include<bits/stdc++.h>
using namespace std;
#define int long long

const int Maxn=1e5+10;
int N,ans,S1[Maxn],S2[Maxn];
struct node{
	int x,y;
}Point[Maxn];

signed main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%lld",&N);
	for(int i=1;i<=N;i++){
		scanf("%lld %lld",&Point[i].x,&Point[i].y);
		S1[Point[i].x]++,S2[Point[i].y]++;
	} 
	for(int i=1;i<=N;i++){
		int x=Point[i].x,y=Point[i].y;
		ans+=(S1[x]-1)*(S2[y]-1);
	}
	printf("%lld",ans);
	return 0;
}
