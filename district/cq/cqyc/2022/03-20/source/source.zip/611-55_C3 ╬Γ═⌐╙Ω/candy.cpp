#include<bits/stdc++.h>
using namespace std;
#define int long long

const int Maxn=1e5+10;
const int Mod=10007;
int Q,x,n,ans[Maxn];

int power(int x,int d){
	int ret=1;
	while(d){
		if(d&1) ret=ret*x%Mod;
		x=(x*x)%Mod; 
		d>>=1;
	}
	return ret%Mod;
}

signed main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%lld %lld",&Q,&x); x%=Mod;
	for(int n,i=1;i<=Q;i++){
		scanf("%lld",&n);
		ans[i]=(power(2,n-1)*x%Mod+power(2,n)%Mod-1)%Mod;
	}
	for(int i=1;i<=Q;i++) printf("%lld ",ans[i]*2%Mod);
	return 0;
}
