#include<bits/stdc++.h>
using namespace std;
#define int long long
#define ls (x<<1)
#define rs ((x<<1)|1)
#define mid ((l+r)>>1)

const int INF=1000000000;
const int Maxn=2010;
int W,S,N,Q[Maxn];
double V[Maxn],dp[Maxn],Tree[Maxn<<2];

void Build(int x,int l,int r){
	if(l==r){ Tree[x]=V[l]; return; }
	Build(ls,l,mid); Build(rs,mid+1,r);
	Tree[x]=max(Tree[ls],Tree[rs]);
}

double Query(int x,int l,int r,int L,int R){
	if(L<=l&&R>=r) return Tree[x];
	double ret=0;
	if(L<=mid) ret=max(ret,Query(ls,l,mid,L,R));
	if(R>mid) ret=max(ret,Query(rs,mid+1,r,L,R));
	return ret;
}

signed main(){
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%lld %lld %lld",&W,&S,&N);
	for(int i=1;i<=N;i++){
		scanf("%lld",Q+i); cin>>V[i];
		V[i]=S/V[i];
	}
	Build(1,1,N);
	for(int i=1;i<=N;i++) dp[i]=INF;
	dp[0]=0; dp[1]=V[1]; 
	for(int i=1;i<=N;i++){
		int sum=Q[i];
		dp[i]=dp[i-1]+V[i];
		for(int j=i-1;j;j--){
			sum+=Q[j];
			if(sum>W) break;
			dp[i]=min(dp[i],dp[j-1]+Query(1,1,N,j,i));
		}
	}
	printf("%.2f",dp[N]);
	return 0;
}

