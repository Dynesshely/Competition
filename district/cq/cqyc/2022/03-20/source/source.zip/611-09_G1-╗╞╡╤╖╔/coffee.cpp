#include<bits/stdc++.h>
#define ldb long double
#define N 4003
#define maxn 1e9
using namespace std;
ldb dp[N];
int W,S,n;
int w[N],v[N];

int main(){
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	
	scanf("%d%d%d",&W,&S,&n);
	for(int i=1;i<=n;i++){
		ldb x;cin>>w[i]>>x;
		v[i]=x*10;
	}

	for(int i=1;i<=n;i++) dp[i]=maxn;
	for(int i=1;i<=n;i++){
		int Min=v[i],Sum=w[i];
		for(int j=i-1;j>=0;j--){
			if(Sum>W) break;
			dp[i]=min(dp[i],dp[j]+S*1.0/Min);
			Min=min(Min,v[j]),Sum+=w[j];
		}
	}
	
	cout<<fixed<<setprecision(2)<<dp[n]*10.0<<endl;
	return 0;
}

