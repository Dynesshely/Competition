#include<bits/stdc++.h>
#define ll long long
#define N 200005
using namespace std;
int n,m;
int col[N];
int lst[N],nxt[N];
ll v[N],bck[N];

inline int read(){
	int s=0;char c=getchar();
	while(c<48||c>57) c=getchar();
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

void write(ll x){
	if(x>9) write(x/10);
	putchar(x%10+48);
}

int main(){
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	
	n=read(),m=read();
	for(int i=1;i<=n;i++) col[i]=read(),v[i]=read();
	
	if(m<=1000){
		while(m--){
			int ope=read(),x=read();
			if(ope==1) col[x]=read(),v[x]=read();
			else{
				int k=read(),i=x; ll ans=0;
				for(i;i<=n;i++){
					ll num=bck[col[i]];
					if(!num) bck[col[i]]=v[i],ans+=v[i];
					else if(k) k--,ans-=num,ans+=bck[col[i]]=max(num,v[i]);
					else break;
				}
				for(int j=x;j<=i;j++) bck[col[j]]=0;
				write(ans),puts("");
			}
		}
		return 0;
	}
	
	for(int i=1;i<=n;i++) {
		int y=bck[col[i]];
		lst[i]=y,nxt[y]=i,bck[col[i]]=i;
	}
	
	
	
	
	return 0;
}

