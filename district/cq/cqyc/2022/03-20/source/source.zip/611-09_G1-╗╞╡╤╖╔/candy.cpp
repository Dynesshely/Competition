#include<bits/stdc++.h>
#define ll long long 
#define maxn 10007
using namespace std;

int q,x;
ll quick_power(ll base,ll power){
	ll s=1;
	while(power) {
		if(power&1) s=s*base%maxn;
		base=base*base%maxn,power>>=1;
	}
	return s;
}

int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	
	scanf("%d%d",&q,&x);
	int n;ll ans;
	while(q--){
		scanf("%d",&n);
		ans=quick_power(2,n)*(x+2)-2;
		ans=(ans%maxn+maxn)%maxn;
		printf("%lld ",ans);
	}
	return 0;
}
