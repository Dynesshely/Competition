#include<bits/stdc++.h>
#define ll long long
#define N 200005
using namespace std;
int n,m;
int col[N];
int lst[N],nxt[N];
ll v[N],bck[N];

inline int read(){
	int s=0;char c=getchar();
	while(c<48||c>57) c=getchar();
	while(c>=48&&c<=57) s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

void write(ll x){
	if(x>9) write(x/10);
	putchar(x%10+48);
}


struct SeTr{
	int Max[4*N];
	int build(int i,int l,int r){
		if(l==r) return Max[i]=lst[l];
		int mid=l+r>>1;
		return Max[i]=max(build(i<<1,l,mid),build((i<<1)+1,mid+1,r));
	}
	void change(int i,int l,int r,int pos,int x){
		if(pos<1||pos>n) return;
		if(l==r) {Max[i]=x;return;}
		int mid=l+r>>1;
		if(pos<=mid) change(i<<1,l,mid,pos,x);
		if(pos>mid) change((i<<1)+1,mid+1,r,pos,x);
		Max[i]=max(Max[i<<1],Max[(i<<1)+1]);
	}
	int find(int i,int l,int r,int L,int R){
		if(L<=l&&r<=R) return Max[i];
		int mid=l+r>>1,maxn=0;
		if(L<=mid) maxn=max(maxn,find(i<<1,l,mid,L,R));
		if(R>mid) maxn=max(maxn,find((i<<1)+1,mid+1,r,L,R));
		return maxn;
	}
}ST;

struct Setr{
	ll Sum[4*N];
	ll build(int i,int l,int r){
		if(l==r) return Sum[i]=v[l];
		int mid=l+r>>1;
		return Sum[i]=build(i<<1,l,mid)+build((i<<1)+1,mid+1,r);
	}
	void change(int i,int l,int r,int pos,int x){
		if(l==r) {Sum[i]=x;return;}
		int mid=l+r>>1;
		if(pos<=mid) change(i<<1,l,mid,pos,x);
		else change((i<<1)+1,mid+1,r,pos,x);
		Sum[i]=Sum[i<<1]+Sum[(i<<1)+1];
	}
	ll find(int i,int l,int r,int L,int R){
		if(L<=l&&r<=R) return Sum[i];
		int mid=l+r>>1;ll ans=0;
		if(L<=mid) ans+=find(i<<1,l,mid,L,R);
		if(R>mid) ans+=find((i<<1)+1,mid+1,L,R);
		return ans;
	}
}St;

int ask(int pos,int L){
	int l=pos,r=n,mid;
	while(l<=r){
		mid=l+r>>1;
		if(l==r) return mid;
		if(ST.find(1,1,n,pos,mid)>=L) r=mid;
		else l=mid+1;
	}
	return n+1;
}

set<int> s[N];
#define IT set<int>::iterator
void del(int x){
	int l=lst[x],r=nxt[x];
	nxt[l]=r,lst[r]=l;
	ST.change(1,1,n,r,l);
	s[col[x]].erase(x);
}
void add(int x){
	int c=col[x],r,l;
	IT it=s[c].upper_bound(x); r=(*it),l=lst[r];
	nxt[l]=x,lst[x]=l,nxt[x]=r,lst[r]=x;
	ST.change(1,1,n,x,l),ST.change(1,1,n,r,x);
	s[c].insert(x);
}


int main(){
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	
	n=read(),m=read();
	for(int i=1;i<=n;i++) s[col[i]=read()].insert(i),v[i]=read();
	for(int i=1;i<=n;i++) s[i].insert(0),s[i].insert(n+1);
	
	for(int i=1;i<=n;i++) {
		int y=bck[col[i]];
		lst[i]=y,nxt[y]=i,nxt[i]=n+1,bck[col[i]]=i;
	}
	
	ST.build(1,1,n);
	St.build(1,1,n);
	
	while(m--){
		int ope=read(),x=read();
		if(ope==1){
			int c=read();St.change(1,1,n,x,v[x]=read());
			del(x),col[x]=c,add(x);
		}
		else{
			
		}
	}
	
	
	return 0;
}

