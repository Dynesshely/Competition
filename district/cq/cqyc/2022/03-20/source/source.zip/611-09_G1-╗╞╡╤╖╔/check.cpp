#include<bits/stdc++.h>
using namespace std;
int main(){
system("fc gem.out gem2.out");
	return 0;
}

