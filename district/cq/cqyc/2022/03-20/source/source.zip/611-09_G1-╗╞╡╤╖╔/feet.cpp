#include<bits/stdc++.h>
#define ll long long
#define N 200005
using namespace std;
int n,Maxx;
ll cnty[N];
vector<int> pos[N];

int main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		cnty[y]++,Maxx=max(Maxx,x);
		pos[x].push_back(y);
	}
	
	ll ans=0;
	for(int i=1;i<=Maxx;i++){
		if(pos[i].empty()) continue;
		sort(pos[i].begin(),pos[i].end());
		ll sum=0;
		for(int j=0;j<pos[i].size();j++){
			int y=pos[i][j];
			ans+=(cnty[y]-1)*j;
			ans+=sum;
			sum+=cnty[y]-1;
		}
	}
	
	printf("%lld",ans);
	
	return 0;
}

