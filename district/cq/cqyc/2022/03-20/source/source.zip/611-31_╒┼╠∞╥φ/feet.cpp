#include <bits/stdc++.h>

const int maxn = 100001;

int N, X[maxn], Y[maxn], numX[maxn], numY[maxn];
std::vector<int> xys[maxn], yxs[maxn];
unsigned long long ans = 0;
int main(){
//	freopen("feet.in", "r", stdin);
//	freopen("feet.out", "w", stdout);
	scanf("%d", &N);
	for(int i = 1; i <= N; ++i){
		scanf("%d %d", &X[i], &Y[i]);
		++numX[X[i]], ++numY[Y[i]];
		xys[X[i]].push_back(Y[i]);
		yxs[Y[i]].push_back(X[i]);
	}
	for(int i = 1; i < maxn; ++ i){
		if(numX[i]){
//			ans += (xys[i].size() - 1) * (yxs[i].size() - 1);
			
		}
	}
	
//	for(int i = 1; i < maxn; ++ i){
//		if(numY[i] != 0){
//			ans += numX[numYi[i]];
//		}
//	}
//	for(int i = 1; i < maxn; ++ i){
//		if(numX[i] != 0){
//			ans += numY[numXi[i]];
//		}
//	}
	printf("%lld\n", ans);
	return 0;
}
