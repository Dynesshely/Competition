#include<bits/stdc++.h>
using namespace std;
long long n,m,c[200005],v[200005],t1,t2,t3,t4,mx[200005],ans,tot;
vector<long long> e;
bitset<200005> vis;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(long long s){
	char f[20];long long cnt=0;
	if(s<0) s=-s,putchar('-');
	if(s==0){
		putchar('0');
		return;
	}
	while(s) {f[++cnt]=s%10;s/=10;}
	while(cnt) putchar(f[cnt--]+'0');
}
int main(){
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n=read(),m=read();
	for(long long i=1;i<=n;i++){
		c[i]=read(),v[i]=read();
	} 
	for(long long i=1;i<=m;i++){
		t1=read();
		if(t1==1){
			t2=read(),t3=read(),t4=read();
			c[t2]=t3;v[t2]=t4;
		}
		else{
			t2=read(),t3=read();
			ans=tot=0;
			for(long long j=t2;j<=n;j++){
				if(!vis[c[j]]){
					vis[c[j]]=1;
					e.push_back(c[j]);
					mx[c[j]]=v[j];
				}
				else{
					if(tot==t3) break;
					mx[c[j]]=max(mx[c[j]],v[j]),tot++;
				} 
			}
			for(long long j=e.size()-1;j>=0;j--){
				ans+=mx[e[j]];
				vis[e[j]]=mx[e[j]]=0;
				e.pop_back();
			}
			write(ans);
			putchar('\n');
		}
	}
	return 0;
}

