#include<bits/stdc++.h>
using namespace std;
int n,m,w,ans=0,t1,t2,t3,t4,u,v,z,cnt=0,tnt=0,head[1505],nxt[6005],txt[6005],zhi[6005],dis[1505],sum[3000005];
struct ok{
	int d,z;
	bool operator < (const ok &A) const{
		return z>A.z;
	}
};
priority_queue<ok> q;
vector<int> g,e[3005],h;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs(int k,int ww){
	if(ww>dis[t1]) return;
	if(k==t2&&ww==dis[t1]){
		tnt++;
		for(int i=0;i<g.size();i++){
			if(g[i]&1) w=(g[i]+1)>>1;
			else w=g[i]>>1;
			e[w].push_back(tnt);
		}
		return;
	}
	for(int i=head[k];i;i=nxt[i]){
		if(dis[txt[i]]>=dis[k]) continue;
		g.push_back(i);
		dfs(txt[i],ww+zhi[i]);
		g.pop_back();
	}
}
void dfs2(int k,int ww){
	if(ww>dis[t3]) return;
	if(k==t4&&ww==dis[t3]){
		int mx=0;
		for(int i=0;i<g.size();i++){
			if(g[i]&1) w=(g[i]+1)>>1;
			else w=g[i]>>1;
			for(int j=0;j<e[w].size();j++){
				if(!sum[e[w][j]]) h.push_back(e[w][j]);
				sum[e[w][j]]+=zhi[w<<1];
			}
		}
		for(int i=h.size()-1;i>=0;i--){
			mx=max(mx,sum[h[i]]);
			sum[h[i]]=0;
			h.pop_back();
		}
		ans=max(ans,mx);
		return;
	}
	for(int i=head[k];i;i=nxt[i]){
		if(dis[txt[i]]>=dis[k]) continue;
		g.push_back(i);
		dfs2(txt[i],ww+zhi[i]);
		g.pop_back();
	}
}
int main(){
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	n=read(),m=read();
	t1=read(),t2=read(),t3=read(),t4=read();
	for(int i=1;i<=m;i++){
		u=read(),v=read(),z=read();
		nxt[++cnt]=head[u],head[u]=cnt,txt[cnt]=v,zhi[cnt]=z;
		nxt[++cnt]=head[v],head[v]=cnt,txt[cnt]=u,zhi[cnt]=z;
	}
	memset(dis,0x3f,sizeof(dis));
	dis[t2]=0;
	q.push((ok){t2,0});
	while(!q.empty()){
		ok t=q.top();q.pop();
		if(t.z>dis[t.d]) continue;
		for(int i=head[t.d];i;i=nxt[i]){
			if(t.z+zhi[i]<=dis[txt[i]]){
				dis[txt[i]]=t.z+zhi[i];
				q.push((ok){txt[i],dis[txt[i]]});
			}
		}
	}
	dfs(t1,0);
	memset(dis,0x3f,sizeof(dis));
	dis[t4]=0;
	q.push((ok){t4,0});
	while(!q.empty()){
		ok t=q.top();q.pop();
		if(t.z>dis[t.d]) continue;
		for(int i=head[t.d];i;i=nxt[i]){
			if(t.z+zhi[i]<=dis[txt[i]]){
				dis[txt[i]]=t.z+zhi[i];
				q.push((ok){txt[i],dis[txt[i]]});
			}
		}
	}
	dfs2(t3,0);
	printf("%d",ans);
	return 0;
}

