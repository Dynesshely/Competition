#include<bits/stdc++.h>
using namespace std;
long long n,a[100005],b[100005],sx[100005],sy[100005],ans=0;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	n=read();
	for(long long i=1;i<=n;i++){
		a[i]=read(),b[i]=read();
		sx[a[i]]++;sy[b[i]]++;
	}
	for(long long i=1;i<=n;i++) ans=ans+(sx[a[i]]-1)*(sy[b[i]]-1);
	printf("%lld",ans);
	return 0;
}

