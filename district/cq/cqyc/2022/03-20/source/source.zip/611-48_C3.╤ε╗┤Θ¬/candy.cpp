#include<bits/stdc++.h>
#define M 10007
using namespace std;
long long q,x,a,t1,t2,ans;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(long long s){
	char f[10];long long cnt=0;
	if(s<0) s=-s,putchar('-');
	if(s==0){
		putchar('0');
		return;
	}
	while(s) {f[++cnt]=s%10;s/=10;}
	while(cnt) putchar(f[cnt--]+'0');
}
long long ksm(long long k,long long c){
	if(!c) return 1%M;
	if(c==1) return k%M;
	long long t=ksm(k,(c>>1))%M;
	if(c&1) return (((t*t)%M)*k)%M;
	return (t*t)%M;
}
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	q=read();
	x=read();
	for(long long i=1;i<=q;i++){
		a=read()%M;
		t1=ksm(2,a);t2=(t1*2)%M;
		ans=(((t1*x)%M)+t2-2+M)%M;
		write(ans);
		putchar(' ');
	} 
	return 0;
}
