#include<bits/stdc++.h>
using namespace std;
int n,w,s,b[2005];
double ans=0.0,dp[2005],m;
struct ok{
	int q;
	double v;
}a[2005];
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main(){
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	w=read(),s=read(),n=read();
	for(int i=1;i<=n;i++){
		a[i].q=read();cin>>a[i].v;
		b[i]=b[i-1]+a[i].q;
	}
	for(int i=1;i<=n;i++) dp[i]=1e9;
	dp[1]=((double)s)/a[1].v;
	for(int i=2;i<=n;i++){
		m=a[i].v;
		for(int j=i-1;j>=0;j--){
			if((b[i]-b[j])>w) break;
			dp[i]=min(dp[i],dp[j]+((double)s)/m);
			m=min(m,a[j].v);
		}
	}
	cout<<fixed<<setprecision(2)<<dp[n];
	return 0;
}

