#include<bits/stdc++.h>
#define int long long
#define N 2005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,m,X,Y,A,B,ans,dis[N];
int head[N],nxt[N<<1],to[N<<1],w[N<<1],t;
bitset<N> sh[N],vis;
inline void add(int c,int v,int u){
	nxt[++t]=head[u];head[u]=v;to[t]=v;w[t]=c;
	nxt[++t]=head[v];head[v]=u;to[t]=u;w[t]=c;
}
struct node{
	int x,dis;
	bool operator<(const node &y)const{
		return dis>y.dis;
	}
} d[N];
inline void dijstra(int u,int v){
	priority_queue<node> P;
	P.push((node){u,0});
	memset(dis,0x3f,sizeof(dis));
	vis=0;
	dis[u]=0;
	while(!P.empty()){
		node x=P.top();
		P.pop();
		if(vis[x.x])
			continue;
		if(x.x==v)
			return;
		vis[x.x]=1;
		for(int i=head[x.x];i;i=nxt[i])
			if(dis[to[i]]>dis[x.x]+w[i]){
				dis[to[i]]=dis[x.x]+w[i];
				P.push((node){to[i],dis[to[i]]});
			} 
	}
}
inline bool dfs(int u,int v,bool s){
	if(u==v)
		return 1;
	for(int i=head[u];i;i=nxt[i])
		if(!vis[to[i]]&&dis[u]+w[i]==dis[to[i]]){
			vis[to[i]]=1;
			if(dfs(to[i],v,s)){
				if(s)
					sh[u][to[i]]=sh[to[i]][u]=1;
				else
					if(sh[u][to[i]])
						ans+=w[i];
				return 1;
			}
			vis[to[i]]=0;
		}
	return 0;
}
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	n=read();m=read();
	X=read();Y=read();A=read();B=read();
	for(int i=1;i<=m;++i){
		add(read(),read(),read());
	}
	dijstra(X,Y);
	for(int i=1;i<=n;++i)
		cout<<dis[i]<<" ";
	vis=0;
	vis[X]=1;
	dfs(X,Y,1);
	dijstra(A,B);
	vis=0;
	vis[A]=1;
	dfs(A,B,0);
	write(ans);
	return 0;
}
