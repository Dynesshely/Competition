#include<bits/stdc++.h>
#define int long long
#define N 2005
using namespace std;
int w,n,c,sum[N];
double s,b,ans,mx[N][N],dp[N];
struct node{
	int q;
	double t;
	bool operator<(const node &x)const{
		return t>x.t;
	}
} a[N];
signed main(){
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%lld%lf%lld",&w,&s,&n);
	for(int i=1;i<=n;++i){
		scanf("%lld%lf",&c,&b);
		a[i].q=c;a[i].t=s/b;
		sum[i]=sum[i-1]+a[i].q;
	}
	for(int i=1;i<=n;++i){
		double MX=0;
		for(int j=i;j<=n;++j){
			MX=max(MX,a[j].t);
			mx[i][j]=MX;
		}
		dp[i]=1e9;
	}
	for(int i=1;i<=n;++i){
		for(int j=0;j<i;++j)
			if(sum[i]-sum[j]<=w)
				dp[i]=min(dp[i],dp[j]+mx[j+1][i]);
	}
	printf("%.2lf",dp[n]);
	return 0;
}
