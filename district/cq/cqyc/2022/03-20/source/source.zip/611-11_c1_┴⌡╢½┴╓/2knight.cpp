#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
#include <algorithm>
using namespace std;

typedef pair<int,int> PII;
const int N = 1505,M = 2*N;
int h[N],ne[M],e[M],w[M],idx;
int dis[N],ans[N];
bool b[N],hxd[M];
int x1,y1,x2,y2;
int n,m;

inline void add(int a,int b,int c){
	w[idx] = c,e[idx] = b,ne[idx] = h[a],h[a] = idx++;
}

int main(){
	freopen("2knight.in","r",stdin);
	freopen("2knight.out","w",stdout);
	memset(h,-1,sizeof(h));
	scanf("%d%d",&n,&m);
	scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
	for(int k=1;k<=m;k++){
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		add(a,b,c);
		add(b,a,c);
	}
	priority_queue<PII,vector<PII>,greater<PII> > q;
	memset(dis,0x3f,sizeof(dis));
	q.push({0,x1});
	dis[x1] = 0;
	b[x1] = true;
	while(q.size()){
		auto u = q.top().second;
		q.pop();
		for(int k=h[u];~k;k=ne[k]){
			int v = e[k];
			if(b[v])
				continue;
			b[v] = true;
			if(dis[u]+w[k]<=dis[v]){
				dis[v] = dis[u]+w[k];
				hxd[k] = true;
				q.push({dis[v],v});
			}
		}
	}
	memset(dis,0x3f,sizeof(dis));
	memset(b,false,sizeof(b));
	q.push({0,x2});
	dis[x2] = 0;
	b[x2] = true;
	while(q.size()){
		auto u = q.top().second;
		q.pop();
		for(int k=h[u];~k;k=ne[k]){
			int v = e[k];
			if(b[v])
				continue;
			b[v] = true;
			if(dis[u]+w[k]<=dis[v]){
				dis[v] = dis[u]+w[k];
				q.push({dis[v],v});
				ans[v] = max(ans[v],hxd[k]?w[k]:0+ans[u]);
			}
		}
	}
	printf("%d",ans[y2]);
	return 0;
}
