#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
	inline int in(){
		char tmp = getchar();
		while(tmp<'0'||tmp>'9')
			tmp = getchar();
		int num = 0;
		while(tmp>='0'&&tmp<='9'){
			num = num*10+(tmp^48);
			tmp = getchar();
		}
		return num;
	}
}
using fastio::in;

typedef pair<int,int> PII;
const int N = 200005;
int c[N],v[N];
int col[N];
int n,m;

signed main(){
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n = in(),m = in();
	for(int k=1;k<=n;k++){
		c[k] = in();
		v[k] = in();
	}
	while(m--){
		if(in()==1){
			int x = in();
			c[x] = in();
			v[x] = in();
		}
		else{
			int s=in(),K=in();
			for(int k=s;k<=n;k++){
				if(!col[c[k]])
					col[c[k]] = v[k];
				else if(K){
					col[c[k]] = max(v[k],col[c[k]]);
					K--;
				}
				else
					break;
			}
			int ans = 0;
			for(int k=s;k<=n;k++){
				ans += col[c[k]];
				col[c[k]] = 0;
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
