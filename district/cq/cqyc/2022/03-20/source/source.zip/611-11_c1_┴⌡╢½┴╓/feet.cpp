#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int N = 100005;
class Ayaka{
	public:
		int x,y;
}a[N];
int cntx[N];
int cnty[N];
int n;

signed main(){
	freopen("feet.in","r",stdin);
	freopen("feet.out","w",stdout);
	scanf("%lld",&n);
	for(int k=1;k<=n;k++){
		scanf("%lld%lld",&a[k].x,&a[k].y);
		cntx[a[k].x]++;
		cnty[a[k].y]++;
	}
	int ans = 0;
	for(int k=1;k<=n;k++)
		ans += (cntx[a[k].x]-1)*(cnty[a[k].y]-1);
	printf("%lld",ans);
	return 0;
}
