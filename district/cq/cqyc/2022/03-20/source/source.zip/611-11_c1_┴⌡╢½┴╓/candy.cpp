#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int N = 10010,mod = 10007;
int ans[N];
int n;

signed main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	int q;
	scanf("%lld%lld",&q,ans);
	for(int k=1;k<=mod;k++)
		ans[k] = (ans[k-1]+1)*2%mod;
	while(q--){
		int n;
		scanf("%lld",&n);
		printf("%lld ",ans[n%(mod-1)]);
	}
	return 0;
}
/*
1
5
10005
*/
