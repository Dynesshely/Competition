#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 2005;
double v[N],f[N];
int q[N];
int w,s,n;

signed main(){
	freopen("coffee.in","r",stdin);
	freopen("coffee.out","w",stdout);
	scanf("%d%d%d",&w,&s,&n);
	for(int k=1;k<=n;k++)
		scanf("%d%lf",q+k,v+k);
	for(int k=1;k<=n;k++){
		double minn = v[k];
		int sum = q[k];
		f[k] = f[k-1]+1.0*s/v[k];
		for(int j=k-1;j;j--){
			if(sum+q[j]>w)
				break;
			sum += q[j];
			minn = min(minn,v[j]);
			f[k] = min(f[k],f[j-1]+1.0*s/minn);
		}
	}
//	for(int k=1;k<=n;k++)
//		printf("%.2lf\n",f[k]);
	printf("%.2lf",f[n]);
	return 0;
}
