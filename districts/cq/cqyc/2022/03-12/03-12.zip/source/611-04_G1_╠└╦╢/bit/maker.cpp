#include<bits/stdc++.h>
using namespace std;

int main(){
	srand(time(0));
	freopen("bit.in","w",stdout);
	int n=rand()*rand()%1000000000+1;
	int k=(rand()%2==1?1:-1)*rand()%1000+1;
	cout<<n<<" "<<k;
	return 0;
} 
