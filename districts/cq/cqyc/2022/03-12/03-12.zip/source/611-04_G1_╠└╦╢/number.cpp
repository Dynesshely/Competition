#include<bits/stdc++.h>
using namespace std;
inline long long read(){
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int m,a,b;
long long num[1000005];
int prime[1000005],tot=0;
bool check_subone(int x){
	for(register int i=1;i<x;i++){
		if(num[x]%num[i]==0) return false;
	}
	return true;
}
void solve_subone(){
	for(register int i=1;i<=m;i++){
		num[i]=(long long)a*i+b;
	}
	int ans=0;
	for(register int i=1;i<=m;i++){
		if(check_subone(i)) ans++;
	}
	printf("%d",ans);
}
bool check(int x){
	for(register int i=1;i<=tot;i++){
		if((x-(b*(prime[i]-1)/a))<=0) return true;
		else if((x-((b*(prime[i]-1))/a))%prime[i]==0) return false;
	}
	return true;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	m=read(),a=read(),b=read();
	if(m<=2000){
		solve_subone();
		return 0;
	}
	else {
		for(register int i=2;i<=m;i++){
			if(b*(i-1)%a==0) prime[++tot]=i;
		}
		int ans=0;
		for(register int i=1;i<=m;i++){
			if(check(i)) ans++;
		}
		printf("%d",ans);
	}
	return 0;
}
