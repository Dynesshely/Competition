#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=(sss<<1)+(sss<<3)+(chh^48);
		chh=getchar();
	}
	return sss*www;
}
int m,a,b;
int main(){
//	freopen("number_daisample1.in","r",stdin);
//	freopen("number.out","w",stdout);
	m=read(),a=read(),b=read();
	
	
	return 0;
}
