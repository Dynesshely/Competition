#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int n,k,ans=1e9;
int base[105];
bool check(int num,int i){
	int tmp=0;
	while(num){
		if(num%2) tmp++;
		num/=2;
	}
	return tmp<=i; 
}
int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read(),k=read();
	for(register int i=0;i<=30;i++){
		base[i]=(1<<i)+k;
	}
	if(base[0]>0&&base[0]>n){
		puts("-1");
		return 0;
	}
	for(register int i=1;i<=100000;i++){
		if(check(n-k*i,i)){
			printf("%d",i);
			return 0;
		}
	}
	return 0;
} 
