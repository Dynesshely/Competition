#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
bool forever;
int n,ans=1e9;
int a[200005];
int has[15];
bool vis[15];
//bool trie[12000005][2];
//int cnt[12000005][2];
int tot=0;
bool Forever;
void change_ans(){
	int tmp=0;
	for(register int i=1;i<n;i++){
		tmp=max(tmp,a[has[i]]^a[has[i+1]]);
	}
	ans=min(ans,tmp);
}
void dfs(int now){
	if(now==n+1){
		change_ans();
		return;
	}
	for(register int i=1;i<=n;i++){
		if(!vis[i]){
			vis[i]=true; has[now]=i;
			dfs(now+1);
			vis[i]=false;
		}
	}
}
/*void insert(int num){
	int p=0;
	for(register int i=1LL<<60;i;i>>=1){
		bool tmp=num&i;
		if(!trie[p][tmp]) trie[p][tmp]=++tot;
		cnt[p][tmp]++; 
		p=trie[p][tmp];
	}
}
void dfs2(int num){
	int p=0;
	for(register int i=1LL<<60;i;i>>=1){
		bool tmp=num&i;
		if(cnt[p][tmp]==2){
			
		}
	}
}*/
signed main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		a[i]=read();
	}
//	if(n<=8){
		for(register int i=1;i<=n;i++){
			has[1]=i; vis[i]=true;
			dfs(2);
			vis[i]=false;
		}
		printf("%lld",ans);
		return 0;
//	}
/*	else {
		for(register int i=1;i<=n;i++){
			insert(a[i]);
		}
		for(register int i=1;i<=n;i++){
			dfs2(i);
		}
		srand(time(0));
		cout<<rand();
	}*/
	return 0;
}
