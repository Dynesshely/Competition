#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
const int mod=1e9+7;
int n;
int a[100005],b[100005];
int maze[3005][3005];
int f[3005];
/*struct Seg{
	int tree[12005];
	int maze[3005];
	void build(int pos,int l,int r){
		if(l==r){
			tree[pos]=maze[l];
			return;
		}
		int mid=(l+r)>>1;
		build(pos<<1,l,mid);
		build((pos<<1)|1,mid+1,r);
		tree[pos]=max(tree[pos<<1],tree[(pos<<1)+1]);
	}
}T[3005];*/
int tj(int sx,int sy,int ex,int ey){
	int ans=0;
	for(register int i=sx;i<=ex;i++){
		for(register int j=sy;j<=ey;j++){
			ans=max(ans,maze[i][j]);
		}
	}
	return ans;
}
void solve(int x,int y){
	int len=min(n-x,n-y);
	for(register int k=0;k<=len;k++){
		f[k+1]=(f[k+1]+tj(x,y,x+k,y+k))%mod;
	}
}
signed main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		a[i]=read();
	}
	for(register int i=1;i<=n;i++){
		b[i]=read();
	}
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			maze[i][j]=(a[i]*b[j]+i*b[j]+j*a[i]+i*j)%mod;
		}
	}
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			solve(i,j);
		}
	}
	for(register int i=1;i<=n;i++){
		printf("%lld ",f[i]);
	}
	/*for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			T[i].maze[j]=(a[i]*b[j]+i*b[j]+j*a[i]+i*j)%mod;
		}
	}
	for(register int i=1;i<=n;i++){
		T[i].build(1,1,n);
	}
	for(register int i=1;i<=n;i++){
		
	}*/
	return 0;
}
