#include<bits/stdc++.h>
using namespace std;

int main(){
	while(true){
		system("maker.exe");
		int tim1=clock();
		system("bit.exe");
		int tim2=clock();
		cout<<"The time usage is:"<<tim2-tim1<<"ms\n";
	}
	return 0;
} 
