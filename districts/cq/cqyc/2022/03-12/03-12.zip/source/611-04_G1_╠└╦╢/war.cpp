#include<bits/stdc++.h>

using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
int n;
int a[1000005];
int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	n=read(); int sum=0;
	for(register int i=1;i<=n;i++){
		a[i]=read(); sum+=a[i];
	}
	cout<<sum/2;
	return 0;
}
