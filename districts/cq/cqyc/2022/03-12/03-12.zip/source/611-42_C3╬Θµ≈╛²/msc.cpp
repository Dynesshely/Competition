#include<bits/stdc++.h>
using namespace std;
int n,a[200005],sum[2],flag=1,ans;
int cost=1e9,vis[200007];
void dfs(int id,int now,int las,int k) {
	if(now>=cost) return;
	if(id>=n+1) {
		cost=now,ans=k;
		return;
	}
	for(int i=1; i<=n; i++) {
		if(vis[i]==0) {
			vis[i]=1;
			dfs(id+1,now+(a[i]^las),a[i],max(k,(a[i]^las)));
			vis[i]=0;
		}
	}
}

int main() {
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; i++) {
		scanf("%d",&a[i]);
		sum[1]+=a[i];
		if(a[i]!=1&&a[i]!=0) flag=0;
	}
	if(n<=10) {
		for(int i=1; i<=n; i++) {
			memset(vis,0,sizeof(vis));
			vis[i]=1;
			dfs(2,0,a[i],0);
			vis[i]=0;
		}
		printf("%d",ans);
	} else if(flag==1) {
		sum[0]=n-sum[1];
		for(int i=1; i<=n; i++) {
			if(sum[a[i]]-1==0)  ans+=2;
			else if(sum[a[i]]-1==1)  ans++;
		}
		ans=max(0,ans-2);
		printf("%d",ans);
	} else {
		for(int i=1; i<=n; i++) {
			memset(vis,0,sizeof(vis));
			vis[i]=1;
			dfs(2,0,a[i],0);
			vis[i]=0;
		}
		printf("%d",ans);
	}
	return 0;
}
