#include<bits/stdc++.h>
using namespace std;
int m,a,b,vis[1000007],ans,ad;
int tp,to,tot;
int gcd(int x,int y) {
	if(x>y) swap(x,y);
	if(x==0) return y;
	return gcd(y%x,x);
}
int main() {
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d %d %d",&m,&a,&b);//4 3
	if(b%a==0) ad=b/a;
	else ad=b/gcd(a,b),tot=a/gcd(a,b);
	for(int i=1; i<=m; i++) {
		if(vis[i]) continue;
		if(b%a==0) {
			tp=i,to=ad+i;
			while(tp+to<=m) {
				tp+=to;
				vis[tp]=1;
			}
		} else {
			tp=tot,to=ad;
			while((tp+1)*i+to<=m) {
				vis[(tp+1)*i+to]=1;
				tp+=tot,to+=ad;
			}
		}

	}
	for(int i=1; i<=m; i++)	ans+=(vis[i]==0);
	printf("%d",ans);
	return 0;
}
