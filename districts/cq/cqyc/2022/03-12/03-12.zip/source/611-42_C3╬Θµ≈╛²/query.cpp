#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
int n;
long long c[3007][3007],a[100007],b[100007],f[100007];
int main() {
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; i++) scanf("%lld",&a[i]);
	for(int i=1; i<=n; i++) scanf("%lld",&b[i]);
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=n; j++)	c[i][j]=a[i]*b[j]%mod+i*b[j]%mod+a[i]*j%mod+i*j%mod;
	}
	for(int t=1; t<=n; t++) {
		for(int i=1; i<=n-t+1; i++) {
			for(int j=1; j<=n-t+1; j++) {
				long long now=0;
				for(int u1=i; u1<=i+t-1; u1++) {
					for(int u2=j; u2<=j+t-1; u2++) {
						now=max(now,c[u1][u2]);
					}
				}
				f[t]+=now;
				f[t]=f[t]%mod;
			}
		}

	}
	for(int i=1; i<=n; i++) printf("%d ",f[i]);
	return 0;
}
