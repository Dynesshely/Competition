#include<bits/stdc++.h>
using namespace std;
int n,k,l=0,r=1e9,ans=40;
long long lg[37];
int check(int now)
{
	long long tmp=n-k*now;
	int g,m=0;
	while(tmp)
	{
		g=log2(tmp);
		tmp-=lg[g];
		m++;
	}
	if(m>now) return 0;
	return 1;
}
int main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);	
	scanf("%d %d",&n,&k);
	lg[0]=1;
	for(int i=1;i<=30;i++)	lg[i]=lg[i-1]*2;
	while(l<=r)
	{
		int mid=(l+r)>>1;
		if(mid>n-k*mid) r=mid-1;
		else if(check(mid)) r=mid-1,ans=min(ans,mid);
		else l=mid+1;
	}
	if(ans!=40) printf("%d",ans);
	else printf("-1");
	return 0;
 } 
