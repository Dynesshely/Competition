#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int stk[30],tp;
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}

int n,res,A,B;
int a[200005],b[1010][1010];
bitset<1010> vis;
int dfs(int x,int y,int k) {
	vis[x]=1;
	int res=0;
	for(register int i=1; i<=n; ++i) {
		if(!vis[i]&&b[x][i]<=k) {
			res=dfs(i,y+1,k);
			if(res+y==n) {
				vis[x]=0;
				return res+1;
			}
		}
	}
	vis[x]=0;
	return res+1;
}
bool check(int k) {
	for(int i=1; i<=n; ++i) {
		int x=dfs(i,1,k);
		if(x==n) return 1;
	}
	return 0;
}

signed main() {
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n=read();
	for(register int i=1; i<=n; ++i) {
		a[i]=read();
		if(a[i]==1) ++A;
		if(a[i]==0) ++B; 
	}
	int l=0,r=1152921504606846975;
	if(n<=10) {
		r=0;
		for(int i=1; i<=n; ++i) for(int j=1; j<=n; ++j) b[i][j]=a[i]^a[j],r=max(r,b[i][j]);
		while(l<=r) {
			int mid=l+r>>1;
			if(!check(mid)) l=mid+1;
			else res=mid,r=mid-1;
		}
		put(res);
		return 0;
	}
	if(A+B==n) {
		if(A&&B) put(1);
		else put(0);
		return 0;
	}
	while(l<=r) {
		int mid=l+r>>1,t=0;
		for(register int i=1; i<=n; ++i) {
			int sum=0;
			for(register int j=1; j<=n; ++j)
				if((a[i]^a[j])<=mid) ++sum;
			if(sum==1) {
				t=3;
				break;
			}
			if(sum==2) {
				++t;
				if(t==3) break;
			}
		}
		if(t==3) l=mid+1;
		else res=mid,r=mid-1;
	}
	put(res);
	return 0;
}


