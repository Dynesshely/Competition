#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int stk[30],tp;
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	do stk[++tp]=x%10,x/=10; while(x);
	while(tp)putchar(stk[tp--]^48);
}
int n,k,m=1e14;
int lowbit(int x) {
	return x&-x;
} 
signed main() {
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read(),k=read();
	int l=1,r=m;
	while(l<=r) {
		int mid=l+r>>1,x=n-mid*k,t=0;
		if(x<0) {
			r=mid-1;
			continue;
		}
		while(x) ++t,x-=lowbit(x);
		x=n-mid*k;
		if(t<=mid&&mid<=x) m=min(m,mid),r=mid-1;
		else l=mid+1;
	}
	if(m>=100000000000000) put(-1);
	else put(m);
	return 0;
}

