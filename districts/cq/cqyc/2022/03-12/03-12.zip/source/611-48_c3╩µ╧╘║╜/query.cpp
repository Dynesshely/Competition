#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int stk[30],tp;
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	do stk[++tp]=x%10,x/=10; while(x);
	while(tp)putchar(stk[tp--]^48);
}

int n;
int a[3010],b[3010],c[3010][3010];


int f(int k) {
	int sum=0;
	for(register int sx=1;sx<=n;++sx) {
		for(register int sy=1;sy<=n;++sy) {
			int ex=sx+k-1,ey=sy+k-1,ma=0;
			if(ex>n||ey>n) continue;
			for(register int i=sx;i<=ex;++i) 
				for(register int j=sy;j<=ey;++j) 
					ma=max(ma,c[i][j]);
			sum+=ma;
		}
	}
	return sum;
}
signed main() {
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;++i) a[i]=read();
	for(register int i=1;i<=n;++i) b[i]=read();
	for(register int i=1;i<=n;++i) 
		for(register int j=1;j<=n;++j) 
			c[i][j]=a[i]*b[j]+i*b[j]+a[i]*j+i*j;
	for(register int i=1;i<=n;++i) put(f(i)),putchar(' ');
	return 0;
}


