#include<bits/stdc++.h>
#define int long long
using namespace std;

inline int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int stk[30],tp;
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	do stk[++tp]=x%10,x/=10; while(x);
	while(tp)putchar(stk[tp--]^48);
}
int m,a,b,p,res;
bitset<1000010> vis;

inline int id(int x) {
	return (x-b)%a==0?(x-b)/a:0;
}

signed main() {
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	m=read(),a=read(),b=read(),p=a*m+b;
	for(register int i=1,x=a+b;i<=m;++i,x+=a) {
		if(vis[i]) continue;
		++res;
		for(register int j=x;j<=p;j+=x) vis[id(j)]=1; 
	}
	put(res);
 	return 0;
}

