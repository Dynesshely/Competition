#include<bits/stdc++.h>
using namespace std;
const long long mod=1e9+7;
int n,a[10005],b[10005];
long long c[1005][1005],ans;
long long mx[105][105][105];
void sol(int k)
{
	ans=0;
	for(int i=1;i+k-1<=n;i++)
	for(int j=1;j+k-1<=n;j++)//���Ͻ�:i��j�� 
	{
		long long res=0;
		for(int x=i;x<=i+k-1;x++)//��x�� 
		res=max(res,mx[x][j][j+k-1]);
		ans=(ans+(res%mod))%mod;
	}
	printf("%lld ",ans);
}
int main()
{
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) scanf("%d",&b[i]);
	
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	c[i][j]=a[i]*b[j]+i*b[j]+a[i]*j+i*j;
	
	for(int i=1;i<=n;i++)//���� 
	for(int j=1;j<=n;j++)//���� 
	for(int k=j;k<=n;k++)//���� 
	mx[i][j][k]=max(mx[i][j][k-1],c[i][k]);

	for(int k=1;k<=n;k++) sol(k);
} 
