#include<bits/stdc++.h>
using namespace std;
int n,m,k,a,y,ans=1e9;
long long bs[70];
int main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%d%d",&n,&k);
	y=n,bs[0]=1;
	
	for(int i=1;i<=63;i++)
	bs[i]=bs[i-1]*2;
	for(int i=1;i<=63;i++)
	bs[i]-=1;
	
	if(k==0)
	{
		while(n)
		{
			if(n%2==1) m++;
			n/=2;
		}
		printf("%d",m);
		return 0;
	}
	if(k<0)
	{
		for(int i=1;i<=63;i++)
		if(bs[i]>=n-k*i) 
		{m=i;break;} 
	}
	else while(y) m++,y/=2;

	for(int i=m;i>=1;i--)
	{
		int x=n-i*k;
		if(x<=0) continue;
		int res=0;
		while(x)
		{
			if(x%2==1) res++;
			x/=2;
		}
		if(res<=i) ans=min(ans,i);
	}
	if(ans==1e9) printf("-1");
	else printf("%d",ans);
	return 0;
} 
