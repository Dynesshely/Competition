#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
cout<<0;
} 
/*

	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			for(int k=j;k<=n;k++)
			printf("mx[%d][%d][%d]:%d\n",i,j,k,mx[i][j][k]);
		}
				
	}	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		printf("%d ",c[i][j]);
		printf("\n");
	}
	
*/
