#include<bits/stdc++.h>
using namespace std;
int m,a,b,ans,res,lst;
bool vis[1000055];
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d%d",&m,&a,&b);
	/*for(int i=1;i<=m;i++)
	{
		int x=i*a+b,flag=0;
		for(int j=1;j<i;j++)
		{
			int y=j*a+b;
			if(x%y==0) 
			{flag=1;break;}
		}
		if(flag==0) 
		{
			ans++;
			int f=0;
			for(int j=2;j<x;j++)
			if(x%j==0) {f=1;break;}
//			if(f==0) printf("Prime!\n"),res++;
//			else printf("Not prime...\n");
			printf("i:%d x:%d jg:%d\n\n",i,x,i-lst);
			lst=i;
		}
	}
	printf("ans:%d\n",ans);
	printf("number of prime:%d",res);*/
	for(int i=1;i<=m;i++)
	{
		if(vis[i]) continue;
		ans++;
		long long x=i*a+b;
		for(int j=i;j<=m;j++)
		{
			long long y=j*a+b;
			if(y%x==0) vis[j]=1;
		}
	}
	printf("%d",ans);/*
	for(int i=min(a,b);i>=1;i--)
	if(a%i==0 && b%i==0) f=i;break;
	k=a/f;q=b/f;
	b=k*a(k=?)
	for(int i=1;i<=m;i++)
	{
		x=(i*a+b)*k-b;
		x%k==0?
	}
	printf("%d",ans);*/
} 
