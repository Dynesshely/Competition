#include<bits/stdc++.h>
using namespace std;
int n,q[1005];
long long w[1005][1005],a[100005];
bool vis[10005];
long long ans=1e9;
void check()
{
	long long res=0;
	for(int i=1;i<n;i++)
	res=max(res,w[q[i]][q[i+1]]);
	ans=min(ans,res);
}
void dfs(int x)
{
	if(x>n) 
	{
		check();
		return;
	}
	for(int i=1;i<=n;i++)
	{
		if(vis[i]==1) continue;
		q[x]=i,vis[i]=1;dfs(x+1);
		vis[i]=0,q[x]=0;
	}
}
int main()
{
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	w[i][j]=a[i]^a[j];
	dfs(1);
	printf("%lld",ans);
} 
