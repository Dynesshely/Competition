#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,k,ans;
signed main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout); 
	scanf("%lld%lld",&n,&k);
	while(1)
	{
		++ans;
		int w=n-k*ans,sum=0,sm=0;
		if(w<=0)
		{
			cout<<-1;
			return 0;
		}
		while(w)
		{
			int y=(w&-w),num=1;
			w-=y;
			while(y!=num) num*=2;
			sum+=num,++sm;
		}
		if(sm==ans|| (sm<ans && sum>=ans))
		{
			cout<<ans;
			return 0;
		}
	}
}
