#include<bits/stdc++.h>
#define int long long
using namespace std;
int m,a,b,ans,sum,i,w,x;
bool f=1;
int fl[10000000];
signed main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%lld%lld%lld",&m,&a,&b);
//	if(m<=1000)
//	{
		for(int i=1; i<=m; ++i)
			if(!fl[a*i+b])
			{
				for(int j=2; j*(a*i+b)<=10000000; ++j) fl[j*(a*i+b)]=1;
				++ans;
			}
		cout<<ans;
//	}
//	else
//	{
//		for(int i=1; i<=m; ++i)
//		{
//			if((i-b)%(a-1)!=0) ++ans;
//		}
//		printf("%lld",ans);
//	}
	return 0;
}
/*
	ax+b==(ay+b)/w (0<x<y)
	axw+bw==ay+b
	1+ay/b==w+axw/b
	(b+ay)/(b+ax)=w
	(ay-b((b+ay)/(b+ax))+b)/a/(b+ay)*(b+ax)==x
	ay-b*b
*/
