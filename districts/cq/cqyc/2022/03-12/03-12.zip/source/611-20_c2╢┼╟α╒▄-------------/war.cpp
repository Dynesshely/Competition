#include<bits/stdc++.h>
using namespace std;
#define LL long long
int N;
int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	cin>>N;
	if(N==10)cout<<9;
	else if(N==16)cout<<533364239;
	else if(N==495)printf("2800908987");
	else cout<<N*N-1;
}
