#include<bits/stdc++.h>
using namespace std;
#define LL long long
LL N,a,b,f=1;
bool c[1000005];
LL Ans=0;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%lld%lld%lld",&N,&a,&b);
	for(int i=1;i<=N;++i){
		if(c[i]==1)continue;
		for(int j=1;;++j){
			if(i+j*(a*i+b)<=N)c[i+j*(a*i+b)]=1;
			else break;
		}
		Ans++;
	}
	printf("%lld",Ans); 
}
