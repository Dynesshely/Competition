#include<bits/stdc++.h>
using namespace std;
#define LL long long
const int Mod=1e9+7;
LL Ans,N,A[1005],B[1005];
LL C[1005][1005];
int main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;++i)scanf("%d",&A[i]);
	for(int i=1;i<=N;++i)scanf("%d",&B[i]);
	for(int i=1;i<=N;++i)
		for(int j=1;j<=N;++j){
			C[i][j]=A[i]*B[j]+i*B[j]+A[i]*j+i*j;
		} 
	for(int k=1;k<=N;++k){
		Ans=0;
		for(int i=1;i<=N-k+1;++i){
			for(int j=1;j<=N-k+1;++j){
				LL Mx=0;
				for(int I=i;I<=N&&I<=i+k-1;++I){
					for(int J=j;J<=N&&J<=j+k-1;++J){
						Mx=max(Mx,C[I][J]);
					}
				}
				Ans=(Mx+Ans)%Mod; 
			}
		}
		printf("%lld\n",Ans);
	}
}
