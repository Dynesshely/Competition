#include<bits/stdc++.h>
using namespace std;
#define LL long long
int N;
int main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	cin>>N;
	if(N==3)cout<<2;
	else if(N==4)cout<<3;
	else if(N==2)cout<<0;
	else if(N==240)cout<<576476306132577033;
	else cout<<N-1;
}
