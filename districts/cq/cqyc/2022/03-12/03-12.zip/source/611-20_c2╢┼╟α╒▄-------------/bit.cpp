#include<bits/stdc++.h>
using namespace std;
#define LL long long
LL N,K,N1,f;
int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%lld%lld",&N,&K);
	for(LL m=1;m<=N;m++){
		int m1=m;
		N1=N,N1-=m*K;
		if(N1==0){
			printf("-1");
			break;
		}
		for(LL i=0;(1<<i)<=N1;i++){
			if((N1&(1<<i))>0)
				m1--;
			if(m1<0)break;
		}
		if(m1>=0){
			printf("%d",m);
			break;
		}
	}
} 
