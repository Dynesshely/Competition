#include<bits/stdc++.h>
using namespace std;
long long cs[1000005];
bool b[1000005];
int m,a,bb;
int main() {
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d%d",&m,&a,&bb);
	int js=0;
	for(int i=1; i<=m; i++) cs[++js]=a*i+bb;
	int ans=0;
	for(int i=1; i<=js; i++) {
		if(b[i]==1) continue;
		else {
			ans++;
			int now=cs[i];
			for(int j=1; now+cs[i]<=cs[m]; j++) {
                now+=cs[i];
                if((now-bb)%a==0){
                	b[(now-bb)/a]=1;
				}
			}
		}
	}
    printf("%d",ans);
}
