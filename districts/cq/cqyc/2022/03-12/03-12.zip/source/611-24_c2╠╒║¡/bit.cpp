#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,k;
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	cout<<-1;
	return 0;
}
