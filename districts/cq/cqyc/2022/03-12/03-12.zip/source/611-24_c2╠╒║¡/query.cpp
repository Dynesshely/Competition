#include<bits/stdc++.h>
using namespace std;
int a[100005],b[100005];
int cs[1005][1005];
int f[20200];
long long mod=1e9+7;
int main(){
	freopen("query.in","r",stdin);
	freopen("qurey.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) scanf("%d",&b[i]);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			cs[i][j]=((a[i]*b[j])%mod+(i*b[j])%mod+(a[i]*j)%mod+(i*j)%mod)%mod;
		}
	}
	for(int k=1;k<=n;k++){
		int ans=0,maxn=0;
		for(int i=1;i<=n-k+1;i++){
			for(int j=1;j<=n-k+1;j++){
			    maxn=0;
				for(int x=i;x<=i+k-1;x++){
					for(int y=j;y<=j+k-1;y++){
						maxn=max(maxn,cs[x][y]);
					}
				}
				ans+=maxn;
			}
		}
		printf("%d ",ans);
	}
}
