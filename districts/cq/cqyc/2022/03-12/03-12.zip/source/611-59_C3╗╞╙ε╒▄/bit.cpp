#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,k,l,r,cnt;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n = read(),k = read();
	for(int i = 1;;i++)
	{
		l = n-i*k,cnt = 0;
		if(l<=0) 
		{
			printf("-1");
			return 0;
		}
		while(l) 
		{
			r = 1;
			while(r<=l) r*=2;
			r/=2,l-=r,cnt++;
		} 
		if(i<=n-i*k and i>=cnt) 
		{
			printf("%lld",i);
			return 0;
		}
	}
	return 0;
}
