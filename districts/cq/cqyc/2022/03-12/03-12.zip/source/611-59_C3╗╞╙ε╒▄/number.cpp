#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 1e6+10;
int m,a,b,l,r,ans;
int vis[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
int gcd(int x,int y)
{
	int z;
	while(x)z=x,x=y%x,y=z;
	return y;
}
signed main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	m = read(),a = read(),b = read();
	for(int i = 1;i<=m;i++)
	{
		if(vis[i]) continue;
		ans++,l=a*i+b,r=l/gcd(l,a);
		for(int j = 1;i+j*r<=m;j++) vis[i+j*r] = 1; 
	}
	printf("%lld",ans);
	return 0;
}

