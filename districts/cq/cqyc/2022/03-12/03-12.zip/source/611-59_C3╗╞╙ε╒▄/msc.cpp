#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 2e5+10,inf = 3e18;
int n,l,r,mid,ans,d;
int a[MAX];
bool vis[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
int dfs(int x,int cnt,int v)
{
	for(int i = 1;i<=n;i++)
		if(!vis[i] and (a[i]^a[x])<=v)vis[i]=1,cnt+=dfs(i,1,v);
	return cnt;
}
bool st1()
{
	int x=1,y=1;
	for(int i = 1;i<=n;i++)
	{
		if(a[i]>1) return false;
		if(a[i]!=1) y=0;
		if(a[i]!=0) x=0;
	} 
	if(y+x==0) d=1;
	return true; 
}
signed main()
{
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n = read(),r = inf;
	for(int i = 1;i<=n;i++) a[i] = read();
	if(st1())
	{
		printf("%lld",d);
		return 0;
	}
	while(l<=r)
	{
		memset(vis,0,sizeof(vis)); 
		mid = (l+r)/2,d = 0,vis[1]=1;
		if(dfs(1,1,mid)>=n) ans = mid,r = mid-1;
		else l = mid+1;
	}
	printf("%lld",ans);
	return 0;
}

