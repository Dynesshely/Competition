#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 3e3+10,mod = 1e9+7;
int n,ma;
int A[MAX],B[MAX],a[MAX][MAX],ans[MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	n = read();
	for(int i = 1;i<=n;i++) A[i] = read();
	for(int i = 1;i<=n;i++) B[i] = read();
	for(int i = 1;i<=n;i++)
		for(int j = 1;j<=n;j++) a[i][j] = A[i]*B[j]+i*B[j]+A[i]*j+i*j;
	for(int i = 1;i<=n;i++)
		for(int j = 1;j<=n;j++)
		{
			ma = 0;
			for(int k = 1;;k++)
			{
				if(i+k-1>n or j+k-1>n) break;
				for(int l = i;l<=i+k-1;l++) ma=max(ma,a[l][j+k-1]);
				for(int l = j;l<j+k-1;l++) ma=max(ma,a[i+k-1][l]);
				ans[k]=(ans[k]+ma)%mod;
			}
		}
	for(int i = 1;i<=n;i++) printf("%lld ",ans[i]);
	return 0;
}

