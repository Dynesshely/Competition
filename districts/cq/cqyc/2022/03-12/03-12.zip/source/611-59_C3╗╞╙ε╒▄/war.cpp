#include<bits/stdc++.h>
using namespace std;
int n;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
signed main()
{
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	printf("%d",read());
	return 0;
}

