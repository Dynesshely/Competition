#include<bits/stdc++.h>
using namespace std;
long long m,a,b,now,tmp,mx;
int ans=0;
bitset<1000005> ok;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%lld%lld%lld",&m,&a,&b);
	ok.set();
	mx=a*m+b;
	for(int i=1;i<=m;++i)
	{
		if(!ok[i]) continue;
		now=a*i+b;
		++ans;
		for(long long j=1;;++j)
		{
			tmp=now*j-b;
			if(tmp>mx) break;
			if(tmp%a==0) ok[tmp/a]=0;
		}
	}
	printf("%d",ans);
	return 0;
}

