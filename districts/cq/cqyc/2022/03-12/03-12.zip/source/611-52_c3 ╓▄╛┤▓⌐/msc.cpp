#include<bits/stdc++.h>
using namespace std;
namespace mn
{
	static int n;
	static long long a[200005];
}
namespace pt20
{
	using namespace mn;
	static long long ans=2333331145141919810,tans;
	static int od[15];
	static bitset<15> vis;
	static void dfs(int p)
	{
		if(p>n)
		{
			tans=-1;
			for(int i=1;i<n;++i)
			{
				tans=max(tans,a[od[i]]^a[od[i+1]]);
			}
			ans=min(ans,tans);
			return ;
		}
		for(int i=1;i<=n;++i)
		{
			if(!vis[i])
			{
				od[p]=i;
				vis[i]=1;
				dfs(p+1);
				vis[i]=0;
			}
		}
	}
}
namespace pt60
{
	struct edge
	{
		int u,v;
		long long w;
		inline const bool operator<(const edge &A)const
		{
			return w<A.w;
		}
	}e[4000005];
	static int fa[200005],deg[200005];
	static long long ecnt=0,ans=-1;
	static int getfa(int k)
	{
		if(fa[k]==k) return k;
		return fa[k]=getfa(fa[k]);
	}
}
int main()
{
	using namespace mn;
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%lld",a+i);
	}
	if(n<=8)
	{
		using namespace pt20;
		dfs(1);
		printf("%lld",ans);
		return 0;
	}
	if(n<=2000)
	{
		using namespace pt60;
		for(int i=1;i<n;++i)
		{
			fa[i]=i;
			for(int j=i+1;j<=n;++j)
			{
				e[++ecnt]=(edge){i,j,a[i]^a[j]};
			}
		}
		fa[n]=n;
		sort(e+1,e+1+ecnt);
		int nu,nv;
		for(int i=1;i<=ecnt;++i)
		{
			nu=e[i].u,nv=e[i].v;
			if(deg[nu]>=2 || deg[nv]>=2) continue;
			if(getfa(nu)==getfa(nv)) continue;
			fa[nu]=getfa(nv);
			ans=max(ans,e[i].w);
		}
		printf("%lld",ans);
		return 0;
	}
	return 0;
}

