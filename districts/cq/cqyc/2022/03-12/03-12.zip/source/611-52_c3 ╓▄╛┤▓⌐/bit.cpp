#include<bits/stdc++.h>
using namespace std;
int n,k,tmp,now;
inline int bitcount(int p)
{
	int ret=0;
	while(p)
	{
		if(p&1) ++ret;
		p>>=1;
	}
	return ret;
}
int main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%d%d",&n,&k);
	tmp=n;
	for(int i=1;i<=500000;++i)
	{
		tmp=n-(i*k);
		now=bitcount(tmp);
		if(0<now && now<=i && i<=n)
		{
			printf("%d",i);
			return 0;
		}
	}
	printf("-1");
	return 0;
}
