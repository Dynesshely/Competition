#include<bits/stdc++.h>
using namespace std;
int n,a[1000005];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) a[i]=read();
	cout<<13;
	return 0;
}

