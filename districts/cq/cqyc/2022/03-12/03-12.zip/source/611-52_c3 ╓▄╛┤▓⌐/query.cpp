#include<bits/stdc++.h>
#define mod 1000000007
using namespace std;
int n;
long long A[100005],B[100005];
inline long long dat(int x,int y)
{
	return (((A[x]*B[y]+x*B[y])%mod)+((A[x]*y+x*y)%mod))%mod;
}
int main()
{
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%lld",A+i);
	for(int i=1;i<=n;++i) scanf("%lld",B+i);
	if(n<=80)
	{
		static long long ans=0,tans;
		for(int k=1;k<=n;++k)
		{
			ans=0;
			for(int i=1;i<=n-k+1;++i)
			{
				for(int j=1;j<=n-k+1;++j)
				{
					tans=0;
					for(int a=0;a<k;++a)
					{
						for(int b=0;b<k;++b)
						{
							tans=max(tans,dat(i+a,j+b));
						}
					}
					ans+=tans;
					ans%=mod;
				}
			}
			printf("%lld ",ans);
		}
	}
	return 0;
}

