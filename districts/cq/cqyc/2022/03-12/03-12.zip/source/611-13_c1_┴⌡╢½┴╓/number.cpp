#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int N = 1000005;
int num[N],pri[N],wei;
bool vis[N];
int m,a,b;

signed main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%lld%lld%lld",&m,&a,&b);
	for(int k=1;k<=m;k++)
		num[k] = a*k+b;
	sort(num+1,num+1+m);
	for(int k=1;k<=m;k++){
		int flag = true;
		for(int j=1;j<=wei&&num[j]*2<=num[k];j++)
			if(!(num[k]%num[j])){
				flag = false;
				break;
			}
		if(flag)
			pri[++wei] = num[k];
	}
	printf("%lld\n",wei);
	return 0;
}
