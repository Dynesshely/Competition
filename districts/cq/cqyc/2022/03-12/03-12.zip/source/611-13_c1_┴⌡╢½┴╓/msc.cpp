#include <iostream>
#include <random>
#include <ctime>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int N = 200005,K = 60;
int col[K][N];
int a[N];
int n;

signed main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	scanf("%lld",&n);
	for(int k=1;k<=n;k++)
		scanf("%lld",a+k);
	int ans = 0x3f3f3f3f3f3f3f3f;
	mt19937 myrand(time(0)^114514);
	double begin = clock();
	while((clock()-begin)<900){
		swap(a[myrand()%n+1],a[myrand()%n+1]);
		int tmpans = 0;
		for(int k=1;k<n;k++)
			tmpans = max(tmpans,a[k]^a[k+1]);
		ans = min(ans,tmpans);
	}
	printf("%lld",ans);
	return 0;
}
