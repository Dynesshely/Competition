#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

int n,K;

inline int getlen(int num){
	int ans = 0;
	while(num){
		ans++;
		num &= num-1;
	}
	return ans;
}

int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%d%d",&n,&K);
	int ans = 0;
	while(getlen(n-K*ans)>ans){
		ans++;
		if((n-K*ans)<=0){
			puts("-1");
			return 0;
		}
	}
	printf("%d",ans);
	return 0;
}
