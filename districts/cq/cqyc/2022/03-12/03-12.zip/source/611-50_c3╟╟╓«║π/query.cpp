#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int tag;
struct ae {
	ll ind,va,ll,lr;
	bool operator<(const ae &oth)const {
		if(tag==0) return ind-ll<oth.ind-oth.ll;
		else if(tag==1) return lr-ind>oth.lr-oth.ind;
		else if(tag==2) return lr-ll<oth.lr-oth.ll;
	}
} a[200010];
ll sa[200010],ind;
int n;
int suma[200010];
ll fa[200010][2];
int main() {
	scanf("%d",&n);
	for(int u=1;u<=2;u++) {
		for(int i=1;i<=n;i++) scanf("%lld",&a[i].va),a[i].ind=i;
	ind=0;
	for(int i=1;i<=n;i++) {
		while(ind) {
			if(a[sa[ind]].va<a[i].va) ind--;
			else break;
		}
		if(ind) a[i].ll=sa[ind];
		else a[i].ll=0;
		sa[++ind]=i;
	}
	ind=0;
	for(int i=n;i>=1;i--) {
		while(ind) {
			if(a[sa[ind]].va<=a[i].va) ind--;
			else break;
		}
		if(ind) a[i].lr=sa[ind];
		else a[i].lr=n+1;
		sa[++ind]=i;
	}
	for(int i=1;i<=n;i++) fa[1][u]+=a[i].va;
	tag=0;sort(a+1,a+1+n);
	int seq=0;
	for(int i=1;i<=n;i++) suma[i]=suma[i-1]+a[i].va;
	for(int i=2;i<=n;i++) {
		while(a[seq+1].ind-a[seq+1].ll<i&&seq<n) seq++;
		fa[i][u]-=suma[seq];
	}
	tag=1;sort(a+1,a+1+n);
	seq=n;
	for(int i=1;i<=n;i++) suma[i]=suma[i-1]+a[i].va;
	for(int i=2;i<=n;i++) {
		while(a[seq].lr-a[seq].ind<i) seq--;
		fa[i][u]+=suma[seq];
	}
	tag=2;sort(a+1,a+1+n);
	seq=0;
	for(int i=1;i<=n;i++) suma[i]=suma[i-1]+a[i].va;
	for(int i=1;i<=n;i++) {
		while(a[seq+1].lr-a[seq+1].ll+1<=i) seq++;
		fa[i][u]+=suma[seq];
	}
	for(int i=2;i<=n;i++) fa[i][u]+=fa[i-1][u];
	}
	for(int i=1;i<=n;i++) cout << fa[i][1] << " ";cout << endl;
	for(int i=1;i<=n;i++) cout << fa[i][2] << " ";cout << endl;
//	for(int i=1;i<=n;i++) {
//		printf("%lld\n",fa[i][1]*fa[i][2]);
//	}
	return 0;
}
