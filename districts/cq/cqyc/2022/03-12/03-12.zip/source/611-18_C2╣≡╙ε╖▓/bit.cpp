#include<bits/stdc++.h>
using namespace std;
int n,k;
bool check(int m)
{
	int num=n-m*k,js=0;
	while(num&&num>0)
	{
		if(num&1)js++;
		num>>=1;
	}
	if(js==m)return 1;
	else return 0;
}
int main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<32;i++)
		if(check(i))
		{
			printf("%d",i);
			return 0;
		}
	printf("-1");
	return 0;
}
