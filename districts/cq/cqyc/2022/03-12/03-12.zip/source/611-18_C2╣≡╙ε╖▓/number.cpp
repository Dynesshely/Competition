#include<bits/stdc++.h>
using namespace std;
#define N 1000005 
int m;
int ans;
long long a,b;
long long vis[N],t[N],len;
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%lld%lld",&m,&a,&b);
	for(int i=1;i<=m;i++)
	{
		if(!vis[i])
		{
			ans++;
			t[++len]=i;
		}
		for(int j=1;j<=len&&((a*i+b)*t[j]-b)/a<=m;j++)
			if(((a*i+b)*t[j]-b)%a==0)vis[((a*i+b)*t[j]-b)/a]=1;
	}
	printf("%d",ans);
	return 0;
}
