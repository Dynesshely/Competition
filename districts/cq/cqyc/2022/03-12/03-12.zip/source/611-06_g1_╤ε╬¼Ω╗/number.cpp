#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) 
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return; 
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while(x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e6+10;
van m,a,b,ans;
bool pr[MaxN];
int main() {
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	read(m),read(a),read(b);
	for (int i=1;i<=m;i++) {
		if (pr[i]) continue; ans++;
		for (int j=2;j<=m;j++) {
			van x=j*(a*i+b)-b; if (x/a>m+10) break;
			if (x%a!=0) continue; pr[x/a]=true;
		}
	} print(ans);
	return 0;
} 
