#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) 
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return; 
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while(x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
const van MaxN=2e5+10;
van n,a[MaxN],ans=1e18; bool used[MaxN];
van l[MaxN],no[MaxN];
void DFS(van now,van d=1,van an=0) {
	used[now]=1;no[d]=now; if (d>=n) {
		if (an<ans) for (int i=1;i<=n;i++) l[i]=no[i];
		ans=min(ans,an);used[now]=0; return;}
	for (int i=1;i<=n;i++) {
		if (!used[i]) DFS(i,d+1,max(an,a[i]^a[now]));
	} used[now]=0;
}
int main() {
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	read(n); for (int i=1;i<=n;i++) read(a[i]);
	if (n<=8) {
		for (int i=1;i<=n;i++) DFS(i);
		print(ans); cout<<endl;
//		for (int i=1;i<=n;i++) {
//			for (int j=1;j<=n;j++) cout<<(a[i]^a[j])<<" ";cout<<endl;
//		}
//		for (int i=1;i<=n;i++) cout<<l[i]<<" ";
		return 0;
	} 
	bool zero=false,one=false;
	for (int i=1;i<=n;i++) {
		if (a[i]==0) zero=true;
		else if (a[i]==1) one=true;
		else goto common;
	} if (zero&&one) print(1);
	else print(0);
	return 0;
	common:
	van _min_=1e18,minid=0;for (int i=1;i<=n;i++) {
		van min_=1e18;
		for (int j=1;j<=n;j++) {
			if (i!=j) min_=min(a[i]^a[j],min_);
		} if (min_<_min_) minid=i,_min_=min_;
	} van now=minid;
	for (int i=1;i<n;i++) {
		used[now]=1;l[i]=now; van minid=0,min_=1e18;
		for (int j=1;j<=n;j++) {
			if (!used[j]) if ((a[i]^a[j])<min_) minid=j,min_=a[i]^a[j];
		} now=minid;
	} l[n]=now; ans=0;
	for (int i=1;i<n;i++) ans=max(ans,a[i]^a[i+1]);
	print(ans);
	return 0;
} 
