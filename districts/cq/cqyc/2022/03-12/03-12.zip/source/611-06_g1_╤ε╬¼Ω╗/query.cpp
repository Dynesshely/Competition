#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) 
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return; 
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while(x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e5+10;
const van mod=1e9+7;
van n,a[MaxN],b[MaxN];
struct SGT {
	van dat[MaxN<<2];
	void BuildTree(van p=1,van l=1,van r=n) {
		if (l==r){dat[p]=0; return;}
		van mid=(l+r)>>1;
		BuildTree(p*2,l,mid);
		BuildTree(p*2+1,mid+1,r);
		dat[p]=max(dat[p*2],dat[p*2+1]);
	}
	void UpdateTree(van wh,van num,van p=1,van l=1,van r=n) {
		if (l==r) {dat[p]=num; return;}
		van mid=(l+r)>>1;
		if (wh<=mid) UpdateTree(wh,num,p*2,l,mid);
		else UpdateTree(wh,num,p*2+1,mid+1,r);
		dat[p]=max(dat[p*2],dat[p*2+1]);
	}
	van QueryTree(van L,van R,van p=1,van l=1,van r=n) {
		if (L<=l&&r<=R) return dat[p];
		van mid=(l+r)>>1,ans=0;
		if (L<=mid) ans=max(ans,QueryTree(L,R,p*2,l,mid));
		if (R>mid) ans=max(ans,QueryTree(L,R,p*2+1,mid+1,r));
		return ans;
	}
}TA,TB;
int main() {
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	read(n); for (int i=1;i<=n;i++) read(a[i]),a[i]+=i;
	for (int i=1;i<=n;i++) read(b[i]),b[i]+=i;
	TA.BuildTree(),TB.BuildTree();
	for (int i=1;i<=n;i++) TA.UpdateTree(i,a[i]);
	for (int i=1;i<=n;i++) TB.UpdateTree(i,b[i]);
	for (int i=1;i<=n;i++) { van sum=0,sum2=0;
		for (int j=1;j<=n-i+1;j++) sum+=TB.QueryTree(j,j+i-1),sum%=mod;
		for (int j=1;j<=n-i+1;j++) sum2+=TA.QueryTree(j,j+i-1),sum2%=mod;
		print(sum*sum2%mod),putchar(' ');
	}
	return 0;
}
