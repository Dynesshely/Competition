#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) 
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return; 
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0){putchar('0');return;}
	van st[51]={0},k=0;
	while(x) st[++k]=x%10,x/=10;
	for (int i=k;i;i--) putchar(st[i]+'0');
}
van count(van x) {van ans=0; while(x) ans+=(x&1),x>>=1; return ans;}
int main() {
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	van n,k; read(n),read(k);
	for (int i=0;i<=100;i++) {
		van re=n-k*i; if (re>=i&&count(re)<=i) {
			print(i);return 0;
		}
	} print(-1);
	return 0;
} 
