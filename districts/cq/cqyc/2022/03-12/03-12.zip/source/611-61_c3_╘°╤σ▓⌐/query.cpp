#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void write(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10);
	putchar(x%10+'0');
}
const int N=100005,mod=1e9+7;
int n,a[N],b[N],f[N];
int c[3005][3005],e[3005][3005][2];
void sub1() {
	for(int i=1;i<=n;++i)
	for(int j=1;j<=n;++j)
		c[i][j]=a[i]*b[j]+i*b[j]+a[i]*j+i*j;
	int now=0,lst=1;
	for(int k=1;k<=n;++k) {
		for(int i=1;i+k-1<=n;++i)
		for(int j=1;j+k-1<=n;++j) {
			if(k==1) e[i][j][now]=c[i][j];
			else e[i][j][now]=max(max(e[i][j][lst],e[i+1][j+1][lst]),max(e[i+1][j][lst],e[i][j+1][lst]));
			f[k]=(f[k]+e[i][j][now])%mod;
		}
		now^=1,lst^=1;
	}
	for(int i=1;i<=n;++i) write(f[i]),putchar(' ');
	exit(0);
}
signed main() {
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) a[i]=read();
	for(int i=1;i<=n;++i) b[i]=read();
	sub1();
	return 0;
}
/*
3
4 1 9
3 4 1

280 204 72
*/
