#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=200005;
int n,a[N],ma,mi=1e18,ans;
bool vis[N];
struct Sub3 {
	int mid;
	void dfs(int x) {
		vis[x]=1;
		for(int i=1;i<=n;++i)
			if((a[i]^a[x])<=mid&&!vis[i]) dfs(i);
	}
	bool check() {
		for(int i=1;i<=n;++i) vis[i]=0;
		dfs(1);
		for(int i=2;i<=n;++i) if(!vis[i]) return 0;
		int t1=0;
		for(int i=1;i<=n;++i) {
			int t=0;
			for(int j=1;j<=n;++j)
				if((a[i]^a[j])<=mid&&i!=j) ++t;
			if(t==1) ++t1;
		}
		return t1<=2;
	}
	void solve() {
		mi=1e18,ma=0;
		for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j)
			ma=max(ma,a[i]^a[j]),mi=min(mi,a[i]^a[j]);
		int l=mi,r=ma;
		while(l<=r) {
			mid=(l+r)/2;
			if(check()) ans=mid,r=mid-1;
			else l=mid+1;
		}
		cout<<ans;
		exit(0);
	}
} sub3;
void sub4() {
	if(ma==mi) puts("0");
	else puts("1");
	exit(0);
}
signed main() {
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) a[i]=read(),ma=max(ma,a[i]),mi=min(mi,a[i]);
	if(ma<=1) sub4();
	/*if(n<=1000)*/ sub3.solve();
	return 0;
}
/*
3
1 2 3

2

4
9 10 13 14

4

2
1 1

0
*/

