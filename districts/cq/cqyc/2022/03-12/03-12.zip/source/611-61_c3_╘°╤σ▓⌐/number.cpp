#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int M=1000005;
int m,ma,a,b,ans;
int v[M];
signed main() {
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	m=read(),a=read(),b=read();
	ma=a*m+b;
	for(int i=1,x;i<=m;++i) {
		x=a*i+b;
		if(!v[i]) ++ans;
		else continue;
		for(int j=x;j<=ma;j+=x) 
			if((j-b)%a==0) v[(j-b)/a]=1;
	}
	cout<<ans;
	return 0;
}
/*
1000 4 3

387

1000000 9 7

457839

1000000 1000000 1000000

78498
*/
