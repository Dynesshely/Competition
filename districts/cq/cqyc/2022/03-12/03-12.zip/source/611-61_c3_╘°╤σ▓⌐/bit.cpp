#include <bits/stdc++.h>
//#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int n,k;
int Log2(int x) {
	int y=1,t=0;
	while(y*2<=x) y*=2,++t;
	return t;
}
signed main() {
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read(),k=read();
	for(int i=1;i<=10000;++i) {
		int x=n-i*k,t=0;
		if(x<=0) continue;
		while(x) x-=(1<<Log2(x)),++t;
		if(t==i||(t<i&&n-i*k>=i)) {
			cout<<i;
			return 0;
		}
	}
	puts("-1");
	return 0;
}
/*
24 0

2

24 1

3

24 -1

4

4 -7

2

1 1

-1
*/
