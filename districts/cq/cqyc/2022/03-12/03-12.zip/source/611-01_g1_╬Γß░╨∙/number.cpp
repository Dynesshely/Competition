#include<cstdio>
#define int long long
int gcd(int a,int b){
	if(!b) return a;
	return gcd(b,a%b);
}
int m,a,b;
const int N=1e6+5;
bool pd[N];
signed main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%lld %lld %lld",&m,&a,&b);
	int v=a/gcd(b,a);
	int ans=0;
	for(int i=1;i<=m;i++){
		int e=(a*i+b)*v/a;
		for(int j=1;j*e+i<=m;j++) pd[j*e+i]=1;
		if(!pd[i]) ans++;
	}
	printf("%lld",ans);
	return 0;
}
