#include<cstdio>
#define int long long
const int N=2e5+5;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[70],tp;
void write(int x) {
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
}
int a[N],fa[N],n;
int ge(int i){
	return fa[i]==i?i:fa[i]=ge(fa[i]);
}
bool pd(int mid){
	for(int i=1;i<=n;i++) fa[i]=i;
	int ans=0;
	for(int i=1;i<=n;i++){
		int an=0;
		for(int j=1;j<=n;j++){
			if((a[i]^a[j])<=mid) fa[ge(i)]=ge(j),an++;
		}
		if(an<=1) ans++;
		if(ans>2) return 0;
	}
	for(int i=1;i<=n;i++) if(fa[i]!=fa[1]) return 0;
	return 1;
}
int ef(int l,int r){
	if(l==r) return l;
	if(r==l+1){
		if(pd(l)) return l;
		return r;
	}
	int mid=((l+r)>>1);
	if(pd(mid)) return ef(l,mid);
	return ef(mid+1,r);
}
signed main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n=read();
	bool pd=1;
	for(int i=1;i<=n;i++){
		a[i]=read();
		if(a[i]>1){
			pd=0;
		}
	}
	if(pd){
		for(int i=1;i<=n;i++){
			if(a[i]!=a[1]) pd=0;
		}
		if(pd) printf("0");
		else printf("1");
		return 0;
	}
	printf("%lld",ef(0,1ll<<60));
	return 0;
}
