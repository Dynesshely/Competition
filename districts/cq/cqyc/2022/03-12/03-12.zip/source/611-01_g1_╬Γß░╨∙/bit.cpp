#include<cstdio>
#define int long long
int fj(int i){
	int ans=0;
	while(i){
		ans++;
		i-=(i&(-i));
	}
	return ans;
}
signed main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	int n=0,k=0;
	scanf("%lld %lld",&n,&k);
	for(int i=0;i<=60;i++){
		if(n<0){
			printf("-1");
			return 0;
		}
		if(i>=fj(n) && i<=n){
			printf("%lld",i);
			return 0;
		}
		n-=k;
	}
	printf("-1");
	return 0;
}
