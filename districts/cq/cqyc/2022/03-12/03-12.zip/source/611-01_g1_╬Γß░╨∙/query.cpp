#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
#define int long long
#define mid ((l+r)>>1) 
const int M=1e9+7,N=3e3+5;
int a[N][N],b[N][N],n;
signed main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i][i]);
		a[i][i]+=i; 
	}
	for(int i=1;i<=n;i++){
		scanf("%lld",&b[i][i]);
		b[i][i]+=i;
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++)
			a[i][j]=max(a[i][j-1],a[j][j]); 
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++)
			b[i][j]=max(b[i][j-1],b[j][j]); 
	}
	for(int i=1;i<=n;i++){
		int an1=0,an2=0;
		for(int j=1;j<=n;j++){
			an1=(an1+a[j][j+i-1])%M;
			an2=(an2+b[j][j+i-1])%M;
		}
		printf("%lld ",an1*an2%M);
	}
	return 0;
}
