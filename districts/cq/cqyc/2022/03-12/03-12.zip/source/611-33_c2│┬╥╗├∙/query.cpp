#include<bits/stdc++.h>
using namespace std;
long long mod=1e9+7,n,a[3005],b[3005],c[3005][3005],sum,num,ans[3005],js,zxy;
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
long long stk[30],tp;
void write(long long x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}
int main()
	{
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	a[i]=read();
	for(int i=1;i<=n;++i)
	b[i]=read();
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			c[i][j]=a[i]*b[j]+i*b[j]+a[i]*j+i*j;
	for(int k=1;k<=n;++k)
	{
		for(int i=1;i<=n-k+1;++i)
		for(int j=1;j<=n-k+1;++j)
		{
			zxy=0;
			for(int q=i;q<=i+k-1;++q)
			for(int w=j;w<=j+k-1;++w)
				zxy=max(zxy,c[q][w]);
			ans[k]+=zxy;
			ans[k]%=mod;
		}
	}
	for(int i=1;i<=n;++i)
	printf("%d ",ans[i]%mod);
	return 0;
	}
