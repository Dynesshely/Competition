#include<bits/stdc++.h>
using namespace std;
long long n,k,sum=1,m,zxy,num,js[105],jl;
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
long long stk[30],tp;
void write(long long x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}
int main()
	{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read(),k=read();
	js[0]=1;
	for(int i=1;i<=62;++i)
		js[i]=js[i-1]*2;
	for(;;)
	{
		zxy=62;
		jl=0;
		num=n-sum*k;
		if(num<=0)
		{
			cout<<-1;
			return 0;
		}
		while(zxy>=0)
		{
			if(num>=js[zxy])
			num=num-js[zxy],jl++;
			else
			zxy--;
		}
		if(num==0&&jl<=sum)
		{
			write(sum);
			return 0;
		}
		sum++;
	}
	return 0;
	}
