#include<bits/stdc++.h>
using namespace std;
long long n,a[200005],sum,num,ans,js;
bool jl[5];
inline long long read()
	{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		{
		if(ch=='-') f=-1;
		ch=getchar();
		}
	while(ch>='0'&&ch<='9')
		{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
		}
	return x*f;
	}
long long stk[30],tp;
void write(long long x)
	{
	do stk[++tp]=x%10,x/=10;
	while(x);
	while(tp)putchar(stk[tp--]^48);
	}
int main()
	{
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	{
		a[i]=read();
		if(a[i]==1)
		jl[1]=true;
		if(a[i]==0)
		jl[0]=true;
	}
	if(jl[1]==true&&jl[0]==true)
	cout<<1;
	else
	cout<<0;
	return 0;
	}
