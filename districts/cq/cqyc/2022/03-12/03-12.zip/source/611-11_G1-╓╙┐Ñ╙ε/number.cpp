// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
ll gcd(ll a,ll b){
	if(b) return gcd(b,a%b);
	else return a;
}
//
const ll N=1e7;
bool vis[N+10];
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
//	usage();
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	ll m=gt(),a=gt(),b=gt(),gbs=a/gcd(a,b)*b,ans=0;
	ll bs=gbs/b,xs=gbs/a;
//	printf("%lld %lld\n",bs,xs);
	FOR(i,1,m){
		if(!vis[i]) ++ans;
		else continue;
//		printf("%lld\n",i);
		FOR(j,1,1e15){
//			printf("%lld-%lld ",(j*bs+1)*i+j*xs,((j*bs+1)*i+j*xs)*a+b);
			if((j*bs+1)*i+j*xs>m) break;
			vis[(j*bs+1)*i+j*xs]=1;
		}
//		printf("\n");
	}
	printf("%lld",ans);
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



