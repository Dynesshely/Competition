#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
	putchar(' ');
}
int MAXM,n,k,a[50],tmp,res,now,l=1,r,mid,ans,N,tot;
bool flag;
signed main(){
	freopen("bit2.in","r",stdin);
	freopen("bit2.ans","w",stdout);
	N=read();k=read();
	if(k>=0)
		r=N/(k+1);
	else
		r=1000000000;
	while(l<=r){
		mid=(l+r)>>1;
		n=N-mid*k;
		tmp=n;
		flag=0;now=res=0;
		memset(a,0,sizeof a);
		for(int j=1;tmp;++j){
			if(tmp&1){
				a[j]=1;
				now=j;
				++res;
			}
			tmp>>=1;
		}
		while(res!=mid){
			if(!a[now])
				--now;
			if(now<=1){
				flag=1;
				break;
			}
			if(a[now]+res<=mid){
				res+=a[now];
				a[now-1]+=a[now]<<1;
				a[now]=0;
			}
			else
				res=mid;
			++tot;
		}
		if(!flag){
			ans=mid;
			r=mid-1;
		}
		else
			l=mid+1;
	}
	if(!ans)
		puts("-1");
	else
		write(ans);
	return 0;
}
