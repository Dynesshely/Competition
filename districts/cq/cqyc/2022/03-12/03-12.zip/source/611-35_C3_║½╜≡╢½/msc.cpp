#include<bits/stdc++.h>
#define int long long
#define N 400005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,a[N],ans=1e9,tot;
bitset<N> vis;
inline void dfs(int k,int mx,int tot){
	if(mx>=ans)
		return;
	if(tot==n){
		ans=mx;
		return;
	}
	for(int i=1;i<=n;++i)
		if(!vis[i]){
			vis[i]=1;
			dfs(i,max(mx,a[i]^a[k]),tot+1);
			vis[i]=0;
		}
}
signed main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
	for(int i=1;i<=n;++i){
		vis[i]=1;
		dfs(i,0,1);
		vis[i]=0;
	}
	write(ans);
	return 0;
}
