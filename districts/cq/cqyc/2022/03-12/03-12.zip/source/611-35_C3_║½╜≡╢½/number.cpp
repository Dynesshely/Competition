#include<bits/stdc++.h>
#define int long long
#define N 100000000
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
inline int gcd(int a,int b){
	if(!a)
		return b;
	return gcd(b%a,a);
}
int m,a,b,ans,xhj,MAXM;
bitset<N> vis;
signed main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	m=read();a=read();b=read();
	MAXM=a*m+b;
	xhj=a*b/gcd(a,b)/b;
	for(int i=1;i<=m;++i){
		if(vis[i])
			continue;
		++ans;
		for(int j=1+xhj;(i*a+b)*j<=MAXM;j+=xhj)
			vis[((i*a+b)*j-b)/a]=1;
	}
	write(ans);
	return 0;
}
