#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e6+10;
int M,A,B,tot,num[Maxn],ans;
bool Vis[Maxn];

inline int read(){
	int ret=0,f=1; char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-1; ch=getchar(); }
	while(isdigit(ch)) ret=(ret<<3)+(ret<<1)+ch-'0',ch=getchar();
	return ret*f;
}

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	M=read(), A=read(), B=read();
	if(M<=1000){
		for(int i=1;i<=M;i++){
			bool flag=false;
			num[i]=A*i+B;
			for(int j=1;j<i;j++)
				if(num[i]%num[j]==0){ flag=true; break; }
			if(!flag) ans++;
		}
		printf("%d",ans);
		return 0;
	}
	for(int i=1;i<=M;i++){
		long long tmp=A*i+B; int k=1;
		while((long long)k*tmp/A+i<=M){
			if(k*tmp%A==0){
				int j=i+(long long)k*((long long)A*i+B)/A;
				if(!Vis[j]) Vis[j]=true,tot++;
			}
			k++;
		}
	}
	printf("%d",M-tot);
	return 0;
} 
