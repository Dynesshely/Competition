#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int Mod=1e9+7;
const int Maxn=5010;
int N,A[Maxn],B[Maxn];
ll C[Maxn][Maxn];

inline int read(){
	int ret=0,f=1; char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-1; ch=getchar(); }
	while(isdigit(ch)) ret=(ret<<3)+(ret<<1)+ch-'0',ch=getchar();
	return ret*f;
}

int main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	N=read();
	for(int i=1;i<=N;i++) A[i]=read();
	for(int i=1;i<=N;i++) B[i]=read();
	for(int i=1;i<=N;i++) for(int j=1;j<=N;j++)
		C[i][j]=((ll)A[i]*B[j]%Mod+(ll)i*B[j]%Mod+(ll)A[i]*j%Mod+(ll)i*j%Mod)%Mod;
	for(int k=1;k<=N;k++){
		int ans=0;
		for(int x=1;x<=N-k+1;x++) for(int y=1;y<=N-k+1;y++){
			ll tmp=0;
			for(int i=x;i<=x+k-1;i++) for(int j=y;j<=y+k-1;j++)
				tmp=max(tmp,C[i][j]);
			ans=((ll)ans+tmp)%Mod;
		}
		printf("%d ",ans);
	}
	return 0;
} 
