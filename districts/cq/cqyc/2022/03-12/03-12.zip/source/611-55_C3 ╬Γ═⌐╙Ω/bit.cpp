#include<bits/stdc++.h>
using namespace std;

int N,K,ans=-1;
bool flag=false;

inline int read(){
	int ret=0,f=1; char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-1; ch=getchar(); }
	while(isdigit(ch)) ret=(ret<<3)+(ret<<1)+ch-'0',ch=getchar();
	return ret*f;
}

bool check(int m){
	int tmp=N-m*K,tot=0;
	if(!tmp) return 0;
	while(tmp){
		if(tmp&1) tot++;
		tmp>>=1;
	}
	if(tot>m) return 0;
	return 1;
}

int main(){ 
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	N=read(),K=read();
	int l=1,r=N;
	while(l<=r){
		int mid=(l+r)>>1;
		if(check(mid)) ans=mid,r=mid-1;
		else l=mid+1;
	}
	printf("%d",ans);
	return 0;
} 
