#include<bits/stdc++.h>
using namespace std;
#define int unsigned long long

const int Maxn=1010;
const int Maxm=2e5+10;
const int INF=1e9+10;
int edge[Maxn][Maxn],mx;
int N,cnt,hed[Maxn],nxt[Maxn*Maxn],to[Maxn*Maxn];
int A[Maxm],size[Maxm],ans,fa[Maxm];
bool flag1,flag2,Vis[Maxn];

inline int read(){
	int ret=0,f=1; char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-1; ch=getchar(); }
	while(isdigit(ch)) ret=(ret<<3)+(ret<<1)+ch-'0',ch=getchar();
	return ret*f;
}

void Addedge(int x,int y){ nxt[++cnt]=hed[x]; to[cnt]=y; hed[x]=cnt; }

bool check(int num){
	cnt=0;
	memset(hed,0,sizeof hed); memset(nxt,0,sizeof nxt);
	memset(to,0,sizeof to); memset(Vis,0,sizeof Vis);
	for(int i=1;i<=N;i++) for(int j=1;j<=N;j++){
		if(i==j||edge[i][j]>num) continue;
		Addedge(i,j),Addedge(j,i);
	}
	queue<int> Q; Q.push(1); Vis[1]=true;
	while(!Q.empty()){
		int x=Q.front(); Q.pop();
		for(int y,i=hed[x];i;i=nxt[i]){
			if(Vis[y=to[i]]) continue;
			Vis[y]=true; Q.push(y);
		}
	}
	for(int i=1;i<=N;i++) if(!Vis[i]) return 0;
	return 1;
}

signed main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	N=read();
	for(int i=1;i<=N;i++){
		A[i]=read();
		if(A[i]>1) flag1=true;
		if(i>1&&A[i]!=A[i-1]) flag2=true;
	}
	if(!flag2){ puts("0"); return 0; }
	if(!flag1){ puts("1"); return 0; }
	if(N<=1000){
		for(int i=1;i<=N;i++) for(int j=1;j<=N;j++)
			edge[i][j]=A[i]^A[j],mx=max(mx,edge[i][j]);
		int l=0,r=mx;
		while(l<=r){
			int mid=(l+r)>>1;
			if(check(mid)){
				ans=mid; if(l==r) break;
				r=mid-1;
			}
			else{ if(l==r) break; l=mid+1; }
		}
		printf("%llu",ans);
		return 0;
	}
	for(int i=1;i<=N;i++){
		if(size[i]==2) continue;
		int len_min=INF,to=0;
		for(int j=1;j<=N;j++){
			if(i==j||j==fa[i]) continue;
			int len=A[i]^A[j];
			if(len<len_min&&size[j]<2)
				len_min=len,to=j;
		}
		size[i]++,size[to]++; fa[to]=i;
		ans=max(ans,len_min);
	}
	printf("%d",ans);
	return 0;
} 
