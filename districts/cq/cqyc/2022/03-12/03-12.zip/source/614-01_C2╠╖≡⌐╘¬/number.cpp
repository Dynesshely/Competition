#include<bits/stdc++.h>
using namespace std;
long long n,a,b,c,d,j=0,ans=0,q=0;
long long sp[1000020][3];
int kl[1000020];
int main() {
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%lld%lld%lld",&n,&a,&b);
	for(int i=2; i<=n; i++) {
		if(((i-1)*b)%a==0) {
			j++;
			sp[j][1]=i;
			sp[j][2]=(i-1)*b/a;
		}
    }
		for(int i=1; i<=n; i++) {
			for(int y=1; y<=j; y++) {
				q++;
				if(sp[y][2]+sp[y][1]*i<=n) kl[sp[y][2]+sp[y][1]*i]=1;
				else break;
			}
		}
		for(int i=1;i<=n;i++) if(kl[i]==0) ans++;
		//cout<<q<<endl;
		printf("%lld\n",ans);
		// y=(z-1)*b/a+zx
}
// y-5x=3
