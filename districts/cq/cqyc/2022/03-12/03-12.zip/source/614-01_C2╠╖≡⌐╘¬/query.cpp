#include<bits/stdc++.h>
using namespace std;
long long n,a[213712],b[214883],mod=10000000007,sum=0,ans=0;
long long sp[2000][2000];
int main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout); 
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++) scanf("%lld",&b[i]);
	for(int i=1;i<=n;i++)
		for(int y=1;y<=n;y++)
		sp[i][y]=a[i]*b[y]+a[i]*y+i*b[y]+i*y;
	for(int k=1;k<=n;k++){
		ans=0;
		for(int y=1;y<=n-k+1;y++)
			for(int z=1;z<=n-k+1;z++) {
			    sum=0;
				for(int q=y;q<=y+k-1;q++){
					for(int h=z;h<=z+k-1;h++){
						sum=max(sum,sp[q][h]);
					}
				}
				ans=(ans+sum)%mod;
			}
		printf("%lld",ans);
		printf(" ");
	}
} 
