#include<bits/stdc++.h>
using namespace std;
int n,k,x=1,y=0,col[200001],kl[200001],l=0;
long long sp2[201000],j=0,ans=0;
struct jk{
	long long lr,rs,qz;
}sp[2000000];
bool cmp(jk x,jk y){
	return x.qz<y.qz;
}
int find(int k){
	if(col[k]==k) return k;
	else return col[k]=find(col[k]);
}
int main(){
	freopen("msu.in","r",stdin);
	freopen("msu.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {
	scanf("%lld",&sp2[i]);	
	if(sp2[i]==1||sp2[i]==0) l++;
	}
	if(l==n){
		printf("1");
		return 0;
	}
	for(int i=1;i<=n;i++){
		col[i]=i;
		for(int y=i+1;y<=n;y++){
			if(i!=y) {
				j++;
				sp[j].qz=sp2[i]^sp2[y];
				sp[j].lr=i;
				sp[j].rs=y;
				//cout<<i<<" "<<y<<" "<<sp[j].qz<<endl;
			}
		}
	}
	sort(sp+1,sp+j+1,cmp);	
	for(int i=1;i<=j;i++){
		find(sp[i].lr);
		find(sp[i].rs);
        if(col[sp[i].lr]!=col[sp[i].rs]){
        	if(kl[sp[i].lr]!=2&&kl[sp[i].rs]!=2){
        		kl[sp[i].lr]++;
        		kl[sp[i].rs]++;
        		col[col[sp[i].lr]]=col[sp[i].rs];
        		ans=max(ans,sp[i].qz);
			}
		}
	//	if(col[i]==col[i])
	}
	printf("%lld\n",ans);
}
//
