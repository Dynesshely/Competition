#include<bits/stdc++.h>
using namespace std;
int n,k,p=0,m=0,j=1,s=0;
int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout); 
	scanf("%d%d",&n,&k);
	while(1==1){
		 m++;
	     n=n-k;
	     p=abs(n);
	   //  cout<<p<<endl;
	     j=1;
	     while(j*2<=p){j=j*2;}
	    // cout<<j<<endl; 
	     s=0;
	     while(2==2){
	     	//cout<<p<<endl;
	     	if(p==0) {//  28=16+8+4
	     	//	cout<<n<<" "<<s<<" "<<m<<endl;
	     		if(s>m) break;
	     		printf("%d\n",m);
	     		return 0;
		    } 
	     	if(p>=j) p=p-j,s++;
	     	j=j/2;
		 }
		 //cout<<1;
	}
} 
