#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+7,logn=62,maxn2=1006;
const long long inf=1e18+7;
int n;
long long a[maxn],ans;
long long b[maxn];
bool vis[maxn];
int cnt,hed[maxn2],nxt[maxn2*maxn2],to[maxn2*maxn2];
//bool used[maxn2*maxn2];
long long l,r,mid;
void init(){
	ans=inf;
	return ;
}
void reinitG(){
	cnt=1;
	memset(hed,0,sizeof(hed));
	memset(nxt,0,sizeof(nxt));
	memset(to,0,sizeof(to));
//	memset(used,0,sizeof(used));
	memset(vis,0,sizeof(vis));
	return ;
}
void add(int u,int v){
	nxt[++cnt]=hed[u];
	hed[u]=cnt;
	to[cnt]=v;
	return ;
}
bool dfs(int x,int sum){
	if(sum==n)return 0;
	vis[x]=1;
	int v;
	bool flag=1;
	for(int i=hed[x];i;i=nxt[i]){
//		if(used[i])continue;
//		used[i]=used[i^1]=1;
		v=to[i];
		if(vis[v])continue;
		if((a[x]^a[v])>mid)continue;
		flag&=dfs(v,sum+1);
	}
	vis[x]=0;
	return flag;
}
int main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	init();
	scanf("%d",&n);
	long long mx=0,mi=inf;
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		mx=max(mx,a[i]);
		mi=min(mi,a[i]);
	}
	if(mx==0){
		putchar('0');
		return 0;
	}
	else if(mx==1){
		if(mi==1){
			putchar('0');
		}
		else putchar('1');
		return 0;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(i==j)continue;
			add(i,j);
			add(j,i);
		}
	}
	bool flag;
	l=1,r=mx*2;
	while(l<=r){
		mid=(l+r)/2;
//		reinitG();
//		for(int i=1;i<=n;i++){
//			for(int j=1;j<=n;j++){
//				if(i==j)continue;
//				if((a[i]^a[j])<=mid){
//					add(i,j);
//					add(j,i);
//				}
//			}
//		}
		flag=1;
		for(int i=1;i<=n;i++){
			flag&=dfs(i,1);
		}
		if(!flag){
			ans=mid;
			r=mid-1;
		}
		else l=mid+1;
	}
	printf("%lld",ans);
	return 0;
}
