#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+7;
long long m,a,b,ans;
bool vis[maxn];
void init(){
	ans=0;
	memset(vis,0,sizeof(vis));
	return ;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	init();
	scanf("%lld%lld%lld",&m,&a,&b);
	long long w;
	for(long long i=1;i<=m;i++){
		if(!vis[i]){
			ans++;
			for(long long j=2;j*(a*i+b)<=a*m+b;j++){
				w=j*(a*i+b);
				if((w-b)%a==0){
					vis[(w-b)/a]=1;
				}
			}
		}
	}
	printf("%lld",ans);
	return 0;
}
