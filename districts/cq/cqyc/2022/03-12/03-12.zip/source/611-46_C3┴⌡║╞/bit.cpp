#include<bits/stdc++.h>
using namespace std;
long long n,k;
int num(long long k){
	int ret=0;
	while(k){
		ret++;
		k-=(k&-k);
	}
	return ret;
}
int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	int w;
	bool flag=1;
	for(long long i=1;i*k<n;i++){
		w=num(n-i*k);
		if(w<=i&&i<=n-i*k){
			printf("%lld",i);
			flag=0;
			break;
		}
	}
	if(flag)printf("-1");
	return 0;
}
