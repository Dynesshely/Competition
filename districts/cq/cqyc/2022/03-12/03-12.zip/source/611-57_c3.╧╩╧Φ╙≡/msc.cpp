#include<bits/stdc++.h>
using namespace std;
const int N=1010,M=N*N;
struct ok{
	int from,to;
	long long lth;
	bool operator <(const ok &A) const{return lth<A.lth;}
};
int n,fa[N],deg[N];
long long ans,a[N];
vector<ok>edge;
inline int find(int x) {return fa[x]==x?x:fa[x]=find(fa[x]);}
void Kruskal()
{
	n=edge.size();
	for(int i=0;i<n;i++)
	{
		ok x=edge[i];
		if(find(x.from)==find(x.to)||deg[x.from]>1||deg[x.to]>1) continue;
		fa[find(x.from)]=find(x.to);
		deg[x.from]++,deg[x.to]++;
		ans=max(ans,x.lth);
	}
	return;
}
int main()
{
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	scanf("%d",&n);
	if(n<=1e3)
	{
		for(int i=1;i<=n;i++) scanf("%lld",a+i),fa[i]=i;
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) if(i!=j) edge.push_back((ok){i,j,a[i]^a[j]});
		sort(edge.begin(),edge.end());
		Kruskal();
	}
	printf("%lld\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
