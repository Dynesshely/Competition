#include<bits/stdc++.h>
using namespace std;
const int N=1e6+10;
int m,a,b,ans;
bool biao[N];
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%d%d",&m,&a,&b);
	if(!(b%a)) b/=a,a=1;
	for(int i=1;i<=m;i++)
	{
		int k=a*i+b;
		for(int j=k+i;j<=m;j+=k) biao[j]=true;
		ans+=!biao[i];
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
