#include<bits/stdc++.h>
using namespace std;
const int N=55,mod=1e9+7;
int n,a[N],b[N];
long long ans[N],A[N][N];
int main()
{
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",a+i);
	for(int i=1;i<=n;i++) scanf("%d",b+i);
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) A[i][j]=1ll*a[i]*b[j]%mod+1ll*i*b[j]%mod+1ll*a[i]*j%mod+i*j;
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) for(int k=0;k<n;k++)
	{
		if(i+k>n||j+k>n) break;
		int r1=i+k,r2=j+k;
		long long res=0;
		for(int I=i;I<=r1;I++) for(int J=j;J<=r2;J++) res=max(res,A[I][J]);
		ans[k+1]=(ans[k+1]+res)%mod;
	}
	for(int i=1;i<=n;i++) printf("%lld ",ans[i]);
	fclose(stdin);fclose(stdout);
	return 0;
}
