#include<bits/stdc++.h>
using namespace std;
int n,k,ans;
bool check(int x)
{
	int num=n-x*k;
	return __builtin_popcount(num)<=x&&x<=num;
}
int main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=50;i++) if(check(i)) {ans=i;break;}
	if(!ans) ans=-1;
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
