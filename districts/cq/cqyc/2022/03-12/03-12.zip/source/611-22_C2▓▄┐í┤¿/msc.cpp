#include <bits/stdc++.h>
using namespace std;
int n,a[1000005];
int main()
{
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	sort(a+1,a+n+1);
	cout<<a[n]-a[1];
}
