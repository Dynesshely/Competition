#include<bits/stdc++.h>
using namespace std;
int n,k,ans;
int p[40];
int main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%d%d",&n,&k);
	p[0]=1; 
	for(int i=1;i<=30;i++) 
	{
		p[i]=p[i-1]*2;
		if(p[i]<n) ans=i;
	}
	cout<<ans;
}
