#include <bits/stdc++.h>
using namespace std;
int n = 10000, a, b;
int main() {
	freopen("number.in", "w", stdout); 
	srand(time(0));
	for(int i = 1; i <= 4; ++i)
		a=rand()%100+1, 
		b=rand()%100+1;
	cout<<n<<" "<<a<<" "<<b<<"\n";
	return 0;
}
