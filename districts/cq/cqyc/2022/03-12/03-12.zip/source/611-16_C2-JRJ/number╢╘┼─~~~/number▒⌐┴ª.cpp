#include <bits/stdc++.h>
using namespace std;
int a, b, m, ans;
long long now, ton[1000006]; 
inline int read() {
	int x=0,f=1; char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main() {
	freopen("number.in", "r", stdin);
	freopen("number.ans", "w", stdout);
	m=read(), a=read(), b=read();
	for(int i = 1; i <= m; ++i) {
		ton[i]=1LL*a*i+1LL*b;
		int panduan=0;
		for(int j = 1; j < i; ++j)
			if(ton[i] % ton[j] == 0)panduan=1;
		if(!panduan) ++ans;
	}
	write(ans);
	return 0;
}
