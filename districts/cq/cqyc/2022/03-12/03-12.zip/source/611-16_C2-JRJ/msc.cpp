#include <bits/stdc++.h>
using namespace std;
int n, pd[1005], l, r;
long long a[1005], mxw;
inline read(auto &x) {
	x=0; int f=1; char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=1LL*(x<<1)+1LL*(x<<3)+1LL*(ch^48);ch=getchar();}
	x*=1LL*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
struct bian{
	long long w;
	int to;
};
struct pnt {
	bian s[1003];
	int fir;
}p[1003];
bool comp(bian A, bian B) {
	return A.w < B.w;
}
int main() {
	freopen("msc.in", "r", stdin);
	freopen("msc.out", "w", stdout);
	read(n);
	if(n >= 100000) return 0;
	for(int i = 1; i <= n; ++i) {
		read(a[i]); 
		for(int j = 1; j < i; ++j) {
			long long www=1LL*(a[i]^a[j]);
			p[i].s[++p[i].fir]=(bian) {www, j};
			p[j].s[++p[j].fir]=(bian) {www, i};
		}
	}
	for(int i = 1; i <= n; ++i)
		p[i].fir=1, sort(p[i].s+1, p[i].s+n, comp);
	mxw=2000000000000000000LL;
	for(int i = 1; i <= n; ++i)
		if(p[i].s[p[i].fir].w < mxw) {
			mxw=p[i].s[p[i].fir].w;
			l=i;
			r=p[i].s[p[i].fir].to;
		}
	pd[l]=pd[r]=1;
	for(int i = 3; i <= n; ++i) {
		while(pd[p[l].s[p[l].fir].to] && p[l].fir < n) ++p[l].fir;
		while(pd[p[r].s[p[r].fir].to] && p[r].fir < n) ++p[r].fir;
		if(p[l].s[p[l].fir].w < p[r].s[p[r].fir].w) {
			mxw=max(mxw, p[l].s[p[l].fir].w); 
			l=p[l].s[p[l].fir].to;
			pd[l]=1;
		} 
		else {
			mxw=max(mxw, p[r].s[p[r].fir].w); 
			r=p[r].s[p[r].fir].to;
			pd[r]=1;
		}
	}
	cout<<mxw<<"\n";
	return 0;
}
/*
��ʱ��1 hour
Tips: ����,�����ĸ�������������QAQ 
*/
