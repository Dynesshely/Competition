#include <bits/stdc++.h>
using namespace std ;
int n, a[3003], b[3003];
long long c[3003][3003];
inline int read() {
	int x=0,f=1; char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
void write(long long x){
	int stk[30],tp=0;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int main() {
	freopen("query.in", "r", stdin);
	freopen("query.out", "w", stdout);
	n = read();
	for(int i = 1; i <= n; ++i)
		a[i]=read();
	for(int i = 1; i <= n; ++i)
		b[i]=read();
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= n; ++j)
			c[i][j]=1LL*a[i]*b[j]+1LL*a[i]*j+1LL*b[j]*i+1LL*i*j;
	for(int k = 1; k <= n; ++k) {
		long long f=0; 
		for(int i = 1; i <= n-k+1; ++i)
			for(int j = 1; j <= n-k+1; ++j) {
				long long maxn=0;
				for(int x = i; x <= i+k-1; ++x)
					for(int y = j; y <= j+k-1; ++y)
						maxn=max(maxn, c[x][y]);
				f+=maxn;
			}
		write(f);
		putchar('\n');
	}
	return 0;
}
