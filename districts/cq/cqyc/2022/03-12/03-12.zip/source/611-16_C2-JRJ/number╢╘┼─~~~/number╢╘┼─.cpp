#include <bits/stdc++.h>
using namespace std;
int main () {
	while(1) {
		system("number����.exe");
		system("number����.exe");
		system("number.exe");
		if(system("fc number.out number.ans"))
			break; 
	}
	return 0;
}
