#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MOD=1000000007;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n,a[100010],b[100010],c[3010][3010],ans;
int qmx(int x,int y)
{
	return max(max(max(c[x][y],c[x-1][y-1]),c[x-1][y]),c[x][y-1]);
}
signed main()
{
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	for(int i=1;i<=n;i++)
	{
		b[i]=read();
	}
	if(n<=3000)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				c[i][j]=a[i]*b[j]+i*b[j]+j*a[i]+i*j;
				ans+=c[i][j];
				if(ans>=MOD) ans%=MOD;
			}
		}
		cout<<ans<<' ';
		for(int t=2;t<=n;t++)
		{
			ans=0;
			for(int i=n;i>=t;i--)
			{
				for(int j=n;j>=t;j--)
				{
					c[i][j]=qmx(i,j);
					ans+=c[i][j];
					if(ans>=MOD) ans%=MOD;
				}
			}
			cout<<ans<<' ';
		}
	}
	
	return 0;
 } 
