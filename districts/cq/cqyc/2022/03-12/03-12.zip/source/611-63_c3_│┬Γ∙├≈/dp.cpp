#include<bits/stdc++.h>
#include<windows.h>
using namespace std;

int main()
{
	while(1)
	{
		system("number_datamaker.exe");
		system("number.exe");
		system("number_t.exe");
		if(system("fc number_t.out number.out"))
		{
			return 0;
		}
	}
	return 0;
} 
