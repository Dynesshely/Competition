#include<bits/stdc++.h>
using namespace std;

signed main()
{
	freopen("msc.in","w",stdout);
	int n=1000;
	cout<<n<<'\n';
	for(int i=1;i<=n;i++)
	{
		cout<<1<<" ";
	}
	return 0;
} 
