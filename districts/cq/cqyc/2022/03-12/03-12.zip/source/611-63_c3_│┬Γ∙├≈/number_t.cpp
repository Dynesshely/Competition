#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int m,a,b,ans;
signed main()
{
	freopen("number.in","r",stdin);
	freopen("number_t.out","w",stdout);
	m=read(),a=read(),b=read();
	for(int i=1;i<=m;i++)
	{
		int tot=i*a+b;
		bool ok=1;
		for(int j=1;j<i;j++) 
		{
			if(tot%(j*a+b)==0)
			{
				ok=0;
				break;
			}
		}
		if(ok==1) ans++;
	}
	cout<<ans;
	return 0;
 } 
