#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n,a[100010],cnt;
vector<int> vc[100010];
bool op=0,vis[100010];
void dfs(int x)
{
//	cerr<<x<<'\n';
	cnt++;
	int tot;
	for(int i=0;i<vc[x].size();i++)
	{
		tot=vc[x][i];
		if(vis[tot]==0)
		{
			vis[tot]=1;
			dfs(tot);
		}
	}
}
bool check(int t)
{
	cnt=0;
	memset(vis,0,sizeof vis);
	vis[1]=1;
	for(int i=1;i<=n;i++)
	{
		vc[i].clear();
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if((a[i]^a[j])<=t)
			{
				vc[i].push_back(j);
				vc[j].push_back(i);
			}
		}
	}
	dfs(1);
//	cerr<<t<<" "<<cnt<<"t\n";
	if(cnt==n) return 1;
	return 0;
}
void Solve3()
{
	int l=0,r=LONG_LONG_MAX/4,mid,ans=0;
	while(l+1<r)
	{
		mid=(l+r)>>1;
//		cerr<<l<<" "<<r<<" "<<mid<<'\n';
		if(check(mid))
		{
			r=mid;
			ans=r;
		}
		else l=mid;
	}
	if(check(l)) cout<<l;
	else cout<<ans;
	return;
}
signed main()
{
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
		if(a[i]>1) op=1;
	}
	if(op==0)//solve4
	{
		for(int i=2;i<=n;i++)
		{
			if(a[i]!=a[i-1])
			{
				cout<<1;
				return 0;
			}
		}
		cout<<0;
		return 0;
	}
	if(n<=1000)
	{
		Solve3();
	}
	return 0;
 } 
