#include<bits/stdc++.h>
using namespace std;
long long ans;
signed main()
{
	for(int i=1;i<=3000;i++)
	{
		ans+=i*i;
	}
	cout<<ans;
	return 0;
}
