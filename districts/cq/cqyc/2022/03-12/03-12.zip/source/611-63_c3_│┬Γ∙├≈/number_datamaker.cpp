#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int m,a,b;
signed main()
{
	freopen("number.in","r",stdin);
	srand(time(0));
	m=read(),a=read(),b=read();
	fclose(stdin);
	freopen("number.in","w",stdout);
	if(a==10000) cout<<m<<" "<<1<<" "<<b+1; 
	else cout<<m<<" "<<a+1<<" "<<b;
	return 0;
 } 
