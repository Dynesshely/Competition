#include<bits/stdc++.h>
#define int long long
#define lowbit(x) (x&-x)
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n,k,cnt;
signed main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read(),k=read();
	for(int i=1;;i++)
	{
		int tot=n-i*k;
		cnt=0;
		if(tot<i)
		{
			cout<<"-1";
			return 0;
		}
		while(tot)
		{
//			tmp[++cnt]=lowbit(tot);
			cnt++;
			tot-=lowbit(tot);
		} 
		if(cnt<=i)
		{
			cout<<i;
			return 0;
		}
	}
	return 0;
 } 
