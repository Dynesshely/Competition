#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int gcd(int x,int y)
{
	if(y==0) return x;
	return gcd(y,x%y);
}
int n,a,b,vis[1000010],ans;
signed main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	n=read(),a=read(),b=read();
	int g=gcd(a,b);
	a/=g,b/=g;
//	cerr<<a<<" "<<b<<'\n'; 
	for(int i=1;i<=n;i++)
	{
		int tmp=a*i+b;
		for(int j=1;;j++)
		{
			if((j*tmp+a*i)/a>n)
			{
				break;
			}
			if((j*tmp+a*i)%a==0)vis[(j*tmp+a*i)/a]=1;
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(!vis[i])
		{
			ans++;
		}
	}
	cout<<ans;
	return 0;
} 
