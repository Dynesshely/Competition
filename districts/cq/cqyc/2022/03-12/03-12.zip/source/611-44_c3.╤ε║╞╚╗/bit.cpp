#include<bits/stdc++.h>
using namespace std;
long long n,m,k,l,r,p,q,num;
inline long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
} 
int stk[40],tp;
void write(long long x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}

int main()
{
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=read(),k=read();
	if(k>=n) {
		printf("-1");
		return 0;
	}
	for(long long i=1;i*(k+1)<=n;i++)
	{
		q=p=n-i*k;num=0;
		for(;q;q>>=1) num+=q&1;
		if(num<=i&&i<=p)
		{
			write(i);
			return 0;
		}
	}
	return 0;
}
