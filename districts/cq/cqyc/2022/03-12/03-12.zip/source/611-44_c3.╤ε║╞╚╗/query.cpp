#include<bits/stdc++.h>
using namespace std;
int n,p,q;
long long a[3001],b[3001],f[3001][3001][2],ans;
inline long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(long long x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
	putchar(' ');
}
int main()
{
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) b[i]=read();
	for(int i=1;i<=n;i++) 
	{
		for(int j=1;j<=n;j++) 
		{
			f[i][j][1]=a[i]*b[j]+i*b[j]+a[i]*j+i*j;
			ans=(ans+f[i][j][1])%1000000007;
		}
	}
	write(ans);
	for(int k=2;k<=n;k++)
	{
		p=k&1;q=1^p;
		ans=0;
		for(int i=1;i<=n-k+1;i++)
		{
			for(int j=1;j<=n-k+1;j++)
			{
				f[i][j][p]=max(max(f[i][j][q],f[i+1][j][q]),max(f[i][j+1][q],f[i+1][j+1][q]));
				ans=(ans+f[i][j][p])%1000000007;
			}
		}
		write(ans);
	}
	return 0;
}

