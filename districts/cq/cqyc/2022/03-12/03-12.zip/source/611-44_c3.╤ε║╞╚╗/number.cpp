#include<bits/stdc++.h>
using namespace std;
int m,a,b,d,pa,pb,ans;
bool vis[1500001];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
int stk[30],tp;
void write(int x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
int gcd(int x,int y)
{
	if(!y) return x;
	return gcd(y,x%y);
}
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	m=read(),a=read(),b=read();
	d=gcd(a,b);
	pa=a/d,pb=b/d;
	for(int i=1;i<=m;i++)
		for(int j=1;((j*pa+1)*(a*i+b)-b)/a<=m;j++)
			vis[((j*pa+1)*(a*i+b)-b)/a]=1;
	for(int i=1;i<=m;i++) if(!vis[i]) ans++;
	write(ans);
	return 0;
}

