#include<bits/stdc++.h>
using namespace std;
struct node{
	int nxt,to;
	unsigned long long dis;
}e[2000001];
int n,ne,u,num;
unsigned long long ans,a[1001],dis[1001];
int h[1001];
bool vis[1001];
priority_queue<pair<unsigned long long,int> > qu;
inline unsigned long long read()
{
	unsigned long long x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x;
}
int stk[40],tp;
void write(unsigned long long x){
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp)putchar(stk[tp--]^48);
}
void add(int x,int y,unsigned long long z)
{
	e[++ne].nxt=h[x];
	e[ne].to=y,e[ne].dis=z,h[x]=ne;
}
void dij()
{
	memset(dis,0x7f,sizeof(dis));
	qu.push(make_pair(0,1));dis[1]=0;
	while(!qu.empty())
	{
		u=qu.top().second;qu.pop();
		if(vis[u]) continue;vis[u]=1;
		for(int i=h[u];i;i=e[i].nxt)
		{
			dis[e[i].to]=min(dis[e[i].to],max(e[i].dis,dis[u]));
			qu.push(make_pair(-dis[e[i].to],e[i].to));
		}
	}
}
int main()
{
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	scanf("%d",&n);
	if(n<=1000)
	{
		for(int i=1;i<=n;i++) 
		{
			a[i]=read();
			for(int j=1;j<i;j++)
			{
				add(i,j,a[i]^a[j]);
				add(j,i,a[i]^a[j]);
			}
		}
		dij();
		for(int i=1;i<=n;i++) ans=max(ans,dis[i]);
		write(ans);
	}
	else
	{
		for(int i=1;i<=n;i++) num+=read();
		if(num)
		{
			if(num==n) putchar((n&1)+48);
			else putchar(49);
		}
		else putchar(48);
	}
	return 0;
}

