#include <bits/stdc++.h>
#define int long long
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
using namespace std ;
const int N = 55 ;
const int p = 1e9+7 ;
int n ;
int a[N],b[N],c[N][N] ;
int ans[N],st[N],top ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
inline void find()
{
	FOR(i,1,n,1) FOR(j,1,n,1)
	{ 
		int mx = 0 ;
		FOR(k,0,n-1,1)
		{
			FOR(v,i,i+k,1) mx = max(mx,c[v][j+k]) ;
			FOR(v,j,j+k,1) mx = max(mx,c[i+k][v]) ;
			if(i+k <= n && j+k <= n) ans[k+1] = (ans[k+1]+mx)%p ;
		}
	}
}
signed main()
{
	freopen("query.in","r",stdin) ;
	freopen("query.out","w",stdout) ;
	read(n) ;
	FOR(i,1,n,1) read(a[i]) ; 
	FOR(i,1,n,1) read(b[i]) ;
	FOR(i,1,n,1) FOR(j,1,n,1) 
		c[i][j] = a[i]*b[j]+i*b[j]+a[i]*j+i*j ;
	find() ;
	FOR(i,1,n,1) print(ans[i]),space ;
	return 0 ;
}

