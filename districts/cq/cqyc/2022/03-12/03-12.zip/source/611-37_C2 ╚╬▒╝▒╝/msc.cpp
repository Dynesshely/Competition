#include <bits/stdc++.h>
#define int long long
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
using namespace std ;
const int N = 1e3+5 ;
int n,top,ans ;
int a[N],jo[N],fa[N],sz[N] ;
struct edge{int x,y,w ;}li[N*N] ; 
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
inline int cmp(edge x,edge y)
{
	return x.w < y.w ;
}
inline int get(int x)
{
	if(x == fa[x]) return x ;
	fa[x] = get(fa[x]) ;
	return fa[x] ;
}
inline int merge(int x,int y)
{
	x = get(x),y = get(y) ;
	if(x == y) return 0 ;
	if(sz[x] < sz[y]) swap(x,y) ;
	sz[x] += sz[y],fa[y] = x ;
	return 1 ;
}
signed main()
{
	freopen("msc.in","r",stdin) ;
	freopen("msc.out","w",stdout) ;
	read(n) ;
	FOR(i,1,n,1) read(a[i]) ;
	FOR(i,1,n,1) fa[i] = i,sz[i] = 1 ;
	FOR(i,1,n,1) FOR(j,i+1,n,1)
		li[++top] = (edge){i,j,a[i]^a[j]} ;
	sort(li+1,li+1+top,cmp) ;
	FOR(i,1,top,1)
	{
//		if(jo[li[i].x] >= 2 || jo[li[i].y] >= 2) continue ;
		if(merge(li[i].x,li[i].y)) jo[li[i].x]++,jo[li[i].y]++,ans = max(ans,li[i].w) ;
	}
	print(ans) ;
	return 0 ;
}

