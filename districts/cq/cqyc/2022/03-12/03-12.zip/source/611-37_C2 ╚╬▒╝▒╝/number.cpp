#include <bits/stdc++.h>
#define int long long
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
using namespace std ;
const int N = 1e6+5 ;
int ans,m,a,b ;
int k[N] ;
struct edge{int x,y ;}f[N];
int vis[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f |= (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
inline int GCD(int x,int y)
{
	if(y == 0) return x ;
	return GCD(y,x%y) ;
}
inline int cmp(edge x,edge y)
{
	return x.y < y.y ;
}
signed main()
{
	freopen("number.in","r",stdin) ;
	freopen("number.out","w",stdout) ;
	read(m),read(a),read(b) ;
	FOR(i,1,m,1) k[i] = a*i+b,f[i] = {k[i]/GCD(k[i],a),i} ;
	sort(f+1,f+1+m,cmp) ;
	FOR(i,1,m,1)
	{
		if(!vis[f[i].y]) ans++ ;
		else continue ;
		FOR(j,f[i].y,f[m].y,f[i].x) vis[j] = 1 ;
	}
	print(ans) ;
	return 0 ;
}
// 1000000 1 1

