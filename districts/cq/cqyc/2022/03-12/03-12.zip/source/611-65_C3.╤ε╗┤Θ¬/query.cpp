#include<bits/stdc++.h>
#define M 1000000007
using namespace std;
long long n,a[100005],b[100005],c[1005][1005],ans,tot;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int stk[30],tp;
void write(int x){
do stk[++tp]=x%10,x/=10;while(x);
while(tp)putchar(stk[tp--]^48);
putchar(' ');
}
int main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=(i+read())%M;
	for(int i=1;i<=n;i++) b[i]=(i+read())%M;
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) c[i][j]=(a[i]*b[j])%M;
	for(int i=1;i<=n;i++){
		ans=0;
		for(int j=1;j<=(n-i+1);j++){
			for(int g=1;g<=(n-i+1);g++){
				tot=0;
				for(int h=j;h<=(i+j-1);h++){
					for(int p=g;p<=(i+g-1);p++) tot=max(tot,c[h][p]);
				}
				ans=(ans+tot)%M;
			}
		}
		write(ans);
	}
	return 0;
}

