#include<bits/stdc++.h>
using namespace std;
long long n,k,t,a[45],tot,tot2=0;
int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	a[0]=1;
	for(long long i=1;i<=40;i++) a[i]=(a[i-1]<<1);
	for(long long i=1;i<=1000;i++){
		t=n-i*k;tot=0;tot2=0;
		for(long long j=40;j>=0;j--) if(t>=a[j]) t-=a[j],tot++,tot2+=a[j];	
		if(tot<=i&&tot2>=i){
			printf("%lld",i);
			return 0;
		}	
	}
	printf("-1");
	return 0;
}
