#include<bits/stdc++.h>
using namespace std;
long long n,a[1005],b[1005][1005],s[1000005],cnt=0,tnt=0,w,l,r,mid,ans=1e9; 
bool flag;
vector<int> e[1005];
bitset<1005> vis;
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void check(int k,int g){
	if(g==n){
		flag=1;
		return;
	}
	for(int i=0;i<e[k].size();i++){
		if(vis[e[k][i]]||b[e[k][i]][k]>s[mid]) continue;
		vis[e[k][i]]=1;
		check(e[k][i],g+1);
		vis[e[k][i]]=0;
		if(flag) return;
	}
}
int main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n=read();
	if(n>1000){
		printf("0");
		return 0;
	} 
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			w=a[i]^a[j];s[++cnt]=w;
			b[i][j]=b[j][i]=w;
			e[i].push_back(j);e[j].push_back(i);
		}
	}
	sort(s+1,s+1+cnt);
	s[0]=-1;
	for(int i=1;i<=cnt;i++){
		if(s[i]!=s[i-1]) s[++tnt]=s[i];
	}
	l=1;r=tnt;
	while(l<=r){
		mid=(l+r)/2;
		flag=0;
		vis[1]=1;
		check(1,1);
		vis[1]=0;
		if(flag) ans=min(ans,s[mid]),r=mid-1;
		else l=mid+1;
	}
	printf("%lld",ans);
	return 0;
}

