#include<bits/stdc++.h>
using namespace std;
long long m,a,b,t[1000005],s,d,dd,mx,ans=0,w;
long long gcd(long long x,long long y){
	if(!y) return x;
	return gcd(y,x%y);
}
bitset<1000005> vis;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%lld%lld%lld",&m,&a,&b);
	mx=a*m+b;
	for(long long i=1;i<=m;i++){
		t[i]=a*i+b;
		if(vis[i]) continue;
		s=gcd(t[i],a);
		d=t[i]/s;dd=d*a;w=0;
		for(long long j=t[i]+dd;j<=mx;j+=dd){
			w+=d;
			vis[i+w]=1;
		} 
	}
	for(long long i=1;i<=m;i++) if(!vis[i]) ans++;
	printf("%lld",ans);
	return 0;
}

