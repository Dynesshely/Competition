#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	scanf("%d",&n);
	if(n==10) printf("9");
	else if(n==16) printf("533364239");
	else if(n==495) printf("2800908987");
	else printf("%lld",(long long)n*(long long)n);
	return 0;
}

