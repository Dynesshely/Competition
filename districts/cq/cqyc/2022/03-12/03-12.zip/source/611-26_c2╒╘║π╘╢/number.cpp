#include<bits/stdc++.h>
using namespace std;
long long m,a,b,van;
int ans,wdnmd;
long long win[1000001],bj[1000001];
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);	
    scanf("%lld%lld%lld",&m,&a,&b);
    for(int i=1;i<=m;i++)
    	win[i]=i*a+b;
	for(int i=1;i<=m;i++){
		if(bj[i]!=1){
			ans++;
			van=win[i];
			while(van+win[i]<=win[m]){
				van+=win[i];
				if((van-b)%a==0){
					bj[(van-b)/a]=1;
				}
			}
		}
	}
	printf("%d",ans);
	return 0;
}
