#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);	
    cout<<1;
	return 0;
}
