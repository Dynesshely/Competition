#include<bits/stdc++.h>
using namespace std;
int n,ok0=1,ok1=1;
long long fa[200001],ans=LONG_LONG_MAX,dep=0,bj[200001];
void dfs(int now,long long mmin){
	bj[now]=1;
	dep++;
	if(dep==n){
		ans=min(mmin,ans);
		dep--;
		bj[now]=0;
		return ;
	}
	for(int i=1;i<=n;i++){
		if(!bj[i]&&fa[now]^fa[i]<ans){
			dfs(i,max(mmin,fa[now]^fa[i]));
		}
	}
	bj[now]=0;
	dep--;
}
int main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);	
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%lld",&fa[i]);
    if(n==1){
	printf("%d",0);
    return 0;	
}
    if(n<=1000){
		for(int i=1;i<=n;i++)
		dfs(i,0);
		printf("%lld",ans);
	}else{
		for(int i=1;i<=n;i++){
			if(fa[i]!=0)ok0=0;
			if(fa[i]!=1)ok1=0;
		}
		if(ok0||ok1)printf("%d",0);
		else printf("%d",1);
	}
	return 0;
}
