#include<bits/stdc++.h>
using namespace std;
long long k,kkk[114514],cnt,tim,ojbk;
long long sum=1,n,van; 
int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);	
    scanf("%lld%lld",&n,&k);
    while(sum*2<=INT_MAX){
    	kkk[++cnt]=sum;
    	sum=sum*2;
	}
	for(int i=1;i<=cnt;i++){
		n=n-k;
//		cout<<n<<" ";
		van=n;
		if(n>kkk[cnt]*2){
			printf("-1");
			return 0;
		}
		if(n<1){
			printf("-1");
			return 0;
		}
		tim=0;
		ojbk=0;
		for(int j=cnt;j>=1;j--){
			if(van>=kkk[j]){
				tim++;
				van-=kkk[j];
			}
			if(van==0&&tim<=i){
			ojbk=1;
			break;
		}
			if(tim>i)break ;
		}
//		cout<<tim<<endl;
		if(ojbk){
		printf("%d",i);
		return 0;
	}
	}
	return 0;
}
