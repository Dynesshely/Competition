#include<bits/stdc++.h>
using namespace std;
int n,a[100001],b[100001],fa[3001][3001],ans,mmax;
int main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);	
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",&a[i]);
    for(int i=1;i<=n;i++)scanf("%d",&b[i]);
    for(int i=1;i<=n;i++){
    for(int j=1;j<=n;j++){
    	fa[i][j]=a[i]*b[j]+i*b[j]+j*a[i]+i*j;
//    	cout<<fa[i][j]<<" ";
    }
//    cout<<endl;
    }
    for(int k=1;k<=n;k++){
    	ans=0;
    	for(int i=1;i+k-1<=n;i++)
    	for(int j=1;j+k-1<=n;j++){
    		mmax=0;
    	for(int ii=i;ii<=i+k-1;ii++)
    	for(int jj=j;jj<=j+k-1;jj++)
    	mmax=max(mmax,fa[ii][jj]);
    	ans+=mmax;
    }
    printf("%d ",ans);
	}
	return 0;
}
