#include<bits/stdc++.h>
#define ll long long
using namespace std;
int m,ans;
ll a,b;
bool vis[1000006];

int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	scanf("%d%lld%lld",&m,&a,&b);
	
	ans=m;
	for(int i=1;i<=m;i++){
		int k=1;ll pos;
		while((pos=(a*k+1)*i+k*b)<=m) vis[pos]=1,k++;
		if(vis[i]) ans--;
	}
	printf("%d",ans);
	
	return 0;
}

