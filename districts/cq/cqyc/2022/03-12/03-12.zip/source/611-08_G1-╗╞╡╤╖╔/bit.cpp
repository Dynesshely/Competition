#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,k;
ll lowbit(ll x){return x&-x;}

int work(ll x){
	int cnt=0;
	while(x) x-=lowbit(x),cnt++;
	return cnt;
}

int main(){
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	
	scanf("%lld%lld",&n,&k);
	for(int m=1;m<=1000;m++){
		n-=k;
		if(n<m) continue;
		int cnt=work(n);
		if(cnt<=m) {printf("%d",m);return 0;}
	}
	puts("-1");
	return 0;
}
