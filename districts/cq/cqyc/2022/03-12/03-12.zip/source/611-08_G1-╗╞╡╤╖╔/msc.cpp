#include<bits/stdc++.h>
#define ll long long
using namespace std;

struct node{int x,y;ll w;}eg[1000006];
bool cmp(node x,node y){return x.w<y.w;}

int n,m;
ll a[1000006];

int f[1000006],cnt;
int deg[1000006];
int find(int x){return f[x]==x?x:f[x]=find(f[x]);}

int main(){
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=2;i<=n;i++) 
		for(int j=1;j<i;j++) 
			eg[++m]=(node){i,j,a[i]^a[j]};
	
	sort(eg+1,eg+m+1,cmp);
	
	cnt=n;for(int i=1;i<=n;i++) f[i]=i; 
	for(int i=1;i<=m;i++){
		int x=eg[i].x,y=eg[i].y;
		if(find(x)==find(y)) continue;
		if(deg[x]==2||deg[y]==2) continue;
		deg[x]++,deg[y]++,f[y]=f[x],cnt--;
		if(cnt==1) {printf("%lld",eg[i].w);return 0;}
	}
	return 0;
}

