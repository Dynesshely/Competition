#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n;
ll a[100005],b[100005];
const ll maxn=1000000007;

pair<int,ll> que[100005];
int l,r;
void add(int i,ll x){
	while(l<=r&&x>=que[r].second) r--;
	que[++r]=make_pair(i,x);
}
void del(int i){
	while(l<=r&&que[l].first<i) l++;
}

int main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]),a[i]+=i;
	for(int j=1;j<=n;j++) scanf("%lld",&b[j]),b[j]+=j;
	
	for(int k=1;k<=n;k++){
		ll suma=0,sumb=0;
		
		l=1,r=0;
		for(int i=1;i<k;i++) add(i,a[i]);
		for(int i=1;i<=n-k+1;i++) {
			del(i),add(i+k-1,a[i+k-1]);
			suma+=que[l].second;
		}
		
		l=1,r=0;
		for(int j=1;j<k;j++) add(j,b[j]);
		for(int j=1;j<=n-k+1;j++) {
			del(j),add(j+k-1,b[j+k-1]);
			sumb+=que[l].second;
		}
		
		printf("%lld ",(suma%maxn)*(sumb%maxn)%maxn);
	}
	
	
	return 0;
}

