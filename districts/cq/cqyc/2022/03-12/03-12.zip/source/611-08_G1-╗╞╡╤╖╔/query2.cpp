#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n;
ll a[100005],b[100005];
const ll maxn=1000000007;

set<pair<ll,int> > s;
#define IT set<pair<ll,int> >::iterator
int lfta[100005],rgta[100005];
int lftb[100005],rgtb[100005];
void geta(){
	s.clear();
	lfta[1]=1,s.insert(make_pair(a[1],1));
	for(int i=2;i<=n;i++){
		IT it=s.upper_bound(make_pair(a[i],i));
		if(it==s.end()) lfta[i]=1;
		else lfta[i]=(*it).second+1;
		s.insert(make_pair(a[i],i));
	}
	s.clear();
	rgta[n]=n,s.insert(make_pair(a[n],n));
	for(int i=n-1;i>=1;i--){
		IT it=s.lower_bound(make_pair(a[i],i));
		if(it==s.end()) rgta[i]=n;
		else rgta[i]=(*it).second-1;
		s.insert(make_pair(a[i],i));
	}
}

void getb(){
	s.clear();
	lftb[1]=1,s.insert(make_pair(b[1],1));
	for(int i=2;i<=n;i++){
		IT it=s.upper_bound(make_pair(b[i],i));
		if(it==s.end()) lftb[i]=1;
		else lftb[i]=(*it).second+1;
		s.insert(make_pair(b[i],i));
	}
	s.clear();
	rgtb[n]=n,s.insert(make_pair(b[n],n));
	for(int i=n-1;i>=1;i--){
		IT it=s.lower_bound(make_pair(b[i],i));
		if(it==s.end()) rgtb[i]=n;
		else rgtb[i]=(*it).second-1;
		s.insert(make_pair(b[i],i));
	}
}

int main(){
	freopen("query.in","r",stdin);
	freopen("query.out2","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]),a[i]+=i;
	for(int j=1;j<=n;j++) scanf("%lld",&b[j]),b[j]+=j;
	
	geta(),getb();
	
	for(int i=1;i<=n;i++){
		
	}
	
	
	return 0;
}

