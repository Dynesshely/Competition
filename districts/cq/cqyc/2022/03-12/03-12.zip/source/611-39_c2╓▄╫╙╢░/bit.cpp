#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,k,ans=0x7ffffff,kl;
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int ksm(int a,int b) {
	int sum=1;
	while(b) {
		if(b&1) sum*=a;
		a*=a;
		b/=2;
	}
	return sum;
}
signed main() {
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	int ss=clock();
	if(n-k<=0) {
		printf("-1");
		return 0;
	}
	if(k==0) {
		int nn=n;
		int sum=0;
		while(nn) {
			sum+=nn%2;
			nn/=2;
			if(sum>ans) break;
		}
		printf("%d",sum);
		return 0;
	}
	int nn=n;
	int kl=(log(n)/log(2))+2,klj=ksm(2,kl);
	while(klj+k<nn) klj*=2,kl++;
//	cout<<klj<<" "<<kl<<endl;
	for(int i=1; ; ++i) {
		while(klj+k>nn) kl--,klj/=2;
//		cout<<klj<<" "<<kl<<endl;
		nn-=klj+k;
		if(nn==0) {
			printf("%d",i);
			return 0;
		}
	}
	return 0;
}
