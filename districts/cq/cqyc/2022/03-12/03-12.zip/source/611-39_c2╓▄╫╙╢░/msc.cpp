#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=1010;
int n,tot=0,gw=0;
int p[N],sum[N],f[N];
struct son_of_a_bitch {
	int u,v,w;
} bd[N*N+10];
int finds(int x) {
	if(f[x]==x) return x;
	return f[x]=finds(f[x]);
}
bool cnm(son_of_a_bitch a,son_of_a_bitch b) {
	return a.w<b.w;
}
signed main() {
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1; i<=n; ++i) scanf("%lld",&p[i]);
	for(int i=1; i<=n; ++i) {
		sum[i]=0,f[i]=i;
		for(int j=i+1; j<=n; ++j) {
			tot++,bd[tot].u=i,bd[tot].v=j,bd[tot].w=p[i]^p[j];
		}
	}
	sort(bd+1,bd+1+tot,cnm);
//	for(int i=1; i<=tot; ++i) {
//		cout<<bd[i].u<<" "<<bd[i].v<<" "<<bd[i].w<<endl;
//	}
//	cout<<endl;
	for(int i=1; i<=tot; ++i) {
		int u=bd[i].u,v=bd[i].v,w=bd[i].w;
		int uu=finds(u),vv=finds(v);
//		cout<<u<<" "<<v<<" "<<uu<<" "<<vv<<" "<<sum[u]<<" "<<sum[v]<<endl;
		if(uu==vv/*||sum[u]>=2||sum[v]>=2*/) continue;
//		cout<<i<<endl;
//		sum[u]++,sum[v]++;
		f[uu]=vv;
		gw++;
		if(gw==n-1) {
			printf("%lld",w);
//			bool flag=1;
//			for(int i=2;i<=n;++i)
//				if(finds(i)!=finds(i-1)) flag=0;
//			cout<<flag;
			return 0;
		}
	}
	return 0;
}
