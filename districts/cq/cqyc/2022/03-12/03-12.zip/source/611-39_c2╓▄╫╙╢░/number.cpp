#include <bits/stdc++.h>
#define int __int128
#define re register
using namespace std;
//int128 cl=(int128)10;
int k,b,m,mx,ans;
bool vis[1000100];
inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x) {
	string ch;
	int xx=x;
	while(xx){
		ch+=char((xx%10)+48);
		xx/=10;
	}
	for(re int i=ch.size()-1;i>=0;--i)
		cout<<ch[i];
}
signed main() {
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	m=read(),k=read(),b=read();
//	write(m);
	mx=m*k+b;
	ans=m;
	for(re int i=1; i<=m; ++i) vis[i]=0;
	for(re int i=1; i<=m; ++i) {
		re int x=k*i+b;
//		cout<<x<<" "<<vis[i]<<endl;
		if(vis[i]) {
			ans--;
			continue;
		}
		for(re int j=2; j*x<=mx; ++j) {
			int xx=x*j;
			if((xx-b)%k!=0) continue;
			vis[(xx-b)/k]=1;
		}
	}
	write(ans);
	return 0;
}
