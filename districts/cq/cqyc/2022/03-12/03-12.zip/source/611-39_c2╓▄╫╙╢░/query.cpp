#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=1001,mod=1e9+7;
int n;
int a[N],b[N],jz[N][N];
signed main() {
		freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1; i<=n; ++i) scanf("%lld",&a[i]);
	for(int i=1; i<=n; ++i) scanf("%lld",&b[i]);
	for(int i=1; i<=n; ++i) {
		for(int j=1; j<=n; ++j) {
			jz[i][j]=a[i]*b[j]+i*b[j]+a[i]*j+i*j;
//			cout<<jz[i][j]<<" ";
		}
//		cout<<endl;
	}
//	cout<<endl;
	for(int k=1; k<=n; ++k) {
		int sum=0;
		for(int i=1; i<=n-k+1; ++i) {
			for(int j=1; j<=n-k+1; ++j) {
				int mx=0;
				for(int x=i; x<=i+k-1; ++x) {
					for(int y=j; y<=j+k-1; ++y) {
						mx=max(jz[x][y],mx);
					}
				}
//				cout<<i<<" "<<j<<" "<<mx<<endl;
				sum+=mx;
				sum%=mod;
			}
		}
		sum%=mod;
		printf("%lld ",sum);
	}
	return 0;
}

