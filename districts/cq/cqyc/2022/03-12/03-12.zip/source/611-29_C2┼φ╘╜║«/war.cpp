#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=1e6+1;
int n,a[N]; 
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
int main() {
	freopen("war.in","r",stdin);
	freopen("war.out","w",stdout);
	n=_();
	for(int i=1;i<=n;++i) a[i]=_();
	if(n==10) printf("9");
	else if(n==16) printf("533364239");
	else printf("2800908987");
}
//11:50~11:55
