#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=3005,tkon=1e9+7;//ĤĤĤ 
int n,hd,tl,a[N],b[N],lin[N],col[N];
struct Que {
	int id,v;
}q[N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void Add(int &x,int y) {x=(x+y)%tkon;}
int Mul(int x,int y) {return (long long)x*y%tkon;}
int main() {
	//50pts�����ˮ 
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	n=_();
	for(int i=1;i<=n;++i) a[i]=_()+i;
	for(int i=1;i<=n;++i) b[i]=_()+i;
	for(int k=1;k<=n;++k) {
	//����ÿһ��k����ÿ�е�����ѡ�� 
		hd=1,tl=0;//ע��ʹ�ö��е�ʱ��һ��Ҫ���*1
		for(int i=1;i<=n;++i) {
			while(hd<=tl&&q[hd].id<i-k+1) hd++;
			while(hd<=tl&&b[i]>=q[tl].v) tl--;
			q[++tl]=(Que){i,b[i]};
			if(i>=k) Add(lin[k],q[hd].v);
		}
//		printf("%d ",lin[k]);
	}
//	pc('\n');
	for(int k=1;k<=n;++k) {
	//����ÿһ��k����ÿ�е�����ѡ�� 
		hd=1,tl=0;//ע��ʹ�ö��е�ʱ��һ��Ҫ���*2 
		for(int i=1;i<=n;++i) {
			while(hd<=tl&&q[hd].id<i-k+1) hd++;
			while(hd<=tl&&a[i]>=q[tl].v) tl--;
			q[++tl]=(Que){i,a[i]};
			if(i>=k) Add(col[k],q[hd].v);
		}
//		printf("%d ",col[k]);
		__(Mul(col[k],lin[k])),pc(' ');
	}
}
//10:50~11��50 
