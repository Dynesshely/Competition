#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=1005;
int n,ans,flag,a[N],vis[N],ed[N][N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
void DFS(int t,int x,int mx) {
	if(t==n) {ans=min(ans,mx);return ;}
	for(int i=1;i<=n;++i) {
		if(!vis[i]) {
			vis[i]=1;
			DFS(t+1,i,max(mx,ed[x][i]));
			vis[i]=0;
		}
	}
}
int main() {
	freopen("msc.in","r",stdin);
	freopen("msc.out","w",stdout);
	n=_();
	for(int i=1;i<=n;++i) {
		if(i>1&&a[i]!=a[i-1]) flag=1;
		a[i]=_(),ans=max(ans,a[i]);
	}
	if(n<=17) {//st1:n<=8 O(N!) 20pts
		for(int i=1;i<=n;++i) 
			for(int j=i+1;j<=n;++j) 
				ed[i][j]=ed[j][i]=a[i]^a[j];
		for(int i=1;i<=n;++i) {
			vis[i]=1;
			DFS(1,i,0);
			vis[i]=0;
		} 
		__(ans);
	}
	else {
		if(flag) pc('1');//st4 �����ܵ�10pts�� 
		else pc('0');
	}
}
//10:05~10:45
