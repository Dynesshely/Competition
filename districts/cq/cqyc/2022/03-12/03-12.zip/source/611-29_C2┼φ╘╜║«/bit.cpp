#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
int n,k,m;
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void __(int x) {
	int stk[30],tp=0;
	if(x<0) pc('-'),x=-x;
	do stk[++tp]=x%10,x/=10;while(x);
	while(tp) pc(stk[tp--]^48);
}
int Getlog(int x) {
	int c=0;
	while(x>1) x>>=1,++c;
	return c;
}
int Getnum(int x) {
//	printf("x=%d\n",x);
	int c=0;
	while(x) /*printf("%d",x&1),*/c+=(x&1),x>>=1;
//	pc('\n');
	return c; 
}
/*����������û���õķ��ﺯ��*/
int Getfac(int x) {
//	printf("%d ",x);
	int res=1;
	while(x--) res*=2;
	return res;
}
int Getmax(int x) {
	int c=0,res=0;
	while(x) {
		res+=(x&1)?Getfac(c):0;
//		printf("%d",x&1);
		++c,x>>=1;
	}
	return res;
}
int main() {
	freopen("bit.in","r",stdin);
	freopen("bit.out","w",stdout);
	n=_(),k=_();
//	__(Getmax(_()));
	m=Getlog(n);
	for(int i=1;i<=m;++i) {
		int x=n-i*k;
		if(x>0&&Getnum(x)<=i&&i<=x) __(i),exit(0);
	}
	printf("-1");
}
//8:20~9:12 
