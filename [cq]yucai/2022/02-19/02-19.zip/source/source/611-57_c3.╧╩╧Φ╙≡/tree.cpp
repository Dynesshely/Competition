#include<bits/stdc++.h>
using namespace std;
const int N=110;
int t,n,maxx,minn,num[N];
bool check()
{
	if(n==1) return !minn;
	if(n==2) return minn==1&&maxx==1;
	if(minn!=(maxx+1>>1)) return false;
	if(maxx&1) {if(num[minn]!=2) return false;}
	else if(num[minn]!=1) return false;
	while(num[maxx]>1) --maxx;
	return maxx<=minn;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		maxx=0,minn=1e9;
		memset(num,0,sizeof(num));
		for(int i=1,x;i<=n;i++)
		{
			scanf("%d",&x);
			maxx=max(maxx,x);
			minn=min(minn,x);
			num[x]++;
		}
		if(check()) printf("Yes\n");
		else printf("NO\n");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
