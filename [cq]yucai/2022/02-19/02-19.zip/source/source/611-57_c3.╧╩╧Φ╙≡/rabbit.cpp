#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int n,m,k,jump[N];
long long a[N],K[N];
long double e=1,ans[N];
void check() {for(int i=1;i<=n;i++) ans[i]+=e*a[i];}
void dfs(int x)
{
	if(x>m) return check();
	int A=jump[x],p=a[A];
	a[A]=(a[A-1]<<1ll)-p;
	dfs(x+1);
	a[A]=(a[A+1]<<1ll)-p;
	dfs(x+1);
}
int main()
{
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%lld",a+i);
	scanf("%d%d",&m,&k);
	for(int i=1;i<=m;i++) scanf("%d",jump+i);
	int l=m+1,t=1;
	m*=k;
	for(int i=l;i<=m;i++)
	{
		jump[i]=jump[t++];
		if(t>l) t=1;
	}
	for(int i=1;i<=m;i++) e/=2;
	dfs(1);
	for(int i=1;i<=n;i++) printf("%.1Lf\n",ans[i]);
	fclose(stdin);fclose(stdout);
	return 0;
}
