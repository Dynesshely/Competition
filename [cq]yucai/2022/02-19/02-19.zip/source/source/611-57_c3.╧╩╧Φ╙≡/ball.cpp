#include<bits/stdc++.h>
using namespace std;
const int N=110;
struct ok{
	int x,y;
};
int n,m,ex,ey,ans;
char a[N][N];
bool biao[N*N],p[20];
vector<ok>ball;
void check()
{
	int tot=0,now=0,lt=1e9,rt=1e9,up=1e9,dn=1e9,siz;
	vector<int>k;
	memset(p,false,sizeof(p));
	for(int i=1;i<=n;i++) if(biao[i])
	{
		lt=min(lt,ball[i].y-1);
		rt=min(rt,m-ball[i].y);
		up=min(up,ball[i].x-1);
		dn=min(dn,n-ball[i].x);
		tot++;
		k.push_back(i);
	}
	if(tot<ans) return;
	int X=ex,Y=ey;
	siz=k.size();
	bool change=true;
	while(now!=tot&&change)
	{
		change=false;
		for(int i=0;i<siz;i++) if(!p[i])
		{
			int nx=ball[k[i]].x-ex,ny=ball[k[i]].y-ey,t=0;
			if(ny<0) t+=(rt>=-ny);
			else t+=(lt>=ny);
			if(nx<0) t+=(dn>=-nx);
			else t+=(up>=nx);
			if(t==2)
			{
				now++;
				change=true;
				ex+=nx,ey+=ny;
				if(ny<0) rt+=ny;
				else lt-=ny;
				if(nx<0) dn+=nx;
				else up-=nx;
				p[i]=true;
			}
		}
	}
	ex=X,ey=Y;
	if(now==tot) ans=max(ans,tot);
}
void dfs(int x)
{
	if(x>n) return check();
	biao[x]=true;
	dfs(x+1);
	biao[x]=false;
	dfs(x+1);
}
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d",&n,&m);
	ball.push_back((ok){0,0});
	for(int i=1;i<=n;i++) scanf("%s",a[i]+1);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++)
	{
		if(a[i][j]=='o') ball.push_back((ok){i,j});
		else if(a[i][j]=='E') ex=i,ey=j;
	}
	dfs(1);
	if(n==3&&m==3) printf("%d\n",n);
	else printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
