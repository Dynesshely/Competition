#include<bits/stdc++.h>
using namespace std;
struct node{
	int x,i;
}ls[100005];
bool cmp(node x,node y){return x.x<y.x;}

int n,a[100005],ans;

int main(){
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&ls[i].x),ls[i].i=i;
	sort(ls+1,ls+n+1,cmp);
	for(int i=1;i<=n;i++) a[ls[i].i]=i;
	for(int i=1;i<=n;i+=2) ans+=(a[i]%2==0);
	printf("%d",ans);
	return 0;
}

