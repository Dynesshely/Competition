#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n;
ll a[100005],b[100005];
int m,jup[100005];
ll k;

int pos[100005],nxt[100005];
int head[100005],siz[100005];
ll ans[100005];

int main(){
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]),b[i]=a[i]-a[i-1];
	scanf("%d%lld",&m,&k);
	for(int i=1;i<=m;i++) scanf("%d",&jup[i]);
	
	if(m*k<=1000000){
		for(int i=1;i<=k;i++) 
			for(int j=1;j<=m;j++)
				swap(b[jup[j]],b[jup[j]+1]);
		
		for(int i=1;i<=n;i++) b[i]+=b[i-1],printf("%lld",b[i]),puts(".0");
		return 0;
	}
	
	for(int i=1;i<=n;i++) pos[i]=i;
	for(int j=1;j<=m;j++) swap(pos[jup[j]],pos[jup[j]+1]);
	for(int i=1;i<=n;i++) nxt[pos[i]]=i;
	
	for(int i=1;i<=n;i++){
		if(head[i]) continue;
		head[i]=i,siz[i]=1;
		int j=nxt[i];
		while(j!=i) head[j]=i,siz[i]++,j=nxt[j];
		
		ll num=k%siz[i];
		int l=i,r=i;
		for(int j=1;j<=num;j++) r=nxt[r];
		for(int j=1;j<=siz[i];j++){
			ans[r]=b[l];
			l=nxt[l],r=nxt[r];
		}
	}
	
	for(int i=1;i<=n;i++) ans[i]+=ans[i-1],printf("%lld",ans[i]),puts(".0");
	return 0;
}

