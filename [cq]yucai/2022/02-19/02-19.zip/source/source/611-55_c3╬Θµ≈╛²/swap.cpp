#include<bits/stdc++.h>
using namespace std;
int n,sum;
struct node
{
	int id,rock,num;
}a[100007];
bool tmp1(node a1,node a2)
{
	return a1.num<a2.num;
}
int main()
{
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i].num);
		a[i].id=i;
	}
	sort(a+1,a+1+n,tmp1);
	for(int i=1;i<=n;i++)
	{
		a[i].rock=i;
		if(abs(a[i].rock-a[i].id)%2==1) sum++;
	}
	printf("%d",sum/2);
	return 0;
}
