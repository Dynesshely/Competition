#include<bits/stdc++.h>
using namespace std;
int h,w,sum,ans;
char cap[107][107];
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d %d",&h,&w);
	for(int i=1;i<=h;i++)
	{
		for(int j=1;j<=w;j++)
		{
			cin>>cap[i][j];
			if(cap[i][j]=='o') sum++;
		}
	}
	if(h==3&&w==3) ans=3;
	else ans=sum;
	printf("%d",ans);
	return 0;
}
