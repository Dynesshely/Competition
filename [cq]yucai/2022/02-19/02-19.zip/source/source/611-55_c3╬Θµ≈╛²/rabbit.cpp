#include<bits/stdc++.h>
using namespace std;
int n,w[100007],a[100007];
int sum[100007],t[100007];
int m,k;
vector<int>dian[100007];
map<pair<int,int> ,int> mp;
struct node
{
	int id,wi,ti;
};
queue<node> q;
void bfs()
{
	while(!q.empty())
	{
		int x=q.front().id,wi=q.front().wi,ti=q.front().ti;
		q.pop(),mp[make_pair(wi,a[x])]=-1;
	//	cout<<a[x]<<" "<<ti<<endl;
		int x1=a[x]+1,x2=a[x]-1;
		for(int i=0;i<dian[x1].size();i++)
		{
			if(mp[make_pair(dian[x1][i],x1)]==-1) continue;
			int ww=2*dian[x1][i]-wi;
			if(ti==k)	sum[a[x]]+=ww,t[a[x]]++;
			else q.push((node){x,ww,ti+1}),dian[a[x]].push_back(ww);
		} 
		for(int i=0;i<dian[x2].size();i++)
		{
			if(mp[make_pair(dian[x2][i],x2)]==-1) continue;
			int ww=2*dian[x2][i]-wi;
			if(ti==k)	sum[a[x]]+=ww,t[a[x]]++;
			else q.push((node){x,ww,ti+1}),dian[a[x]].push_back(ww);
		} 
	}
}
int main()
{
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&w[i]);
		dian[i].push_back(w[i]);
	}
	scanf("%d %d",&m,&k);
	for(int i=1;i<=m;i++)
	{
		scanf("%d",&a[i]);
		q.push((node){i,w[a[i]],1});
	}
	bfs();
//	cout<<sum[2]<<" "<<t[2]<<endl;
	for(int i=1;i<=n;i++)
	{
		double ans;
		if(sum[i]!=0) ans=(double)sum[i]/t[i];
		else ans=(double)w[i];
		printf("%.1lf\n",ans);
	}
	return 0;
}
