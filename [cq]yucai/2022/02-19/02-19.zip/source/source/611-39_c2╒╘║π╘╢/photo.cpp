#include<bits/stdc++.h>
using namespace std;
int n,m;
char fa[101][101],van[401][401];
int main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
		scanf("%s",fa[i]+1);
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			for(int k=i*2;k>=i*2-1;k--)
			for(int l=j*2-1;l<=j*2;l++)
			van[k][l]=fa[i][j];
		}
	}
	for(int j=n*2;j>=1;j--){
		for(int i=m*2;i>=1;i--)
		printf("%c",van[i][j]);
		printf("\n");
	}
	return 0;
}
