#include<bits/stdc++.h>
using namespace std;
int n,m;
char a[201][201],c[201][201];
int main()
{
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("\n");
		for(int j=1;j<=n;j++)
			a[i][j]=getchar();
	}
	for(int i=1;i<=n;i++)
		for(int j=m;j;j--)
			c[i][j]=a[j][i];
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
			{putchar(c[i][j]);putchar(c[i][j]);}
		putchar('\n');
		for(int j=1;j<=m;j++)
			{putchar(c[i][j]);putchar(c[i][j]);}
		putchar('\n');
	}
	return 0;
}
