#include<bits/stdc++.h>
using namespace std;
struct node{
	int y,z;
	vector<pair<int,int> > v;
}a;
int n,m,ex,ey,tx,ty,fl,s(4),si,ans,t;
int dir[4][2]={{0,1},{0,-1},{1,0},{-1,0}};
char ch;
vector<pair<int,int> > ve;
queue<node> qu;
void bfs()
{
	qu.push((node){4,0,ve});
	while(!qu.empty()&&clock()-t<=700)
	{
		a=qu.front();qu.pop();
		ans=max(ans,a.z);
		if(a.y==0) s=1;
		else if(a.y==1) s=0;
		else if(a.y==2) s=3;
		else if(a.y==3) s=2;
		vector<pair<int,int> > vec;
		vec.resize(si);
		for(int i=0;i<4;i++)
		{
			if(i==s) continue;
			fl=0;
			for(int j=0;j<si;j++)
			{
				if(!a.v[j].first) continue;
				tx=a.v[j].first+dir[i][0],ty=a.v[j].second+dir[i][1];
				if(tx>0&&ty>0&&tx<=n&&ty<=m) 
				{
					if(tx==ex&&ty==ey) vec[j].first=0,vec[j].second=0,fl=1;
					else vec[j].first=tx,vec[j].second=ty;
				}
				else vec[j].first=0,vec[j].second=0;
			}
			qu.push((node){i,a.z+fl,vec});
		}
	}
}
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	t=clock();
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("\n");
		for(int j=1;j<=m;j++)
		{
			ch=getchar();
			if(ch=='o') ve.push_back(make_pair(i,j));
			else if(ch=='E') ex=i,ey=j;
		}
	}
	si=ve.size();
	bfs();
	printf("%d",ans);
	return 0;
}
