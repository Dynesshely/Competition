#include<bits/stdc++.h>
using namespace std;
int n,m,k,de,si;
vector<long long> ve[100001];
vector<long long>::iterator it,t;
long long x[100001],sum;
long double ans;
int a[100001];
int main()
{
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) 
	{
		scanf("%lld",&x[i]);
		ve[i].push_back(x[i]);
	}
	scanf("%d%d",&m,&k);
	for(int i=1;i<=m;i++) scanf("%d",&a[i]);
	for(int i=1;i<=k;i++)
	{
		for(int j=1;j<=m;j++)
		{
			si=ve[a[j]].size();
			vector<long long> v;
			for(int z=0;z<si;z++)
			{
				it=ve[a[j]].begin()+z;
				for(t=ve[a[j]+1].begin();t!=ve[a[j]+1].end();++t)
				{
					de=abs(*it-*t);
					if(*it<*t) v.push_back(*t+de);
					else v.push_back(*t-de);
				}
				for(t=ve[a[j]-1].begin();t!=ve[a[j]-1].end();++t)
				{
					de=abs(*it-*t);
					if(*it<*t) v.push_back(*t+de);
					else v.push_back(*t-de);
				}
			}
			for(int z=0;z<si;z++) ve[a[j]][z]=v[z];
			for(it=v.begin()+si;it!=v.end();it++) ve[a[j]].push_back(*it);
		}
	}
	for(int i=1;i<=n;i++) 
	{
		si=ve[i].size(),sum=0;
		for(it=ve[i].begin();it!=ve[i].end();++it) sum+=*it;
		ans=(long double)sum/si;
		printf("%.1Lf\n",ans);
	}
	return 0;
}

