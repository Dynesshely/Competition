#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	cout<<1.0<<"\n"<<-1.0<<"\n"<<1.0<<"\n";
}
