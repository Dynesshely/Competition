#include<bits/stdc++.h>
using namespace std;
int T,N;
int p[105];
bool comp(int a,int b) {
	return a>b;
}
bool tf[105],f,af;
int psum,hi,td[105];
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--) {
		scanf("%d",&N);

		for(int i=1; i<=N; ++i)
			tf[i]=0,td[i]=0;
		hi=1,psum=0;

		for(int i=1; i<=N; ++i)
			scanf("%d",&p[i]);
		sort(p+1,p+N+1,comp);

		af=0;
		for(int i=1; i<=N; ++i) {
			f=0;

			for(int j=hi; j>=1; --j) {
				if(td[j]==p[i]) {
					if(tf[j]==0) {
						tf[j]=1,f=1;
					//	cout<<"to_a;"<<j<<"\n"; 
						break;
					} else if(tf[1+hi-j]==0) {
						tf[1+hi-j]=1,f=1;
					//	cout<<"to_b;"<<j<<"\n"; 
						break;
					} else if(psum<N&&j>=hi/2+(hi%2==1)&&j!=2&&j!=1) {
						psum++,f=1;
					//	cout<<"to_c;"<<j<<"\n"; 
						break;
					} else {
						af=1,printf("NO ");
						break;
					}
				}
			}

			if(af==1)break;
			if(f==0) {
				if(i==1) {
					int j=p[i];
					hi=p[i]+1,tf[1]=1;
					for(int k=1; k<=hi/2; ++k) {
						td[k]=j,j--;
					}
					j=p[i];
					for(int k=hi; k>hi/2; --k) {
						td[k]=j,j--;
					}
					psum+=p[i]+1;
				} else {
					af=1,printf("NO ");
					break;
				}
				
			}
			//for(int i=1;i<=hi;++i)cout<<td[i]<<" ";
			//cout<<"end\n";
		}
		if(af==0)printf("Yes\n");
	}
}
