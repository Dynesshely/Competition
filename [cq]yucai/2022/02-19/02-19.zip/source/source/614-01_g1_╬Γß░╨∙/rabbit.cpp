#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
#define int long long
const int N=1e5+5;
int a[N],b[N],n,m,k,ne[N],fz[N],da[N],ans[N];
signed main(){
	freopen("1.in","r",stdin);
	freopen("1.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]),b[i]=i;
	scanf("%lld %lld",&m,&k);
	for(int i=1;i<=m;i++){
		int u;
		scanf("%lld",&u);
		swap(b[u+1],b[u]);
	}
	for(int i=1;i<=n;i++) ne[b[i]]=i;
	for(int i=1;i<=n;i++){
		if(da[i]) continue;
		if(ne[i]==i){
			da[i]=i;
			continue;
		}
		int sz=0,j=i;
		fz[1]=i;
		while(ne[j]!=i){
			fz[sz+2]=ne[j];
			j=ne[j];
			sz++;
		}
		fz[sz+2]=ne[j];
		j=ne[j];
		sz++;
		int v=k%sz;
		int now=0;
		while(ne[j]!=i){
			da[j]=fz[(now+v)%sz+1];
			now++;
			j=ne[j];
		}
		da[j]=fz[(now+v)%sz+1];
		now++;
	}
	for(int i=n;i>=1;i--) a[i]-=a[i-1];
	for(int i=2;i<=n;i++)  ans[da[i]]=a[i];
	ans[1]=a[1];
	for(int i=1;i<=n;i++){
		ans[i]+=ans[i-1];
		printf("%lld.0\n",ans[i]);
	}
	return 0;
	
}
