#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
const int N=105;
int a[N],n,T,ans[N];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		memset(ans,0,sizeof(ans));
		int mi=998244353,ma=0;
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]),ans[a[i]]++;
			mi=min(a[i],mi);
			ma=max(a[i],ma);
		}
		if(n==1){
			printf("NO\n");
			continue;
		}
		if(mi==ma){
			if(mi==1 && n==2) printf("Yes\n");
			else printf("NO\n");
			continue;
		}
		if(ma==2){
			if(ans[mi]==1) printf("Yes\n");
			else printf("NO\n");
			continue;
		}
		int pd=1;
		for(int i=mi+1;i<=ma;i++){
			if(ans[i]<2){
				pd=0;
				break;
			}
		}
		printf("%s\n",pd?"Yes":"NO");
	}
	return 0;
}
