#include<cstdio>
int n,m;
const int N=205;
char a[N][N];
int main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++) scanf("%s",a[i]+1);
	for(int i=1;i<=2*n;i++){
		for(int j=1;j<=2*m;j++){
			putchar(a[(2*m-j+2)/2][(2*n-i+2)/2]);
		}
		putchar('\n');
	}
	return 0;
}
