#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
const int N=1e5+5;
struct aa{
	int i,a;
}a[N];
int n;
bool cmp(aa a,aa b){
	return a.a<b.a;
}
int main(){
	freopen("Swap.in","r",stdin);
	freopen("Swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i].a),a[i].i=i;
	sort(a+1,a+1+n,cmp);
	int ans=0;
	for(int i=1;i<=n;i++){
		if(i%2!=a[i].i%2) ans++;
	}
	printf("%d",ans/2);
	return 0;
}
