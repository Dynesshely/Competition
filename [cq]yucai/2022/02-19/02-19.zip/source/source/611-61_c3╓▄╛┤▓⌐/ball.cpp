#include<bits/stdc++.h>
using namespace std;
int n,m;
char mp[105][105];
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
//			scanf(" %c ",&mp[i][j]);
			cin>>mp[i][j];
//			printf("\n %d,%d : %c\n",i,j,mp[i][j]);
		}
	}
	if(n==m && m==3 && mp[1][1]=='o' && mp[2][2]=='E' && mp[3][3]=='o' && mp[1][3]=='o' && mp[1][2]=='.')
	{
		printf("3");
		return 0;
	}
	cout<<1;
	return 0;
}

