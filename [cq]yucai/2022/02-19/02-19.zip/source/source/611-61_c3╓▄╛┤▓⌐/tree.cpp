#include<bits/stdc++.h>
#define max(x,y) (x>y?x:y)
using namespace std;
int T,n,a[105],cnt[105],mx,fst;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		memset(cnt,0,sizeof(cnt));
		mx=-1;
		scanf("%d",&n);
		for(int i=1;i<=n;++i)
		{
			scanf("%d",a+i);
			mx=max(mx,a[i]);
			++cnt[a[i]];
		}
		if(n==1)
		{
			puts("NO");
			continue;
		}
		if(n>2 && cnt[1]>1)
		{
			puts("NO");
			continue;
		}
		int flag=0;
		for(int i=1;i<=mx;++i)
		{
			if(cnt[i])
			{
				if(!flag)
				{
					fst=i;
					if(cnt[i]>cnt[i+1]) break;
				}
				flag=i;
			}
			else if(flag) break;
		}
		if(flag!=mx)
		{
			puts("NO");
			continue;
		}
		else if(mx>2 && cnt[1])
		{
			puts("NO");
			continue;
		}
		else if(mx==2 && !cnt[1])
		{
			puts("NO");
			continue;
		}
		flag=0;
		for(int i=fst+1;i<mx;++i)
		{
			if(cnt[i]<cnt[i+1])
			{
				flag=1;
			}
		}
		if(flag)
		{
			puts("NO");
			continue;
		}
		puts("Yes");
	}
	return 0;
}

