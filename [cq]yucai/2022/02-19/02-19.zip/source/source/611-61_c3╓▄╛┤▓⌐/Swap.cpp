#include<bits/stdc++.h>
using namespace std;
int a[100005],n,tmp[2][100005],ans=0;
struct node
{
	int w,id;
	const inline bool operator<(const node& A)const
	{
		return w<A.w;
	}
}b[100005];
int main()
{
	freopen("Swap.in","r",stdin);
	freopen("Swap.out","w",stdout);
	scanf("%d",&n);
	memset(tmp,0x3f3f,sizeof(tmp));
	for(int i=1;i<n;i+=2)
	{
		scanf("%d",a+i);
		scanf("%d",a+i+1);
		b[i].w=a[i];
		b[i].id=i;
		b[i+1].w=a[i+1];
		b[i+1].id=i+1;
		tmp[0][i]=tmp[0][i+1]=a[i];
		tmp[1][i]=tmp[1][i+1]=a[i+1];
	}
	if(n&1)
	{
		scanf("%d",a+n);
		b[n].w=a[n];
		b[n].id=n;
		tmp[0][n]=tmp[0][n+1]=a[n];
	}
	sort(b+1,b+1+n);
	sort(tmp[0]+1,tmp[0]+1+n);
	sort(tmp[1]+1,tmp[1]+1+n);
	for(int i=1;i<=n;++i)
	{
		b[i].w=a[b[i].id]=i;
		a[i]=tmp[!(i&1)][i];
	}
	for(int i=1;i<=n;++i)
	{
		if(abs(a[i]-i)&1)
		{
			++ans;
			swap(a[a[i]],a[i]);
		}
	}
	printf("%d",ans);
	return 0;
}

