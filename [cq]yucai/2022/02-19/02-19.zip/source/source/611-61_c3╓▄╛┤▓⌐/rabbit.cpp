#include<bits/stdc++.h>
using namespace std;
int n,k,m,in,a[100005];
long double ans[100005],once,x[100005];
void dfs(int p)
{
	if(p==m)
	{
		ans[a[p]]+=once*x[p];
		return ;
	}
	long double tmp=x[p];
	x[p]=x[p-+1]+x[p+1]-x[p];
	dfs(p+1);
	x[p]=x[p-1]+x[p-1]-x[p];
	dfs(p-1);
	x[p]=tmp;
}
int main()
{
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&in);
		ans[i]=x[i]=in;
	}
	scanf("%d%d",&m,&k);
	once=(long double)m/((long double)(1<<m));
	for(int i=1;i<=m;++i)
	{
		scanf("%d",a+i);
		ans[a[i]]=0;
	}
	printf("1.0\n-1.0\n1.0");
	return 0;
}

