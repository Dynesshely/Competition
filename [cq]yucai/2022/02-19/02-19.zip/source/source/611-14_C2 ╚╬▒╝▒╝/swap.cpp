#include <bits/stdc++.h>
#define FOR(i,k,n,p) for(int i = k ; i <= n ; i += p)
#define ROF(i,k,n,p) for(int i = k ; i >= n ; i -= p)
#define gc getchar
#define pc putchar
#define space pc(' ')
#define enter pc('\n')
using namespace std ;
const int N = 1e5+5 ;
struct node{int x,id ;}a[N];
int n,ans ;
int b[N],tr[N] ;
inline void read(int &x)
{
	x = 0 ; int f = 0 ; char c = gc() ;
	while(!isdigit(c)) f = (c=='-'),c = gc() ;
	while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
	x = (f?-x:x) ;
}
inline void print(int x)
{
	if(x < 0) pc('-'),x = -x ;
	if(x > 9) print(x/10) ;
	pc(x%10+'0') ;
}
inline int ask(int x)
{
	int sum = 0 ;
	while(x) sum += tr[x],x -= -x&x ;
	return sum ;
}
inline void add(int x)
{
	while(x <= n) tr[x]++,x += -x&x ;
}
inline int cmp(node x,node y)
{
	return x.x < y.x ;
}
int main()
{
	freopen("swap.in","r",stdin) ;
	freopen("swap.out","w",stdout) ;
	read(n) ;
	FOR(i,1,n,1) read(a[i].x),a[i].id = i ;
	sort(a+1,a+1+n,cmp) ;
	FOR(i,1,n,1) b[a[i].id] = i ;
	FOR(i,1,n,1)
	{
		int sum = i-1-ask(b[i]) ;
		add(b[i]) ;
		ans += sum>>1 ;
	}
	print(ans) ;
	return 0 ;
}
