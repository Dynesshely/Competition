#include <bits/stdc++.h>
using namespace std;
int n, m;
char qwq[105][105], ans[205][205];
int main() {
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1; i <= m; ++i)
		scanf("%s", qwq[i]+1);
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j)
			ans[j*2][i*2]=ans[j*2-1][i*2]=ans[j*2][i*2-1]=ans[j*2-1][i*2-1]=qwq[j][i];
	for(int i = 1; i <= n*2; ++i) {
		for(int j = 1; j <= m*2; ++j)
			printf("%c",ans[j][i]);
		printf("\n");
	}
	return 0;
} 
