#include <bits/stdc++.h>
using namespace std;
int n, a[100005], id[100005], ans;
struct qwq{
	int s, x;
}b[100005];
bool comp(qwq  A, qwq B) {
	return A.s < B.s;
}
int main() {
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i = 1; i <= n; ++i)
		scanf("%d",&a[i]), b[i].s=a[i], b[i].x=i;
	sort(b+1,b+1+n,comp);
	for(int i = 1; i <= n; ++i)
		id[b[i].x]=i;
	for(int i = 1; i <= n; ++i)
		ans += (id[i]%2 != i%2)/*, cout<<id[i]<<" "*/;
	cout<<ans/2<<"\n";
	return 0;
} 
