#include <bits/stdc++.h>
using namespace std;
const int fx[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
int h, w, ans, a, b, m[105][105], pd[205][205];
char zf[105][105];
struct node{
	int x, y, s, vis[105][105];
	bool operator <(const node &A) const {
		return A.s > s;
	}
};
priority_queue <node> q;
bool sf(int x, int y) {
	if(x <= 0 || y <= 0 || x > h || y > w) return 1;
	return 0;
}
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d",&h,&w);
	for(int i = 1; i <= h; ++i)
		scanf("%s", zf[i]+1);
	for(int i = 1; i <= h; ++i)
		for(int j = 1; j <= w; ++j)
			if(zf[i][j] == 'E') a=i, b=j;
	q.push((node) {0,0,0});
	while(!q.empty()) {
		node it=q.top(); q.pop();
		ans=max(ans, it.s);
//		cout<<it.x<<" "<<it.y<<" "<<it.s<<"\n";
//		for(int i = 1; i <= h; ++i) {
//			for(int j = 1; j <= w; ++j)
//				cout<<it.vis[i][j]<<" ";
//			cout<<"\n";
//		}cout<<"\n";
		pd[it.x+h][it.y+w]=it.s;
		for(int o = 0; o <= 3; ++o) {
			node cc;
			cc.x=it.x+fx[o][0], cc.y=it.y+fx[o][1], cc.s=it.s;
			if(cc.x+h <= 0 || cc.y+w <= 0 || cc.x >= h || cc.y >= w) continue;
			for(int i = 1; i <= h; ++i)
				for(int j = 1; j <= w; ++j)
					cc.vis[i][j]=it.vis[i][j];
			int qwq=0;
			for(int i = 1; i <= h; ++i)
				for(int j = 1; j <= w; ++j) {
					if(it.vis[i][j] || zf[i][j] != 'o') continue;
					if(sf(i+cc.x, j+cc.y)) {
						cc.vis[i][j]=1;
						continue;
					}qwq=1;
					if(i+cc.x == a && j+cc.y == b) ++cc.s, cc.vis[i][j]=1;
				}
			if(qwq && cc.s > pd[cc.x+h][cc.y+w])
				q.push(cc), pd[cc.x+h][cc.y+w]=cc.s;
		}
	}
	printf("%d",ans);
	return 0;
} 
