#include <bits/stdc++.h>
using namespace std;
int n,m,ex,ey;
char ch[200][200];
int sumx[200][200],sumy[200][200];
int dp[101][101][101][101];
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) {
		for(int j=0;j<=m;j++) scanf("%c",&ch[i][j]);
		for(int j=1;j<=m;j++) if(ch[i][j]=='E') ex=i,ey=j;
	}
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=m;j++) sumx[i][j]=sumx[i][j-1]+(ch[i][j]=='o');
		for(int j=1;j<=m;j++) sumy[j][i]=sumy[j][i-1]+(ch[i][j]=='o');
	}
	for(int w=m;w>=1;w--) {
		for(int h=n;h>=1;h--) {
			for(int i=max(ex-w+1,1);i<=ex&&i+h-1<=n;i++) {
				for(int j=max(ey-h+1,1);j<=ey&&j+w-1<=m;j++) {
					dp[w][h][i][j]=0;
					dp[w][h][i][j]=max(dp[w+1][h][i-1][j]+sumy[j-1][min(i+h-1,n-(ex-i))]-sumy[j-1][max(i,i+h-ex)-1],dp[w][h][i][j]);
					dp[w][h][i][j]=max(dp[w+1][h][i][j]+sumy[j+w][min(i+h-1,n-(ex-i))]-sumy[j+w][max(i,i+h-ex)-1],dp[w][h][i][j]);
					dp[w][h][i][j]=max(dp[w][h+1][i][j-1]+sumx[i-1][min(j+w-1,m-(ey-j))]-sumx[i-1][max(j,j+w-ey)-1],dp[w][h][i][j]);
					dp[w][h][i][j]=max(dp[w][h+1][i][j]+sumx[i+h][min(j+w-1,m-(ey-j))]-sumx[i+h][max(j,j+w-ey)-1],dp[w][h][i][j]);
				}
			}
		}
	}
	printf("%d\n",dp[1][1][ex][ey]);
	return 0; 
}
