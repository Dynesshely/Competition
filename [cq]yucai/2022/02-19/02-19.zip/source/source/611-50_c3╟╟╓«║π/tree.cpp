#include <bits/stdc++.h>
using namespace std;
int T,n,a[200],b[200];
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	for(int i=1;i<=T;i++) {
		scanf("%d",&n);
		for(int j=1;j<=n;j++) scanf("%d",&a[j]);
		sort(a+1,a+1+n);
		for(int i=0;i<200;i++) b[i]=0;
		for(int j=1;j<=n;j++) b[a[j]]++;
		bool tu=1;
		if((a[n]+1)/2!=a[1]) tu=0;
		if(a[n]%2==0) {
			if(b[a[1]]!=1) tu=0;
			for(int j=a[2];j<=a[n];j++) {
				if(b[j]<2) tu=0;
			}
		} else {
			if(b[a[1]]!=2) tu=0;
			for(int j=a[2];j<=a[n];j++) {
				if(b[j]<2) tu=0;
			}
		}
		if(tu) printf("Yes\n");
		else printf("NO\n");
	}
	return 0; 
}
//Yes
//NO
