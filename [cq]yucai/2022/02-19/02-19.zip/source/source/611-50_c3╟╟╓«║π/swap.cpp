#include <bits/stdc++.h>
using namespace std;
struct inp {
	int va,ind;
	bool operator<(const inp &oth)const {
		return va<oth.va;
	}
} g[200000];
int n,f[200000];
int main() {
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&g[i].va),g[i].ind=i;
	sort(g+1,g+1+n);
	for(int i=1;i<=n;i++) f[g[i].ind]=i;
	int ans=0;
	for(int i=1;i<=n;i++) {
		if(f[i]%2!=i%2) ans++;
	}
	printf("%d\n",ans/2);
	return 0; 
}
