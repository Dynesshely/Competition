#include<bits/stdc++.h>
using namespace std;
int h,w,cnt=0,dx,dy,tx,ty,xx,yy,ans=0,vis[10005],ansx=1e9,tnt=0;
char a[105][105];
struct ok{
	int x,y;
}b[10005];
vector<int> e[10005];
void dfs(int k){
	tnt++;
	if(tnt>=1000000) return;
	for(int i=1;i<=cnt;i++){
		if(vis[i]>0) continue;
		vis[i]++;
		for(int j=0;j<(int)e[i].size();j++) vis[e[i][j]]++;
		dfs(k+1);
		if(ans==ansx) return;
		vis[i]--;
		for(int j=0;j<(int)e[i].size();j++) vis[e[i][j]]--;
	}
	ans=max(ans,k);
	if(ans==ansx) return;
}
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d",&h,&w);
	for(int i=1;i<=h;i++){
		scanf("%s",a[i]+1);
		for(int j=1;j<=w;j++){
			if(a[i][j]=='o'){
				cnt++;
				b[cnt].x=i,b[cnt].y=j;
			}
			if(a[i][j]=='E') dx=i,dy=j;
		}
	} 
	for(int i=1;i<=cnt;i++){
		for(int j=1;j<=cnt;j++){
			if(i==j) continue;
			tx=b[i].x-dx,ty=b[i].y-dy;
			xx=b[j].x-tx,yy=b[j].y-ty;
			if(xx<=0||xx>h||yy<=0||yy>w) e[i].push_back(j);
		}
		ansx=min(ansx,(int)e[i].size());
	}
	ansx=cnt-ansx;
	dfs(0);
	printf("%d",ans);
	return 0;
}
