#include<bits/stdc++.h>
using namespace std;
int t,n,a[105],dis[105],b[105],head[105],nxt[205],txt[205],cnt;
bool flag;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs2(int k,int f,int d,int g){
	if(d>dis[g]) dis[g]=d;
	for(int i=head[k];i;i=nxt[i]) if(txt[i]!=f) dfs2(txt[i],k,d+1,g);
}
void dfs(int k,int g){
	if(k==g){
		cnt=0;
		for(int i=1;i<=g;i++) head[i]=dis[i]=0;
		for(int i=1;i<g;i++){
			nxt[++cnt]=head[b[i]],head[b[i]]=cnt,txt[cnt]=i+1;
			nxt[++cnt]=head[i+1],head[i+1]=cnt,txt[cnt]=b[i];
		}
		for(int i=1;i<=g;i++){
			dfs2(i,0,0,i);
			if(dis[i]!=a[i]) break;
			else if(i==g) flag=1;
		}
		return;
	}
	for(int i=1;i<=k;i++){
		b[k]=i;
		dfs(k+1,g);
		if(flag) return;
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	t=read();
	for(int i=1;i<=t;i++){
		n=read();
		flag=0;
		for(int j=1;j<=n;j++) a[j]=read();
		dfs(1,n);
		if(flag){
			putchar('Y');
			putchar('e');
			putchar('s');
		}
		else{
			putchar('N');
			putchar('O');
		}
		putchar('\n');
	}
	return 0;
}

