#include<bits/stdc++.h>
using namespace std;
long long n,x[100005],m,k,t,tot=0,a[100005],ans[100005];
long double c[100005];
inline long long read(){
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs(long long k){
	if(k==t+1){
		for(int i=1;i<=n;i++) ans[i]+=x[i];
		tot++;
		return;
	}
	long long g=k%m,temp;
	if(g==0) g=m;
	g=a[g];
	temp=x[g];
	x[g]=x[g+1]-x[g]+x[g+1];
	dfs(k+1);
	x[g]=temp;
	x[g]=x[g-1]-x[g]+x[g-1];
	dfs(k+1);
	x[g]=temp;
}
int main(){
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) x[i]=read();
	m=read(),k=read();
	for(int i=1;i<=m;i++) a[i]=read();
	t=m*k;
	dfs(1);
	for(int i=1;i<=n;i++) c[i]=(long double)ans[i]/(long double)tot;
	for(int i=1;i<=n;i++) cout<<fixed<<setprecision(1)<<c[i]<<'\n'; 
	return 0;
}

