#include<bits/stdc++.h>
using namespace std;
const int maxn=110;
int n,m;
char fu[maxn][maxn];
int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) if(ch=='-') f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar()) x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
int main() {
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	n=read(),m=read();
	for(int i=1; i<=m; i++)	for(int j=1; j<=n; j++) cin>>fu[j][i];
	for(int i=1; i<=n; i++) for(int k=1; k<=2; k++)	{for(int j=1; j<=m; j++) cout<<fu[i][j]<<fu[i][j];	printf("\n");}
	return 0;
}
