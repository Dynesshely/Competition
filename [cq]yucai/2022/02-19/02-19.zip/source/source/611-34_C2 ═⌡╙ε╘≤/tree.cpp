#include<bits/stdc++.h>
using namespace std;
const int maxn=110;
int T,n,max_v,min_v;
int f[maxn],fu[maxn];
int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar())x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
void ycl() {
	n=0,max_v=0,min_v=110;
	memset(f,0,sizeof(f));
	memset(fu,0,sizeof(fu));
	return;
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	T=read();
	for(int i=1; i<=T; i++) {
		ycl();
		n=read();
		for(int j=1; j<=n; j++) {
			f[j]=read();
			fu[f[j]]++;
			max_v=max(max_v,f[j]);
			min_v=min(min_v,f[j]);
		}
		if(max_v%2==0) {
			if(min_v!=(max_v/2)) {
				printf("NO\n");
				continue;
			}
			if(fu[min_v]!=1) {
				printf("NO\n");
				continue;
			}
			for(int j=max_v; j>=min_v; j--) {
				if(j==min_v) printf("Yes\n");
				if(j!=min_v&&fu[j]<2) {
					printf("NO\n");
					break;
				}
			}
			continue;
		}
		if(max_v%2==1) {
			if(min_v!=((max_v+1)/2)) {
				printf("NO\n");
				continue;
			}
			if(fu[min_v]!=2) {
				printf("NO\n");
				continue;
			}
			for(int j=max_v; j>=min_v; j--) {
				if(j==min_v) printf("Yes\n");
				if(j!=min_v&&fu[j]<2) {
					printf("NO\n");
					break;
				}
			}
			continue;
		}
	}
	return 0;
}
