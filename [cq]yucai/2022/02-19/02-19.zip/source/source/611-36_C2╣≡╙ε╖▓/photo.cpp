#include<bits/stdc++.h>
using namespace std;
#define N 205
int n,m;
char s[N][N];
char ans[N][N];
int main()
{
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin>>s[j][i];
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			ans[2*i-1][2*j-1]=ans[2*i-1][2*j]=ans[2*i][2*j-1]=ans[2*i][2*j]=s[i][j];
		}
	}
	for(int i=1;i<=2*n;i++){
		for(int j=1;j<=2*m;j++)
			cout<<ans[i][j];
		cout<<endl;
	}
	return 0;
}
