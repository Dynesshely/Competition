#include<bits/stdc++.h>
using namespace std;
#define N 105
int t;
int n;
int a[N];
int tot[N];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		memset(tot,0,sizeof(tot));
		scanf("%d",&n);
		int mx=0,mn=N;
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			mx=max(mx,a[i]);
			mn=min(mn,a[i]);
			tot[a[i]]++;
		}
		if(tot[mx]==1||tot[mn]!=2*mn-mx+1)
		{
			printf("NO\n");
			continue;
		}
		int flag=0,num=N;
		for(int i=mn+1;i<mx;i++)
		{
			if(tot[i]>num)
			{
				flag=1;
				break;
			}
			num=tot[i];
		}
		if(!flag)printf("Yes\n");
		else printf("NO\n");
	}
	return 0;
}
