#include<bits/stdc++.h>
using namespace std;
const int maxn=106,maxs=10006,maxm=20006;
int H,W,ls,rs,us,ds,cot,id[maxn][maxn],ans,x[maxs],y[maxs];
int cnt,hed[maxs],nxt[maxm],to[maxm];
char ch[maxn][maxn];
bool vis[maxs];
void init(){
	memset(hed,0,sizeof(hed));
	memset(nxt,0,sizeof(nxt));
	cot=cnt=ans=0;
	return ;
}
void reinit(){
	for(int i=1;i<=cot;i++){
		vis[i]=1;
	}
	return ;
}
void add(int u,int v){
	nxt[++cnt]=hed[u];
	hed[u]=cnt;
	to[cnt]=v;
	return ;
}
int dfs(int x){
	int sum=0;
	vis[x]=1;
	for(int i=hed[x];i;i=nxt[i]){
		if(vis[to[i]])continue;
		sum=max(sum,dfs(to[i]));
	}
	return sum+1;
}
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	init();
	scanf("%d%d",&H,&W);
	for(int i=1;i<=H;i++){
		scanf("%s",ch[i]+1);
	}
	for(int i=1;i<=H;i++){
		for(int j=1;j<=W;j++){
			if(ch[i][j]=='o'){
				id[i][j]=++cot;
				x[cot]=i,y[cot]=j;
			}
			else if(ch[i][j]=='E'){
				ls=j,rs=W-j+1;
				us=i,ds=H-i+1;
			}
		}
	}
	for(int i=1;i<=cot;i++){
		for(int pi=x[i]-us+1;pi<=x[i]+ds-1;pi++){
			for(int pj=y[i]-ls+1;pj<=y[i]+rs-1;pj++){
				if(!(pi==x[i]&&pj==y[i])&&ch[pi][pj]=='o'){
					add(i,id[pi][pj]);
					add(id[pi][pj],i);
				}
			}
		}
	}
	for(int i=1;i<=cot;i++){
		reinit();
		for(int j=hed[i];j;j=nxt[j]){
			vis[to[j]]=0;
		}
		ans=max(ans,dfs(i));
	}
	printf("%d",ans);
	return 0;
}
