#include<bits/stdc++.h>
using namespace std;
const int maxn=106;
int T,n,a[maxn],v[maxn],ma,ha;
void reinit(){
	memset(v,0,sizeof(v));
	ma=0;
	return ;
}
bool check(){
	reinit();
	for(int i=1;i<=n;i++){
		v[a[i]]++;
		ma=max(ma,a[i]);
	}
	ha=(ma+1)/2;
	for(int i=ha-1;i>=1;i--){
		if(v[i])return 0;
	}
	if(ma%2==0&&v[ha]!=1)return 0;
	for(int i=ha+1;i<=ma;i++){
		if(v[i]<2)return 0;
		v[i]-=2;
	}
	return 1;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		printf("%s",(check())?"Yes":"NO");
		putchar('\n');
	}
	return 0;
}
