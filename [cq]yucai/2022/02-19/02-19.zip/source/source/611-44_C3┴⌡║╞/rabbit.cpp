#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+7;
int n,m,k,a[maxn];
long double C[5006][5006];
struct node{
	int x,w;
}ra[maxn];
void calcC(){
	C[0][0]=1;
	for(int i=1;i<=5005;i++){
		for(int j=0;j<=i;j++){
			if(j)C[i][j]+=C[i-1][j-1];
			C[i][j]+=C[i-1][j];
			C[i][j]/=2;
		}
	}
	return ;
}
void init(){
	memset(C,0,sizeof(C));
	return ;
}
void out(long double x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	int outnum;
	outnum=(int)x;
	putchar(outnum+'0');
	putchar('.');
	outnum=((int)(x*10))%10;
	putchar(outnum+'0');
	return ;
}
int main(){
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	init();
	calcC();
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&ra[i].x);
		ra[i].w=0;
	}
	scanf("%d%d",&m,&k);
	for(int i=1;i<=m;i++){
		scanf("%d",&a[i]);
		ra[a[i]].w++;
	}
	for(int i=1;i<=n;i++){
		ra[i].w*=k;
	}
	int sum,mid;
	long double ans;
	for(int i=1;i<=n;i++){
		mid=(ra[i].w/2)+1,ans=0;
		for(int j=1;j<=ra[i].w+1;j++){
			sum=((j<=mid)?(ra[i].x-2*abs(j-mid)):(ra[i].x+2*abs(j-mid)));
			sum=((ra[i].w%2==1)?(sum-1):sum);
			ans+=((long double)sum)*C[ra[i].w][j-1];
//			cout<<sum<<' ';
		}
		out(ans);
		putchar('\n');
//		printf("%d %d\n",ra[i].w,ra[i].x);
	}
//	cout<<C[1][1]<<' '<<C[1][0]<<' '<<C[2][1]<<'\n';
//	out(3.1415936);
	return 0;
}
