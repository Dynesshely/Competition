#include<bits/stdc++.h>
using namespace std;
int n,a[100005],ans;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	{
		a[i]=read();
		int sum=i;
		while(a[sum]<a[sum-2]&&sum>2)
		{
			swap(a[sum],a[sum-2]);
			sum-=2;
		}
	}
	for(int i=1;i<n;++i)
		if(a[i]>a[i+1])
		{
		swap(a[i],a[i+1]);
		ans++;	
		}
	printf("%d",ans);
	return 0;
}
