#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=405;
int n,m;
char a[N][N],b[N][N];
signed main() {
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=m;++i) scanf("%s",a[i]+1);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			b[i][j]=a[m-j+1][i];
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			a[i*2-1][j*2-1]=a[i*2-1][j*2]=a[i*2][j*2-1]=a[i*2][j*2]=b[i][j];
	for(int i=1;i<=n<<1;++i) printf("%s\n",a[i]+1);
	return 0;
}
/*
3 2
.*.
.*.

....
....
****
****
....
....

3 2
...
.*.

....
....
**..
**..
....
....
*/
