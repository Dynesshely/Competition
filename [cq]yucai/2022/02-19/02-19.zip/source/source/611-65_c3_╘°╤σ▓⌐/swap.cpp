#include <bits/stdc++.h>
#define int long long
#define pii pair<int,int>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=100005;
int n,a[N],ans;
pii p[N];
signed main() {
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) p[i].first=read(),p[i].second=i;
	sort(p+1,p+1+n);
	for(int i=1;i<=n;++i) a[p[i].second]=i;
	for(int i=1;i<=n;++i) if(a[i]%2!=i%2) ++ans;
	cout<<ans/2;
	return 0;
}
/*
4 
2 4 3 1

1
*/
