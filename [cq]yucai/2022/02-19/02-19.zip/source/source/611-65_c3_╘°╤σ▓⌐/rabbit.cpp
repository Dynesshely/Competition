#include <bits/stdc++.h>
#define pid pair<int,double>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=100005;
int n,m,K,a[N];
vector<pid> v[N];
pid p[N];
signed main() {
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) v[i].push_back(pid(read(),1.0));
	m=read(),K=read();
	for(int i=1;i<=m;++i) a[i]=read();
	for(int _=1;_<=K;++_)
	for(int i=1;i<=m;++i) {
		int tot=0,ta=v[a[i]].size(),tb=v[a[i]+1].size(),tc=v[a[i]-1].size();
		for(int j=0;j<ta;++j)
			for(int k=0;k<tb;++k)
				p[++tot]=pid(2*v[a[i]+1][k].first-v[a[i]][j].first,v[a[i]][j].second*v[a[i]+1][k].second/2);
		for(int j=0;j<ta;++j)
			for(int k=0;k<tc;++k)
				p[++tot]=pid(2*v[a[i]-1][k].first-v[a[i]][j].first,v[a[i]][j].second*v[a[i]-1][k].second/2);
		v[a[i]].clear();
		for(int j=1;j<=tot;++j) v[a[i]].push_back(pid(p[j].first,p[j].second));
	}
	for(int i=1;i<=n;++i) {
		double res=0;
		int t=v[i].size();
		for(int j=0;j<t;++j) res+=v[i][j].first*v[i][j].second;
		cout<<fixed<<setprecision(1)<<res<<'\n';
	}
	return 0;
}
/*
3 
1 -1 1
2 2
2 2

1.0
-1.0
1.0
*/
