#include <bits/stdc++.h>
#define pii pair<int,int>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=105;
int n,m,ans,st;
char s[N][N];
int dir[4][2]={{0,1},{0,-1},{-1,0},{1,0}};
bool va[N*N];
pii a[N*N];
map<string,bool> mp;
string S() {
	string ss="";
	for(int i=1;i<=st;++i) if(!va[i]) {
		ss+=' ';
		int x=a[i].first,y=a[i].second;
		while(x) ss+=x%10+'0',x/=10;
		ss+=' ';
		while(y) ss+=y%10+'0',y/=10;
	}
	return ss;
}
void dfs(int t,int tot) {
//	cerr<<t<<" "<<tot<<endl;
//	if(t) cerr<<t<<endl;
	if(!tot) {
		ans=max(ans,t);
		return;
	}
	string ss=S();
//	cout<<ss<<endl;
	if(mp[ss]) return;
	mp[ss]=1;
	bool vb[st+1];
	pii b[st+1];
	for(int i=1;i<=st;++i) b[i]=a[i],vb[i]=va[i];
	for(int i=0;i<4;++i) {
//		cerr<<i<<endl;
		int tt=t,tott=tot;
		for(int j=1;j<=st;++j) {
			if(va[j]) continue;
			int nx=a[j].first+dir[i][0],ny=a[j].second+dir[i][1];
			a[j].first=nx,a[j].second=ny;
			if(s[nx][ny]=='E') ++tt,--tott,va[j]=1;
			if(nx<1||nx>n||ny<1||ny>m) --tott,va[j]=1;
		}
//		cerr<<"fa\n";
//		for(int j=1;j<=st;++j) if(!va[j]) cerr<<a[j].first<<" "<<a[j].second<<endl;
//		cerr<<"fb\n";
		dfs(tt,tott);
		for(int j=1;j<=st;++j) a[j]=b[j],va[j]=vb[j];
	}
}
signed main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cout<<3;
//	n=read(),m=read();
//	for(int i=1;i<=n;++i) scanf("%s",s[i]+1);
//	for(int i=1;i<=n;++i)
//	for(int j=1;j<=m;++j) 
//		if(s[i][j]=='o') a[++st].first=i,a[st].second=j;
////	cerr<<"fa\n";
////	for(int j=1;j<=st;++j) if(!va[j]) cerr<<a[j].first<<" "<<a[j].second<<endl;
////	cerr<<"fb\n";
////	cerr<<st<<endl;
//	dfs(0,st);
	return 0;
}
/*
3 3
o.o
.Eo
ooo

3
*/
