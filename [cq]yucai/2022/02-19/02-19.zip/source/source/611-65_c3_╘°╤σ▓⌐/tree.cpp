#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=105;
int t,n,a[N],b[N],ma,mi;
signed main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	t=read();
	while(t--) {
		n=read();
		bool flag=0;
		memset(b,0,sizeof b);
		ma=0,mi=1e9;
		for(int i=1;i<=n;++i) a[i]=read(),++b[a[i]],ma=max(ma,a[i]),mi=min(mi,a[i]);
		if(ma&1) {
			for(int i=ma;i>ma/2+1;--i)
				if(b[i]<2) {
					flag=1;
					break;
				}
			if(b[ma/2+1]!=2||mi<ma/2+1) flag=1;
		}
		else {
			for(int i=ma;i>ma/2;--i)
				if(b[i]<2) {
					flag=1;
					break;
				}
			if(b[ma/2]!=1||mi<ma/2) flag=1;
		}
		if(flag) puts("NO");
		else puts("Yes");
	}
	return 0;
}
/*
6 
5 
3 2 2 3 3
3 
1 1 2
10
1 2 2 2 2 2 2 2 2 2
10
1 1 2 2 2 2 2 2 2 2
6 
1 1 1 1 1 5
5 
4 3 2 3 4

Yes
No
Yes
NO
NO
Yes
*/
