#include<bits/stdc++.h>
using namespace std;

int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
const int Maxn=1e5+10;
int n,res;
struct node {
	int x,id;
	bool operator <(const node &b) const {
		return x<b.x;
	}
}a[Maxn];
signed main() {
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) a[i].x=read(),a[i].id=i;
	sort(a+1,a+n+1);
	for(int i=1;i<=n;++i) res+=(i+a[i].id)&1;
	put(res/2);
	return 0;
}

