#include<bits/stdc++.h>
using namespace std;

int n,m,N,M; 
char a[501][501];

signed main() {
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	cin>>n>>m,N=n<<1,M=m<<1;
	for(int i=1;i<=m;++i) {
		for(int j=1;j<=n;++j) {
			int x=i<<1,y=j<<1;
			char c; cin>>c;
			a[x-1][y-1]=a[x-1][y]=a[x][y-1]=a[x][y]=c;
		}
	}
	for(int j=N;j>=1;--j) {
		for(int i=1;i<=M;++i) putchar(a[i][j]);
		putchar('\n');
	}
	return 0;
}

