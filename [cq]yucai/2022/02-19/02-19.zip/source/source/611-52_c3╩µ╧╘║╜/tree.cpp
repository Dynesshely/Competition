#include<bits/stdc++.h>
#define int long long
using namespace std;

int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10+'0');
}
int T,cnt[101]; 
signed main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	T=read();
	while(T--) {
		memset(cnt,0,sizeof cnt);
		int n=read(),ma=0,x,m,flag=0;
		for(int i=1;i<=n;++i) x=read(),ma=max(ma,x),++cnt[x];
		m=ma+1>>1;
		for(int i=1;i<=100;++i) {
			if(i<m||i>ma) {if(cnt[i]) flag=1;break;}
			else {
				if(i!=m||(i==m&&(ma&1))) {if(cnt[i]<2) {flag=1;break;}} 
				else {if(cnt[i]!=1) {flag=1;break;}}
			}
		}
		puts(flag?"NO":"Yes");
	}
	return 0;
}

