#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) x=-x;
	if(x>10) out(x/10);
	putchar(x%10+'0');
}
signed main()
{
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
	
	return 0;
} 
