#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) x=-x;
	if(x>10) out(x/10);
	putchar(x%10+'0');
}
int T,n,a[110],cnt[110],sum,ans;
signed main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	T=read();
	while(T--)
	{
		sum=0;
		memset(cnt,0,sizeof cnt);
		n=read();
		int mi=1e9,mx=0;
		for(int i=1;i<=n;i++)
		{
			a[i]=read();
			cnt[a[i]]++;
			mi=min(mi,a[i]);
			mx=max(mx,a[i]);
		}
		if(mx>mi*2)
		{
			cout<<"NO\n";
			continue;
		}
		bool flag=0;
		for(int i=mi+1;i<=mx;i++)
		{
			if(cnt[i]<2)
			{
				cout<<"NO\n";
				flag=1;
				break;
			}
		}
		if(flag==1) continue;
		if(cnt[mi]>2)
		{
			cout<<"NO\n";
			continue;
		}
		if((mx-mi)*2+cnt[mi]-1==mx) cout<<"Yes\n";
		else cout<<"NO\n";
	}
	return 0;
} 
