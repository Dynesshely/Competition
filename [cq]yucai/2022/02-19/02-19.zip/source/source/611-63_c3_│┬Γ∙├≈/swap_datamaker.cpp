#include<bits/stdc++.h>
using namespace std;
bool vis[100010];
signed main()
{
	srand(114514);
	int n=1000;
	freopen("swap.in","w",stdout);
	cout<<n<<'\n';
	for(int i=1;i<=n;i++)
	{
		int a=rand()%n+1;
		while(vis[a]) a=rand()%n+1;
		vis[a]=1;
		cout<<a<<' ';
	}
	return 0;
} 
