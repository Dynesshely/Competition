#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c=getchar();
	int x=0,f=0;
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
void out(int x)
{
	if(x<0) x=-x;
	if(x>10) out(x/10);
	putchar(x%10+'0');
}
int n,m;
char c[110][110];
signed main()
{
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	n=read(),m=read();
	char nouse;
	for(int i=1;i<=m;++i)
	{
		for(int j=1;j<=n;++j)
		{
//			cin>>c[i][j];
			c[i][j]=getchar();
		}
		nouse=getchar();
	}
	for(int i=1;i<=n;++i)
	{
		for(int t=1;t<=2;++t)
		{
			for(int j=1;j<=m;++j)
			{
				putchar(c[j][i]);
			}
			for(int j=m;j>=1;--j)
			{
				putchar(c[j][i]);
			}
			putchar('\n');
		}
	}
	return 0;
} 
