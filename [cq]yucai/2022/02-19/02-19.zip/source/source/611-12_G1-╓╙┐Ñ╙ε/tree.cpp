// By Hasinon,the juruo who's waiting for AFO life.
/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool hasinon;
ll time1=clock();
//
const ll N=100;
ll a[N+10],vis[N+10];
ll mmax=0,n;
//
bool sol(){
	ll mid=mmax/2+1;
	FOR(i,mid,mmax){
		vis[i]-=2;
		if(vis[i]<0) return 0;
	}
	if(!(mmax&1)){
		--vis[mid-1];
		if(vis[mid-1]<0) return 0;
		--mid;
	}
	FOR(i,1,mid){
		if(vis[i]) return 0;
	}
	return 1;
}
//
inline char gc(){
	static char buf[100000],*p1=buf,*p2=buf;
	return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Hasinon;
void usage() {
	ll time2=clock();
	cout<<(&Hasinon-&hasinon)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	ll T=gt();
	while(T--){
		memset(vis,0,sizeof(vis));
		n=gt(),mmax=0;
		FOR(i,1,n){
			a[i]=gt();
			++vis[a[i]];
			mmax=max(mmax,a[i]);
		} 
		sol()?printf("Yes\n"):printf("NO\n");
	}
}
/*
  0. Enough array size? Enough array size? Enough array size? Integer overflow?

  1. Think TWICE, Code ONCE!
  Are there any counterexamples to your algo?

  2. Be careful about the BOUNDARIES!
  N=1? P=1? Something about 0?

  3. Do not make STUPID MISTAKES!
  Time complexity? Memory usage? Precision error?
*/



