#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

int n,m;

//namespace stb1{
//	const int N = 15;
//	char a[N][N];
//	
//	int main(){
//		for(int k=1;k<=n;k++)
//			scanf("%s",a[k]+1);
//		int len = n+m-1;
//		int lox = 1,upx = n,lowy = 1,upy = m;
//		for(int k=0;k<(1<<len);k++){
//			for(int j=0;j<len;j++){
//				if((k>>j)&1){
//					
//				}
//			}
//		}
//	}
//}

namespace stb2{
	const int N = 105;
	class Ayaka{
		public:
			int x,y;
			Ayaka(int x_=0,int y_=0):x(x_),y(y_){}
	}a[N],c[N],end;
	char s[N];
	int wei;

	int main(){
		for(int k=1;k<=n;k++){
			scanf("%s",s+1);
			for(int j=1;j<=m;j++)
				if(s[j]=='E')
					end = Ayaka(k,j);
				else if(s[j]=='o')
					a[++wei] = Ayaka(k,j);
		}
		int ans = 0;
		for(int k=1;k<(1<<wei);k++){
			int tt = 0;
			for(int j=1;j<=wei;j++)
				if((k>>(j-1))&1)
					c[++tt] = a[j];
			int flag = false;
			int maxx = 0,minx = n,maxy = 0,miny = m;
			for(int k=1;k<=tt;k++){
				maxx = max(maxx,c[k].x-end.x);
				maxy = max(maxy,c[k].y-end.y);
				minx = min(minx,c[k].x-end.x);
				miny = min(miny,c[k].y-end.y);
			}
			maxx = max(maxx,n-end.x-1);
			maxy = max(maxy,n-end.y-1);
			minx = min(minx,-end.x);
			miny = min(miny,-end.y);
			for(int k=1;k<=tt;k++){
				if(min(n-c[k].x-1,c[k].x)>=maxx||max(n-c[k].x-1,c[k].x)<=minx){
					flag = true;
					break;
				}
				if(min(n-c[k].y-1,c[k].y)>=maxy||max(n-c[k].y-1,c[k].y)<=miny){
					flag = true;
					break;
				}
			}
			ans = max(ans,flag?0:tt);
		}
		printf("%d",ans);
		return 0;
	}
}

int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d",&n,&m);
//	if(n<=10&&m<=10)
//		return stb1::main();
	return stb2::main();
	return 0; 
}
