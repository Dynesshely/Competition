#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 100005;
int a[N];
int n,m,K;

namespace stb1{
	const int N = 100005;
	int wei[N];
	
	int main(){
		for(int k=1;k<=m;k++)
			scanf("%d",wei+k);
		while(K--)
			for(int k=1;k<=m;k++)
				a[wei[k]] = a[wei[k]+1]+a[wei[k]-1]-a[wei[k]];
		for(int k=1;k<=n;k++)
			printf("%.1lf\n",(double)a[k]);
		return 0;
	}
}

namespace stb2{
	const int N = 100005,M = 2*N;
	int h[N],ne[M],e[M],idx;
	int wei[N];
	int pos[N];
	
	inline void add(int a,int b){
		e[idx] = b,ne[idx] = h[a],h[a] = idx++;
	}
	
	int main(){
		memset(h,-1,sizeof(h));
		for(int k=1;k<=m;k++)
			scanf("%d",wei+k);
		for(int k=1;k<=n;k++)
			pos[k] = k;
		for(int k=1;k<=m;k++)
			swap(pos[wei[k]],pos[wei[k+1]]);
		for(int k=1;k<=n;k++)
			add(pos[k],k);
		for(int k=1;k<=n;k++){
			int u = k,cnt = 0;
			for(int j=h[k];~j&&e[j]!=k&&cnt<K;j=ne[j],cnt++)
				a[u=e[k]] = a[u-1]+a[u+1]-a[u];
		}
		for(int k=1;k<=n;k++)
			printf("%.1lf\n",(double)a[k]);
		return 0;
	}
}

int main(){
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	scanf("%d",&n);
	for(int k=1;k<=n;k++)
		scanf("%d",a+k);
	scanf("%d%d",&m,&K);
	if(m*K<=1000000)
		return stb1::main();
	return stb2::main();
	return 0;
}
