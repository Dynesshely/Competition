#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 105;
int col[N];
int n;

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int q;
	scanf("%d",&q);
	while(q--){
		memset(col,0,sizeof(col));
		scanf("%d",&n);
		int maxx = 0;
		for(int k=1;k<=n;k++){
			int num;
			scanf("%d",&num);
			maxx = max(maxx,num);
			col[num]++;
		}
		bool flag = false;
		if((!(maxx&1))&&(!(col[maxx>>1]&1)))
			flag = true;
		for(int k=1;k<((maxx+1)>>1);k++)
			if(col[k])
				flag = true;
		puts(flag?"NO":"Yes");
	}
	return 0;
}
