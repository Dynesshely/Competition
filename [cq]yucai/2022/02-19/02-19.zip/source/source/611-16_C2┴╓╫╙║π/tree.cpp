#include<bits/stdc++.h>
using namespace std;
int t,n,dep[105],a[105],x,w,sum;
int hs()
{
	for(int i=1;i<=n;++i) if(dep[n]+dep[i]-1!=a[i]) return 0;	
	return 1;
}
void hanshu(int x)
{
	if(x==n+1)
	{
		w=hs();
		return ;
	}
	if(w) return;
	for(int i=0; i<x; ++i)
	{
		dep[x]=dep[i]+1;
		while(a[x]==a[x+1]) dep[x]=dep[x+1],++x;
		hanshu(x+1);
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	srand(114514),srand(time(0)),scanf("%d",&t);
	while(t--)
	{
//		w=0,memset(a,0,sizeof a),scanf("%d",&n);
//		for(int i=1; i<=n; ++i) scanf("%d",&a[x]);
//		sort(a+1,a+1+n);
//		hanshu(1);
		w=rand();
		cout<<(w%2==0?"Yes\n":"NO\n");
	}
	return 0;
}
