#include<bits/stdc++.h>
using namespace std;
int n,m;
char a[105][105];
int main()
{
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=m; ++i) for(int j=1; j<=n; ++j) cin>>a[i][j];
	for(int i=1,k=m; i<m/2; ++i,--k) for(int j=1; j<=n; ++j) swap(a[i][j],a[k][j]);
	for(int j=1; j<=2*n; ++j) for(int i=2*m; i>=1; --i) cout<<a[(i+1)/2][(j+1)/2]<<(i==1?"\n":" ");
	return 0;
}
