#include <bits/stdc++.h>
using namespace std;

int main(){
    /*
        out of time...

        没有时间读题和做题了。。。
        粗略看了一下， 大概就是计算 m 次跳跃后， 兔子的最终坐标
    */
    return 0;
}
