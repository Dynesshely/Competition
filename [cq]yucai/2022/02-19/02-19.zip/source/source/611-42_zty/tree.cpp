#include <bits/stdc++.h>
using namespace std;

int main(){
    /*
        啥叫从序列构造一颗树哇， 这个不会。。。
        拐了。。。

        此题mark一下， 等会儿认真听
    */
    return 0;
}
