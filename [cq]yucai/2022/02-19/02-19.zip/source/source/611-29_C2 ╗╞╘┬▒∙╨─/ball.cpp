#include<bits/stdc++.h>
#define ll long long
#define N 103
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
using namespace std;
int n,m,sum[N][N],san;
char s[N][N];
struct hhh{
	int u,d,l,r,nu,nd,nl,nr;
}h[N][N];
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cout<<"3";
//	scanf("%d%d",&n,&m);
//	fff(i,1,n)
//	    fff(j,1,m){
//	    scanf("%s",&s[i][j]);
//		if(s[i][j]=='E') a=i,b=j;
//		if(s[i][j]=='o') sum[i][j]++;
//	    }
//	fff(i,1,n){
//		fff(j,1,m){
//		sum[i][j]+=sum[i][j-1]+sum[i-1][j]-sum[i][j];	
//		h[i][j]=(hhh){a-i,b-j,};
//		}	
//	fff(i,1,n){
//		fff(j,1,m){
//			fff(h,1,min(n,m)){
//				if(j+h>m||i+m>n)break;
//				
//				
//				
//				
//				if()
//				san=max(san,sum[i+h][j+h]-sum[i+h][j-1]-sum[i-1][j+h]+sum[i-1][j-1]);
//			}
//		}
//	}
//	cout<<san<<"\n"; 
	return 0;
} 
