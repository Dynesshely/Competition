#include<bits/stdc++.h>
#define ll long long
#define N 110
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
#define kkk(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;
int n,m;
char p[N][N];
int main(){//photo
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	scanf("%d%d",&m,&n);
	fff(i,1,n)
	    fff(j,1,m)
		cin>>p[i][j];
	fff(j,1,m)
		fff(qwq,1,2){
		kkk(i,n,1) cout<<p[i][j]<<p[i][j];
			cout<<"\n";
		}
	return 0;
} 
