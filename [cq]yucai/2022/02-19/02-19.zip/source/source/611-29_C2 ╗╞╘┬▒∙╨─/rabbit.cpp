#include<bits/stdc++.h>
#define ll long long
#define N
#define fff(i,a,b) for(int i=(a);i<=(b);++i)
using namespace std;
int main(){
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	cout<<"1.0\n-1.0\n1.0";
	return 0;
} 
