#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
int T,n;
bool vis[100005];
int cnt[100005];//��¼ÿ���߶��м����� 
bool cmp(int x,int y){
	return x>y;
}
void init(){
	memset(vis,false,sizeof vis);
	memset(cnt,0,sizeof cnt);
}
void build(int x){
	int len=x+1;
	for(register int i=1;i<=len;i++){
		vis[max(i-1,len-i)]=true;
		cnt[max(i-1,len-i)]--;
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	T=read();
	while(T--){
		n=read();
		int tmp,maxn=0;//maxn��ʾ����ֱ�� 
		bool flag=false;//����ֱ���޷����� 
		for(register int i=1;i<=n;i++){
			tmp=read(); maxn=max(maxn,tmp);
			if(tmp>=n) flag=true;
			else cnt[tmp]++;
		}
		if(flag) puts("NO");
		else {
			build(maxn);//��ʼ��ֱ�� 
			for(register int i=1;i<=n;i++){
				if(cnt[i]>0){
					if(vis[i-1]) vis[i]=true;
					else flag=true;
				}
				if(cnt[i]<0) flag=true;
			}
			if(flag) puts("NO");
			else puts("Yes");
		}
		init();
	}
	return 0;
}
