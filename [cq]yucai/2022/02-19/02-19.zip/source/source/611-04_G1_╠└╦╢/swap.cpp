#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
int n;
long long ans=0;
int a[100005],tota=0;
int b[100005],totb=0;
int num[100005],tot=0;
int tmp[100005];
void merge_sort(int l,int r){
	if(l==r) return;
	int mid=(l+r)>>1;
	merge_sort(l,mid);
	merge_sort(mid+1,r);
	int i=l,j=mid+1,k=l;
	while(i<=mid&&j<=r){
		if(num[i]<=num[j]){
			tmp[k]=num[i];
			i++; k++;
		}
		else {
			tmp[k]=num[j];
			ans+=(long long)mid-i+1; 
			j++; k++;
		}
	}
	while(i<=mid){
		tmp[k]=num[i];
		i++; k++;
	}
	while(j<=r){
		tmp[k]=num[j];
		j++; k++;
	}
	for(register int k=l;k<=r;k++){
		num[k]=tmp[k];
	}
}
int main(){
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		if(i&1) a[++tota]=read();
		else b[++totb]=read();
	}
	sort(a+1,a+tota+1);
	sort(b+1,b+totb+1);
	for(register int i=1;i<=tota;i++){
		num[++tot]=a[i];
		num[++tot]=b[i];//����Ϊn,����Ҫ�� 
	}
	merge_sort(1,n);
	printf("%lld",ans);
	return 0;
}
