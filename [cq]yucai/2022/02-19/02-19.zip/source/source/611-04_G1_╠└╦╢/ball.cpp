#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
inline char get_char(){
	char chh=getchar();
	while(chh!='o'&&chh!='E'&&chh!='.') chh=getchar();
	return chh;
}
const int dx[]={-1,0,1,0},dy[]={0,1,0,-1};
int n,m,ans=3;
int ex,ey;
char maze[105][105];
struct Ball{
	int x,y;
}ball[10005];
int ball_num=0;
bool in(int x,int y){
	return 1<=x&&x<=n&&1<=y&&y<=m;
}
void dfs(int sum,int score){
	//sum��ʾ������ż�����
	if(sum+score<=ans) return;
	ans=max(ans,score);
	int tmp_sum=sum,tmp_score=score;
	for(register int k=0;k<4;k++){
		vector<int> has;
		for(register int i=1;i<=n;i++){
			if(!in(ball[i].x,ball[i].y)||(ball[i].x==ex&&ball[i].y==ey)) continue;
			has.push_back(i);
			ball[i].x+=dx[k],ball[i].y+=dy[k];
			if(ball[i].x==ex&&ball[i].y==ey) tmp_score++;
			else if(!in(ball[i].x,ball[i].y)) tmp_sum--;
		}
		dfs(tmp_sum,tmp_score);
		int len=has.size();
		for(register int i=0;i<len;i++){
			ball[has[i]].x-=dx[k];
			ball[has[i]].y-=dy[k];
		}
	}
}
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	n=read(),m=read();
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			maze[i][j]=get_char();
			if(maze[i][j]=='E'){
				ex=i,ey=j;
			}
			if(maze[i][j]=='o'){
				ball[++ball_num]=(Ball){i,j};
			}
		}
	}
	if(ball_num<=1) printf("%d\n",ball_num);
	else {
		dfs(ball_num,0);
		printf("%d",ans);
	}
	return 0;
}
