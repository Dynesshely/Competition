#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
inline char get_char(){
	char chh=getchar();
	while(chh!='.'&&chh!='*') chh=getchar();
	return chh;
}
int n,m;
char maze[105][105];
int main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	m=read(),n=read();
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			maze[i][j]=get_char();
		}
	}
	for(register int j=1;j<=m;j++){
		for(register int i=n;i>=1;i--){
			cout<<maze[i][j]<<maze[i][j];
		}
		puts("");
		for(register int i=n;i>=1;i--){
			cout<<maze[i][j]<<maze[i][j];
		}
		puts("");
	}
	return 0;
}
