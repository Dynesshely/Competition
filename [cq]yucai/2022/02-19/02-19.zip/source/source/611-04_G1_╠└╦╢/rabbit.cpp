#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9'){
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
int n,m,k;
double x[100005];
int turn[100005];
double ans[100005];
void dfs(int now_cnt,int now_pos,double rate){
	//now_cnt��ʾ����һ�ֵĵڼ�����Ծ
	//now_pos��ʾ��һ����Ծ�����ӵı��
	//rate��ʾ���ﵱǰλ�õĸ���
	if(now_cnt==n+1){
		ans[now_pos]+=x[now_pos]*rate;
		return;
	}
	double pos=x[now_pos];
	x[now_pos]=x[now_pos-1]+x[now_pos-1]-x[now_pos];
	dfs(now_cnt+1,turn[now_cnt+1],rate/2);
	x[now_pos]=x[now_pos+1]+x[now_pos+1]-x[now_pos];
	dfs(now_cnt+1,turn[now_cnt+1],rate/2);
	x[now_pos]=pos;
}
int main(){
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		x[i]=(double)read();
	}
	m=read(),k=read();
	for(register int i=1;i<=m;i++){
		turn[i]=read();
	}
	while(k--){
		dfs(1,turn[1],1); 
	}
	for(register int i=1;i<=n;i++){
		printf("%.1lf\n",ans[i]);
	}
	return 0;
}
