#include <bits/stdc++.h>
using namespace std;
int n,ans;
struct s{
	int id,num;
}a[100005];
int cnp(s x,s y){return x.num>y.num;}
int main()
{
//	freopen("swap.in","r",stdin);
//	freopen("swap.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) scanf("%d",&a[i].num),a[i].id=i;
	sort(a+1,a+n+1,cnp);
	for(int i=1;i<=n;i++)
	{
		if((abs(a[i].id-i))%2==1) ++ans;
	}
	cout<<ans/2;
} 
