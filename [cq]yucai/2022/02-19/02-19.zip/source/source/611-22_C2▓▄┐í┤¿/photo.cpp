#include <bits/stdc++.h>
using namespace std;
int n,m;
char a[205][205],b[205][205],c[205][205];
int main()
{
//	freopen("photo.in","r",stdin);
//	freopen("photo.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			cin>>a[i][j];
	for(int i=1;i<=m;++i)
		for(int j=1;j<=n;++j)
		{
			b[i][j]=a[n-j+1][i];
		}
	int sum=0;
	for(int i=1;i<=2*m;++i)
		for(int j=1;j<=2*n;++j)
	{
		int x=0,y=0;
		x=i/2,y=j/2;
		if(i%2!=0) x++;
		if(j%2!=0) y++;
		c[i][j]=b[x][y];
	}
	for(int i=1;i<=2*m;++i)
	{
		for(int j=1;j<=2*n;++j)
		{
			cout<<c[i][j];
		}
		cout<<'\n';
	}
} 
