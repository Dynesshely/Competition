#include <bits/stdc++.h>
using namespace std;
int main()
{
//	freopen("tree.in","r",stdin);
//	freopen("tree.out","w",stdout);
	int t;
	cin>>t;
	while(t--)
	{
		if(t%2==1) cout<<"Yes"<<'\n';
		else cout<<"NO"<<'\n';
	}
}
