#include <bits/stdc++.h>
#define gc getchar
using namespace std;
const int N=1e5+5;
int n,ans;
struct Data {
	int v,id;
	bool operator <(const Data &A) const {
		return v<A.v;
	}
//	void Print() {printf("%d %d\n",id,v);}
}a[N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
int main() {
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	n=_();
	for(int i=1;i<=n;++i) a[i]=(Data){_(),i};
	sort(a+1,a+n+1);
//	for(int i=1;i<=n;++i) a[i].Print();
	for(int i=1;i<=n;++i) if((i+a[i].id)&1) ans++;
	printf("%d",ans/2);
}
//9:10~9:25
