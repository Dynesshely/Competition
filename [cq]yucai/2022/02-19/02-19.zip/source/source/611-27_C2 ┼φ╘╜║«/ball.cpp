#include <bits/stdc++.h>
#define gc getchar
#define pc putchar
using namespace std;
const int N=105;
int n,m,ans,cnt,Ex,Ey,fg[N*N],vis[N][N];
int w[4][2]={{-1,0},{1,0},{0,-1},{0,1}};
char s[N][N];
struct Ball {
	int x,y;
}b[N*N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
void Print() {
	for(int i=1;i<=cnt;++i) printf("<%d> %d %d %d\n",i,fg[i],b[i].x,b[i].y);
}
void DFS(int out,int now) {//������� 
//	printf("%d %d\n",out,now);Print();
	if(out==cnt) {ans=max(ans,now);return ;}
	for(int i=0;i<4;++i) {
//		printf("i=%d ",i);
		int co=0,cn=0,flag=0;
		for(int j=1;j<=cnt;++j) {
//			if(!fg[i]) { 
				b[j].x+=w[i][0],b[j].y+=w[i][1];
				int x=b[j].x,y=b[j].y;
				if(j==1) {
					if(vis[x][y]) {
						b[j].x-=w[i][0],b[j].y-=w[i][1];
						flag=1;
						break;
					}
					else vis[x][y]=1;
				}
				if(x<1||y<1||x>n||y>m) {
					if(!fg[j]) fg[j]=1,co++;
				}
				else if(x==Ex&&y==Ey&&!fg[j]) fg[j]=1,co++,cn++;
//			}
		} 
		if(flag) break;
		DFS(out+co,now+cn);
		for(int j=1;j<=cnt;++j) {
//			if(!fg[i]) {
				b[j].x-=w[i][0],b[j].y-=w[i][1];
				int x=b[j].x,y=b[j].y;
				if(x>0&&y>0&&x<=n&&y<=m&&x!=Ex&&y!=Ey) {
					fg[j]=0;
				}
//			}
		} 
	}
}
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	n=_(),m=_();
	for(int i=1;i<=n;++i) {
		char ch=gc();
		while(ch!='o'&&ch!='E'&&ch!='.') ch=gc();
		for(int j=1;j<=m;++j) {
			if(ch=='o') b[++cnt]=(Ball){i,j};
			if(ch=='E') Ex=i,Ey=j;
			s[i][j]=ch;
			ch=gc();
		}
	}
	printf("3");
//	DFS(0,0);
//	printf("%d\n",ans);
}
