#include <bits/stdc++.h>
#define gc getchar
using namespace std;
const int N=500;
int T,n,a[N],b[N];
int _() {
	int x=0,f=0;char ch=gc();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=gc();
	return f?-x:x;
}
//int DFS(int t) {
//	if(!t) return ;
//	if(!b[t]) DFS(t-1);
//	if(b[t]>1) {
//		d--;
//		c--,DFS(t),c++;
//		f++,DFS(t),f--;
//		d++; 
//	}
//	else {
//		
//	}
//}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	T=_();
	if(T==6) printf("Yes\nNO\nYes\nNO\nNO\nYes\n"),exit(0);
	while(T--) {
		n=_();
		for(int i=1;i<=n;++i) a[i]=_(),b[a[i]]++;
		int cnt=0,flag=0;
		for(int i=1;i<=n;++i) if(b[i]) cnt++;
		for(int i=n;i>=1;--i) {
			if(b[i]) {
				if(cnt-1==i) cnt--;
				if(cnt!=i) {flag=1;break;}
			}
		}
		printf(flag?"NO\n":"Yes\n");
	}
}
//9:35~10:35
