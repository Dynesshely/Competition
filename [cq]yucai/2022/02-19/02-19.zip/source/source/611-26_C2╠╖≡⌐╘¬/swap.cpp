#include<bits/stdc++.h>
using namespace std;
int n,m,ans=0;
struct jk{
	int dx,bm;
}sp[213877];
bool cmp(jk x,jk y){return x.dx<y.dx;}
int main(){
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&sp[i].dx),sp[i].bm=i;
	sort(sp+1,sp+n+1,cmp);
	for(int i=1;i<=n;i=i+2) if(sp[i].bm%2==0) ans++;
	printf("%d\n",ans);
}
