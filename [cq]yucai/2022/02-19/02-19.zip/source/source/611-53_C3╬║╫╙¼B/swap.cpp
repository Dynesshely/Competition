#include<bits/stdc++.h>
using namespace std;
int n,ans,a[100005];
int vis[100005];
struct node{
	int w,id;
}b[100005];
bool cmp(node a,node b)
{
	return a.w<b.w;
}
int main()
{
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%d",&b[i].w),b[i].id=i;
	sort(b+1,b+n+1,cmp);
	
	for(int i=1;i<=n;i++)
	a[b[i].id]=i;
	
	for(int i=1;i<=n;i++)
	if((a[i]%2) != (i%2)) ans++;
	printf("%d",ans/2);
	return 0;
}

