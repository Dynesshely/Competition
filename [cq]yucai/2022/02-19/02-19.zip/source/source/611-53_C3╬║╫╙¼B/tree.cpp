#include<bits/stdc++.h>
using namespace std;
int t,n,a[105];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	}
	printf("Yes\nNO\nYes\nNO\nNO\nYes");
	return 0;
}
