#include<bits/stdc++.h>
using namespace std;
char ch;
int h,w,a[105][105];
int dir[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
void sol(int x,int y)
{
	for(int i=1;i<=h;i++)
	for(int j=1;j<=w;j++)
	{
		if(a[i][j]==1)
		{
			int bx=i,by=j;
			int tx=bx+x,ty=ty+y;
		}
	}
}
void dfs()
{
	for(int i=0;i<4;i++)
	sol(dir[i][0],dir[i][1]);
}
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	scanf("%d%d",&h,&w);
	for(int i=1;i<=h;i++)
	for(int j=1;j<=w;j++)
	{
		cin>>ch;
		if(ch=='o') a[i][j]=1;
		if(ch=='E') a[i][j]=2;
	}
	dfs();
	cout<<3;
	return 0;
}
