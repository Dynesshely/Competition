#include<bits/stdc++.h>
using namespace std;
string s[505];
int main(){
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	int n,m;
	scanf("%d%d",&m,&n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>s[i][j];
		}
	}
	for(int i=1;i<=m;i++){
		for(int j=1;j<=2;j++){
			for(int k=n;k>=1;k--){
				cout<<s[k][i]<<s[k][i];
			}
			cout<<"\n";
		}
	}
} 
