#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0; char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[52]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	for (int i=top;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e5+10;
van n,m,k,op[MaxN];double x[MaxN];
int main() {
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	read(n); for (int i=1;i<=n;i++) read(x[i]);
	read(m),read(k); for (int i=1;i<=m;i++) read(op[i]);
	for (int i=1;i<=k;i++) {
		for (int j=1;j<=m;j++) {
			van e=op[(i-1)%m+1];
			x[e]=x[e-1]+x[e+1]-x[e];
		} 
	} for (int k=1;k<=n;k++) cout<<fixed<<setprecision(1)<<x[k]<<endl;
	return 0;
}

