#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0; char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch))
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[52]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	for (int i=top;i;i--) putchar(st[i]+'0');
}
const van MaxN=1e3+10;
van n,m;
char x[MaxN][MaxN],y[MaxN][MaxN];
int main() {
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	read(n),read(m);
	for (int i=1;i<=m;i++) for (int j=1;j<=n;j++) cin>>x[j][i];
//	for (int i=1;i<=n;i++){for (int j=1;j<=m;j++) cout<<x[i][j];cout<<endl;}
	for (int i=1;i<=n;i++) for (int j=1;j<=m;j++) 
		y[i*2][j*2]=y[i*2-1][j*2]=y[i*2][j*2-1]=y[i*2-1][j*2-1]=x[i][j];
	for (int i=1;i<=n*2;i++) {
		for (int j=1;j<=m*2;j++) {
			cout<<y[i][j];
		} cout<<endl;
	}
	return 0;
}

