#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0; char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) 
		b*=10,b+=ch-'0',ch=getchar();
	x=f*b; return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[52]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	for (int i=top;i;i--) putchar(st[i]+'0');
}
int main() {
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
	
	return 0;
} 
