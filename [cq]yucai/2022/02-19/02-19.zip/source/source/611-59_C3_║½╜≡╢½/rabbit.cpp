#include<bits/stdc++.h>
#define int long long
#define N 400005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int ans[N],sum,x[N],n,a[N],m,K;
inline void baoli(int k){
	if(k>m){
		++sum;
		for(int i=1;i<=n;++i)
			ans[i]+=x[i]-1e9;
		return;
	}
	int p=x[a[k]];
	if(a[k]<n){
		x[a[k]]=x[a[k]+1]*2-p;
		baoli(k+1);
	}
	if(a[k]){
		x[a[k]]=x[a[k]-1]*2-p;
		baoli(k+1);
	}
	x[a[k]]=p;
}
signed main(){
	freopen("rabbit.in","r",stdin);
	freopen("rabbit.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
		x[i]=read()+1e9;
	m=read();K=read();
	for(int i=1;i<=m;++i)
		a[i]=read();
	if(n<=15&&m<=15&&K==1)
		baoli(1);
	for(int i=1;i<=n;++i)
		printf("%.1lf\n",(double)ans[i]/sum);
	return 0;
}
