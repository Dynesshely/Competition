#include<bits/stdc++.h>
#define int long long
#define N 400005
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
inline void write(int x){
	if(!x)
		putchar('0');
	if(x<0){
		x=-x;
		putchar('-');
	}
	int cnt=0;char f[40];
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,a[N],b[N],A,B,res[N],ans;
signed main(){
	freopen("swap.in","r",stdin);
	freopen("swap.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
		if(i%2)
			b[++B]=read();
		else
			a[++A]=read();
	sort(a+1,a+1+A);
	sort(b+1,b+1+B);
	for(int i=1;i<=n;++i)
		if(i%2)
			res[i]=b[i/2+1];
		else
			res[i]=a[i/2];
	for(int i=1;i<n;++i)
		if(res[i]>res[i+1]){
			swap(res[i],res[i+1]);
			++ans;
		}
	write(ans);
	return 0;
}
