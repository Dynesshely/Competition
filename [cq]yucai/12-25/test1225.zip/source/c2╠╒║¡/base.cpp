#include<bits/stdc++.h>
using namespace std;
long long n,js,num,w,l,s[10005];
void find(int a){
	if(a==k){
		int ans=0;
		for(int i=0;i<k;i++) ans+=sp[i]*s[i];
		if(ans==n){
			for(int i=k-1;i>=0;i--) printf("%d",s[i]);
			bb=1;
		}
		return ;
	}
	s[a]=1;
	find(a+1);
	if(bb==1) return ;
	s[a]=0;find(a+1);
}
int main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	int n;
	scanf("%d",&n);
	s[0]=1;
	int num,p;
	for(int i=1;i<=10;i++) s[i]=s[i-1]*(-2);
	if(n==0){
		cout<<0;
		return 0;
	}
	if(n>0){
		num=1;p=1;
	    js=0;
		while(js<n){
			js+=num;
			num*=4;
			p+=2;
		}
		p-=2;
	} 
	if(n<0){
		num=2;p=2;
		js=0;
		while(js<abs(n)){
			js+=num;
			num*=4;
			p+=2;
		}
		p-=2;
	}
	for(int i=1;i<=n;i++) cout<<s[i];
}
