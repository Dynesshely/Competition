#include<bits/stdc++.h>
using namespace std;
int a[40][40],dir[8][2]={{-2,-1},{-2,1},{2,1},{2,-1},{-1,2},{1,2},{1,-2},{-1,2}},n,m;
int ans=1e7,js[1000];
bool b[35][35];
void dfs(int x,int y,int sum){
	if(a[x][y]==3){
		ans=min(ans,sum);
		return ;
	}
	for(int i=0;i<=7;i++){
		int X=x+dir[i][0];
		int Y=y+dir[i][1];
		if(a[X][Y]==2) continue ;
		if(X<1||Y<1||X>n||Y>m||b[X][Y]==1) continue;
		int j=sum;		
		if(a[X][Y]==0){
		    b[X][Y]=1;
			dfs(X,Y,++j);
		} 
		if(a[X][Y]==1){
			b[X][Y]=1;
			dfs(X,Y,sum);
		} 
		if(a[X][Y]==4){
			for(int i=1;i<=30;i++){
				for(int j=1;j<=30;j++) b[i][i]=0;
			}
		    ans=min(ans,sum);
		    js[sum]++;
		    return ;
	    }
	}
	return ;
}
int main(){
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	int x,y;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
			if(a[i][j]==3) x=i,y=j;
		}
	}
	cout<<-1;
	return 0;
	dfs(x,y,0);
	printf("%d\n%d",ans,js[ans]);
} 
/*
4 5
1 0 0 0 0
3 0 0 0 0
0 0 2 0 0
0 0 0 4 0
 */
