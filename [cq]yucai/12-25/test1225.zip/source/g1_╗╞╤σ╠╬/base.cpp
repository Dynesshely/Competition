#include<bits/stdc++.h>
#define For(i,a,b) for(int i=(a),i##END=(b);i<=i##END;i++)
#define Rof(i,b,a) for(int i=(b),i##END=(a);i>=i##END;i--)
#define go(u) for(int i=head[u];i;i=nxt[i])
using namespace std;
inline int read(){
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    return x*f;
}
const int N=65;
int a[N],l,s;
signed main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	int n=read();
	if(n==0)return puts("0"),0;
	int f=n<0;n=f?-n:n;
	while(n)a[l++]=n&1,n>>=1;
	For(i,0,60){
		if(a[i]>1)a[i+1]+=(a[i]>>1),a[i]&=1;
		if(a[i]&&(i&1)!=f)a[i+1]++;
	}Rof(i,60,0)if(a[i]){s=i;break;}
	Rof(i,s,0)printf("%d",a[i]);
	return 0;
}
