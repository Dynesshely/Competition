#include<bits/stdc++.h>
#define For(i,a,b) for(int i=(a),i##END=(b);i<=i##END;i++)
#define Rof(i,b,a) for(int i=(b),i##END=(a);i>=i##END;i--)
#define go(u) for(int i=head[u];i;i=nxt[i])
using namespace std;
inline int read(){
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    return x*f;
}
const int D=5;
int p,b1,b2,r;
int res[20][20];//[1,9]
int getin(int fr,int x){
	if(b1<fr&&fr<b2){
		if(x<=b1)x+=(b1-x)/(b2-b1+1)*(b2-b1+1);
		if(x>=b2)x-=(x-b2)/(b1-b2+1)*(b1-b2+1);
		if(x<=b1)x=-x+2*b1+1;
		if(x>=b2)x=-x+2*b2-1;
	}else if(fr<b1){
		if(x>=b1)x=-x+2*b1-1;
	}else if(fr>b2){
		if(x<=b2)x=-x+2*b2+1;
	}
	return x;
}
signed main(){
	freopen("waves.in","r",stdin);
	freopen("waves.out","w",stdout);
	p=read(),b1=read()+D,b2=read()+D,r=read();
	if(b1>b2)swap(b1,b2);
	For(i,1,p){
		int x=read()+D,y=read()+D,t=read();
		For(i,1,9){//y->i
			int l=r-t-abs(y-i);
			if(l<0)continue;
			//(x+l,i),(x-l,i)
			int a=x-l,b=x+l;
			a=getin(x,a),b=getin(x,b);
			if(1<=a&&a<=9)res[a][i]++;
			if(a!=b&&1<=b&&b<=9)res[b][i]++;
			l-=2;if(l<0)continue;
			a=x-l,b=x+l;
			a=getin(x,a),b=getin(x,b);
			if(1<=a&&a<=9)res[a][i]--;
			if(a!=b&&1<=b&&b<=9)res[b][i]--;
		}
	}
	Rof(j,9,1){
		For(i,1,9){
			if(i==b1||i==b2)putchar('X');
			else if(!res[i][j])putchar('-');
			else if(res[i][j]>0)putchar('*');
			else putchar('o');
		}puts("");
	}
	return 0;
}
