#include<bits/stdc++.h>
#define For(i,a,b) for(int i=(a),i##END=(b);i<=i##END;i++)
#define Rof(i,b,a) for(int i=(b),i##END=(a);i>=i##END;i--)
#define go(u) for(int i=head[u];i;i=nxt[i])
using namespace std;
inline int read(){
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    return x*f;
}
const int N=510;
int n,a[N][N];
#define id(i,j) (((i)-1)*n+(j))
struct node{
	int u,v,w;
	bool operator < (const node &x) const {
		return w<x.w;
	}
}b[N*N];int l;
int fa[N*N],sz[N*N],lim,f;
int get(int x){return fa[x]==x?x:fa[x]=get(fa[x]);}
void merge(int x,int y){
	x=get(x),y=get(y);
	if(x==y)return;
	if(sz[x]>sz[y])swap(x,y);
	fa[x]=y,sz[y]+=sz[x];
	if(sz[y]>=lim)f=1;
}
signed main(){
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	n=read(),lim=n*n/2;For(i,1,n)For(j,1,n){
		a[i][j]=read();
		if(i-1)b[++l]=(node){id(i,j),id(i-1,j),abs(a[i][j]-a[i-1][j])};
		if(j-1)b[++l]=(node){id(i,j),id(i,j-1),abs(a[i][j]-a[i][j-1])};
	}sort(b+1,b+1+l);
	For(i,1,n*n)fa[i]=i,sz[i]=1;
	For(i,1,l){
		int u=b[i].u,v=b[i].v,w=b[i].w;
		merge(b[i].u,b[i].v);
		if(f)return printf("%d\n",w),0;
	}
	return 0;
}
