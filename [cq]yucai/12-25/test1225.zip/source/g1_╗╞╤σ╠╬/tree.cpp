#include<bits/stdc++.h>
#define For(i,a,b) for(int i=(a),i##END=(b);i<=i##END;i++)
#define Rof(i,b,a) for(int i=(b),i##END=(a);i>=i##END;i--)
#define go(u) for(int i=head[u];i;i=nxt[i])
#define ll long long
using namespace std;
inline int read(){
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    return x*f;
}
const int N=1e5+10;
int head[N],to[N<<1],nxt[N<<1],cnt;
void add(int u,int v){to[++cnt]=v,nxt[cnt]=head[u],head[u]=cnt;}
int n,m;char op[5];
int sz[N],son[N],dfn[N],top[N],fa[N],dep[N],idx;
void dfs1(int u,int f){
	sz[u]=1,fa[u]=f,dep[u]=dep[f]+1;go(u){
		int v=to[i];if(v==f)continue;dfs1(v,u),sz[u]+=sz[v];
		if(sz[v]>sz[son[u]])son[u]=v;
	}
}
void dfs2(int u,int t){
	top[u]=t,dfn[u]=++idx;if(son[u])dfs2(son[u],t);
	go(u){int v=to[i];if(v==fa[u]||v==son[u])continue;dfs2(v,v);}
}
struct Tree{
	#define ls (k<<1)
	#define rs (k<<1|1)
	int q[N];
	struct node{ll s;int t;}t[N<<2];
	void f(int k,int l,int r,int v){t[k].s+=1ll*(r-l+1)*v,t[k].t+=v;}
	void up(int k){t[k].s=t[ls].s+t[rs].s;}
	void down(int k,int l,int r){int m=l+r>>1;f(ls,l,m,t[k].t),f(rs,m+1,r,t[k].t),t[k].t=0;}
	void add(int k,int l,int r,int x,int y){
		if(x>y)return;
		if(x<=l&&r<=y)return f(k,l,r,1);
		int m=l+r>>1;down(k,l,r);
		if(x<=m)add(ls,l,m,x,y);
		if(y>m)add(rs,m+1,r,x,y);
		up(k);
	}
	ll ask(int k,int l,int r,int x,int y){
		if(x>y)return 0;
		if(x<=l&&r<=y)return t[k].s;
		int m=l+r>>1;down(k,l,r);
		ll ret=(x<=m?ask(ls,l,m,x,y):0)+(y>m?ask(rs,m+1,r,x,y):0);
		up(k);return ret;
	}
}T;
void mdf(int u,int v){
	while(top[u]!=top[v]){
		if(dep[top[u]]<dep[top[v]])swap(u,v);
		T.add(1,1,n,dfn[top[u]],dfn[u]);
		u=fa[top[u]];
	}if(dfn[u]>dfn[v])swap(u,v);
	T.add(1,1,n,dfn[u]+1,dfn[v]);
}
ll qry(int u,int v,ll s=0){
	while(top[u]!=top[v]){
		if(dep[top[u]]<dep[top[v]])swap(u,v);
		s+=T.ask(1,1,n,dfn[top[u]],dfn[u]);
		u=fa[top[u]];
	}if(dfn[u]>dfn[v])swap(u,v);
	s+=T.ask(1,1,n,dfn[u]+1,dfn[v]);
	return s;
}
signed main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read(),m=read();For(i,2,n){int u=read(),v=read();add(u,v),add(v,u);}
	dfs1(1,1),dfs2(1,1);while(m--){
		scanf("%s",op);int u=read(),v=read();
		if(op[0]=='P')mdf(u,v);
		else printf("%lld\n",qry(u,v));
	}
	return 0;
}
