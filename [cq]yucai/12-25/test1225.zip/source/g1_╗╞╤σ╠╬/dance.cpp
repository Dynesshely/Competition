#include<bits/stdc++.h>
#define For(i,a,b) for(int i=(a),i##END=(b);i<=i##END;i++)
#define Rof(i,b,a) for(int i=(b),i##END=(a);i>=i##END;i--)
#define go(u) for(int i=head[u];i;i=nxt[i])
#define int long long
using namespace std;
inline int read(){
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
    return x*f;
}
bool st;
const int N=32;
int f[N][N],g[N][N],a[N][N];
//f:��С����,g:������ 
int n,m;
int dir[8][2]={1,2,-1,2,1,-2,-1,-2,2,1,-2,1,2,-1,-2,-1};
#define ok(x,y) (1<=x&&x<=n&&1<=y&&y<=m&&a[x][y]!=2)
struct node{int x,y,t;};
deque<node> q;
int sx,sy,ex,ey;
void bfs(){
	memset(f,0x3f,sizeof f);
	f[sx][sy]=0,g[sx][sy]=1,q.push_front((node){sx,sy,0});
	while(!q.empty()){
		node d=q.front();q.pop_front();
		int x=d.x,y=d.y,t=d.t;
		if(x==ex&&y==ey)continue;
		For(i,0,7){
			int dx=x+dir[i][0],dy=y+dir[i][1];
			if(!ok(dx,dy))continue;
			int nt=t+(a[dx][dy]==0);
			if(nt<=f[dx][dy]){
				if(nt<f[dx][dy]){
					if(a[dx][dy]==0)q.push_back((node){dx,dy,nt});
					else q.push_front((node){dx,dy,nt});
					f[dx][dy]=nt;
				}
				g[dx][dy]+=g[x][y];
			}
		}
	}
}
bool ed;
signed main(){
//	printf("%.2lf MB\n",abs(&ed-&st)/1024.0/1024.0);
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	n=read(),m=read();For(i,1,n)For(j,1,m){
		a[i][j]=read();
		if(a[i][j]==3)sx=i,sy=j;
		if(a[i][j]==4)ex=i,ey=j;
	}bfs();
	if(f[ex][ey]<=n*n)printf("%lld %lld\n",f[ex][ey],g[ex][ey]);
	else puts("-1");
	return 0;
}
