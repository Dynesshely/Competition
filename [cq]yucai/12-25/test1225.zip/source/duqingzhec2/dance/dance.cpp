#include<bits/stdc++.h>
using namespace std;
long long a1,a2;
int N,M,sx,sy,w[35][35],f[35][35],dis[8][2]={{1,2},{-1,2},{1,-2},{-1,-2},{2,-1},{2,1},{-2,-1},{-2,1}};
bool Check(int i,int j){return i>=1&&j>=1&&i<=N&&j<=M&&w[i][j]!=2&&f[i][j]==0;}
void dfs(int x,int y,long long cnt){
	if(cnt>a1)return ;
	if(w[x][y]==4){
		if(cnt<a1)a1=cnt,a2=0;
		if(cnt==a1)a2++;
		return ;
	}
	f[x][y]=1;
	for(int i=0;i<8;++i){
		int X=x+dis[i][0],Y=y+dis[i][1];
		if(Check(X,Y)==1)dfs(X,Y,cnt+(w[X][Y]==0));
	} 
	f[x][y]=0;
}
int main(){
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d%d",&N,&M),a1=1e7;
	for(int i=1;i<=N;++i)
		for(int j=1;j<=M;++j){
			scanf("%d",&w[i][j]);
			if(w[i][j]==3)sx=i,sy=j;
		}	
	dfs(sx,sy,0);
	if(a2>0)printf("%lld\n%lld",a1,a2);
	else printf("-1\n");
}
