#include<bits/stdc++.h>
using namespace std;
long long ask;
long long up,down,now,I=1,len;
int num[200];
int main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%lld",&ask);
	if(ask==0){printf("0");return 0;}
	while(1){
		if(I>0)up+=I;
		else down+=I;
		if((ask<=up&&ask>0)||(ask>=down&&ask<0))break; 
		I=I*(-2),len++;
	}
	now=I;
	for(int i=1;i<len;++i){
		if(I>0)up-=I;
		else down-=I;
		I=-I/2;
		if(I>0)up-=I;
		else down-=I;
		if(ask<=(now+I+up)&&ask>=(now+I+down))num[i]=1,now=now+I;
		else num[i]=0;
		if(I>0)up+=I;
		else down+=I;
	}
	cout<<1;
	for(int i=1;i<len;++i)printf("%d",num[i]);
}
