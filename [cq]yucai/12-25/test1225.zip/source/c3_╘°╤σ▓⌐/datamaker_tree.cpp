#include <bits/stdc++.h>
using namespace std;
int n=100000,m=100000;
signed main() {
	freopen("tree.in","w",stdout);
	srand(time(0));
	cout<<n<<" "<<m<<endl;
	for(int i=2;i<=n;++i) {
		cout<<i<<" "<<rand()%(i-1)+1<<endl;
	}
	for(int i=1;i<=m;++i) {
		int tmp=rand()%2;
		if(tmp) putchar('P');
		else putchar('Q');
		cout<<" "<<rand()%n+1<<" "<<rand()%m+1<<endl;
	}
	return 0;
}
/*
*/

