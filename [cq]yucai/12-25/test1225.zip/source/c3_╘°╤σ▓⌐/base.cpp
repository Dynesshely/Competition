#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
int n,a[105],st;
signed main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	n=read();
	if(n>0) {
		while(n) {
			int b=1,t=0;
			while((b<<1)<=n) b<<=1,++t;
			n-=b;
			a[t]=1;
		}
		for(int i=1;i<=100;++i) {
			if(!a[i]) continue;
			if(i&1) {
				a[i+1]+=(a[i]>>1);
				a[i]&=1;
				if(a[i]) ++a[i+1];
			}
			else a[i+1]+=(a[i]>>1),a[i]&=1;
		}
		for(int i=100;i>=0;--i)
			if(a[i]) {
				st=i;
				break;
			}
		for(int i=st;i>=0;--i) printf("%lld",a[i]);
	}
	else if(n<0) {
		n=-n;
		while(n) {
			int b=1,t=0;
			while((b<<1)<=n) b<<=1,++t;
			n-=b;
			a[t]=1;
		}
		for(int i=0;i<=100;++i) {
			if(!a[i]) continue;
			if(!(i&1)) {
				a[i+1]+=(a[i]>>1);
				a[i]&=1;
				if(a[i]) ++a[i+1];
			}
			else a[i+1]+=(a[i]>>1),a[i]&=1;
		}
		for(int i=100;i>=0;--i)
			if(a[i]) {
				st=i;
				break;
			}
		for(int i=st;i>=0;--i) printf("%lld",a[i]);
	}
	else cout<<0;
	return 0;
}
/*
-13

110111
*/
