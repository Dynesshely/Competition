#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,a[105],st;
signed main() {
	for(int _=1999000000;_<=2000000000;++_) {
		n=_;
		memset(a,0,sizeof a);
		while(n) {
			int b=1,t=0;
			while((b<<1)<=n) b<<=1,++t;
			n-=b;
			a[t]=1;
		}
		for(int i=1;i<=100;++i) {
			if(!a[i]) continue;
			if(i&1) {
				a[i+1]+=(a[i]>>1);
				a[i]&=1;
				if(a[i]) ++a[i+1];
			}
			else a[i+1]+=(a[i]>>1),a[i]&=1;
		}
		int tmp=1,sum=0;
		for(int i=0;i<=100;++i) {
			if(a[i]>1||a[i]<0) cout<<"ErrorA "<<_<<endl;
			if(a[i]) sum+=(i&1?-tmp:tmp);
			tmp<<=1;
		}
		if(sum!=_) cout<<"ErrorB "<<_<<endl;
	}
	for(int _=-1999000000;_>=-2000000000;--_) {
		n=_;
		memset(a,0,sizeof a);
		n=-n;
		while(n) {
			int b=1,t=0;
			while((b<<1)<=n) b<<=1,++t;
			n-=b;
			a[t]=1;
		}
		for(int i=0;i<=100;++i) {
			if(!a[i]) continue;
//			cout<<i<<" "<<a[i]<<endl;
			if(!(i&1)) {
				a[i+1]+=(a[i]>>1);
				a[i]&=1;
				if(a[i]) ++a[i+1];
			}
			else a[i+1]+=(a[i]>>1),a[i]&=1;
		}
		int tmp=1,sum=0;
		for(int i=0;i<=100;++i) {
			if(a[i]>1||a[i]<0) cout<<"ErrorA "<<_<<endl;
			if(a[i]) sum+=(i&1?-tmp:tmp);
			tmp<<=1;
		}
		if(sum!=_) cout<<"ErrorB "<<_<<endl;
	}
	puts("Finished");
	return 0;
}
/*
*/
