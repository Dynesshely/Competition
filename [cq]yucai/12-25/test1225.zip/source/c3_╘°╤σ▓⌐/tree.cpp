#include <bits/stdc++.h>
#define ls (x<<1)
#define rs (x<<1|1)
#define mid ((l+r)>>1)
using namespace std;
int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void write(int x) {
	if(x>=10) write(x/10);
	putchar(x%10+'0');
}
const int N=100005;
int n,m;
int hed[N],nxt[N<<1],to[N<<1],cnt;
void add(int x,int y) {
	to[++cnt]=y,nxt[cnt]=hed[x],hed[x]=cnt;
}
int fa[N],son[N],id[N],siz[N],dep[N],top[N],tot;
void dfs1(int x,int fath) {
	siz[x]=1,fa[x]=fath,dep[x]=dep[fath]+1;
	int ma=0,pos=0;
	for(int i=hed[x],y;i;i=nxt[i]) {
		y=to[i];
		if(y==fath) continue;
		dfs1(y,x);
		siz[x]+=siz[y];
		if(siz[y]>ma) ma=siz[y],pos=y;
	}
	son[x]=pos;
}
void dfs2(int x,int topf) {
	id[x]=++tot,top[x]=topf;
	if(son[x]) dfs2(son[x],topf);
	for(int i=hed[x],y;i;i=nxt[i]) {
		y=to[i];
		if(y==son[x]||y==fa[x]) continue;
		dfs2(y,y);
	}
}
int tree[N<<2],tag[N<<2];
void Update(int x) {
	tree[x]=tree[ls]+tree[rs];
}
void PushUp(int x,int l,int r,int v) {
	tree[x]+=(r-l+1)*v;
	tag[x]+=v;
}
void PushDown(int x,int l,int r) {
	if(!tag[x]) return;
	PushUp(ls,l,mid,tag[x]);
	PushUp(rs,mid+1,r,tag[x]);
	tag[x]=0;
}
void Modify(int x,int l,int r,int L,int R) {
	if(L>R||l>r) return;
	if(l==L&&r==R) {
		PushUp(x,l,r,1);
		return;
	}
	PushDown(x,l,r);
	if(R<=mid) Modify(ls,l,mid,L,R);
	else if(L>mid) Modify(rs,mid+1,r,L,R);
	else Modify(ls,l,mid,L,mid),Modify(rs,mid+1,r,mid+1,R);
	Update(x);
}
int Query(int x,int l,int r,int L,int R) {
	if(L>R||l>r) return 0;
	if(l==L&&r==R) return tree[x];
	PushDown(x,l,r);
	if(R<=mid) return Query(ls,l,mid,L,R);
	else if(L>mid) return Query(rs,mid+1,r,L,R);
	return Query(ls,l,mid,L,mid)+Query(rs,mid+1,r,mid+1,R);
}
void Change(int x,int y) {
	while(top[x]!=top[y]) {
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		Modify(1,1,n,id[top[x]],id[x]);
		x=fa[top[x]];
	}
	if(x!=y) Modify(1,1,n,min(id[x],id[y])+1,max(id[x],id[y]));
}
int Ask(int x,int y) {
	int sum=0;
	while(top[x]!=top[y]) {
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		sum+=Query(1,1,n,id[top[x]],id[x]);
		x=fa[top[x]];
	}
	if(x!=y) sum+=Query(1,1,n,min(id[x],id[y])+1,max(id[x],id[y]));
	return sum;
}
signed main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read(),m=read();
	for(int i=1,x,y;i<n;++i) {
		x=read(),y=read();
		add(x,y),add(y,x);
	}
	dfs1(1,0);
	dfs2(1,1);
	while(m--) {
		char ch;
		ch=getchar();
		while(ch!='P'&&ch!='Q') ch=getchar();
//		cin>>ch;
		int l=read(),r=read();
		if(ch=='P') Change(l,r);
		else write(Ask(l,r)),putchar('\n');
	}
	return 0;
}
/*
4 6
1 4
2 4
3 4
P 2 3
P 1 3
Q 3 4
P 1 4
Q 2 4
Q 1 4

2
1
2

10 7
1 2
1 3
2 4
2 5
5 6
5 7
7 10
3 8
8 9
P 6 9
P 4 9
P 4 10
Q 6 5
Q 6 8
Q 10 3
Q 4 3

1
9
8
6
*/

