#include <bits/stdc++.h>
using namespace std;
typedef pair<int,int> pii;
int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=505;
int n,hn,a[N][N],ans;
int dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
bool vis[N][N];
bool in(int x,int y) {
	return 1<=x&&x<=n&&1<=y&&y<=n;
}
bool bfs(int sx,int sy,int d) {
	queue<pii> qu;
	qu.push(pii(sx,sy));
	int tot=0;
	while(!qu.empty()) {
		int x=qu.front().first,y=qu.front().second;
		qu.pop();
		if(vis[x][y]) continue;
		vis[x][y]=1;
		++tot;
		for(int i=0,nx,ny;i<4;++i) {
			nx=x+dir[i][0],ny=y+dir[i][1];
			if(!in(nx,ny)||vis[nx][ny]||abs(a[nx][ny]-a[x][y])>d) continue;
			qu.push(pii(nx,ny));
		}
	}
	return tot>=hn;
}
bool check(int d) {
	memset(vis,0,sizeof vis);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			if(!vis[i][j]) if(bfs(i,j,d)) return 1;
	return 0;
}
signed main() {
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	n=read(),hn=(n*n+1)/2;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			a[i][j]=read();
	int l=0,r=2000000,mid=(l+r)/2;
	while(l<=r) {
		mid=(l+r)/2;
		if(check(mid)) r=mid-1,ans=mid;
		else l=mid+1;
	}
	printf("%d",ans);
	return 0;
}
/*
5 
0 0 0 3 3
0 0 0 0 3
0 9 9 3 3
9 9 9 3 3
9 9 9 9 3

3
*/

