#include<bits/stdc++.h>
using namespace std;
const int N=35;
int n,m,ans1=1e9,ans2;
int a[N][N],biao[N][N],c[8][2]={{1,2},{1,-2},{2,1},{-2,1},{-1,-2},{-1,2},{-2,-1},{2,-1}};
bool check(int x,int y) {return 1<=x&&x<=n&&1<=y&&y<=m&&a[x][y]!=2;}
void dfs(int x,int y,int tot)
{
	biao[x][y]=tot;
	if(tot>ans1) return;
	if(a[x][y]==4)
	{
		if(ans1>tot) ans2=1,ans1=tot;
		else if(ans1==tot) ans2++;
		return;
	}
	for(int i=0;i<8;i++)
	{
		int tx=x+c[i][0],ty=y+c[i][1];
		if(check(tx,ty)&&biao[tx][ty]>=biao[x][y]+(a[tx][ty]==0)) dfs(tx,ty,tot+(a[tx][ty]==0));
	}
	return;
}
int main()
{
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(biao,0x3f,sizeof(biao));
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) scanf("%d",a[i]+j);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) if(a[i][j]==3) {dfs(i,j,0);break;}
	if(ans1==1e9) printf("-1"),exit(0);
	else printf("%d\n%d",ans1,ans2);
	fclose(stdin);fclose(stdout);
	return 0;
}
