#include<bits/stdc++.h>
using namespace std;
const int N=510,M=N*N;
int n,t,ans=1e9,num[M],dp[M<<2];
int a[N][N],col[N][N],c[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
int first[M],to[M<<2],nxt[M<<2],lth[M<<2],cnt;
bool biao[M];
queue<int>q;
inline void inc(int x,int y,int l) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt,lth[cnt]=l;}
bool CK(int x,int y) {return 1<=x&&x<=n&&1<=y&&y<=n;}
void dfs(int x,int y)
{
	num[col[x][y]]++;
	for(int i=0;i<4;i++)
	{
		int tx=x+c[i][0],ty=y+c[i][1];
		if(CK(tx,ty)) if(!col[tx][ty]&&a[tx][ty]==a[x][y]) col[tx][ty]=col[x][y],dfs(tx,ty);
		else if(col[tx][ty]&&a[tx][ty]!=a[x][y])
		{
			int x1=col[tx][ty],x2=col[x][y],k=abs(a[x][y]-a[tx][ty]);
			inc(x1,x2,k),inc(x2,x1,k);
		}
	}
	return;
}
void check(int lim,int y)
{
	memset(biao,false,sizeof(biao));
	memset(dp,0,sizeof(dp));
	q.push(y);
	biao[y]=true;
	for(int j=lim;~j;j--) dp[j]=num[y];
	while(!q.empty())
	{
		int x=q.front();
		q.pop();
		for(int i=first[x],v;i;i=nxt[i]) if(!biao[v=to[i]])
		{
			for(int j=lim;j>=lth[i];j--) dp[j]=max(dp[j],dp[j-lth[i]]+num[v]);
			q.push(v);
			biao[v]=true;
		}
	}
	for(int i=0;i<=lim;i++) if(dp[i]>=t)
	{
		ans=min(ans,i);
		break;
	}
	return;
}
int main()
{
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	scanf("%d",&n);
	int lim=0;
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) scanf("%d",a[i]+j),lim=max(lim,a[i][j]);
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) if(!col[i][j])
	{
		col[i][j]=++t;
		dfs(i,j);
	}
	int k=t;
	t=(n*n+1)>>1;
	for(int i=1;i<=k;i++) check(lim,i);
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
