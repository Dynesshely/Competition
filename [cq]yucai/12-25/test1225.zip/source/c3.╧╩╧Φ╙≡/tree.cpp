#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10,M=N<<1;
int n,m;
int first[N],to[M],nxt[M],lth[M],cnt;
bool check;
inline void inc(int x,int y) {nxt[++cnt]=first[x],to[cnt]=y,first[x]=cnt;}
void dfs(int x,int from,int To)
{
	if(x==To) return (void)(check=true);
	for(int i=first[x],v;i;i=nxt[i]) if((v=to[i])!=from)
	{
		dfs(v,x,To);
		if(check) return (void)(++lth[i]);
	}
	return;
}
int Dfs(int x,int from,int To)
{
	if(x==To) return -1;
	int tot;
	for(int i=first[x],v;i;i=nxt[i]) if((v=to[i])!=from)
	{
		tot=Dfs(v,x,To);
		if(tot) return tot+lth[i];
	}
	return 0;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,u,v;i<n;i++)
	{
		scanf("%d%d",&u,&v);
		inc(u,v),inc(v,u);
	}
	while(m--)
	{
		char k;
		int x,y;
		scanf("\n%c %d%d",&k,&x,&y);
		if(k=='P') dfs(x,x,y),dfs(y,y,x),check=false;
		else printf("%d\n",Dfs(x,x,y)+1);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
