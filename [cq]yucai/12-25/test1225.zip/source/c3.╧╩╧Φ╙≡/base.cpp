#include<bits/stdc++.h>
using namespace std;
const int N=510;
long long n,t,tot,base;
char ans[N];
bool can;
int main()
{
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%lld",&n);
	if(n==0) printf("0");
	else if(n>0)
	{
		long long now=0;
		while(tot!=n)
		{
			base++;
			long long k=1<<base-1,num=0,answer=(n-now-1)/k&1^1;
			if(answer) tot+=pow(-2,base-1);
			ans[++t]=answer+'0';
			if(base&1) now+=1<<base-1;
		}
		for(int i=t;i;i--) printf("%c",ans[i]);
	}
	else
	{
		long long now=0;
		n=-n;
		while(tot!=-n)
		{
			base++;
			long long k=1<<base-1,num=0,answer=(n-now-1)/k&1^1;
			if(answer) tot+=pow(-2,base-1);
			ans[++t]=answer+'0';
			if(!(base&1)) now+=1<<base-1;
		}
		for(int i=t;i;i--) printf("%c",ans[i]);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
