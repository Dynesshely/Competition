#include <bits/stdc++.h>
using namespace std;
int n, m, a[35][35], sum[1005], sx, sy, fx, fy, ans[35][35], xf[8][2]={
{2,1},{2,-1},{-2,1},{-2,-1},{1,2},{1,-2},{-1,2},{-1,-2}
};
struct qwq {
	int s, x, y;
	bool operator<(const qwq &A) const {return A.s < s; };
};
priority_queue <qwq> q;
int main() {
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j) {
			scanf("%d",&a[i][j]);
			if(a[i][j] == 3)
				sx=i, sy=j;
			else {
				ans[i][j]=1000000000;
				if(a[i][j] == 4)
					fx=i, fy=j;
			} 
		}
	q.push((qwq) {0, sx, sy});
	while(!q.empty()) {
		qwq it=q.top();
		q.pop();
		if(it.s > ans[it.x][it.y] || it.s > ans[fx][fy]) continue; 
		for(int i = 0; i <= 7; ++i){
			int X=it.x+xf[i][0], Y=it.y+xf[i][1], c=0;
			if(a[X][Y] == 2) continue;
			if(a[X][Y] == 0) c=1;
			if(it.s+c <= ans[X][Y])
				ans[X][Y]=it.s+c, q.push((qwq) {ans[X][Y], X, Y});
		}
	}
	printf("%d\n%d",ans[fx][fy],ans[fx][fy]+1);
	return 0;
}
