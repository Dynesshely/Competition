#include <bits/stdc++.h>
using namespace std;
int n, m, a[100005], b[100005], dep[100005], lca, pd[100005], fa[100005];
long long s[100005], ans;
char q;
vector <int> road[100005];
void dfs(int x, int fa) {
	dep[x]=dep[fa]+1;
	for(int i = 0; i < (int) road[x].size(); ++i) 
		if(road[x][i] != fa) dfs(road[x][i],x);
}
void add(int x, int w) {
	if(x == 0) return ;
	if(pd[x] == m && w != -1) {
		lca=x;
		return ;
	}
	s[x]+=w, pd[x] = m;
	add(fa[x], w);
}
long long sch(int x, int w) {
	if(x == 0) return 0;
	if(pd[x] == m && w != -1) {
		lca=x;
		return 0;
	}
	pd[x] = m;
	return s[x]*w+sch(fa[x], w);
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1; i < n; ++i) {
		scanf("%d%d",&a[i],&b[i]);
		road[a[i]].push_back(b[i]);
		road[b[i]].push_back(a[i]);
	}
	dfs(1,0);
	for(int i = 1; i < n; ++i) {
		if(dep[a[i]] > dep[b[i]]) swap(a[i], b[i]);
		fa[b[i]]=a[i];
	}
	for( ; m >= 1; --m) {
		scanf(" %c %d %d",&q,&a[m],&b[m]);
		if(q == 'P') {
			add(a[m],1);
			add(b[m],1);
			add(lca,-1);
		}
		if(q == 'Q') {
			ans=sch(a[m],1)+sch(b[m],1)+sch(lca,-1);
			printf("%lld\n",ans);
		}
	}
	return 0;
}
