#include <bits/stdc++.h>
using namespace std;
int now, m[100], qwq, ans1[100], ans2[100], pd[100], ans[100], x=1;
long long n, a[100] = {1,2,4,8,16,32,64,128,256,512,1024,
2048,4096,8192,16384,32768,65536,131072,262144,524288,
1048576,2097152,4194304,8388608,16777216,33554432,
67108864,134217728,268435456LL,536870912LL,1073741824LL,
2147483648LL,4294967296LL,8589934592LL};
int main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%lld",&n);
	if(n <= 0)
		n=-n, x=0;
	while(a[now] < n) ++now; qwq = now+1;
	for( ; now >= 0; --now) 
		if(n >= a[now])
			n-=a[now], m[now]=1;
	for(int i = 0; i <= 64; ++i) {
		if(i%2 == x) {
			if(m[i] == 0) {
				if(pd[i] == 1) {
					pd[i+1]=1, pd[i]=0;
					ans1[i]=1, ans2[i]=1;
				}
			}
			else {
				if(pd[i] == 1) {
					pd[i+1]=1, pd[i]=0;
					ans1[i]=1;
				}
				else {
					pd[i+1]=1;
					ans1[i]=2, ans2[i]=1;
				}
			}
		}
		else {
			if(m[i] == 1) {
				ans1[i]=1;
				if(pd[i] == 0) pd[i] = 1;
				else pd[i+1] = 1;
			}
		}
	}
//	for(int i = 64; i >= 0; --i)
//		cout<<ans1[i];
//	cout<<"\n";
//	for(int i = 64; i >= 0; --i)
//		cout<<ans2[i];
//	cout<<"\n";
//	for(int i = 64; i >= 0; --i)
//		cout<<m[i];
//	cout<<"\n";
	for(int i = 0; i <= 63; ++i)
		if(ans1[i] == 2)
			ans1[i+1]+=1, ans1[i]=0;
	for(int i = 0; i <= 63; ++i)
		ans[i]=(ans1[i] | ans2[i]);
	int c=0;
	for(c = 64; c >= 0; --c)
		if(ans[c] == 1)
			break;
	for(int i = c; i >= 0; --i)
		printf("%d",ans[i]);
	printf("\n");
	return 0;
} 
