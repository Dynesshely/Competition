#include <bits/stdc++.h>
using namespace std;
int a[2]={-1,1};
int main() {
	srand(time(0));
	freopen("base.in","w",stdout);
	cout<<(long long) rand()%2000000001*rand()%2000000001*rand()%2000000001*rand()%2000000001*a[rand()%2]<<"\n";
	return 0;
} 
