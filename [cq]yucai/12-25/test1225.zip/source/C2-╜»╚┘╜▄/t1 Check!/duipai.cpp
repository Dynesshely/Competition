#include <bits/stdc++.h>
using namespace std;
int main() {
	while(1){
		system("qwq.exe");
		system("base.exe");
		system("check.exe");
		if(system("fc check.in base.in")){
			printf("WA\n");
		}
		else
			printf("AC!\n\n");
	}
	return 0;
} 
