#include <bits/stdc++.h>
using namespace std;
string a;
int main() {
	freopen("base.out","r",stdin);
	freopen("check.in","w",stdout);
	cin>>a;
	long long b = 1, ans = 0;
	for(int i = a.size()-1; i >= 0; --i){
		if(a[i] == '1') ans+=b;
		b*=(-2);
	}
	cout<<ans<<"\n";
	return 0;
} 
