#include <bits/stdc++.h>
using namespace std;
int n,flag;
int a[13],b[13],c[13];
void r(){
	int x=1;
	for(int i=0;i<=10;i++) a[i]=x,x*=-2;
	return;
}
int calc(){
//	printf("a");
	int x=0;
	for(int i=10;i>=0;i--) x+=a[i]*b[i];
	return x;
}
void copy(){
	for(int i=0;i<=10;i++) c[i]=b[i];
	return;
}
void dfs(int k){
	if(k>10){
//		printf("A");
//		for(int i=0;i<=10;i++) cout << b[i];
//		cout << endl << calc();
		if(calc()==n){
			copy();
			flag=1;
			return;
		}
		return;
	}
	if(flag) return;
	b[k]=1;dfs(k+1);
	if(flag) return;
	b[k]=0;dfs(k+1);
}
void print(){
	int place;
	for(int i=10;i>=0;i--){
		if(c[i]==1){
			place=i;
			break;
		}
	}
	for(int i=place;i>=0;i--) cout << c[i];
	return;
}
int main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	r();
//	for(int i=0;i<=10;i++) cout << a[i] << ' ';cout<<endl;
	cin >> n;
	dfs(0);
	print();
	return 0;
}
