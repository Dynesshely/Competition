#include <bits/stdc++.h>
#define P pair<int,int>
#define F first
#define S second
#define N 505
//#define inf 
using namespace std;
int n,a[N][N],l=1000000,r,mid,goal;
int vis[N][N],cntt[N][N],dir[4][2]={{0,1},{0,-1},{1,0},{-1,0}};
P fa[N][N];
bool in(int x,int y){
	return 1<=x&&x<=n&&1<=y&&y<=n;
}
P find(int x,int y){
	P u;u.F=x;u.S=y;
	if(fa[x][y]==u) return u;
	return fa[x][y]=find(fa[x][y].F,fa[x][y].S);
}
void merge(int x,int y,int xx,int yy){
	P aa=find(x,y),bb=find(xx,yy);
	if(aa!=bb) fa[x][y]=bb;
	return;
}
void dfs(int x,int y){
	vis[x][y]=1;
	for(int i=0;i<4;i++){
		int tx=x+dir[i][0],ty=y+dir[i][1];
		if(in(tx,ty)&&vis[tx][ty]==0){
			if(abs(a[tx][ty]-a[x][y])<=mid){
//				cout << "Cor:" << tx << ' ' << ty << ' ' << a[tx][ty] << endl;
				vis[tx][ty]=1;
				merge(tx,ty,x,y);
				dfs(tx,ty);
			}
		}
	}
}
bool ok(){
	memset(vis,0,sizeof(vis));
//	memset(fa,0,sizeof(fa));
	memset(cntt,0,sizeof(cntt));
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			fa[i][j].F=i,fa[i][j].S=j;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(!vis[i][j]){
//				cout << "St:" << i << ' ' << j << ' ' << a[i][j] << endl;
				
				dfs(i,j);
			}
				
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++){
//			cout << "#" << i << ' ' << j << ' ' << fa[i][j].F << ' ' << fa[i][j].S << endl;
			cntt[fa[i][j].F][fa[i][j].S]++;
		}
			
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(cntt[i][j]>=goal){
//				cout << i << ' ' << j << endl;
				return 1;
			}
	return 0;
}
int main(){
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	cin >> n;goal=(n*n+n%2)/2;
//	cout<<"&&&"<<goal<<endl;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++) scanf("%d",&a[i][j]),l=min(a[i][j],l),r=max(a[i][j],r);
	}
//	cout<<"dddd"<<l << ' '<<r<<endl;
	r-=l;l=0;
	while(l+1<r){mid=(l+r)>>1;/*cout<<l<<' '<<r<<' '<<mid<<endl;*/ok()?r=mid:l=mid;}
	mid=l;//cout<<l<<' '<<r<<' '<<mid<<endl;
	cout << (ok()?l:r);
	return 0;
}
