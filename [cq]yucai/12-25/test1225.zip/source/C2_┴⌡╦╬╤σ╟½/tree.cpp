#include <bits/stdc++.h>
#define gc getchar()
using namespace std;
int n,Q,uuuu,vvvv,a[3010][3010],alla;
vector<int> v[3010];
char opt;
bool flag,vis[3010];
void dfs(int now){
//	cout<<"NNNN"<<now<<endl;
//	puts("HEL");
	if(now==vvvv){
		flag=1;
//		if(opt=='P') a[now][vvvv]++,a[vvvv][now]++;
//		else alla+=a[now][vvvv];
		return;
	}
	int len=v[now].size(),q;
	for(int i=0;i<len;i++){
		q=v[now][i];
		if(!vis[q]){
			vis[q]=1;
			dfs(q);
			if(flag){
//				cout << "ii " << now << ' ' << q << ' ' << a[now][q] << endl;
				if(opt=='P') a[now][q]++,a[q][now]++;
				else alla+=a[now][q];
				return;
//				flag=0;
//				break;
			}
		}
		if(flag) return;
	}
	return;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin >> n >> Q;
	for(int i=1;i<n;i++) scanf("%d%d",&uuuu,&vvvv),v[uuuu].push_back(vvvv),v[vvvv].push_back(uuuu);
	while(Q--){memset(vis,0,sizeof(vis));flag=0;alla=0;gc;opt=gc;gc;/*cout<<opt<<endl;*/scanf("%d%d",&uuuu,&vvvv);vis[uuuu]=1;dfs(uuuu);if(opt=='Q'){printf("%d\n",alla);}}
	return 0;
}
