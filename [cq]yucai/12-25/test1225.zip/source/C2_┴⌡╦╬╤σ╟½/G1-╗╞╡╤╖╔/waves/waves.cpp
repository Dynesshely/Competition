#include<bits/stdc++.h>
using namespace std;
int P,b1,b2,T;
const int base=5,maxn=0x3f3f3f3f;
int ans[15][15];
int x[10],y[10],t[10];
int wv[4]={1,0,-1,0};

bool bein(int x,int y){return !(x<-4||x>4||y<-4||y>4);}

bool Bein(int x,int l,int r){return x>l&&x<r;}

void solve(int x,int y,int r,int cas,int kk,int L,int R){
	if(x-r<=L&&kk!=-1) solve(L+1,y,r-x+L,cas,-1,L,R);
	if(x+r>=R&&kk!=1) solve(R-1,y,r+x-R,cas,1,L,R);
	
	L=max(max(x-r,L+1),-4),R=min(min(x+r,R-1),4);
	if(L>R) return;
	for(int i=L;i<=R;i++){
		int d=r-abs(i-x);
		if(bein(i,y+d)) ans[i+base][y+d+base]+=wv[cas];
		if(bein(i,y-d)) ans[i+base][y-d+base]+=wv[cas];
	}
}

int main(){
	freopen("waves.in","r",stdin);
	freopen("waves.out","w",stdout);
	scanf("%d%d%d%d",&P,&b1,&b2,&T);
	if(b1>b2) swap(b1,b2);
	for(int i=1;i<=P;i++) scanf("%d%d%d",&x[i],&y[i],&t[i]);
	
	if(b1>=-4&&b1<=4) for(int j=-4;j<=4;j++) ans[b1+base][j+base]=maxn;
	if(b2>=-4&&b2<=4) for(int j=-4;j<=4;j++) ans[b2+base][j+base]=maxn;
	
	for(int i=1;i<=P;i++){
		if(t[i]>T) continue;
		int L,R,len=T-t[i];
		if(Bein(x[i],-maxn,b1)) L=-maxn,R=b1;
		else if(Bein(x[i],b1,b2)) L=b1,R=b2;
		else L=b2,R=maxn;
		int cas=len%4;
		for(int j=0;j<=len;j++) solve(x[i],y[i],j,(j-cas+4)%4,0,L,R);
	}
	
	for(int j=4+base;j>=-4+base;j--){
		for(int i=-4+base;i<=4+base;i++){
			if(ans[i][j]==maxn) putchar('X');
			else if(ans[i][j]>0) putchar('*');
			else if(ans[i][j]<0) putchar('o');
			else putchar('-');
		}
		puts("");
	}
	
	return 0;
}

