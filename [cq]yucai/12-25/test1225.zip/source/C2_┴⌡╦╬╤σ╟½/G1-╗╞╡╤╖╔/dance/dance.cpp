#include<bits/stdc++.h>
using namespace std;
int dir[8][2]={{1,2},{-1,2},{1,-2},{-1,-2},{2,1},{-2,1},{2,-1},{-2,-1}};
int n,m,a[35][35];
int sx,sy,tx,ty;
int ans=100000;

bool out(int x,int y){return x<1||y<1||x>n||y>m;}

bool vis[35][35];
void dfs(int x,int y,int num){
	if(x==tx&&y==ty) {ans=min(ans,num);return;}
	if(num>=ans) return;
	vis[x][y]=1;
	for(int i=0;i<8;i++){
		int dx=x+dir[i][0],dy=y+dir[i][1];
		if(out(dx,dy)) continue;
		if(vis[dx][dy]||a[dx][dy]==2) continue;
		dfs(dx,dy,num+1);
	}
	vis[x][y]=0;
}

int main(){
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) 
		for(int j=1;j<=m;j++) {
			scanf("%d",&a[i][j]);
			if(a[i][j]==3) sx=i,sy=j,a[i][j]=1;
			if(a[i][j]==4) tx=i,ty=j,a[i][j]=1;
		}
		
	dfs(sx,sy,0);
	
	if(ans!=100000) printf("%d",ans-1);
	else puts("-1");
	
	return 0;
}

