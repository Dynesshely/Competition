#include<bits/stdc++.h>
using namespace std;
int n;
int a[10005],top;

int main(){
	
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	
	scanf("%d",&n);
	if(n==0) puts("0"),exit(0);
	
	bool ca=0;
	if(n<0) ca=1,n=-n;
	
	for(int i=1;i<=100;i++){
		if(n&1){
			if((i&1)^ca) a[i]++,top=max(top,i);
			else a[i+1]++,a[i]++,top=max(top,i+1);
		}
		n>>=1;
	}
	
	int i=1;
	while(i<=top){
		if(a[i]==2&&a[i+1]==1) a[i]=a[i+1]=0;
		if(a[i]>1){
			int num=a[i]/2;a[i]&=1;
			a[i+2]+=num,a[i+1]+=num;
			top=max(top,i+2);
		}
		i++;
	}
	
	while(!a[top]) top--;
	
	for(int i=top;i>=1;i--) printf("%d",a[i]);
	
	return 0;
}
