#include<bits/stdc++.h>
using namespace std;
int n,m;
vector<int> a[100005];

int f[100005],dep[100005],siz[100005],maxson[100005];
void dfs1(int x){
	dep[x]=dep[f[x]]+1,siz[x]=1;
	for(int i=0;i<a[x].size();i++){
		int y=a[x][i];if(y==f[x]) continue;
		f[y]=x,dfs1(y),siz[x]+=siz[y];
		if(siz[y]>siz[maxson[x]]) maxson[x]=y;
	}
}

int dfn[100005],top[100005],cnt;
void dfs2(int x,int t){
	dfn[x]=++cnt,top[x]=t;
	if(!maxson[x]) return;
	dfs2(maxson[x],t);
	for(int i=0;i<a[x].size();i++){
		int y=a[x][i];if(y==f[x]||y==maxson[x]) continue;
		dfs2(y,y);
	}
}

inline int read(){
	int s=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9') s=(s<<1)+(s<<3)+c-48,c=getchar();
	return s;
}

int lan[400005];
void add(int i,int l,int r,int L,int R){
	if(L>R) return;
	if(L<=l&&r<=R){lan[i]++;return;}
	int mid=(l+r)>>1;
	if(L<=mid) add((i<<1),l,mid,L,R);
	if(R>mid) add((i<<1)+1,mid+1,r,L,R);
}

void Add(int x,int y){
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		add(1,1,n,dfn[top[x]],dfn[x]),x=f[top[x]];
	}
	if(dep[x]<dep[y]) swap(x,y);  add(1,1,n,dfn[y]+1,dfn[x]);
}

int find(int i,int l,int r,int pos){
	if(l==r) return lan[i];
	int mid=(l+r)>>1;
	if(pos<=mid) return find((i<<1),l,mid,pos)+lan[i];
	return find((i<<1)+1,mid+1,r,pos)+lan[i];
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	
	for(int i=1;i<n;i++){
		int x=read(),y=read();
		a[x].push_back(y),a[y].push_back(x);
	}
	
	dfs1(1),dfs2(1,1);
	
	for(int i=1;i<=m;i++){
		char c;cin>>c;
		int x=read(),y=read();
		if(c=='P') Add(x,y);
		else printf("%d\n",find(1,1,n,dfn[dep[x]>dep[y]?x:y]));
	}
	return 0;
}

