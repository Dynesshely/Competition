#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,a[35],b[35],ans[35];

namespace sub1{
	void r1(){
		int x=1;
		for(int i=0;i<=33;i++) a[i]=x,x*=-2;
		b[0]=1;
		for(int i=2;i<=33;i+=2){b[i]=b[i-2]+a[i];b[i-1]=b[i]+a[i-1];}
		return;
	}
	void out(){
		r1();
		for(int i=0;i<=33;i++) cout << a[i] << ' ';cout<<endl;
		for(int i=0;i<=33;i++) cout << b[i] << ' ';cout<<endl;
		while(n>5){
			int ss;
			for(ss=32;ss>=0;ss-=2){
				if(b[ss]<n) break;
			}
			ss+=2;
			if(n<=b[ss-1]){
				ans[ss-1]=1;
				n+=a[ss-1];
				ss-=2;
			}else{
				ans[ss]=1;
				n-=a[ss];	
			}
			
		}
		for(int i=33;i>=0;i--) cout<<ans[i];
		cout<<endl<<n;
	}
}
signed main(){
	cin >> n;
	if(n==0){cout << "0";return 0;}
	if(n>0) sub1::out();
//	if(n<0) sub2::out();
	return 0;
}
