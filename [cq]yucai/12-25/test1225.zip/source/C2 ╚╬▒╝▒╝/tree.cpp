#include <bits/stdc++.h>
#define int long long
#define FOR(i,k,x,p) for(int i = k ; i <= x ; i += p)
#define ROF(i,k,x,p) for(int i = k ; i >= x ; i -= p)
#define pb push_back
#define gc getchar
#define pc putchar
#define enter pc('\n')
#define space pc(' ')
using namespace std ;
const int N = 1e5+5 ;
int n,m,top,ans ;
int fa[N],son[N],sz[N],vis[N],dep[N] ;
int pe[N],id[N] ;
vector<int>cha[N] ; 
struct ww{int w,l,r,f ;}tr[N*4];
inline void read(int &x)
{
   x = 0 ;
   int f = 0 ;
   char c = gc() ;
   while(!isdigit(c)) f |= (c=='-'),c = gc() ;
   while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
   x = f?-x:x ;
}
inline void print(int x)
{
    char bf[40] ;
    int lenn = 0 ;
       if(!x) pc('0') ;
       if(x < 0) x = -x,pc('-') ;
    while(x) bf[++lenn] = x%10,x /= 10 ;
    while(lenn--) pc(bf[lenn+1]+'0') ;
}
void find1(int x,int f)
{
	sz[x] = vis[x] = 1 ;
	dep[x] = dep[f]+1,fa[x] = f ;
	FOR(i,0,cha[x].size()-1,1)
	{
		int v = cha[x][i] ;
		if(vis[v]) continue ;
		find1(v,x) ;
		sz[x] += sz[v] ;
		if(sz[v] > sz[son[x]]) son[x] = v ;
	}
	vis[x] = 0 ;
}
void find2(int x,int tops)
{
	vis[x] = 1 ;
	id[x] = ++top,pe[x] = tops ;
	if(!son[x]) return ;
	find2(son[x],tops) ;
	FOR(i,0,cha[x].size()-1,1)
	{
		int v = cha[x][i] ;
	 	if(vis[v] || v == son[x]) continue ;
	 	find2(v,v) ;
	 } 
}
inline int ls(int x){return x<<1 ;}
inline int rs(int x){return x<<1|1 ;}
void build(int x,int le,int ri)
{
	tr[x].l = le,tr[x].r = ri ;
	if(le == ri) return ;
	int mid = le+ri>>1 ;
	build(ls(x),le,mid),build(rs(x),mid+1,ri) ;
}
void down(int x)
{
	tr[ls(x)].w += (tr[ls(x)].r-tr[ls(x)].l+1)*tr[x].f ;
	tr[rs(x)].w += (tr[rs(x)].r-tr[rs(x)].l+1)*tr[x].f ;
	tr[ls(x)].f += tr[x].f,tr[rs(x)].f += tr[x].f ;
	tr[x].f = 0 ;
}
void insert(int x,int le,int ri,int k)
{
	if(tr[x].l >= le && tr[x].r <= ri)
	{
		tr[x].w += k*(tr[x].r-tr[x].l+1) ;
		tr[x].f += k ;
		return ;
	}
	down(x) ;
	int mid = tr[x].l+tr[x].r>>1 ;
	if(le <= mid) insert(ls(x),le,ri,k) ;
	if(mid < ri) insert(rs(x),le,ri,k) ;
	tr[x].w = tr[ls(x)].w+tr[rs(x)].w ;
}
void query(int x,int le,int ri)
{
	if(tr[x].l >= le && tr[x].r <= ri)
	{
		ans += tr[x].w ;
		return ;
	}
	down(x) ;
	int mid = tr[x].l+tr[x].r>>1 ;
	if(le <= mid) query(ls(x),le,ri) ;
	if(mid < ri) query(rs(x),le,ri) ;
	tr[x].w = tr[ls(x)].w+tr[rs(x)].w ;
}
void Do(int f,int u,int v)
{
	while(pe[u] != pe[v])
	{
		if(dep[pe[u]] < dep[pe[v]]) swap(u,v) ;
		if(f) insert(1,id[pe[u]],id[u],1) ;
		else query(1,id[pe[u]],id[u]) ;
		u = fa[pe[u]] ;
	}
	if(dep[u] < dep[v]) swap(u,v) ;
	if(f) insert(1,id[v]+1,id[u],1) ;
	else query(1,id[v]+1,id[u]) ;
}
signed main()
{
    freopen("tree.in","r",stdin) ;
    freopen("tree.out","w",stdout) ;
    read(n),read(m) ;
    FOR(i,1,n-1,1)
    {
    	int u,v ;
    	read(u),read(v) ;
    	cha[u].pb(v),cha[v].pb(u) ;
	}
	find1(1,1) ;
	find2(1,1) ;
	build(1,1,n) ;
    FOR(i,1,m,1)
    {
    	char s = gc() ;
    	int u,v ;
    	read(u),read(v) ;
    	if(s == 'P') Do(1,u,v) ;
    	else ans = 0,Do(0,u,v),print(ans),enter ;
	}
	return 0 ;
}

