#include <bits/stdc++.h>
#define udl long long
#define FOR(i,k,x,p) for(int i = k ; i <= x ; i += p)
#define ROF(i,k,x,p) for(int i = k ; i >= x ; i -= p)
#define pb push_back
#define gc getchar
#define pc putchar
#define enter pc('\n')
#define space pc(' ')
using namespace std ;
const int N = 35 ;
struct ww{int x,y ;}st,ed;
int n,m ;
int a[N][N],vis[N][N],fx[N][N] = {{2,1},{-2,1},{2,-1},{-2,-1},{1,2},{1,-2},{-1,2},{-1,-2}} ;
udl dp[N][N],ans,sum[N][N] ;
inline void read(int &x)
{
   x = 0 ;
   int f = 0 ;
   char c = gc() ;
   while(!isdigit(c)) f |= (c=='-'),c = gc() ;
   while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
   x = f?-x:x ;
}
inline void print(int x)
{
    char bf[40] ;
    int lenn = 0 ;
       if(!x) pc('0') ;
       if(x < 0) x = -x,pc('-') ;
    while(x) bf[++lenn] = x%10,x /= 10 ;
    while(lenn--) pc(bf[lenn+1]+'0') ;
}
void find(int x,int y)
{
	if(a[x][y] == 2) return ;
	FOR(i,0,7,1)
	{
		int X = x+fx[i][0],Y = y+fx[i][1] ;
		if(X < 1 ||X > n || Y < 1 || Y > m) continue ;
		dp[x][y] = min(dp[x][y],dp[X][Y]+(!a[x][y])) ;
	}
}
void dfs(int x,int y)
{
	vis[x][y] = 1 ;
	FOR(i,0,7,1)
	{
		int X = x+fx[i][0],Y = y+fx[i][1] ;
		if(X < 1 ||X > n || Y < 1 || Y > m) continue ;
		if(dp[x][y] == dp[X][Y]+(!a[x][y])) 
		{
			if(!vis[X][Y]) dfs(X,Y) ;
			sum[x][y] += sum[X][Y] ;
		}
	}
}
int main()
{
    freopen("dance.in","r",stdin) ;
    freopen("dance.out","w",stdout) ;
    read(n),read(m) ;
    FOR(i,1,n,1) FOR(j,1,m,1) 
    {
    	read(a[i][j]) ;
    	if(a[i][j] == 3) st = (ww){i,j} ;
    	if(a[i][j] == 4) ed = (ww){i,j} ;
	}
	memset(dp,0x3f,sizeof(dp)) ;
	dp[st.x][st.y] = 0,sum[st.x][st.y] = 1 ;
	FOR(i,1,n,1) FOR(j,1,m,1) find(i,j) ;
	FOR(i,1,n,1) FOR(j,1,m,1) find(i,j) ;
	FOR(i,1,n,1) FOR(j,1,m,1) find(i,j) ;
	FOR(i,1,n,1) FOR(j,1,m,1) find(i,j) ;
	dfs(ed.x,ed.y) ;
	if(dp[ed.x][ed.y] == dp[0][0])
	{
		print(-1) ;
		return 0 ;
	}
	if(!dp[ed.x][ed.y]) sum[ed.x][ed.y] = 0 ; 
	print(dp[ed.x][ed.y]),enter,print(sum[ed.x][ed.y]) ;
	return 0 ;
}

