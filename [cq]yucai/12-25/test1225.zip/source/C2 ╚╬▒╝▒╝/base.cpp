#include <bits/stdc++.h>
#define FOR(i,k,x,p) for(int i = k ; i <= x ; i += p)
#define ROF(i,k,x,p) for(int i = k ; i >= x ; i -= p)
#define pb push_back
#define gc getchar
#define pc putchar
#define enter pc('\n')
#define space pc(' ')
using namespace std ;
const int N = 35 ; 
const int MAXN = 1<<30 ;
int x,ans,len ;
int vis[N] ;
inline void read(int &x)
{
   x = 0 ;
   int f = 0 ;
   char c = gc() ;
   while(!isdigit(c)) f |= (c=='-'),c = gc() ;
   while(isdigit(c)) x = (x<<1)+(x<<3)+(c^48),c = gc() ;
   x = f?-x:x ;
}
inline void print(int x)
{
    char bf[40] ;
    int lenn = 0 ;
       if(!x) pc('0') ;
       if(x < 0) x = -x,pc('-') ;
    while(x) bf[++lenn] = x%10,x /= 10 ;
    while(lenn--) pc(bf[lenn+1]+'0') ;
}
int main()
{
	freopen("base.in","r",stdin) ;
	freopen("base.out","w",stdout) ;
    read(x) ;
    if(!x) 
    {
    	print(0) ;
    	return 0 ;
	}
    FOR(i,1,MAXN-5,1)
    {
    	len = 0 ;
    	int sum = 0,s = i,k = 1 ;
    	while(s) vis[++len] = s&1,s >>= 1 ;;
    	FOR(j,1,len,1) sum += vis[j]*(j&1?k:-k),k <<= 1 ;
		if(sum == x)
		{
			FOR(j,1,len,1) print(vis[len-j+1]) ;
			break ;
		}
	}
    return 0 ;
}

