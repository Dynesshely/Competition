#include<bits/stdc++.h>
using namespace std;
#define N 10005
int n,m;
int ans;
int vis[N];
int a[N][N];
vector<int>tr[N];
int bfs(int now,int to_,int add)
{
	if(now==to_)return 1;
	vis[now]=1;
	int flag=0;
	for(int i=0;i<tr[now].size();i++)
	{
		if(!vis[tr[now][i]]){
			if(bfs(tr[now][i],to_,add))
			{
				flag=1;
				ans+=a[now][tr[now][i]];
				a[now][tr[now][i]]+=add;
				a[tr[now][i]][now]+=add;
				break;
			}
		}
	}
	vis[now]=0;
	if(flag)return 1;
	else return 0;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&m);
	int u,v;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&u,&v);
		tr[u].push_back(v);
		tr[v].push_back(u);
	}
	char ch;
	for(int i=1;i<=m;i++)
	{
		cin>>ch;
		scanf("%d%d",&u,&v);
		if(ch=='P')bfs(u,v,1);
		else 
		{
			ans=0,bfs(u,v,0);
			printf("%d\n",ans);
		}
	}
	return 0;
}
