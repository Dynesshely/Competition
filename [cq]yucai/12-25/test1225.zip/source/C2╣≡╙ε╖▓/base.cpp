#include<bits/stdc++.h>
using namespace std;
#define base -2
int n;
int ans[35];
bool check(int num)
{
	int ret=0,tot=1;
	while(num)
	{
		if(num&1)ret+=tot;
		num>>=1,tot*=base;
	}
	if(ret==n)return 1;
	else return 0;
}
int main()
{
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%d",&n);
	int t=0;
	for(int i=1;i<=(1<<24);i++){
		if(check(i)){
			while(i)
			{
				ans[++t]=i&1;
				i>>=1;
			}
			break;
		}
	}
	int flag=0;
	for(int i=t;i>=1;i--)
	{
		if(flag||ans[i]){
			printf("%d",ans[i]);
			flag=1;
		}
	}
	return 0;
}
