#include<bits/stdc++.h>
using namespace std;
#define N 35
int n,m;
int ans;
int a[N][N];
int f[N][N];
int dir[4][2]={{2,1},{2,-1},{-2,1},{-2,-1}};
int change(int i,int j,int toi,int toj)
{
	if(a[toi][toj]==2)return 0;
	if(a[toi][toj]==4)
	{
		if(f[i][j]==f[toi][toj])ans++;
		else if(f[i][j]<f[toi][toj])
		{
			f[toi][toj]=f[i][j];
			ans=1;			
		}
	}
	else{
		if(f[i][j]+(1-a[toi][toj])<f[toi][toj])
		{
			f[toi][toj]=f[i][j]+(1-a[toi][toj]);
			return 1;
		}
	}
	return 0;
}
void dp(int i,int j,int lai,int laj)
{
	if(i>n||i<0||j>m||j<0)return ;
	for(int d=0;d<4;d++){
		int toi=i+dir[d][0],toj=j+dir[d][1];
		if((toi!=lai||toj!=laj)&&toi>0&&toi<=n&&toj>0&&toj<=m)
			if(change(i,j,toi,toj))dp(toi,toj,i,j);
	}
	for(int d=0;d<4;d++){
		int toi=j+dir[d][0],toj=i+dir[d][1];
		if((toi!=laj||toj!=lai)&&toi>0&&toi<=m&&toj>0&&toj<=n)
			if(change(i,j,toj,toi))dp(toj,toi,i,j);
	}
}
int main()
{
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d%d",&n,&m);
	int u,v,x,y;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
			if(a[i][j]==3)u=i,v=j;
			if(a[i][j]==4)x=i,y=j;
		}
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			f[i][j]=1e9;
	f[u][v]=0;
	dp(u,v,0,0);
	if(f[x][y]==1e9)printf("-1\n");
	else printf("%d\n%d",f[x][y],ans);
	return 0;
}
