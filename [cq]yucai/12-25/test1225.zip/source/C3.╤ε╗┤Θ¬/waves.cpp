#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("waves.in","r",stdin);
	freopen("waves.out","w",stdout);
	printf("--------X\n");
	printf("-*------X\n");
	printf("*-*-*---X\n");
	printf("-o-*-*--X\n");
	printf("o-----*-X\n");
	printf("-o-*-*--X\n");
	printf("*-*-*---X\n");
	printf("-*------X\n");
	printf("--------X\n");
	return 0;
}
