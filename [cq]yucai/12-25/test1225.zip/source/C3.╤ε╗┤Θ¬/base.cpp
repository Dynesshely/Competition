#include<bits/stdc++.h>
using namespace std;
long long n,a[65],b[65],t;
void dfs(long long k,long long sum){
	if(k==t+1){
		if(sum==n){
			int l=t;
			while(b[l]) l--;
			for(int i=l;i>=1;i--) printf("%lld",!b[i]);
			exit(0);
		}
		return;
	}
	b[k]=0;
	dfs(k+1,sum);
	b[k]=1;
	dfs(k+1,sum-a[k]);
}
int main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%lld",&n);
	a[1]=1;
	for(int i=2;i<=63;i++) a[i]=a[i-1]*(long long)(-2);
	int f=1,l=63,mid,s=0;
	while(f<=l){
		mid=(f+l)>>1;
		if((long long)(pow(2,mid)/2)==abs(n)) break;
		if((long long)(pow(2,mid)/2)>abs(n)) l=mid-1;
		else f=mid+1;
	}
	t=mid*2+1;
	for(int i=1;i<=t;i++) s+=a[i];
	dfs(1,s);
	return 0;
}
