#include<bits/stdc++.h>
using namespace std;
int ans=1e9,mb,n,a[505][505],cnt=0,clr[505][505],dx[4],dy[4],tnt=0,sum[200005],head[200005],txt[400005],nxt[400005],zhi[400005];
bitset<200005> vis;
void dfs(int x,int y,int cl){
	clr[x][y]=cl;
	for(int i=0;i<=3;i++){
		int xx=x+dx[i],yy=y+dy[i];
		if(xx<=0||xx>n||yy<=0||yy>n||clr[xx][yy]||a[x][y]!=a[xx][yy]) continue;
		dfs(xx,yy,cl);
	}
}
void dfs2(int k,int rs,int hf){
	if(rs>=mb){
		ans=min(ans,hf);
		return;
	}
	for(int i=head[k];i;i=nxt[i]){
		if(vis[txt[i]]) continue;
		vis[txt[i]]=1;
		dfs2(k,rs+sum[txt[i]],hf+zhi[i]);
		vis[txt[i]]=0;
	}
}
int main(){
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	scanf("%d",&n);
	mb=(n*n+1)/2;
	dx[0]=0,dy[0]=1,dx[1]=0,dy[1]=-1,dx[2]=1,dy[2]=0,dx[3]=-1,dy[3]=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++) scanf("%d",&a[i][j]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(!clr[i][j]){
				cnt++;
				dfs(i,j,cnt);
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int g=0;g<=3;g++){
				int xx=i+dx[g],yy=j+dy[g];
				if(xx<=0||xx>n||yy<=0||yy>n||a[i][j]==a[xx][yy]) continue;
				nxt[++tnt]=head[clr[i][j]],head[clr[i][j]]=tnt,txt[tnt]=clr[xx][yy],zhi[tnt]=abs(a[i][j]-a[xx][yy]);
			}
			sum[clr[i][j]]++;
		}
	}
	for(int i=1;i<=cnt;i++) dfs2(i,sum[i],0);
	printf("%d",ans);
	return 0;
} 
