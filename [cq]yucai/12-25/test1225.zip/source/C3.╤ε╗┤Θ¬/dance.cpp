#include<bits/stdc++.h>
using namespace std;
long long n,m,a[35][35],t1,t2,sum[100005],ans1,ans2,dx[8],dy[8],xx,yy;
struct ok{
	long long x,y,tot;
	bool operator <(const ok &A) const{
		return tot>A.tot;
	}
}s;
priority_queue<ok> q;
bitset<35> vis[35];
int main(){
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	dx[0]=-2,dy[0]=1,dx[1]=-1,dy[1]=2,dx[2]=1,dy[2]=2,dx[3]=2,dy[3]=1;
	dx[4]=2,dy[4]=-1,dx[5]=1,dy[5]=-2,dx[6]=-1,dy[6]=-2,dx[7]=-2,dy[7]=-1;
	scanf("%lld%lld",&n,&m);
	for(long long i=1;i<=n;i++){
		for(long long j=1;j<=m;j++){
			scanf("%lld",&a[i][j]);
			if(a[i][j]==3) s.x=i,s.y=j,s.tot=0,vis[i][j]=1;
			if(a[i][j]==4) t1=i,t2=j;
		} 
	}
	q.push(s);
	while(!q.empty()){
		ok t=q.top();q.pop();
//		cout<<t.x<<" "<<t.y<<" "<<t.tot<<endl;
		if(t.x==t1&&t.y==t2){
			sum[t.tot]++;
			continue;
		}
		for(long long i=0;i<=7;i++){
			xx=t.x+dx[i],yy=t.y+dy[i];
			if(xx<=0||xx>n||yy<=0||yy>m||a[xx][yy]==2||vis[xx][yy]) continue;
			if(a[xx][yy]!=1) q.push((ok){xx,yy,t.tot+1});
			else q.push((ok){xx,yy,t.tot});
			if(xx!=t1||yy!=t2) vis[xx][yy]=1;
		}
	}
	for(long long i=0;i<=100000;i++){
		if(sum[i]){
			printf("%lld\n%lld",i-1,sum[i]);
			return 0;
		}
	}
	printf("-1");
	return 0;
} 
