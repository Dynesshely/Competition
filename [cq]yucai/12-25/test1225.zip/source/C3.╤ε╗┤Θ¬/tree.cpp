#include<bits/stdc++.h>
using namespace std;
int n,m,t1,t2,tnt=0,dep[100005],tag[800005],sum[800005],id[100005],top[100005],sz[100005],son[100005],f[100005],cnt=0,head[100005],nxt[200005],txt[200005];
char s;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs(int k,int fa){
	f[k]=fa;dep[k]=dep[fa]+1;
	for(int i=head[k];i;i=nxt[i]){
		if(txt[i]==fa) continue;
		dfs(txt[i],k);
		if(sz[txt[i]]>sz[son[k]]) son[k]=txt[i];
		sz[k]+=sz[txt[i]];
	}
	sz[k]++;
}
void dfs2(int k,int fa){
	id[k]=++tnt;top[k]=fa;
	if(!son[k]) return;
	dfs2(son[k],fa);
	for(int i=head[k];i;i=nxt[i]){
		if(txt[i]==f[k]||txt[i]==son[k]) continue;
		dfs2(txt[i],txt[i]);
	}
}
void pushdown(int k,int l,int r){
	int mid=(l+r)>>1;
	sum[k*2]=sum[k*2]+tag[k]*(mid-l+1);
	sum[k*2+1]=sum[k*2+1]+tag[k]*(r-mid);
	tag[k*2]+=tag[k],tag[k*2+1]+=tag[k];
	tag[k]=0;
}
void add(int k,int l,int r,int ll,int rr,int q){ 
	if(ll<=l&&rr>=r){
		sum[k]=sum[k]+(r-l+1)*q;
		tag[k]+=q;
		return;
	}
	if(tag[k]) pushdown(k,l,r);
	int mid=(l+r)>>1;
	if(ll<=mid) add(k*2,l,mid,ll,rr,q);
	if(rr>mid) add(k*2+1,mid+1,r,ll,rr,q);
	sum[k]=sum[k*2]+sum[k*2+1];
}
int query(int k,int l,int r,int q){
	if(l==r) return sum[k];
	if(tag[k]) pushdown(k,l,r);
	int mid=(l+r)>>1;
	if(q<=mid) return query(k*2,l,mid,q);
	else return query(k*2+1,mid+1,r,q);
	sum[k]=sum[k*2]+sum[k*2+1];
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout); 
	n=read(),m=read();
	for(int i=1;i<n;i++){
		scanf("%d%d",&t1,&t2);
		nxt[++cnt]=head[t1],head[t1]=cnt,txt[cnt]=t2;
		nxt[++cnt]=head[t2],head[t2]=cnt,txt[cnt]=t1;
	}
	dfs(1,0);
	dfs2(1,1);
	for(int i=1;i<=m;i++){
		cin>>s;
		scanf("%d%d",&t1,&t2);
		if(s=='P'){
			while(top[t1]!=top[t2]){
				if(dep[top[t1]]<dep[top[t2]]) swap(t1,t2);
				add(1,1,n,id[top[t1]],id[t1],1);
				t1=f[top[t1]];
			}
			if(t1==t2) add(1,1,n,id[t2],id[t2],-2);
			else{
				if(dep[t1]<dep[t2]) swap(t1,t2);
				add(1,1,n,id[t2],id[t1],1);
				add(1,1,n,id[t2],id[t2],-1);
			}	
		}
		else if(s=='Q'){
			if(dep[t1]>dep[t2]) printf("%d\n",query(1,1,n,id[t1]));
			else printf("%d\n",query(1,1,n,id[t2]));
		}
	}
	return 0;
}
