#include <bits/stdc++.h>
#define int long long
#define N 1000
using namespace std;
string ans[500010];
int n,sum,la,ld;
//int db[35],jx[35];
//bool vis[35];
int val(int x) {
	return x+(N*109);
}
int raw(int x) {
	return x-(N*109);
}
queue<int> dl;
signed main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%lld",&n);
/*	db[0]=sum=1;
	jx[0]=1;
	la=1;
	for(int i=1; i<=32; i++) {
		vis[i]=0;
		sum*=-2,db[i]=sum;
		if(i%2==1) {
			jx[i]=db[i]+ld;
		} else jx[i]=db[i]+la;
		if(sum>0) la+=sum;
		else ld+=sum;
		if(n==db[i]) {
			puts("1");
			for(int j=i-1; j>=0; j--) puts("0");
			return 0;
		}
//		cout<<db[i]<<" "<<jx[i]<<endl;
	}
	if(n<0) {
		int cz;
		for(int i=1;; i+=2) {
			if(jx[i]<=n) {
				cz=i;
				break;
			}
		}
		cout<<cz<<endl;
		int nn=n-db[cz];
		vis[cz]=1;
		if(nn%2==1) vis[0]=1;
		
	}*/
		int sum=1;
		dl.push(val(0));
		//ans[val(0)]="0";
		while(!dl.empty()) {
			int x=dl.front();
	//		cout<<raw(x)<<" : "<<ans[x]<<endl;
			sum=1;
			for(int i=0; i<=11; ++i) {
				sum=(i==0?1:sum*(-2));
	//			cout<<i<<" "<<sum<<endl;
				int xx=x+sum;
				if(xx<0||xx>(5000*N)) break;
				if(ans[x][ans[x].size()-1-i]=='1') continue;
	////			cout<<ans[x][ans[x].size()-1-i]<<endl;
				if(xx==x||ans[xx].size()>0) continue;
				ans[xx]="1";
	//			cout<<<<endl;
				while(ans[xx].size()+ans[x].size()<(i+1)) ans[xx]+="0";
				ans[xx]+=ans[x];
				dl.push(xx);
	//			cout<<raw(xx)<<" "<<ans[xx]<<" "<<ans[x][ans[x].size()-1-i]<<endl;
			}
	//			cout<<114514;
			dl.pop();
		}
	//	cout<<114514;
		ans[val(0)]='0';
	for(int i=-N*109; i<=N*109; ++i) cout<<ans[val(i)]<<",";
//	cout<<ans[val(n)];
	return 0;
}
