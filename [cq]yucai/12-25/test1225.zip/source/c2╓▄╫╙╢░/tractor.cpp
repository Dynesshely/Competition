#include <bits/stdc++.h>
#define N 555
using namespace std;
const int p[4][2]= {{1,0},{0,1},{-1,0},{0,-1}};
int n,ans,cnm,l=0,r=0;
int jz[N][N];
bool flag=0,vis[N][N];
void dfs(int x,int y,int sum,int mb) {
//	cout<<x<<" "<<y<<" "<<sum<<" "<<mb<<endl;
	if(sum>=cnm) {
		flag=1;
		return ;
	}
	if(flag==1) return ;
	for(int i=0; i<=3; ++i) {
		int xx=x+p[i][0],yy=y+p[i][1];
		if(xx>=1&&xx<=n&&yy>=1&&yy<=n&&vis[xx][yy]==0&&jz[xx][yy]-jz[x][y]<=mb) {
			vis[xx][yy]=1;
			dfs(xx,yy,sum+1,mb);
		}
	}
}
int check(int md) {
//	cout<<md<<endl;
	flag=0;
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++)
			vis[i][j]=0;
	for(int i=1; i<=n; i++) {
		int j=1;
		if(flag!=1&&jz[i][j]<=md&&vis[i][j]==0)  vis[i][j]=1,dfs(i,j,1,md);
	}
	for(int i=1; i<=n; i++) {
		int j=n;
		if(flag!=1&&jz[i][j]<=md&&vis[i][j]==0)  vis[i][j]=1,dfs(i,j,1,md);
	}
	for(int j=1; j<=n; j++) {
		int i=1;
		if(flag!=1&&jz[i][j]<=md&&vis[i][j]==0)  vis[i][j]=1,dfs(i,j,1,md);
	}
	for(int j=1; j<=n; j++) {
		int i=n;
		if(flag!=1&&jz[i][j]<=md&&vis[i][j]==0)  vis[i][j]=1,dfs(i,j,1,md);
	}
	return (flag==1?114514:1919810);
}
int main() {
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	scanf("%d",&n);
	if(n%2==1) {
		double fuck=((double)(n*n))/2.0;
		if(fuck>=((double)((int)((n*n)/2)))+0.5) cnm=(int)fuck+1;
		else cnm=(int)fuck;
	} else cnm=(n*n)/2;
//	cout<<cnm<<endl;
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++)
			scanf("%d",&jz[i][j]),r=max(r,jz[i][j]),vis[i][j]=0;
	while(l<=r) {
		int mid=(l+r)/2;
		if(check(mid)==114514) {
			r=mid-1;
			ans=mid;
		} else 	l=mid+1;
	}
	printf("%d",ans);
	return 0;
}
