#include<bits/stdc++.h>
#define maxn 100
using namespace std;
inline long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
long long a[maxn],b[maxn],n,sum=1;
void check(long long x,long long y)
	{
	long long f=x;
	if(x<0) x=-x;
	if(y<0) y=-y;
	if(x>y) cout<<"0";
	else putchar('1'),n=f;
	return;
	}
int pd(long long x)
	{
	if(n==1)  cout<<"1";
	if(n==0)  cout<<"0";
	if(n==-1) cout<<"11";
	if(n==-2) cout<<"10";
	if(n==1||n==0||n==-1||n==-2) return 0;
	return 1;
	}
void ycl()
	{
	for(int i=1; i<=35; i++) a[i]=b[i]=sum,sum*=-2;
	for(int i=3; i<=35; i++) a[i]+=a[i-2];
	return;
	}
signed main()
	{
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	n=read();
	ycl();
	if(pd(n)==0) return 0;
	if(n<0)
		{
		for(int i=34; i>=1; i-=2)
			if(n<a[i])
				{
				for(int j=i+2; j>=1; j--) check(n-b[j],a[j-1]);
				return 0;
				}
		}
	else
		{
		for(int i=35; i>=1; i-=2)
			if(n>a[i])
				{
				for(int j=i+2; j>=1; j--) check(n-b[j],a[j-1]);
				return 0;
				}
		}
	return 0;
	}
