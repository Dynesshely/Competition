#include<bits/stdc++.h>
using namespace std;
long long n,m,a[50][50],x,y,b,c,num,X,Y,ans,fa,minn=0x3f3f3f3f,fx[8][2]={{2,1},{2,-1},{-2,1},{-2,-1},{1,2},{1,-2},{-1,2},{-1,-2}};
bool pd,jl[50][50];
inline long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs(long long x,long long y,long long sum)
{
	if(x==X&&y==Y)
	{
		pd=true;
		if(sum<minn)
		minn=sum,ans=0;
		if(sum==minn)
		ans++;
		return;
	}
	for(int i=0;i<8;i++)
	{
		if(jl[x+fx[i][0]][y+fx[i][1]]==true||a[x+fx[i][0]][y+fx[i][1]]==2||x+fx[i][0]<1||x+fx[i][0]>n||y+fx[i][1]<1||y+fx[i][1]>m)
		continue;
		jl[x+fx[i][0]][y+fx[i][1]]=true;
		if(a[x+fx[i][0]][y+fx[i][1]]==0)
		dfs(x+fx[i][0],y+fx[i][1],sum+1);
		else
		dfs(x+fx[i][0],y+fx[i][1],sum);
		jl[x+fx[i][0]][y+fx[i][1]]=false;
	}
	return;
}
int main()
	{
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		a[i][j]=read();
		if(a[i][j]==3)
		b=i,c=j;
		if(a[i][j]==4)
		X=i,Y=j;
	}
	jl[b][c]=true;
	dfs(b,c,0);
	if(pd==false)
	cout<<-1<<endl;
	else
	{
	cout<<minn<<endl;
	cout<<ans;	
	}
	return 0;
	}
