#include<bits/stdc++.h>
using namespace std;
long long n,m,a[50][50],x,y,b,c,X,Y,ans,fa,minn=0x3f3f3f3f,fx[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
bool jl[50][50];
inline long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
void dfs(long long x,long long y,long long sum,long long num)
{
	if(sum>minn)
	return;
	if(num==X)
	{
		if(sum<minn)
		minn=sum;
		return;
	}
	for(int i=0;i<8;i++)
	{
		if(jl[x+fx[i][0]][y+fx[i][1]]==true||x+fx[i][0]<1||x+fx[i][0]>n||y+fx[i][1]<1||y+fx[i][1]>n)
		continue;
		jl[x+fx[i][0]][y+fx[i][1]]=true;
		dfs(x+fx[i][0],y+fx[i][1],max(sum,abs(a[x][y]-a[x+fx[i][0]][y+fx[i][1]])),num+1);
	}
	return;
}
int main()
	{
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	n=read();
	if(n%2==1)
	X=(n+1)/2;
	else
	X=n/2;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	a[i][j]=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	{
		jl[i][j]=true;
		dfs(i,j,0,0);
		for(int l=1;l<=n;l++)
		memset(jl[l],0,sizeof(jl[l]));
	}
	cout<<minn;
	return 0;
	}
