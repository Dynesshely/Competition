#include<bits/stdc++.h>
using namespace std;
long long a[200],b[200];
long long n,k;
int main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	cin>>n;
	k=1;
	for(int i=1; i<=35; i++) {
		a[i]=b[i]=k;
		k=k+k,k=-k;
	}
	for(int i=3; i<=35; i++) a[i]+=a[i-2];
	if(n==0) {
		cout<<0;
		return 0;
	}
	if(n<0) {
		if(n==-1) cout<<"11";
		if(n==-2) cout<<"10";
		for(long long i=34; i>=1; i-=2) {
			if(n<a[i]) {
				for(long long j=i+2; j>=1; j--) {
					int aa=n-b[j],bb=a[j-1];
					if(aa<0) aa=-aa;
					if(bb<0) bb=-bb;
					if(aa>bb) cout<<"0";
					else {
						n=n-b[j];
						cout<<"1";
					}
				}
				return 0;
			}
		}
	}
	if(n>0) {
		if(n==1) 	cout<<"1";
		for(long long i=35; i>=1; i-=2) {
			if(n>a[i]) {
				for(long long j=i+2; j>=1; j--) {
					long long aa=n-b[j],bb=a[j-1];
					if(aa<0) aa=-aa;
					if(bb<0) bb=-bb;
					if(aa>bb) cout<<"0";
					else {
						n=n-b[j];
						cout<<"1";
					}
				}
				return 0;
			}
		}
	}
	return 0;
}
