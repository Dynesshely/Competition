#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
T read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) {
		b*=10,b+=ch-'0',ch=getchar();
	} x=f*b;return x;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[110]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	while (top) putchar(st[top--]+'0');
	return;
}
const van MaxN=1e5+10;
van n,m;vector<van> g[MaxN];bool used[MaxN];
van dep[MaxN],fa[MaxN],wson[MaxN],siz[MaxN];
van belong[MaxN],dfn[MaxN],back[MaxN],cnt;
void DFS1(van now=1) {
	siz[now]=1;used[now]=1;
	for (int i=0;i<g[now].size();i++) if (!used[g[now][i]]) {
		dep[g[now][i]]=dep[now]+1;
		fa[g[now][i]]=now;
		DFS1(g[now][i]);
		siz[now]+=siz[g[now][i]];
		if (siz[g[now][i]]>siz[wson[now]]) wson[now]=g[now][i];
	}
}
void DFS2(van now=1) {
	used[now]=1,dfn[now]=++cnt,back[cnt]=now;
	if (wson[now]) belong[wson[now]]=belong[now],DFS2(wson[now]);
	for (int i=0;i<g[now].size();i++) if (!used[g[now][i]]) {
		belong[g[now][i]]=g[now][i];
		DFS2(g[now][i]);
	}
}
void CutTree() {
	dep[1]=1;DFS1();memset(used,0,sizeof used);
	DFS2();memset(used,0,sizeof used);
}
struct SegmentTree {
	van dat[MaxN*4],lazytag[MaxN*4];
	void BuildTree(van p=1,van l=1,van r=n) {
		if (l==r) {dat[p]=0;return;}
		van mid=(l+r)>>1;
		BuildTree(p*2,l,mid);BuildTree(p*2+1,mid+1,r);
		dat[p]=dat[p*2]+dat[p*2+1];
	}
	void spread(van p,van ls,van rs) {
		if (lazytag[p]) {
			lazytag[p*2]+=lazytag[p],lazytag[p*2+1]+=lazytag[p];
			dat[p*2]+=lazytag[p]*ls,dat[p*2+1]+=lazytag[p]*rs;
			lazytag[p]=0;
		}
	}
	void AddTree(van L,van R,van num,van p=1,van l=1,van r=n) {
		if (L>R) return;
		if (L<=l&&r<=R) {
			dat[p]+=num*(r-l+1);
			lazytag[p]+=num;return;
		} van mid=(l+r)>>1;
		spread(p,mid-l+1,r-mid);
		if (L<=mid) AddTree(L,R,num,p*2,l,mid);
		if (R>mid) AddTree(L,R,num,p*2+1,mid+1,r);
		dat[p]=dat[p*2]+dat[p*2+1];
	}
	van QueryTree(van L,van R,van p=1,van l=1,van r=n) {
		if (L>R) return 0;
		if (L<=l&&r<=R) return dat[p];
		van sum=0,mid=(l+r)>>1;spread(p,mid-l+1,r-mid);
		if (L<=mid) sum+=QueryTree(L,R,p*2,l,mid);
		if (R>mid) sum+=QueryTree(L,R,p*2+1,mid+1,r);
		return sum;
	}
}T;
void Update(van l,van r) {
	while (belong[l]!=belong[r]) {
		if (dep[belong[l]]>dep[belong[r]]) {
			T.AddTree(dfn[belong[l]],dfn[l],1);
			l=fa[belong[l]];
		} else {
			T.AddTree(dfn[belong[r]],dfn[r],1);
			r=fa[belong[r]];
		}
	} if (dep[l]>dep[r]) T.AddTree(dfn[r]+1,dfn[l],1);
	else T.AddTree(dfn[l]+1,dfn[r],1);
}
van Query(van l,van r) {
	van sum=0;while (belong[l]!=belong[r]) {
		if (dep[belong[l]]>dep[belong[r]]) {
			sum+=T.QueryTree(dfn[belong[l]],dfn[l],1);
			l=fa[belong[l]];
		} else {
			sum+=T.QueryTree(dfn[belong[r]],dfn[r],1);
			r=fa[belong[r]];
		}
	} if (dep[l]>dep[r]) sum+=T.QueryTree(dfn[r]+1,dfn[l]);
	else sum+=T.QueryTree(dfn[l]+1,dfn[r]); return sum;
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(n),read(m);
	for (int i=1;i<n;i++) {
		van f,s;read(f),read(s);
		g[f].push_back(s);
		g[s].push_back(f);
	} CutTree();T.BuildTree();
	for (int i=1;i<=m;i++) {
		char op=getchar();van l,r;read(l),read(r);
		if (op=='P') Update(l,r);
		else print(Query(l,r)),putchar('\n'); 
	}
	return 0;
}
