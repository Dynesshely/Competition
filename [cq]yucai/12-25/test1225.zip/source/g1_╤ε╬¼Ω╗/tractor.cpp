#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
T read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) {
		b*=10,b+=ch-'0',ch=getchar();
	} x=f*b;return x;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[110]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	while (top) putchar(st[top--]+'0');
	return;
}
const van MaxN=510;
van n,d[MaxN][MaxN];bool used[MaxN][MaxN];
van VanGo[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
van ans=0;
bool in(van x,van y) {
	return x>0&&y>0&&x<=n&&y<=n;
}
void DFS(van x,van y,van lim) {
	if (used[x][y]) return;
	ans++;used[x][y]=1;
	for (int i=0;i<4;i++) {
		van xx=x+VanGo[i][0],yy=y+VanGo[i][1];
		if (!in(xx,yy)) continue;
		if (abs(d[xx][yy]-d[x][y])>lim) continue;
		DFS(xx,yy,lim);
	}
}
bool check(van num) {
	van goal=(n*n%2?n*n/2+1:n*n/2),res=0;
	memset(used,0,sizeof used);
	for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) 
		if (!used[i][j]) {
			ans=0,DFS(i,j,num);
			res=max(res,ans);
		}
//	cout<<num<<" "<<goal<<" "<<res<<endl;
	return res>=goal;
}
int main() {
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	read(n);for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) read(d[i][j]);
	van l=0,r=1e18,ans=1e18;
	while (l<=r) {
		van mid=(l+r)>>1;
		if (check(mid)) r=mid-1,ans=mid;
		else l=mid+1;
	} print(ans);
	return 0;
}

