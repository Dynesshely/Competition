#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
T read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) {
		b*=10,b+=ch-'0',ch=getchar();
	} x=f*b;return x;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[110],top=0;
	while (x) st[++top]=x%10,x/=10;
	while (top) putchar(st[top--]+'0');
	return; 
}
const van MaxN=1e6+10;
bool b[MaxN];van top=0,res[MaxN];
int main() {
	freopen("base.in","r",stdin);
	van n;read(n);van m=abs(n);
	while (m) b[++top]=m%2,m/=2;
//	for (van i=1;i<=top;i++) cout<<b[i];
	for (van i=1;i<=top;i++) {
		if (n<0) {
			res[i]+=b[i];
			if (i%2==1) res[i+1]+=b[i],top=max(top,i+1);
		} else {
			res[i]+=b[i];
			if (i%2==0) res[i+1]+=b[i],top=max(top,i+1);
		}
	} for (van i=1;i<=top;i++) {
		if (res[i]<=1) continue;
//		cout<<res[i]<<" "<<res[i+1]<<" "<<res[i+2]<<" ";
		van x=res[i]/2;res[i]%=2;van num=min(x,res[i+1]);
		x-=num,res[i+1]-=num;
//		cout<<i<<" "<<x<<" "<<res[i]<<endl;
		res[i+1]+=x,res[i+2]+=x,top=max(top,i+2);
	} freopen("base.out","w",stdout);
	for (int i=top;i>=1;i--) putchar('0'+res[i]);
	return 0;
}
