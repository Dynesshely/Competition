#include<bits/stdc++.h>
using namespace std;
typedef long long van;
template<typename T> inline
T read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) {
		b*=10,b+=ch-'0',ch=getchar();
	} x=f*b;return x;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[110]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	while (top) putchar(st[top--]+'0');
	return;
}
const van MaxN=110;
van p,b1,b2,r;
van res[MaxN][MaxN];
van bases=5;
struct w {
	van x,y,t;van area;
	w(van x,van y,van t):x(x),y(y),t(t){};
};
vector<w> waves;
van a[MaxN][MaxN];
int main() {
	freopen("waves.in","r",stdin);
	read(p),read(b1),read(b2),read(r);
	if (b1>b2) swap(b1,b2);
	for (int i=1;i<=p;i++) {
		van x,y,t;read(x),read(y),read(t);
		waves.push_back(w(x,y,t));
		if (x<b1) waves.push_back(w(b1-1,y,b1-x+t));
		else if (x>b2) waves.push_back(w(b2+1,y,x-b2+t));
		else { van xback=x; 
			van tnow=t;bool left=true;while (tnow<=r) { left=1-left;
				if (left) waves.push_back(w(b1+1,y,x-b1+tnow)),tnow+=x-b1,x=b1;
				else waves.push_back(w(b2-1,y,b2-x+tnow)),tnow+=b2-x,x=b2;
			} tnow=t,x=xback,left=false;while (tnow<=r) { left=1-left;
				if (left) waves.push_back(w(b1+1,y,x-b1+tnow)),tnow+=x-b1,x=b1;
				else waves.push_back(w(b2-1,y,b2-x+tnow)),tnow+=b2-x,x=b2;
			} 
		}
	} 
	for (int i=-4;i<=4;i++) for (int j=-4;j<=4;j++)
		if (i<b1) a[i+bases][j+bases]=0; 
		else if (i<b2) a[i+bases][j+bases]=1; 
		else a[i+bases][j+bases]=2;
	for (int i=0;i<waves.size();i++)
		if (waves[i].x<b1) waves[i].area=0; 
		else if (waves[i].x<b2) waves[i].area=1; 
		else waves[i].area=2;
	for (int i=-4;i<=4;i++) for (int j=-4;j<=4;j++) {
		for (int k=0;k<waves.size();k++) {
//			if (i==0&&j==-2) cout<<res[i+bases][j+bases]<<endl;
			if (waves[k].area!=a[i+bases][j+bases]) continue;
			van d=abs(i-waves[k].x)+abs(j-waves[k].y);
			if (waves[k].t+d>r) continue;
			van lst=r-waves[k].t-d;
			if (lst%2==1) continue;
			if ((lst/2)%2==0) res[i+bases][j+bases]++;
			else res[i+bases][j+bases]--;
		}
	}
//	for (int i=-4;i<=4;i++) {
//		for (int j=-4;j<=4;j++) {
//			print(res[j+bases][i+bases]),putchar(' ');
//		} putchar('\n');
//	}
	freopen("waves.out","w",stdout);
	for (int i=4;i>=-4;i--) {
		for (int j=-4;j<=4;j++) {
			if (j==b1||j==b2) putchar('X');
			else if (res[j+bases][i+bases]==0) putchar('-');
			else if (res[j+bases][i+bases]>0) putchar('*');
			else putchar('o');
		} putchar('\n');
	}
//	for (int i=0;i<waves.size();i++) {
//		cout<<waves[i].x<<" "<<waves[i].y<<" "<<waves[i].t<<endl;
//	}
	return 0;
}

