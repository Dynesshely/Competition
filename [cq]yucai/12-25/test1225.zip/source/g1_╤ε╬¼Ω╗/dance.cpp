#include<bits/stdc++.h>
#define mk make_pair
using namespace std;
typedef long long van;
template<typename T> inline
void read(T& x) {
	T f=1,b=0;char ch=getchar();
	while (!isdigit(ch)) {
		if (ch=='-') f=-1;
		ch=getchar();
	} while (isdigit(ch)) {
		b*=10,b+=ch-'0',ch=getchar();
	} x=f*b;return;
}
template<typename T> inline
void print(T x) {
	if (x<0) putchar('-'),x=-x;
	if (x==0) {putchar('0');return;}
	van st[110]={0},top=0;
	while (x) st[++top]=x%10,x/=10;
	while (top) putchar(st[top--]+'0');
	return;
}
const van MaxN=31;
van n,m,ma[MaxN][MaxN];
van sx,sy,ex,ey,d,ans;bool ar=false;
van f[MaxN][MaxN],num[MaxN][MaxN];
van VanGo[8][2]={{-2,1},{-2,-1},{-1,2},{-1,-2},{1,2},{1,-2},{2,1},{2,-1}};
deque<pair<pair<van,van>,van> > q;
bool in(van x,van y) {
	return x>0&&y>0&&x<=n&&y<=m;
}
int main() {
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	read(n),read(m);
	for (int i=1;i<=n;i++) for (int j=1;j<=m;j++) read(ma[i][j]);
	for (int i=1;i<=n;i++) for (int j=1;j<=m;j++) {
		if (ma[i][j]==3) sx=i,sy=j;
		if (ma[i][j]==4) ex=i,ey=j;
	} memset(f,0x3f,sizeof f);q.push_back(mk(mk(sx,sy),0));
	num[sx][sy]=1;f[ex][ey]=1e18;
	while (!q.empty()) {
		van x=q.front().first.first,y=q.front().first.second,s=q.front().second;q.pop_front();
		if (f[x][y]<s) continue;
//		cout<<s<<endl;
//		cout<<x<<" "<<y<<" "<<s<<" "<<num[x][y]<<endl;
		if (x==ex&&y==ey) break;
		for (int i=0;i<8;i++) {
			van xx=x+VanGo[i][0],yy=y+VanGo[i][1];
			if (!in(xx,yy)) continue;
//			cout<<f[xx][yy]<<" "<<xx<<" "<<yy<<" "<<s<<endl;
			if (ma[xx][yy]==2) continue;
			if (ma[xx][yy]==1&&s<=f[xx][yy]) {
				if (s<f[xx][yy]) {
					f[xx][yy]=s,num[xx][yy]=num[x][y];
					q.push_front(mk(mk(xx,yy),s));
				}
				else num[xx][yy]+=num[x][y];
			}
			else if (s+1<=f[xx][yy]){
				if (s+1<f[xx][yy]) {
					f[xx][yy]=s+1,num[xx][yy]=num[x][y];
					q.push_back(mk(mk(xx,yy),s+1));
				}
				else num[xx][yy]+=num[x][y];
			}
		}
	} 
	if (f[ex][ey]!=1e18) print(f[ex][ey]-1),putchar('\n'),print(num[ex][ey]);
	else print(-1);
	return 0;
}

