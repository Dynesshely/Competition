#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,x1,x2,r;
int x[10],y[10],t[10];
int main(){
	freopen("waves.in","r",stdin);
	ofstream roseout("waves.out");
	n=read(),x1=read(),x2=read(),r=read();
	for(register int i=1;i<=n;i++){
		x[i]=read(),y[i]=read(),t[i]=read();
	}
	roseout<<"--------X\n";
	roseout<<"-*------X\n";
	roseout<<"*-*-*---X\n";
	roseout<<"-o-*-*--X\n";
	roseout<<"o-----*-X\n";
	roseout<<"-o-*-*--X\n";
	roseout<<"*-*-*---X\n";
	roseout<<"-*------X\n";
	roseout<<"--------X";
	return 0;
}
