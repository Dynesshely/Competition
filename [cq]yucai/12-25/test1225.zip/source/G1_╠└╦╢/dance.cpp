#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int dx[]={2,2,1,-1,-2,-2,-1,1};
int dy[]={1,-1,-2,-2,-1,1,2,2};
int n,m;
int s,t;
int maze[35][35];
int head[20005],to[20005],nxt[20005],val[20005],tot=0;
int dist[20005];
bool vis[20005];
long long dp[905][905];
void add(int u,int v,int w){
	tot++;
	to[tot]=v;
	val[tot]=w;
	nxt[tot]=head[u];
	head[u]=tot;
}
bool in(int x,int y){ return 1<=x&&x<=n&&1<=y&&y<=m; }
int calc(int x,int y){ return m*(x-1)+y; }
struct node{
	int dis,pos;
	bool operator<(const node& x)const{
		return x.dis<dis;
	} 
};
void Dijsktra(){
	priority_queue<node> q;
	memset(dist,0x3f3f3f3f,sizeof dist);
	dist[s]=0; dp[s][0]=1;
	q.push((node){0,s});
	while(!q.empty()){
		int x=q.top().pos; q.pop();
		if(vis[x]) continue;
		if(x==t) return;//һ��С�Ż� 
		vis[x]=true;
		for(register int i=head[x];i;i=nxt[i]){
			int u=to[i],v=val[i];
			if(dist[u]>=dist[x]+v){
				dist[u]=dist[x]+v;
				dp[u][dist[u]]+=dp[x][dist[x]];
				if(!vis[u]) q.push((node){dist[u],u});
			}
		}
	}
}
int main(){
	freopen("dance.in","r",stdin);
	ofstream roseout("dance.out");
	n=read(),m=read();
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			maze[i][j]=read();
			if(maze[i][j]==3) s=calc(i,j);
			if(maze[i][j]==4) t=calc(i,j);
		}
	}
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			for(register int k=0;k<8;k++){
				int tx=i+dx[k],ty=j+dy[k];
				if(in(tx,ty)&&maze[tx][ty]!=2){
					if(maze[tx][ty]==1) add(calc(i,j),calc(tx,ty),0);
					else add(calc(i,j),calc(tx,ty),1);
				}
			}
		}
	}
	Dijsktra();
	if(dist[t]>=1e8){
		roseout<<-1;
		return 0;
	} 
	roseout<<dist[t]-1<<"\n";//�յ㲻��Ҫ 
	roseout<<dp[t][dist[t]];
	return 0;
}
