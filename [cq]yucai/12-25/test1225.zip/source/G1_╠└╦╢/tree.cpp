#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int n,m;
int fa[100005][20],depth[100005],Log[100005];
int dist[100005],delta[100005],num[100005];
int head[100005],to[200005],nxt[200005],tot=0;
int val[100005];
void add(int u,int v){
	tot++;
	to[tot]=v;
	nxt[tot]=head[u];
	head[u]=tot;
}
void init(int now,int father){
	depth[now]=depth[father]+1;
	fa[now][0]=father;
	for(register int i=1;i<=Log[depth[now]];i++)
		fa[now][i]=fa[fa[now][i-1]][i-1];
	for(register int i=head[now];i;i=nxt[i]){
		int u=to[i];
		if(u!=father) init(u,now);
	}
}
int LCA(int x,int y){
	if(depth[x]<depth[y]) swap(x,y);
	while(depth[x]>depth[y])
		x=fa[x][Log[depth[x]-depth[y]]-1];
	if(x==y) return x;
	for(register int i=Log[depth[x]]-1;i>=0;i--){
		if(fa[x][i]!=fa[y][i]){
			x=fa[x][i];
			y=fa[y][i];
		}
	}
	return fa[x][0];
}
void calc(int now,int father){
	for(register int i=head[now];i;i=nxt[i]){
		int u=to[i];
		if(u==father) continue;
		calc(u,now);
		delta[now]+=delta[u];
	}
	num[now]+=delta[now];
}
void dfs(int now,int father){
	dist[now]=num[now]+dist[father];
	for(register int i=head[now];i;i=nxt[i]){
		int u=to[i];
		if(u==father) continue;
		dfs(u,now);
	} 
}
int main(){
	freopen("tree.in","r",stdin);
	ofstream roseout("tree.out");
	n=read(),m=read();
	for(register int i=1;i<n;i++){
		int u=read(),v=read();
		add(u,v); add(v,u);
	}
	for(register int i=1;i<=n;i++) Log[i]=Log[i>>1]+1;
	init(1,0);
	while(m--){
		char op; scanf("%c",&op);
		int x=read(),y=read();
		if(op=='P'){
			delta[x]++; delta[y]++;
			delta[LCA(x,y)]-=2;
		}
		else {
			calc(1,0);
			dfs(1,0);
			roseout<<dist[x]+dist[y]-2*dist[LCA(x,y)]<<"\n";
			memset(delta,0,sizeof delta);
			memset(dist,0,sizeof dist);
		}
	}
	return 0;
}
