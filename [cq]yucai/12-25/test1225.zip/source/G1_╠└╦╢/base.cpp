#include<bits/stdc++.h>
using namespace std;
inline long long read(){
	long long sss=0,www=1;
	char chh=getchar();
	while(chh<'0'||chh>'9') {
		if(chh=='-') www=-1;
		chh=getchar();
	}
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss*www;
}
long long n;
long long vis[1005];
void divide_base_up(long long x){
	for(register long long i=31;i>=0;i--){
		if(x>=(long long)(1LL<<i)){
			x-=(long long)(1LL<<i);
			vis[i]=1;
		}
	}
}
int main(){
	freopen("base.in","r",stdin);
	ofstream roseout("base.out");
	n=read();
	if(n==0){ roseout<<0; return 0; }
	if(n>0){
		divide_base_up(n);
		vector<long long> ans;
		for(register long long i=0;i<=1000;i++){
			if(!vis[i]) ans.push_back(0);
			if(vis[i]){
				if(i%2==0){
					if(vis[i]%2==0){
						vis[i+1]+=vis[i]/2;
						ans.push_back(0);
					}
					else {
						vis[i+1]+=vis[i]/2;
						ans.push_back(1);
					}
				}
				else {
					vis[i+1]+=vis[i]/2;
					if(vis[i]%2){
						vis[i+1]++;
						ans.push_back(1);
					}
					else ans.push_back(0);
				}
			}
		}
		long long len=ans.size();
		for(register long long i=len-1;i>=0;i--){
			if(ans[i]){
				for(register long long j=i;j>=0;j--){
					roseout<<ans[j];
				}
				return 0;
			}
		}
	}
	else {
		divide_base_up(-1*n);
		vector<long long> ans;
		for(register long long i=0;i<=1000;i++){
			if(!vis[i]) ans.push_back(0);
			else {
				if(i%2){
					vis[i+1]+=vis[i]/2;
					ans.push_back(vis[i]%2);
				}
				else {
					vis[i+1]+=vis[i]/2;
					if(vis[i]%2){
						vis[i+1]++;
						ans.push_back(1);
					}
					else ans.push_back(0);
				}
			} 
		}
		long long len=ans.size();
		for(register long long i=len-1;i>=0;i--){
			if(ans[i]){
				for(register long long j=i;j>=0;j--){
					roseout<<ans[j];
				}
				return 0;
			}
		}
	}
	return 0;
}
