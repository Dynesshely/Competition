#include<bits/stdc++.h>
#define par pair<int,int>
using namespace std;
inline int read(){
	int sss=0;
	char chh=getchar();
	while(chh<'0'||chh>'9') chh=getchar();
	while(chh>='0'&&chh<='9'){
		sss=sss*10+chh-'0';
		chh=getchar();
	}
	return sss;
}
int dx[]={0,1,0,-1},dy[]={-1,0,1,0};
int n,sum,cnt=0;
int maze[505][505];
bool vis[505][505];
bool in(int x,int y){ return 1<=x&&x<=n&&1<=y&&y<=n; }
void bfs(int i,int j,int delta){
	queue<par> q;
	q.push(make_pair(i,j));
	while(!q.empty()){
		int x=q.front().first,y=q.front().second; q.pop();
		cnt++; 
		for(register int i=0;i<4;i++){
			int tx=x+dx[i],ty=y+dy[i];
			if(in(tx,ty)&&(!vis[tx][ty])&&(abs(maze[x][y]-maze[tx][ty]))<=delta){
				vis[tx][ty]=true;
				q.push(make_pair(tx,ty));
			}
		}
	}
}
bool check(int x){
	memset(vis,0,sizeof vis);
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			if(!vis[i][j]){
				cnt=0;
				bfs(i,j,x);
				if(cnt>=sum) return true;
			}
		}
	}
	return false;
}
int main(){
	freopen("tractor.in","r",stdin);
	ofstream roseout("tractor.out");
	n=read();
	if((n*n)%2==0) sum=(n*n)/2;
	else sum=((n*n)/2)+1; 
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=n;j++){
			maze[i][j]=read();
		}
	}
	int l=0,r=1000000,mid,ans=1e9;
	while(l<=r){
		mid=(l+r)>>1;
		if(check(mid)){
			ans=min(ans,mid);
			r=mid-1;
		}
		else l=mid+1;
	}
	roseout<<ans;
	return 0;
}
