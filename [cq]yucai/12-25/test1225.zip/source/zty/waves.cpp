#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("waves.in", "r", stdin);
	freopen("waves.out", "w", stdout);
	
	return 0;
}

