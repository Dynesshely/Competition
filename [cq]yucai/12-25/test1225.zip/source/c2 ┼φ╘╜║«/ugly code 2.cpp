#include <bits/stdc++.h>
#define gc getchar
#define it __int128
using namespace std;
int ans[250],flag,wrong;
it _() {
	it x=0,f=0;char ch=gc();
	for(;ch<'0'||ch>'9';ch=gc()) f|=(ch=='-');
	for(;ch>='0'&&ch<='9';ch=gc()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
void __(it x) {
	if(x<0) {putchar('-'),__(-x);return;}
	if(x>9) __(x/10);
	putchar(x%10+'0');
}
it power(int b) {
	it s=1,x=2,cpb=b;
	while(b>=1) {
		if(b&1) s*=x;
		x*=x,b>>=1; 
	}
	return (cpb&1)?-s:s;
}
void work(it x) {
	__(x);putchar('\n');
	if(x==0) return;
	it a=x>0?x:-x;
	int cnt=0,can=0;
	while(a>1) a/=2,cnt++;
	if(ans[cnt]&&ans[cnt+1]) {wrong=1;return ;}
	if(!ans[cnt]) {
		ans[cnt]=1;
		work(x-power(cnt));
		if(wrong) ans[cnt]=0,wrong=0;
		else can=1;
	}
	else {
		cnt++;
		ans[cnt]=1;
		work(x-power(cnt));
		if(wrong) ans[cnt]=0,wrong=0;
		else can=1;
	}
	if(!can) wrong=1;
}
int main() {
//	freopen("base.in","r",stdin);
//	freopen("base.out","w",stdout);
//	__(power(_()));
//	int n,cnt=0;
//	cin>>n;
//	while(n>1) n/=2,cnt++;
//	printf("%d",cnt);
	work(_());
	for(int i=10;i>=0;--i) printf("%d ",ans[i]);
	printf("\n");
	for(int i=120;i>=0;--i) {
		if(flag) putchar(ans[i]+'0');
		else if(ans[i]) flag=1,putchar('1');
	}
//	__(_());
}
//8:25
