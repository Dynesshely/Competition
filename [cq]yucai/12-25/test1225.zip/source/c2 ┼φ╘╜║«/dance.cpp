#include <bits/stdc++.h>
#define gc getchar
using namespace std;
int _() {
	int x=0,f=0;char ch=gc();
	for(;ch<'0'||ch>'9';ch=gc()) f|=(ch=='-');
	for(;ch>='0'&&ch<='9';ch=gc()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
int main() {
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	n=_(),m=_();
	for(int i=1;i<=n;++i) {
		for(int j=1;j<=m;++j) {
			a[i][j]=_();
		} 
	}
	printf("-1");
}
