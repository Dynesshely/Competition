#include <bits/stdc++.h>
#define gc getchar
//����__int128�������Լ�ֻ�ܴ��int���ڵ��㷨������
#define it __int128
using namespace std;
int ans[250],flag,wrong;
it _() {
	it x=0,f=0;char ch=gc();
	for(;ch<'0'||ch>'9';ch=gc()) f|=(ch=='-');
	for(;ch>='0'&&ch<='9';ch=gc()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
void __(it x) {
	if(x<0) {putchar('-'),__(-x);return;}
	if(x>9) __(x/10);
	putchar(x%10+'0');
}
it power(int b) {
	it s=1,x=2,cpb=b;
	while(b>=1) {
		if(b&1) s*=x;
		x*=x,b>>=1; 
	}
	return (cpb&1)?-s:s;
}
void print(int now) {
	for(int i=now;i>=0;--i) {
		if(flag) putchar(ans[i]+'0');
		else if(ans[i]) flag=1,putchar('1');
	}
}
void work(int now,it x) {
//	printf("<%d> ",now),__(x),putchar('\n');
	if(now>20) return;
	if(x==0) print(now),exit(0);
	ans[now]=0;
	work(now+1,x);
	ans[now]=1;
	work(now+1,x-power(now));
	ans[now]=0;
} 
int main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	memset(ans,0,sizeof(ans));
	work(0,_());
}
//8:25~9:45 
