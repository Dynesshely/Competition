#include <bits/stdc++.h>
#define gc getchar
#define it __int128
using namespace std;
it n,x,bs[250];
int ans[500],flag,fg,wrong;
it _() {
	it x=0,f=0;char ch=gc();
	for(;ch<'0'||ch>'9';ch=gc()) f|=(ch=='-');
	for(;ch>='0'&&ch<='9';ch=gc()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
void __(it x) {
	if(x<0) {putchar('-'),__(-x);return;}
	if(x>9) __(x/10);
	putchar(x%10+'0');
}
it power(int b) {
	it s=1,x=2,cpb=b;
	while(b>=1) {
		if(b&1) s*=x;
		x*=x,b>>=1; 
	}
	return (cpb&1)?-s:s;
}
//ͻȻ���֣������ڸ�ʲô������������������ 
int main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	bs[0]=1;
	for(int i=1;i<=110;++i) 
		bs[i]=bs[i-1]*2;
	n=_();
	x=(n>0)?n:-n;
	for(int i=110;i>=0;--i) {
		if(x>=bs[i]) {
			if(!fg) fg=i;
			ans[i]=1,x-=bs[i];
		}
		if(x==0) break;
	}
//	for(int i=fg;i>=0;--i) printf("%d ",ans[i]);
//	printf("\n");
	for(int i=0;i<=fg;++i) {
		ans[i+1]+=ans[i]/2;
		ans[i]=ans[i]&1;
		if(((i&1)^(n<0))&&ans[i]) ans[i+1]++;
//		printf("i:%d %d i+1:%d %d\n",i,ans[i],i+1,ans[i+1]);
	}
	while(ans[fg+1]) {
		fg++;
		ans[fg+1]+=ans[fg]/2;
		ans[fg]=ans[fg]&1;
		if(((fg&1)^(n<0))&&ans[fg]) ans[fg+1]++;
	}
	for(int i=fg+1;i>=0;--i) {
		if(flag) putchar(ans[i]+'0');
		else if(ans[i]) flag=1,putchar('1');
	}
}
//8:25~9:45 and 11:00~11:32
