//����lca���ӣ� 
//���������� 
//�����������У� 
//���������ʷ֣� 
//���������޴�����ʣ��ҷ����ˣ�
#include <bits/stdc++.h>
#define gc getchar
using namespace std;
const int mxn=1e5+5;
int n,m,u,v,ans,a[mxn],fa[mxn],dp[mxn];
int cnt,nxt[mxn<<1],to[mxn<<1],hed[mxn];
char type;
int _() {
	int x=0,f=0;char ch=gc();
	for(;ch<'0'||ch>'9';ch=gc()) f|=(ch=='-');
	for(;ch>='0'&&ch<='9';ch=gc()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
void Addedge(int x,int y) {
//	printf("%d %d\n",x,y);
	nxt[++cnt]=hed[x],to[cnt]=y,hed[x]=cnt;
	nxt[++cnt]=hed[y],to[cnt]=x,hed[y]=cnt;
}
void Dfs(int x,int p) {
//	printf("%d %d\n",x,p);
	for(int v,i=hed[x];i;i=nxt[i]) {
		if((v=to[i])!=p) {
			fa[v]=x;
			dp[v]=dp[x]+1;
			Dfs(v,x);
		}
	}
}
/*���ǲ�Ҫȥѧ��Щʲô�����ʷ�~*/
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=_(),m=_();
	for(int i=1;i<n;++i) Addedge(_(),_());
	Dfs(1,0);
	memset(a,0,sizeof(a));
	while(m--) {
		cin>>type;
		if(type=='P') {
			u=_(),v=_();
			if(dp[u]<dp[v]) swap(u,v);
			while(dp[u]>dp[v]) a[u]++,u=fa[u];
			while(u!=v) {
//				printf("%d %d\n",u,v);
				a[u]++,a[v]++;
				u=fa[u],v=fa[v];
			}
//			for(int i=1;i<=n;++i) printf("%d ",a[i]);
//			printf("\n");
		}
		else {
			ans=0; 
			u=_(),v=_();
			if(dp[u]<dp[v]) swap(u,v);
			while(dp[u]>dp[v]) ans+=a[u],u=fa[u];
			while(u!=v) {
				ans+=a[u],ans+=a[v];
				u=fa[u],v=fa[v];
			}
			printf("%d\n",ans);
		}
	}
}
/*
4 6
1 4
2 4
3 4
P 2 3
P 1 3
Q 3 4
P 1 4
Q 2 4
Q 1 4
*/
//9:45~10:25
