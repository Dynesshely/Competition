#include <bits/stdc++.h>
using namespace std;
int main() {
	freopen("base.in","w",stdout);
	freopen("dance.in","w",stdout);
	freopen("tree.in","w",stdout);
	freopen("tractor.in","w",stdout);
	freopen("waves.in","w",stdout);
}
//8:25
