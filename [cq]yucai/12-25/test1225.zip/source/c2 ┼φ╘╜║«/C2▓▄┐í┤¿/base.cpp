#include <bits/stdc++.h>
using namespace std;
long long n;
int main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	cin>>n;
	if(n==1) {
		cout<<1;
		return 0;
	}
	if(n==0) {
		cout<<0;
		return 0;
	}
	for(int a=0; a<2; a++) {
		for(int b=0; b<2; b++) {
			if(a*1+b*-2==n) {
				printf("%d%d",b,a);
				return 0;
			}
			for(int c=0; c<2; c++) {
				if(a*1+b*-2+c*4==n) {
					printf("%d%d%d",c,b,a);
					return 0;
				}
				for(int d=0; d<2; d++) {
					if(a*1+b*-2+c*4+d*-8==n) {
						printf("%d%d%d%d",d,c,b,a);
						return 0;
					}
					for(int e=0; e<2; e++) {
						if(a*1+b*-2+c*4+d*-8+e*16==n) {
							printf("%d%d%d%d%d",e,d,c,b,a);
							return 0;
						}
						for(int f=0; f<2; f++) {
							if(a*1+b*-2+c*4+d*-8+e*16+f*-32==n) {
								printf("%d%d%d%d%d%d",f,e,d,c,b,a);
								return 0;
							}
							for(int g=0; g<2; g++) {
								if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64==n) {
									printf("%d%d%d%d%d%d%d",g,f,e,d,c,b,a);
									return 0;
								}
								for(int h=0; h<2; h++) {
									if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128==n) {
										printf("%d%d%d%d%d%d%d%d",h,g,f,e,d,c,b,a);
										return 0;
									}
									for(int i=0; i<2; i++) {
										if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256==n) {
											printf("%d%d%d%d%d%d%d%d%d",i,h,g,f,e,d,c,b,a);
											return 0;
										}
										for(int k=0; k<2; k++) {
											if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512==n) {
												printf("%d%d%d%d%d%d%d%d%d%d",k,i,h,g,f,e,d,c,b,a);
												return 0;
											}
											for(int l=0; l<2; l++) {
												if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024==n) {
													printf("%d%d%d%d%d%d%d%d%d%d%d",l,k,i,h,g,f,e,d,c,b,a);
													return 0;
												}
												for(int m=0; m<2; m++) {
													if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048==n) {
														printf("%d%d%d%d%d%d%d%d%d%d%d%d",m,l,k,i,h,g,f,e,d,c,b,a);
														return 0;
													}
													for(int o=0; o<2; o++) {
														if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096==n) {
															printf("%d%d%d%d%d%d%d%d%d%d%d%d%d",o,m,l,k,i,h,g,f,e,d,c,b,a);
															return 0;
														}
														for(int p=0; p<2; p++) {
															if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192==n) {
																printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d",p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																return 0;
															}
															for(int q=0; q<2; q++) {
																if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384==n) {
																	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																	return 0;
																}
																for(int r=0; r<2; r++) {
																	if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768==n) {
																		printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																		return 0;
																	}
																	for(int s=0; s<2; s++) {
																		if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536==n) {
																			printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																			return 0;
																		}
																		for(int t=0; t<2; t++) {
																			if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072==n) {
																				printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);

																				return 0;
																			}
																			for(int u=0; u<2; u++) {
																				if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144==n) {
																					printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																					return 0;
																				}
																				for(int v=0; v<2; v++) {
																					if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144+v*-524288==n) {
																						printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",v,u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																						return 0;
																					}
																					for(int w=0; w<2; w++) {
																						if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144+v*-524288+w*1048576==n) {
																							printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",w,v,u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																							return 0;
																						}
																						for(int x=0; x<2; x++) {
																							if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144+v*-524288+w*1048576+x*-2097152==n) {
																								printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",x,w,v,u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																								return 0;
																							}
																							for(int y=0; y<2; y++) {
																								if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144+v*-524288+w*1048576+x*-2097152+y*4197304==n) {
																									printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",y,x,w,v,u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																									return 0;
																								}
																								for(int z=0; z<2; z++) {
																									if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144+v*-524288+w*1048576+x*-2097152+y*4197304+z*-8388608==n) {
																										printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",z,y,x,w,v,u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																										return 0;
																									}
																									for(int aa=0; aa<2; aa++) {
																										if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144+v*-524288+w*1048576+x*-2097152+y*4197304+z*-8388608+aa*16777216==n) {
																											printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",aa,z,y,x,w,v,u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																											return 0;
																										}
																										for(int bb=0; bb<2; bb++) {
																											if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144+v*-524288+w*1048576+x*-2097152+y*4197304+z*-8388608+aa*16777216+bb*-33554432==n) {
																												printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",bb,aa,z,y,x,w,v,u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																												return 0;
																											}
																											for(int cc=0; cc<2; cc++) {
																												if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144+v*-524288+w*1048576+x*-2097152+y*4197304+z*-8388608+aa*16777216+bb*-33554432+cc*-67108864==n) {
																													printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",cc,bb,aa,z,y,x,w,v,u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																													return 0;
																												}
																												for(int xx=1; xx<2; xx++) {
																													if(a*1+b*-2+c*4+d*-8+e*16+f*-32+g*64+h*-128+i*256+k*-512+l*1024+m*-2048+o*4096+p*-8192+q*16384+r*-32768+s*65536+t*-131072+u*262144+v*-524288+w*1048576+x*-2097152+y*4197304+z*-8388608+aa*16777216+bb*-33554432+cc*-67108864+xx*134217728==n) {
																														printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",xx,cc,bb,aa,z,y,x,w,v,u,t,s,r,q,p,o,m,l,k,i,h,g,f,e,d,c,b,a);
																														return 0;
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
