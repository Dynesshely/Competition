#include <bits/stdc++.h>
using namespace std;
int n,m;
int f[4][2]={{2,1},{2,-1},{-2,1},{-2,-1}};
int a[31][31],b[31][31],ans=10000006;
void dfs(int x,int y,int sum)
{
 	b[x][y]=1; 
	if(a[x][y]==4)
	{
		ans=min(ans,sum);
		return;
	}
	for(int c=0;c<4;c++)
	{
		int X=x+f[c][0],Y=y+f[c][1];
		if(X>0&&X<n&&Y>0&&Y<m&&a[X][Y]!=2&&b[X][Y]==0)
		{
			dfs(X,Y,sum+1);
			b[x][y]=0;
		}
	}
	return;
}
int main()
{
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	int r,mm,zdx,zdy;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{	
			scanf("%d",&a[i][j]);
			if(a[i][j]==3) r=i,mm=j;
			if(a[i][j]==4) zdx=i,zdy=j;
		}
	//dfs(r,mm,0);
	cout<<-1;
} 
