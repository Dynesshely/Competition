#include <bits/stdc++.h>
#define gc getchar
using namespace std;
int p,b1,b2,r,x,y,t;
int _() {
	int x=0,f=0;char ch=gc();
	for(;ch<'0'||ch>'9';ch=gc()) f|=(ch=='-');
	for(;ch>='0'&&ch<='9';ch=gc()) x=(x<<1)+(x<<3)+(ch^48);
	return f?-x:x;
}
int main() {
	freopen("waves.in","r",stdin);
	freopen("waves.out","w",stdout);
	p=_(),b1=_(),b2=_(),r=_();
	for(int i=1;i<=p;++i) 
		x=_(),y=_(),t=_();
	for(int i=1;i<=9;++i) {
		for(int j=1;j<=9;++j) 
			putchar('-');
		putchar('\n');
	} 
	//����һ̲��������ˮ����紵���������� 
}
