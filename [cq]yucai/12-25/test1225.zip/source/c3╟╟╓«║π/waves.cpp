#include <bits/stdc++.h>
using namespace std;
int P,B1,B2,R;
int x[20],y[20],t[20],v[20];
int ans[20][20];
inline int abss(int a) {return a>0?a:-a;} 
inline int d(int a1,int b1,int a2,int b2) {
	return abss(a1-a2)+abss(b1-b2);
}
int suan(int a,int b,int num) {
	if(a<B1&&x[num]<B1) {
		if(d(a,b,x[num],y[num])==R-t[num]||d(B1-a+B1-1,b,x[num],y[num])==R-t[num]) return v[num];
		return 0;
	} else if(a>B1&&a<B2&&x[num]>B1&&x[num]<B2) {
		if(d(a,b,x[num],y[num])==R-t[num]) return v[num];
		if(d(B1-a+B1+1,b,x[num],y[num])==R-t[num]) return v[num];
		if(d(B2-a+B2-1,b,x[num],y[num])==R-t[num]) return v[num];
		return 0;
	} else if(a>B2&&x[num]>B2) {
		if(d(a,b,x[num],y[num])==R-t[num]||d(B2-a+B2+1,b,x[num],y[num])==R-t[num]) return v[num];
		return 0;
	}
	return 0;
}
void print() {
	for(int i=-4;i<=4;i++) {
		for(int j=-4;j<=4;j++) {
			int yu=0;
			for(int k=1;k<=P*2;k++) yu+=suan(i,j,k);
			ans[4-j][i+4]=yu;
			if(i==B1||i==B2) ans[4-j][i+4]=1e9;
		}
	}
	for(int i=0;i<9;i++) {
		for(int j=0;j<9;j++) {
			if(ans[i][j]==1e9) printf("X");
			else if(ans[i][j]>0) printf("*");
			else if(ans[i][j]==0) printf("-");
			else printf("o");
		}
		printf("\n");
	}
}
int main() {
	freopen("waves.in","r",stdin);
	freopen("waves.out","w",stdout);
	scanf("%d%d%d%d",&P,&B1,&B2,&R);
	if(B1>B2) swap(B1,B2);
	for(int i=1;i<=P;i++) scanf("%d%d%d",&x[i],&y[i],&t[i]);
	for(int i=1;i<=P;i++) {x[i+P]=x[i];y[i+P]=y[i];t[i+P]=t[i]+2;v[i]=1;v[i+P]=-1;}
	print();
	return 0;
}
