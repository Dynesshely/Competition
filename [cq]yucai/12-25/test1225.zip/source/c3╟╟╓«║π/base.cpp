#include <bits/stdc++.h>
using namespace std;
int n;
vector<int> ans;
int main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%d",&n);
	while(n!=0) {
		if(n%2!=0) {ans.push_back(1);n--;}
		else ans.push_back(0);
		n/=2;n=-n;
	}
	for(int i=ans.size()-1;i>=0;i--) printf("%d",ans[i]);
	if(ans.size()==0) printf("0");
	printf("\n");
	return 0;
}
