#include <bits/stdc++.h>
using namespace std;
int n,f[520][520],shu;
bool vis[520][520];
inline int abss(int D) {return D>0?D:-D;} 
void sou(int x,int y,int D) {
	if(vis[x][y]) return;
	vis[x][y]=1;shu++;
	if(abss(f[x-1][y]-f[x][y])<=D) sou(x-1,y,D);
	if(abss(f[x+1][y]-f[x][y])<=D) sou(x+1,y,D);
	if(abss(f[x][y-1]-f[x][y])<=D) sou(x,y-1,D);
	if(abss(f[x][y+1]-f[x][y])<=D) sou(x,y+1,D);
}
bool check(int D) {
	int maxx=0;
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) vis[i][j]=false;
	}
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) {
			if(vis[i][j]) continue;
			shu=0;sou(i,j,D);maxx=max(maxx,shu);
		}
	}
	if(maxx>(n*n/2)) return true;
	return false;
}
int main() {
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<=n+1;i++) f[0][i]=f[n+1][i]=f[i][0]=f[i][n+1]=1e9;
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) scanf("%d",&f[i][j]);
	}
	int l=0,r=1000010,mid;
	while(r-l>1) {
		mid=(l+r)/2;
		if(check(mid)) r=mid;
		else l=mid;
	}
	if(check(l)) printf("%d\n",l);
	else printf("%d\n",r);
	return 0;
}
