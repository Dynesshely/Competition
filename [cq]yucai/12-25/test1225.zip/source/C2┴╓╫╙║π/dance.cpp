#include<bits/stdc++.h>
using namespace std;
int n,m,a[32][32],xx,yy,x,y,ans,b[32][32];
int wc[8][2]= {{1,2},{-1,2},{1,-2},{-1,-2},{-2,1},{-2,-1},{2,1},{2,-1}};
struct ll
{
	int a,b;
};
queue<ll> q;
int main()
{
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=n; ++i) for(int j=1; j<=m; ++j)
		{
			scanf("%d",&a[i][j]),b[i][j]=1e7;
			if(a[i][j]==3) q.push((ll)
			{
				i,j
			}),b[i][j]=0;
			if(a[i][j]==4) xx=i,yy=j;
		}
	while(!q.empty())
	{
		x=q.front().a,y=q.front().b;
		q.pop();
		if(x==xx&&y==yy) continue;
		for(int i=0; i<=7; ++i)
			if(x+wc[i][0]>0 && y+wc[i][1]>0 && y+wc[i][1]<=m && x+wc[i][0]<=n && a[x+wc[i][0]][y+wc[i][1]]!=2)
			{
				if(b[x+wc[i][0]][y+wc[i][1]]==b[x][y]+(a[x+wc[i][0]][y+wc[i][1]]==0?1:0) && a[x+wc[i][0]][y+wc[i][1]]==4) ++ans;
				if(b[x+wc[i][0]][y+wc[i][1]]>b[x][y]+(a[x+wc[i][0]][y+wc[i][1]]==0?1:0))
				{
					b[x+wc[i][0]][y+wc[i][1]]=b[x][y]+(a[x+wc[i][0]][y+wc[i][1]]==0?1:0),q.push((ll)
					{
						x+wc[i][0],y+wc[i][1]
					});
					if(a[x+wc[i][0]][y+wc[i][1]]==4) ans=1;
				}
			}
	}
	printf("%d\n%d",b[xx][yy],ans);
	return 0;
}
