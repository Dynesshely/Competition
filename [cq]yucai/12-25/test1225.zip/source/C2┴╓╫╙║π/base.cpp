#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[40]={1,-2,5,-10,21,-42,85,-170,341,-682,1365,-2730,5461,-10922,21845,-43690,87381,-174762,349525,-699050,1398101,-2796202,5592405,-11184810,22369621,-44739242,89478485,-178956970,357913941,-715827882,1431655765,-2863311530,5726623061},i;
bool f,ans[40];
void hanshu(int w,int now)
{
	if(w==-1 && now==n)
	{
		for(int j=i; j>=0; --j) cout<<ans[j];
		f=1;
	}
	if(w==-1 || f==1) return;
	int c=(2<<(w-1))*(w%2==0?1:-1);
	if(w==0) c=1;
	ans[w]=1,hanshu(w-1,now+c),ans[w]=0,hanshu(w-1,now);
}
signed main()
{
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%lld",&n);
	for(i=0; (n<0?a[i]>n:a[i]<n); ++i);
	hanshu(i,0);
	return 0;
}
