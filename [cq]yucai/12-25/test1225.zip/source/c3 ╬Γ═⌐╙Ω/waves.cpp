#include<bits/stdc++.h>
using namespace std;

int P,B1,B2,R,Map[410][410];

void Print(){
	for(int i=196;i<=204;i++){
		for(int j=196;j<=204;j++){
			if(Map[i][j]==2) putchar('X');
			else if(Map[i][j]==0) putchar('-'); 
			else if(Map[i][j]==1) putchar('*');
			else putchar('o');
		}
		puts("");
	}
}

void Solve1(){
	int X,Y,T;
	scanf("%d %d %d",&X,&Y,&T),X+=200,Y+=200;
	if(B1>B2) swap(B1,B2);
	int len1=X-B1-1,len2=B2-X-1,tim=R-T;
	tim++;
	if(len1>=tim&&len2>=tim){
		for(int i=X-tim;i<=X+tim;i++){
			if(i==X-tim||i==X+tim) Map[i][Y]=1;
			int tmp=tim-abs(X-i);
			Map[i][Y-tmp]=Map[i][Y+tmp]=1;
		}
	}
	else {
		for(int i=X-tim;i<=X+tim;i++){
			if(i==X-tim||i==X+tim) Map[i][Y]=1;
			int tmp=tim-abs(X-i);
			Map[i][Y-tmp]=Map[i][Y+tmp]=1;
		}
//	for(int i=196;i<=204;i++){
//		for(int j=196;j<=204;j++) cout<<Map[i][j]<<" ";
//		puts("\n");
//	}
		if(Y-tim<B1) for(int j=0;j<=400;j++)
			for(int i=Y-tim;i<=B1;i++) if(Map[j][i]==1)
				Map[j][B1+(B1-i)+1]=1,Map[j][i]=0;
		else if(Y+tim>B1){
			for(int j=0;j<=400;j++) for(int i=Y+tim;i>=B2;i--)
				if(Map[i][j]==1) Map[B2-(i-B2+1)][j]=1,Map[i][j]=0;
		}
	}
//	for(int i=196;i<=204;i++){
//		for(int j=196;j<=204;j++) cout<<Map[i][j]<<" ";
//		puts("");
//	}
	tim-=2;
	if(len1>=tim&&len2>=tim){
		for(int i=X-tim;i<=X+tim;i++){
			if(i==X-tim||i==X+tim) Map[i][Y]--;
			int tmp=tim-abs(X-i);
			Map[i][Y-tmp]--,Map[i][Y+tmp]--;
		}
	}
	else {
		for(int i=X-tim;i<=X+tim;i++){
			if(i==X-tim||i==X+tim) Map[i][Y]=-1;
			int tmp=tim-abs(X-i);
			Map[i][Y-tmp]=Map[i][Y+tmp]=-1;
		}
		if(Y-tim<B1) for(int j=0;j<=400;j++)
			for(int i=Y-tim;i<=B1;i++) if(Map[i][j]==-1)
				Map[B1+(B1-i)+1][j]=(Map[2*B1-i+1][j]==1?0:-1),Map[i][j]=0;
		else if(Y+tim>B1){
			for(int j=0;j<=400;j++) for(int i=Y+tim;i>=B2;i--)
				if(Map[i][j]==-1) Map[B2-(i-B2+1)][j]=(Map[2*B2-i-1][j]==1?0:-1),Map[i][j]=0;
		}
	}
	for(int i=0;i<=400;i++) Map[i][B1]=Map[i][B2]=2;
	Print(); 
}

void Solve2(){
	for(int i=1;i<=9;i++) puts("---------");
}

int main(){
	freopen("waves.in","r",stdin);
	freopen("waves.out","w",stdout);
	scanf("%d %d %d %d",&P,&B1,&B2,&R); B1+=200, B2+=200;
	if(P==1) Solve1();
	else Solve2();
	return 0;
} 
