#include<bits/stdc++.h>
using namespace std;
#define int long long

int N,num[30],sum[30],cs;
vector<int> ans;

void Solve1(){
	num[1]=sum[1]=1;
	for(int i=2;i<16;i++) num[i]=num[i-1]*4;
	for(int i=2;i<16;i++) sum[i]=sum[i-1]+num[i];//,cout<<i<<" "<<num[i]<<" "<<sum[i]<<"\n";
//	cout<<sum[15]<<"\n";
//	while(N>=0) cs++,N-=num[cs];
	int l=1,r=15,tmp=0,mid;
	while(l<=r) {
		mid=((l+r)>>1);
//		cout<<l<<" "<<r<<" "<<mid<<"\n";
//		cout<<sum[l]<<" "<<N<<"\n";
		if(sum[mid]>N) r=mid-1;//,cout<<r<<" "<<"Here\n";
		else tmp=mid,l=mid+1;//,cout<<"QQQQQQWQQQQQQ\n";
	}
//	N--;
//	cout<<tmp<<"\n";
	N-=sum[tmp];
//	cout<<N<<"\n";
	for(int i=tmp;i;i--)
		ans.push_back(N%4),N=(N-1)/4+1;//,cout<<N<<" ";puts("");
//	while(N>0) ans.push_back(N/4),N/=4;
//	for(int i=0;i<ans.size();i++) cout<<ans[i]<<" ";puts("");
	printf("1");
	for(int i=ans.size()-1;~i;i--){
		if(ans[i]==1) printf("10");
		else if(ans[i]==2) printf("11");
		else if(ans[i]==3) printf("00");
		else printf("01");
	}
}

void Solve2(){
	num[1]=sum[1]=2;
	for(int i=2;i<16;i++) num[i]=num[i-1]*4;
	for(int i=2;i<16;i++) sum[i]=sum[i-1]+num[i];//,cout<<i<<" "<<num[i]<<" "<<sum[i]<<"\n";
	if(N==-1) { printf("11"); return; }
	if(N==-2) { printf("10"); return; }
	int l=1,r=15,tmp=0,mid,now=-N;
	while(l<=r){
		mid=((l+r)>>1);
		if(sum[mid]>now) r=mid-1;
		else tmp=mid,l=mid+1;
	}
	N=-N;
//	cout<<tmp<<"\n";
	N-=sum[tmp];
//	cout<<N<<"\n";
	for(int i=tmp;i;i--) ans.push_back(N%4),N=(N-1)/4+1;//,cout<<N<<" ";puts("");
//	for(int i=0;i<ans.size();i++) cout<<ans[i]<<" ";puts("");
	if(N==1) printf("11");
	else printf("10");
	for(int i=ans.size()-1;~i;i--){
		if(ans[i]%4==1) printf("01");
		else if(ans[i]%4==2) printf("00");
		else if(ans[i]%4==3) printf("11");
		else printf("10");
	}
}

signed main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%lld",&N);
	if(N>0) Solve1();
	else Solve2();
	return 0;
} 

