#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	puts("0");
	return 0;
} 
