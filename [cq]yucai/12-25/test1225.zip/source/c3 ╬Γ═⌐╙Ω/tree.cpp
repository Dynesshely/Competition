#include<bits/stdc++.h>
using namespace std;

const int Maxn=1e5+10;
char ch;
int N,M,hed[Maxn],cnt,num[Maxn],deep[Maxn],sum[5010][5010];
int heavy[Maxn],top[Maxn],fa[Maxn],siz[Maxn];
struct node{
	int nxt,to;
}G[Maxn<<1];

void Addedge(int x,int y){
	G[++cnt].nxt=hed[x]; G[cnt].to=y; hed[x]=cnt;
}

void DFS1(int x,int p){
	fa[x]=p; siz[x]=1; deep[x]=deep[p]+1;
	for(int y,i=hed[x];i;i=G[i].nxt){
		if((y=G[i].to)==p) continue;
		DFS1(y,x); siz[x]+=siz[y];
		if(siz[y]>siz[heavy[x]]) heavy[x]=y;
	}
}

void DFS2(int x,int t){
	top[x]=t;
	if(!heavy[x]) return;
	DFS2(heavy[x],t);
	for(int y,i=hed[x];i;i=G[i].nxt){
		if((y=G[i].to)==fa[x]||y==heavy[x]) continue;
		DFS2(y,y);
	}
}

int Get_lca(int x,int y){
	while(top[x]!=top[y]){
		if(deep[x]<deep[y]) swap(x,y);
		x=fa[top[x]];
	}
	return (deep[x]<deep[y]?x:y);
}

void Add(int x,int y){ while(x!=y) sum[x][fa[x]]++,x=fa[x]; }

int Count(int x,int y){
	int ret=0;
	while(x!=y) ret+=sum[x][fa[x]],x=fa[x];
	return ret;
}

void Solve1(){
	while(M--){
		int x,y; cin>>ch; scanf("%d %d",&x,&y);
		int LCA=Get_lca(x,y);
		if(ch=='P') Add(x,LCA),Add(y,LCA);
		else if(ch=='Q') printf("%d\n",Count(x,LCA)+Count(y,LCA));
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d %d",&N,&M);
	for(int u,v,i=1;i<N;i++){
		scanf("%d %d",&u,&v);
		Addedge(u,v); Addedge(v,u);
	}
	DFS1(1,0); DFS2(1,1);
	if(N<=5000&&M<=5000) Solve1();
	else while(M--){
		int x,y; cin>>ch; scanf("%d %d",&x,&y);
		if(ch=='P')
			num[x]++,num[y]++,num[fa[Get_lca(x,y)]]-=2;
		else if(ch=='Q')
			printf("%d\n",num[x]+num[y]+num[Get_lca(x,y)]);
	}
	return 0;
} 
