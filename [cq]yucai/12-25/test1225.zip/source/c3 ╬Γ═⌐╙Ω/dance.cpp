#include<bits/stdc++.h>
using namespace std;

const int Maxn=40;
int N,M,Map[Maxn][Maxn],num[Maxn][Maxn];
int Sx,Sy,Tx,Ty,tot,stp[Maxn][Maxn];
struct node{
	int x,y;
};
queue<node> Q;
bool Vis[Maxn][Maxn];
int flag[9][2]={{2,1},{2,-1},{-2,1},{-2,-1},{1,2},{-1,2},{1,-2},{-1,-2}};

int check(int x,int y){
	if(x<=0||x>N||y<=0||y>M||Vis[x][y]) return 0;
	if(Map[x][y]==2) return 0;
	if(Map[x][y]==1||Map[x][y]==4) return 1;
	return 2;
}

void BFS(){
	memset(num,0x3f,sizeof num);
	memset(stp,0x3f,sizeof stp);
	Q.push((node){Sx,Sy}); Vis[Sx][Sy]=true;
	num[Sx][Sy]=0; stp[Sx][Sy]=0;
	while(!Q.empty()){
		node tmp=Q.front(); Q.pop();
		int x=tmp.x,y=tmp.y;
		for(int i=0;i<8;i++){
			int tx=x+flag[i][0],ty=y+flag[i][1];
			if(!check(tx,ty)) continue;
			if(check(tx,ty)==1) num[tx][ty]=min(num[tx][ty],num[x][y]);
			else num[tx][ty]=min(num[tx][ty],num[x][y]+1);
			stp[tx][ty]=stp[x][y]+1;
			Q.push((node){tx,ty}); Vis[tx][ty]=true;
		}
	}
}

bool check2(int x,int y,int chk){
	if(x<=0||x>N||y<=0||y>M||stp[x][y]!=chk) return 0;
	return 1;
}

void DFS(int x,int y,int sum){
	if(x==Sx&&y==Sy){ ++tot; /*cout<<"Here";*/ return; }
//	cout<<x<<" "<<y<<"\n";
	for(int i=0;i<8;i++){
		int tx=x+flag[i][0],ty=y+flag[i][1];
		if(!check2(tx,ty,sum-1)) {/*cout<<tx<<" "<<ty;*/ continue;}
		DFS(tx,ty,stp[tx][ty]);
	}
}

void Solve2(){
	DFS(Tx,Ty,stp[Tx][Ty]);
	printf("%d",tot);
}

int main(){
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d %d",&N,&M);
	for(int i=1;i<=N;i++){
		for(int j=1;j<=M;j++){
			scanf("%d",Map[i]+j);
			if(Map[i][j]==3) Sx=i,Sy=j;
			if(Map[i][j]==4) Tx=i,Ty=j;
		}
	}
	BFS();
//	for(int i=1;i<=N;i++){
//		for(int j=1;j<=M;j++){
//			cout<<num[i][j]<<" ";
//		}puts("");
//	}
	printf("%d\n",num[Tx][Ty]);
	Solve2();
	return 0;
} 
