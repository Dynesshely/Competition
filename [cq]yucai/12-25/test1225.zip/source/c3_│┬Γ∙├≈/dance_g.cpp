#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c;
	int x=0,f=0;
	c=getchar();
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n,m,a[110][110],zx,zy,ans,tot[110][110],sum,sx,sy;
int dis[8][2]={{-2,1},{-1,2},{1,2},{2,1},{2,-1},{1,-2},{-1,-2},{-2,-1}};
bool vis[110][110];
struct node
{
	int x,y,cnt;
	bool operator > (const node t) const
	{
		return cnt>t.cnt;
	}
	void gz(int a,int b,int c)
	{
		x=a,y=b,cnt=c;
	}
	void add(int i)
	{
		x+=dis[i][0],y+=dis[i][1];
	}
	bool ok()
	{
		return (1<=x&&x<=n&&1<=y&&y<=m&&a[x][y]!=2&&vis[x][y]==0); 
	}
	bool debug()
	{
		cerr<<x<<" "<<y<<" "<<cnt<<"nd\n";
	}
};
void bfs()
{
	priority_queue<node,vector<node>,greater<node> > qu;
	qu.push((node){zx,zy,0});
	while(!qu.empty())
	{
		node now=qu.top();
//		now.debug();
		if(a[now.x][now.y]==4)
		{
			ans=now.cnt;
			return;
		}
		qu.pop();
		for(int i=0;i<=7;i++)
		{
			node nxt=now;
			nxt.add(i);
//			if(nxt.x==3&&nxt.y==2)
//			{
//				now.debug();
//				cerr<<"em\n";
//			}
			if(nxt.ok())
			{
				vis[nxt.x][nxt.y]=1;
				if(a[nxt.x][nxt.y]==0) nxt.cnt++;
				qu.push(nxt);
			}
		}
	}
}
//int rm;
vector<node> vc[110][110];
void dfs1(int x,int y,int t)
{
//	cerr<<"??"<<x<<" "<<y<<" "<<t<<" "<<vis[2][5]<<'\n';
//	rm++;
//	if(rm>100000000) cerr<<rm<<'\n';
	if(t==0)
	{
		tot[x][y]++;
		return; 
	}
	if(!vc[x][y].empty())
	{
		node nxt;
		for(int i=vc[x][y].size()-1;i>=0;i--)
		{
			nxt=vc[x][y][i];
			vis[nxt.x][nxt.y]=1;
			dfs(nxt.x,nxt.y,t-nxt.cnt);
			vis[nxt.x][nxt.y]=0;
		}
	} 
	node nxt;
	for(int i=0;i<=7;i++)
	{
		nxt.gz(x,y,t);
		nxt.add(i);
//		nxt.debug();
		if(nxt.ok())
		{
			vis[nxt.x][nxt.y]=1;
			if(a[nxt.x][nxt.y]==0) nxt.cnt--;
			dfs1(nxt.x,nxt.y,nxt.cnt);
			node tmp=nxt;
			tmp.cnt++;
			if(nxt.cnt==0) vc[x][y].push_back(cnt);
			for(int i=0;i<vc[nxt.x][nxt.y].size();i++)
			{
				tmp=vc[nxt.x][nxt.y][i];
				tmp.cnt++;
				vc[x][y].push_back(tmp);
			}
			vis[nxt.x][nxt.y]=0;
		}
	}
}
 
void dfs2(int x,int y,int t)
{
//	cerr<<"??"<<x<<" "<<y<<" "<<t<<"dfs2\n";
	
	if(t==0)
	{
		sum+=tot[x][y];
		return; 
	}
	node nxt;
	for(int i=0;i<=7;i++)
	{
		nxt.gz(x,y,t);
		nxt.add(i);
//		nxt.debug();
		if(nxt.ok())
		{
			vis[nxt.x][nxt.y]=1;
			if(a[nxt.x][nxt.y]==0) nxt.cnt--;
			dfs2(nxt.x,nxt.y,nxt.cnt);
			vis[nxt.x][nxt.y]=0;
		}
	}
}
signed main()
{
	freopen("dance.in","r",stdin);
	freopen("dance_g.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			a[i][j]=read();
			if(a[i][j]==3)
			{
				zx=i,zy=j;
			}
			if(a[i][j]==4)
			{
				sx=i,sy=j;
			}
		}
	}
//	cerr<<zx<<" "<<zy<<"\n";
	vis[zx][zy]=1;
	bfs();
	cout<<ans<<'\n';
	memset(vis,0,sizeof vis);
	vis[zx][zy]=1;
	dfs1(zx,zy,ans/2+1);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cerr<<tot[i][j]<<" ";
		}
		cerr<<'\n'; 
	}
	memset(vis,0,sizeof vis);
	vis[sx][sy]=1;
	dfs2(sx,sy,ans-ans/2);
	cout<<sum;
	return 0;
}
/*
4 5
1 0 0 0 0
3 0 0 0 0
0 0 2 0 0
0 0 0 4 0
*/
