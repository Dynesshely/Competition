#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	char c;
	int x=0,f=0;
	c=getchar();
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
//int quick_pow(int x,int t)
//{
//	if(t==0) return 1;
//	if(t==1) return x;
//	int tot=quick_pow(x,t>>1);
//	if(t&1) return tot*tot*x;
//	else return tot*tot; 
//} 
int n,a[1010][110],pw[100],sumz[110],sumf[110],ans[110]; 
bool vis[1010];
signed main()
{
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	n=read();
	pw[0]=1;
	for(int i=1;i<=60;i++)
	{
		pw[i]=pw[i-1]*2;
	}
	for(int i=0;i<=60;i++)
	{
		if(i%2==0) sumz[i]+=pw[i];
		else sumf[i]+=pw[i];
		sumz[i+1]=sumz[i];
		sumf[i+1]=sumf[i];
	}
	while(n!=0)
	{
//		cerr<<n<<'\n';
//		for(int i=100;i>=0;i--)
//		{
//			if(ans[i]==1)
//			{
//				for(int j=i;j>=0;j--)
//				{
//					cerr<<ans[j];
//				}
//				break;
//			}
//		}
//		cerr<<'\n';
		if(n>0)
		{
			int t=log2(n);
//			cerr<<t<<"nt\n";
			if(t%2==0)
			{
				if(n<=sumz[t])
				{
					ans[t]=1;
//					cerr<<n<<" "<<t<<" "<<pw[t]<<"pw[t]\n";
					n-=pw[t];
				}
				else
				{
					t+=2;
					ans[t]=1;
//					cerr<<n<<" "<<t<<" "<<pw[t]<<"pw[t]\n";
					n-=pw[t];
				}
			}
			else
			{
				t++;
				ans[t]=1;
				n-=pw[t];
			}
		}
		else
		{
			int nn=-n;
			int t=log2(nn);
			if(t%2==1)
			{
				if(nn<=sumf[t])
				{
					ans[t]=1;
					n+=pw[t];
				}
				else
				{
					t+=2;
					ans[t]=1;
					n+=pw[t];
				}
			}
			else
			{
				t++;
				ans[t]=1;
				n+=pw[t];
			}
		}
	}
	for(int i=100;i>=0;i--)
	{
		if(ans[i]==1)
		{
			for(int j=i;j>=0;j--)
			{
				cout<<ans[j];
			}
			return 0;
		}
	}
//	for(int i=0;i<=60;i++)
//	{
//		cerr<<sumf[i]<<'\n';
//	}
	return 0;
}
