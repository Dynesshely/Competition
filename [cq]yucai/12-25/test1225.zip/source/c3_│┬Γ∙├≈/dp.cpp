#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("base.in","w",stdout);
	for(int i=1;i<=200;i++)
	{
//		cerr<<i<<'\n';
		cout<<i;
		system("base.exe");
		system("base_g.exe");
		if(system("fc base.out base_g.out")) return 0; 
	}
	return 0;
}
