#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read()
{
	char c;
	int x=0,f=0;
	c=getchar();
	while(!isdigit(c))
	{
		if(c=='-') f=1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-48;
		c=getchar();
	}
	return f==0?x:-x;
}
int n,nn,a[510][510],vis[510][510],dis[4][2]={{0,1},{0,-1},{1,0},{-1,0}},ans;
struct node
{
	int x,y;
	void gz(int a,int b,int c)
	{
		x=a,y=b;
	}
	void add(int i)
	{
		x+=dis[i][0],y+=dis[i][1];
	}
	bool ok()
	{
		return (1<=x&&x<=n&&1<=y&&y<=n&&vis[x][y]==0); 
	}
	bool debug()
	{
		cerr<<x<<" "<<y<<"nd\n";
	}
};
bool check(int t)
{
	queue<node> qu;
	memset(vis,0,sizeof vis);
	int cnt=0,mx=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
//			cerr<<i<<' '<<j<<"\n";
			if(!vis[i][j])
			{
				vis[i][j]=1;
				qu.push((node){i,j});
				while(!qu.empty())
				{
					node now=qu.front();
					qu.pop();
//					now.debug();
					for(int i=0;i<=3;i++)
					{
						node nxt=now;
						nxt.add(i);
						if(nxt.ok()&&abs(a[nxt.x][nxt.y]-a[now.x][now.y])<=t)
						{
							cnt++;
							vis[nxt.x][nxt.y]=1;
							qu.push(nxt);
						}
					}
				}
				mx=max(mx,cnt);
				if(mx>=nn)
				{
					return 1;
				}
				cnt=0;
			}
		}
	}
	return 0;
}
void erfen()
{
	int l=0,r=1000010,mid;
	while(l<r)
	{
		mid=(l+r)>>1;
//		cerr<<l<<" "<<r<<" "<<mid<<'\n';
		if(check(mid))
		{
			r=mid;
			ans=r;
		}
		else
		{
			l=mid+1;
		}
	}
}
signed main()
{
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	n=read();
	nn=n*n/2+(n%2==0?0:1);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			a[i][j]=read();
		} 
	}
	erfen();
	cout<<ans;
	return 0;
}
