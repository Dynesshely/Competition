#include<bits/stdc++.h>
using namespace std;
int n,fa[501][501],mmax,mid,ojbk,ans,sum;
int bj[501][501];
int move[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
void dfs(int x,int y){
	bj[x][y]=1;
	sum++;
	for(int i=0;i<4;i++){
		int xx=x+move[i][0],yy=y+move[i][1];
		if(xx<=n&&yy<=n&&xx>=1&&yy>=1&&!bj[xx][yy]&&mid>=abs(fa[xx][yy]-fa[x][y]))
		dfs(xx,yy);
	}
}
int main(){
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    for(int j=1;j<=n;j++){
    	scanf("%d",&fa[i][j]);
    	mmax=max(fa[i][j],mmax);
}
    int l=0,r=mmax;
    while(l!=r){
    	mid=(l+r)/2;
//    	cout<<mid<<" ";
    	ojbk=0;
        for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
        bj[i][j]=0;
    	for(int i=1;i<=n&&!ojbk;i++)
    	for(int j=1;j<=n&&!ojbk;j++)
    	if(!bj[i][j]){
    	sum=0;
    	dfs(i,j);
    	if(sum>=(n*n)/2)
		ojbk=1;
    }
    	if(ojbk){
    		ans=mid;
    		r=mid;
		}else{
			l=mid+1;
		}
	}
	printf("%d",l);
	return 0;
} 
