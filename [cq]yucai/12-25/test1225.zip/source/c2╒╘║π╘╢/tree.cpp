#include<bits/stdc++.h>
using namespace std;
int n,m,st,ed,bj[100001],ojbk;
struct van{
	int nx,sum;
}shit;
vector<van>fa[100001];
void find(int now){
	if(now==ed){
		ojbk=1;
		return ;
	}
	bj[now]=1;
	for(int i=0;i<fa[now].size();i++){
		if(!bj[fa[now][i].nx]){
		find(fa[now][i].nx);
		if(ojbk){
			bj[now]=0;
			fa[now][i].sum++;
			for(int j=0;j<fa[fa[now][i].nx].size();j++){
			if(fa[fa[now][i].nx][j].nx==now)
			fa[fa[now][i].nx][j].sum++;
	}
//			cout<<now<<" "<<i<<" ";
			return ;
		}
	}
	}
	bj[now]=0;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int u,v;
	char kkk;
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		shit.nx=v,shit.sum=0;
		fa[u].push_back(shit);
		shit.nx=u;
		fa[v].push_back(shit);
	}
	for(int i=1;i<=m+m;i=i+1){
		scanf("%c",&kkk);
		if(kkk=='P'){
		scanf("%d%d",&st,&ed);
		ojbk=0;
		find(st);
		for(int j=1;j<=n;j++)
		bj[j]=0;
		}
		if(kkk=='Q'){
		scanf("%d%d",&st,&ed);
		for(int j=0;j<fa[st].size();j++){
			if(fa[st][j].nx==ed){
				printf("%d\n",fa[st][j].sum);
			}
		}
		}
	}
	return 0;
} 
