#include<bits/stdc++.h>
using namespace std;
int n,m,van[114514],kkk=1,js=1,www,lll;
int fa[114514];
vector<int>nms;
int main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%d",&n);
	m=abs(n);
	while(kkk<=m){
	kkk*=2;	
}
	kkk/=2;
	for(int i=kkk;i>=1;i=i/2){
		if(m>=i){
			m-=i;
			van[js]=1;
		}
		js++;
	}
	js--;
	if(n>=0){
	for(int i=1;i<=js;i++){
	fa[i]=van[js-i+1];	
}
	for(int i=1;i<=js;i++){
		if(fa[i]>1){
			fa[i+1]+=fa[i]/2;
			fa[i]%=2;
		}
		if(fa[i]==1){
			if(i%2==0)nms.push_back(1),fa[i+1]++,js++;
			else nms.push_back(1);
		}
		if(fa[i]==0)nms.push_back(0);
	}
	for(lll=nms.size()-1;lll>=0;lll--)
	if(nms[lll]==1)break;
	for(int i=lll;i>=0;i--)printf("%d",nms[i]);
}
    else{
	for(int i=1;i<=js;i++){
	fa[i]=van[js-i+1];	
}
	for(int i=1;i<=js;i++){
		if(fa[i]>1){
			fa[i+1]+=fa[i]/2;
			fa[i]%=2;
		}
		if(fa[i]==1){
			if(i%2==1)nms.push_back(1),fa[i+1]++,js++;
			else nms.push_back(1);
		}
		if(fa[i]==0)nms.push_back(0);
	}
	for(lll=nms.size()-1;lll>=0;lll--)
	if(nms[lll]==1)break;
	for(int i=lll;i>=0;i--)printf("%d",nms[i]);
}
	return 0;
} 
//1 -2 4 -8 16 -32 64 -128 256 -512 1024 -2048                                        11
//10110                                        11111        
//0 1 10 11 100 101 110 111 1000 1001 1010 1011 1100 1101 1110 1111
