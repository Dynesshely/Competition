#include<bits/stdc++.h>
using namespace std;
int n,m,fa[31][31],s1,s2,e1,e2;
int bj[31][31],van[31][31],ans;
int move[8][2]={{1,2},{2,1},{-1,2},{2,-1},{1,-2},{-2,1},{-1,-2},{-2,-1}};
void dfs(int x,int y,int far){
	if(x==e1&&y==e2){
		if(van[x][y]!=far)
		ans=0;
		ans++;
		van[x][y]=far;
		return ;
	}
	bj[x][y]=1;
	for(int i=0;i<8;i++){
		int xx=x+move[i][0],yy=y+move[i][1],ff=far;
		if(xx<=n&&yy<=m&&xx>=1&&yy>=1&&!bj[xx][yy]&&fa[xx][yy]!=2){
			if(fa[xx][yy]==0)
			ff++;
			if(ff<=van[e1][e2]&&ff<van[xx][yy]){
				van[xx][yy]=ff;
				dfs(xx,yy,ff);
			}
		}
	}
	bj[x][y]=0;
}
int main(){
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++){
    	van[i][j]=114514191;
    	scanf("%d",&fa[i][j]);
        if(fa[i][j]==3)s1=i,s2=j;
        if(fa[i][j]==4)e1=i,e2=j;
}
    dfs(s1,s2,0);
    if(van[e1][e2]==114514191)printf("-1");
    else printf("%d\n%d",van[e1][e2],ans);
	return 0;
} 
