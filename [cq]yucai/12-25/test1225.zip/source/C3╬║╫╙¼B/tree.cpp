#include<bits/stdc++.h>
using namespace std;
char ch;
int n,m,u,v,fa[1005];
int tree[1005][1005],cnt;
int nxt[2005],head[2005],to[1005];
void add(int u,int v)
{
	nxt[u]=cnt;
	head[u]=++cnt;
	to[u]=v;
}
void dfs(int x,int f)
{
	for(int i=head[x];i;i=nxt[i])
	{
		int y=to[i];
		if(y==f) continue;
		fa[y]=x;dfs(y,x);
	}
	return;
}
void sol()
{
	
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&u,&v);
		add(u,v),add(v,u);
	}
	dfs(1,0);
	while(m--)
	{
		cin>>ch;
		scanf("%d%d",&u,&v);
		if(ch=='P') sol();
		else printf("%d\n",tree[u][v]);
	}
	return 0;
}
