#include<bits/stdc++.h>
using namespace std;
int n,tot,b[105],a[105],num,q;
long long bs[100],add,res;
int main()
{
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	bs[0]=1;
	for(int i=1;i<=65;i++) bs[i]=bs[i-1]*(-2);
	scanf("%d",&n);
	if(n<0) q=1;
	while(n){b[tot++]=n%2; n/=2;}
	for(int i=0;i<tot || add!=0;i++)
	{
		if(add==0 && i>=tot) break;
		if(b[i]<0) b[i]=-b[i];
		a[++num]=b[i];
		if(i%2!=q)
		{
			//cout<<"Come in "<<i<<"!"<<endl;
			if(add==-bs[i] && b[i]!=0) add=0,a[num]=0,a[++num]=1;
			else if(b[i]!=0) add+=bs[i+1],a[num]=1;//,cout<<"Add in "<<i<<"!"<<endl;
		}
		if(add && i%2==q)
		{
			if(bs[i]==add && b[i]==0)
			a[num]=1,add=0;//,cout<<"!@#$$@#%";
			else if(bs[i-1]==-add && b[i]==0 && b[i-1]==0)
			a[num]=1,a[num-1]=1,add=0;//,cout<<"!@#$$@#%";
			else add+=bs[i],a[num]=0;//,cout<<"I can't help you..."<<endl;
		}
		//cout<<"i:"<<i<<" add:"<<add<<" num:"<<num<<endl;
	}
	for(int i=1;i<=num;i++) cout<<a[num-i+1];
	return 0;
}
