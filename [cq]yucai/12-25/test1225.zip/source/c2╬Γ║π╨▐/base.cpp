#include<bits/stdc++.h>
using namespace std;
long long n,js,num,k,jj,a[100001],q,cnt,kk=1,jb,sum[1000001],sp[100001];
void dfs(int jj,int shu,int kk){
	if(jb==1) return;
	if(jj==n){
		jb=1;
		return;
	}
	else{
		a[++cnt]=1;
		dfs(jj+pow(-2,k-kk),1,kk+1);
		if(jb==1) return;
		a[cnt]=0;
		dfs(jj,0,kk+1);
	}
}
int main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=30;i++) sp[i]=sp[i-1]*(-2);
	if(n==0){
		cout<<0;
		return 0;
	}
	if(n>0){
		num=1;k=1;
		while(js<n){
			js+=num;
			num*=4;
			k+=2;
		}
		k-=2;
	}
	if(n<0){
		num=2;k=2;
		while(js<abs(n)){
			js+=num;
			num*=4;
			k+=2;
		}
		k-=2;
	}
	a[++cnt]=1;
	dfs(jj+pow(-2,k-kk),1,kk+1);
	for(int i=1;i<=k;i++) cout<<a[i];
}
