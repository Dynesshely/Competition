#include<bits/stdc++.h>
#define N 505
#define re register
using namespace std;
//bool ppp;
inline int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')
		ch=getchar();
	while(ch>='0'&&ch<='9')
		x=(x<<1)+(x<<3)+(ch^48),
		ch=getchar();
	return x;
}
inline void write(int x){
	int cnt=0;char f[50];
	if(!x)
		putchar('0');
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
int n,a[N][N],col[N][N],t,dis[N*N],tot;
int head[N*N],nxt[N*N*4],to[N*N*4],vis[N*N*4];
int X[4]={0,0,1,-1},Y[4]={1,-1,0,0};
int sz[N*N],as=1e9;
inline void dfs(const int xx,const int yy){
	col[xx][yy]=t;
	++sz[t];
	for(re int i=0;i<4;++i){
		int x=xx+X[i],y=yy+Y[i];
		if(x&&y&&x<=n&&y<=n&&!col[x][y]&&a[x][y]==a[xx][yy])
			dfs(x,y);
	}
}
set<int> P[250000];
set<int>::iterator it;
inline void add(const int u,const int v){
	nxt[++tot]=head[u];head[u]=tot;
	to[tot]=v;vis[tot]=abs(dis[u]-dis[v]);
}
struct node{
	int to,w;
	bool operator<(const node &x)const{
		return w>x.w;
	}
};
bool c[N*N];
inline void bfs(const int k){
	memset(c,0,sizeof c);
	priority_queue<node> Q;
	int res=0,ans=0;
	Q.push((node){k,0});
	while(!Q.empty()){
		node x=Q.top();
		Q.pop();
		if(c[x.to])
			continue;
		c[x.to]=1;
		ans=max(ans,x.w);
		if(ans>=as)
			return;
		res+=sz[x.to];
		if(res>=(n*n+1)/2){
			as=min(as,ans);
			return;
		}
		for(re int i=head[x.to];i;i=nxt[i])
			if(!c[to[i]])
				Q.push((node){to[i],vis[i]});
	}
}
//bool pppp;
signed main(){
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
//	cout<<(&pppp-&ppp)/1024.0/1024.0<<"\n";
	n=read();
	for(re int i=1;i<=n;++i)
		for(re int j=1;j<=n;++j)
			a[i][j]=read();
	for(re int i=1;i<=n;++i)
		for(re int j=1;j<=n;++j)
			if(!col[i][j])
				dis[++t]=a[i][j],
				dfs(i,j);
	for(re int i=1;i<=n;++i)
		for(re int j=1;j<=n;++j)
			for(re int k=0;k<4;++k){
				int x=i+X[k],y=j+Y[k];
				if(x&&y&&x<=n&&y<=n&&col[x][y]!=col[i][j])
					P[col[i][j]].insert(col[x][y]);
			}
	for(re int i=1;i<=t;++i){
		it=P[i].begin();
		while(it!=P[i].end()){
			add(i,*it);
			++it;
		}
	}
	for(re int i=1;i<=t;++i)
		bfs(i);
	write(as);
	return 0;
}
