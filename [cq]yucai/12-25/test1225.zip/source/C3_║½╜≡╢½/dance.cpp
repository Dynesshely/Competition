#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
		x=(x<<1)+(x<<3)+(ch^48),
		ch=getchar();
	return x*f;
}
inline void write(int x){
	int cnt=0;char f[50];
	if(!x)
		putchar('0');
	if(x<0)
		putchar('-');
	x=x<0?-x:x;
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
}
signed main(){
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	puts("-1");
	return 0;
}
