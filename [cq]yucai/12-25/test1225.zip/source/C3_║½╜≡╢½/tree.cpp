#include<bits/stdc++.h>
#define N 200000
#define ls (w<<1)
#define rs (w<<1|1)
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
		x=(x<<1)+(x<<3)+(ch^48),
		ch=getchar();
	return x*f;
}
inline void write(int x){
	int cnt=0;char f[50];
	if(!x)
		putchar('0');
	if(x<0)
		putchar('-');
	x=x<0?-x:x;
	while(x){
		f[cnt++]=x%10+'0';
		x/=10;
	}
	while(cnt)
		putchar(f[--cnt]);
	putchar('\n');
}
int u,v,n,m,f[N],sz[N],id,dfn[N];
int nxt[N<<1],head[N<<1],to[N<<1],t;
int son[N],c[N<<2],tp[N],a,b,dep[N];
int tag[N<<2];
char ch;
inline void add(){
	nxt[++t]=head[u];head[u]=t;to[t]=v;
	nxt[++t]=head[v];head[v]=t;to[t]=u;
}
void dfs1(int k,int fa){
	f[k]=fa;
	sz[k]=1;
	dep[k]=dep[fa]+1;
	int maxson=0;
	for(int i=head[k];i;i=nxt[i])
		if(to[i]!=fa){
			dfs1(to[i],k);
			sz[k]+=sz[to[i]];
			if(maxson<sz[to[i]]){
				maxson=sz[to[i]];
				son[k]=to[i];
			}
		}
}
void dfs2(int k,int top){
	dfn[k]=++id;
	tp[k]=top;
	if(son[k])
		dfs2(son[k],top);
	for(int i=head[k];i;i=nxt[i])
		if(to[i]!=f[k]&&to[i]!=son[k])
			dfs2(to[i],to[i]);
}
inline void push_down(int w,int l,int r){
	int mid=(l+r)>>1;
	c[ls]+=tag[w]*(mid-l+1);
	c[rs]+=tag[w]*(r-mid);
	tag[ls]+=tag[w];
	tag[rs]+=tag[w];
	tag[w]=0;
}
inline void push_up(int w){
	c[w]=c[ls]+c[rs];
}
void update(int w,int l,int r,int L,int R){
	if(L<=l&&R>=r){
		c[w]+=r-l+1;
		++tag[w];
		return;
	}
	int mid=(l+r)>>1;
	push_down(w,l,r);
	if(L<=mid)
		update(ls,l,mid,L,R);
	if(R>mid)
		update(rs,mid+1,r,L,R);
	push_up(w);
}
int query(int w,int l,int r,int X){
	if(l==r)
		return c[w];
	int mid=(l+r)>>1;
	push_down(w,l,r);
	if(X<=mid)
		return query(ls,l,mid,X);
	else
		return query(rs,mid+1,r,X);
}
inline void reup(){
	while(tp[a]!=tp[b]){
		if(dep[a]<dep[b])
			swap(a,b);
		update(1,1,n,dfn[tp[a]],dfn[a]);
		a=f[tp[a]];
	}
	if(a!=b){
		if(dep[a]<dep[b])
			swap(a,b);
		update(1,1,n,dfn[b]+1,dfn[a]);
	}
}
signed main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<n;++i){
		u=read();v=read();
		add();
	}
	dfs1(1,0);
	dfs2(1,1);
	while(m--){
		scanf("%s",&ch);
		a=read();
		b=read();
		if(ch=='P')
			reup();
		else
			write(query(1,1,n,dfn[dep[a]<dep[b]?b:a]));
	}
	return 0;
}
