#include<bits/stdc++.h>
#define N 120
#define int long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
		x=(x<<1)+(x<<3)+(ch^48),
		ch=getchar();
	return x*f;
}
int n,lg[N];
int cnt[N];
signed main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	n=read();
	lg[0]=1;
	for(int i=1;i<=40;++i)
		lg[i]=lg[i-1]<<1;
	if(n>0){
		for(int i=40;i>=0;--i)
			if(n>=lg[i]){
				if((i%2))
					++cnt[i],
					++cnt[i+1];
				else
					++cnt[i];
				n-=lg[i];
			}
	}
	else{
		n=-n;
		for(int i=40;i>=0;--i)
			if(n>=lg[i]){
				if(!(i%2))
					++cnt[i],
					++cnt[i+1];
				else 
					++cnt[i];
				n-=lg[i];
			}
	}
	for(int i=0;i<=40;++i)
		if(cnt[i]>1)
			cnt[i+1]+=cnt[i]/2,
			cnt[i+2]+=cnt[i]/2,
			cnt[i]%=2;
	for(int i=40;i>=0;--i)
		if(cnt[i]){
			while(i>=0)
				putchar(cnt[i--]?'1':'0');
			break;
		}
	return 0;
}
