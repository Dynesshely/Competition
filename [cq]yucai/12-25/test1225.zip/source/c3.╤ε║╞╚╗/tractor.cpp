#include<bits/stdc++.h>
using namespace std;
struct node{
	int x,y,z;
};
int n,cop,x,y,z,l,r,mid,hn,ty,tx,nn;
bool vis[501][501];
int a[501][501],dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
inline int read()
{
	int X(0);char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
	return X;
}
bool ck(int X)
{
	queue<node> qu;
	cop=0;memset(vis,0,sizeof(vis));
	qu.push((node){1,1,1});
	while(!qu.empty())
	{
		x=qu.front().x,y=qu.front().y,z=qu.front().z;qu.pop();
		cop=max(cop,z);
		if(cop>=hn) return 1;
		for(int i=0;i<4;i++)
		{
			tx=x+dir[i][0],ty=y+dir[i][1];
			if(vis[tx][ty]) {qu.push((node){tx,ty,z});continue;}
			if(tx>0&&ty>0&&tx<=n&&ty<=n&&abs(a[tx][ty]-a[x][y])<=X)
				{qu.push((node){tx,ty,z+1});vis[tx][ty]=1;}
		}
	}
	return 0;
}
int main()
{
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
//	n=read();nn=n*n;
//	hn=(nn>>1)+(nn&1);
//	for(int i=1;i<=n;i++)
//		for(int j=1;j<=n;j++) a[i][j]=read();
//	l=0,r=1000001;
//	ck(3);
//	while(l+1<r)
//	{
//		mid=l+r>>1;
//		if(ck(mid)) r=mid;
//		else l=mid;
//	}
//	if(!ck(mid)) mid++;
//	if(ck(mid-1)) mid--;
//	printf("%d",mid);
	puts("0");
	return 0;
}

