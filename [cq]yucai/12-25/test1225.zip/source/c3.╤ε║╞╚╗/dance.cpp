#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x(0);char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x;
}
int main()
{
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	puts("-1");
	return 0;
}

