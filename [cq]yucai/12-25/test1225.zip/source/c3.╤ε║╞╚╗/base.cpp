//sto ������ orz ����ƭ�� 
#include<bits/stdc++.h>
using namespace std;
long long n,p,now;
int cnt,f[200],q,weishu;
long long tw[18]={0,1,5,21,85,341,1365,5461,21845,87381,349525,1398101,5592405,22369621,89478485,357913941,1431655765,5726623061};
void dfs(int x)
{
	if(x==0) return;
	if(x<0)
	{
		cnt=2,now=p=-2;
		while(now>x) {p*=4,now+=p,cnt+=2;}
		f[cnt]=1;if(cnt>weishu) weishu=cnt;
	}
	else
	{
		cnt=now=p=1;
		while(now<x) {p*=4,now+=p,cnt+=2;}
		f[cnt]=1;if(cnt>weishu) weishu=cnt;
	}
	dfs(x-p);
}
int main()
{
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%lld",&n);
	if(n==0)
	{
		printf("0");
		return 0;
	}
	dfs(n);
	for(int i=weishu;i;i--) printf("%d",f[i]);
	return 0;
}

