#include<bits/stdc++.h>
using namespace std;
struct node{
	int nxt,to;
}e[200001];
int n,m,p,l,r,ans,ne,u,v;
int h[100001],dep[100001],lg[100001],num[100001],fa[100001][19];
char op;
inline int read()
{
	int x(0);char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x;
}
void add(int x,int y)
{
	e[++ne].nxt=h[x];
	e[ne].to=y,h[x]=ne;
}
void dfs(int x,int f)
{
	fa[x][0]=f,dep[x]=dep[f]+1;
	for(int i=1;i<=lg[x];i++)
		fa[x][i]=fa[fa[x][i-1]][i-1];
	for(int i=h[x];i;i=e[i].nxt)
		if(e[i].to!=f) dfs(e[i].to,x);
}
int lca(int x,int y)
{
	if(dep[x]<dep[y]) swap(x,y);
	while(dep[x]>dep[y]) 
		x=fa[x][lg[dep[x]-dep[y]]-1];
	if(x==y) return x;
	for(int i=lg[dep[x]]-1;i>=0;i--)
		if(fa[x][i]!=fa[y][i]) x=fa[x][i],y=fa[y][i];
	return fa[x][0];
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<n;i++)
	{
		u=read(),v=read();
		add(u,v);add(v,u);
	}
	for(int i=1;i<=n;i++)
		lg[i]=lg[i-1]+(1<<lg[i-1]==i);
	dfs(1,0);
	while(m--)
	{
		scanf("\n");
		op=getchar();
		l=read(),r=read();
		p=lca(l,r);
	}
	return 0;
}

