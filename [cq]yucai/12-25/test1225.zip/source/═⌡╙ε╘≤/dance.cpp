#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,a,b,c,d,ans=1e9+7,js;
int mapp[35][35],qz[35][35];
int fx[8][2]= {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
int read() {
	int x=0;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar());
	for(; ch>='0'&&ch<='9'; ch=getchar()) x=(x<<3)+(x<<1)+(ch^48);
	return x;
}
void dfs(int x,int y,int z) {
	if(x==c&&y==d) {
		if(z==ans) js++;
		if(ans>z) ans=z,js=1;
		return;
	}
	if(z<qz[x][y]) qz[x][y]=z;
	else return;
	if(z>ans) return;
	int X=0,Y=0;
	for(int i=0; i<8; i++) {
		X=x+fx[i][0],Y=y+fx[i][1];
		if(X<=0||X>n||Y<=0||Y>m) continue;
		if(mapp[X][Y]==2) continue;
		if(mapp[X][Y]==1) dfs(X,Y,z);
		if(mapp[X][Y]==0) dfs(X,Y,z+1);
		if(mapp[X][Y]==4) dfs(X,Y,z);
	}
	return;
}
signed main() {
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	memset(qz,0x3f3f3f3f,sizeof(qz));
	n=read(),m=read();
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=m; j++) {
			mapp[i][j]=read();
			if(mapp[i][j]==3) a=i,b=j;
			if(mapp[i][j]==4) c=i,d=j;
		}
	}
	dfs(a,b,0);
	printf("%lld\n%lld",ans,js);
	return 0;
}
