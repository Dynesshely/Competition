#include<bits/stdc++.h>
#define int long long 
using namespace std;
int read() {
	int x=0,f=1;
	char ch=getchar();
	for(; ch<'0'||ch>'9'; ch=getchar()) if(ch=='-') f=-1;
	for(; ch>='0'&&ch<='9'; ch=getchar()) x=(x<<3)+(x<<1)+(ch^48);
	return x*f;
}
int a[50],n,p=1,js=1,b[50],f;
int abss(int x)
{
	if(x<0) return -x;
	return x;
}
signed main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout); 
	n=read(); 
	b[0]=0;
	while(js<=34) {
		if(js>=3)a[js]=p+a[(js-2)];
		if(js<=2)a[js]=p;
		b[js]=p;
		p*=(-2),js++;
	}
	if(n==0) {printf("0");return 0;}
	if(n==1) {printf("1");return 0;}
	if(n==-1) {printf("11");return 0;}
	if(n==-2) {printf("10");return 0;}
	if(n<0) for(int i=32; i>=1; i-=2) if(n<a[i]) {f=i+2;break;}
	if(n>0) for(int i=33; i>=1; i-=2) if(n>a[i]) {f=i+2;break;}
	for(int i=f; i>=1; i--) if((abss(n-b[i])>abss(a[i-1]))) printf("0");else {n-=b[i];printf("1");}
	return 0;
}
