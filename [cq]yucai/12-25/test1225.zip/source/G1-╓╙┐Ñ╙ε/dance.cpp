/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool happy1041;
ll time1=clock();
//
struct node{
	ll x,y,z;
};
const ll N=30;
ll mmap[N+10][N+10],lth[N+10][N+10],num[N+10][N+10],dx[8]={-2,-2,-1,1,2,2,1,-1},dy[8]={-1,1,2,2,1,-1,-2,-2};
bool vis[N+10][N+10];
ll lh[N+10][N+10][N+10][N+10];
ll sx,sy,ex,ey,n,m;
priority_queue <node> pq;
bool operator <(node a,node b){
	return a.z>b.z||(a.z==b.z&&mmap[b.x][b.y]==0);
}
//
void djstr(){
	memset(lh,-1,sizeof(lh)); memset(lth,0x3f,sizeof(lth)); memset(vis,0,sizeof(vis));
	lth[sx][sy]=0;
	vis[sx][sy]=1;
	lh[sx][sy][0][0]=0;
	num[0][0]=1;
	pq.push((node){sx,sy,0});
	while(pq.size()){
		node tem=pq.top(); pq.pop();
		ll nx=tem.x,ny=tem.y;
		if(!vis[nx][ny]) continue;
		vis[nx][ny]=0;
//		printf("%lld %lld:\n",nx,ny);
		FOR(i,0,n){
			FOR(j,0,m){
				num[nx][ny]+=(lh[nx][ny][i][j]==lth[nx][ny])?num[i][j]:0;
//				printf("%lld ",lh[nx][ny][i][j]);
			}
//			printf("\n");
		}
		FOR(i,0,7){
			ll tx=nx+dx[i],ty=ny+dy[i];
			if(tx>=1&&tx<=n&&ty>=1&&ty<=m&&mmap[tx][ty]!=2){
				if(lth[tx][ty]>lth[nx][ny]+((mmap[tx][ty]!=0)?0:1)){
					lth[tx][ty]=lth[nx][ny]+((mmap[tx][ty]!=0)?0:1);
					vis[tx][ty]=1;
					pq.push((node){tx,ty,lth[tx][ty]});
				}
				if(lth[tx][ty]==lth[nx][ny]+(mmap[tx][ty]!=0?0:1)){
					if(mmap[nx][ny]==0){
						lh[tx][ty][nx][ny]=lth[tx][ty];
					}
					else{
						FOR(ii,0,n){
							FOR(jj,0,m){
								lh[tx][ty][ii][jj]=(lh[nx][ny][ii][jj]==lth[nx][ny])?lth[tx][ty]:lh[tx][ty][ii][jj];
							}
						}
					}
				}
			}
		}
	}
}
//
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Happy1041;
void usage() {
	ll time2=clock();
	cout<<(&Happy1041-&happy1041)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
//	usage();
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	n=gt(),m=gt();
	FOR(i,1,n){
		FOR(j,1,m){
			mmap[i][j]=gt();
			if(mmap[i][j]==3) sx=i,sy=j;
			if(mmap[i][j]==4) ex=i,ey=j;
		} 
	} 
	djstr();
	if(lth[ex][ey]>=1e15) printf("-1");
 	else printf("%lld\n%lld",lth[ex][ey],num[ex][ey]);
// 	printf("\n");
// 	FOR(i,1,n){
// 		FOR(j,1,m){
// 			printf("%lld-%lld  ",lth[i][j],num[i][j]); 
//		} printf("\n");
//	}
}
/*
LOOKING FOR:
Array limits
Special cases
file name
match by a brute force program
output(between "Yes" and "yes",)
*/



