/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool happy1041;
ll time1=clock();
//
const ll N=500;
ll mmap[N+10][N+10],dx[4]={0,1,0,-1},dy[4]={-1,0,1,0};
bool vis[N+10][N+10];
ll mid,hnum,n;
//
ll dfs(ll x,ll y){
	vis[x][y]=1;
	ll rt=1;
	FOR(i,0,3){
		ll tx=x+dx[i],ty=y+dy[i];
		if(tx>=1&&tx<=n&&ty>=1&&ty<=n&&abs(mmap[tx][ty]-mmap[x][y])<=mid&&!vis[tx][ty]) 
			rt+=dfs(tx,ty);
	}
	return rt;
}
//
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Happy1041;
void usage() {
	ll time2=clock();
	cout<<(&Happy1041-&happy1041)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
//	usage();
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	n=gt();
	FOR(i,1,n) FOR(j,1,n) mmap[i][j]=gt();
	if((n&1)) hnum=(n*n+1)/2;
	else hnum=n*n/2;
	ll l=0,r=1e6+10;
	while(l<r){
		memset(vis,0,sizeof(vis));
		mid=(l+r)>>1; ll mmax=-1e18;
		FOR(i,1,n){
			FOR(j,1,n){
				if(!vis[i][j]){
					mmax=max(mmax,dfs(i,j));
				} 
			}
		}
		if(mmax>=hnum) r=mid;
		else l=mid+1;
	}
	printf("%lld",l);
}
/*
LOOKING FOR:
Array limits
Special cases
file name
match by a brute force program
output(between "Yes" and "yes",)
*/



