/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(int i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(int i=(a); i>=(b); --i)
using namespace std;
bool happy1041;
ll time1=clock();
//
const ll N=2e5;
ll T[N*4+10];
ll dth[N+10],zson[N+10],fa[N+10],zfa[N+10],dfn[N+10];
vector<ll> side[N+10];
ll dcnt=0,n,m;
//
ll dfs1(ll po,ll dep){
	dth[po]=dep;
	ll rt=1,mmax=-1e18;
	for(int i=0; i<side[po].size(); ++i){
		ll tx=side[po][i];
		if(tx!=fa[po]){
			fa[tx]=po;
			ll lrt=dfs1(tx,dep+1);
			if(lrt>mmax){
				zson[po]=tx;
				mmax=lrt;
			} rt+=lrt;
		}
	}
	return rt;
}
void dfs2(ll po){
	dfn[po]=++dcnt;
	if(zson[po]){
		zfa[zson[po]]=zfa[po];
		dfs2(zson[po]);
	} 
	for(int i=0; i<side[po].size(); ++i){
		ll tx=side[po][i];
		if(tx!=fa[po]&&tx!=zson[po]){
			zfa[tx]=tx;
			dfs2(tx);
		}	
	}
}
void add(ll tord,ll l,ll r,ll ql,ll qr){
//	printf("%lld %lld %lld %lld %lld\n",tord,l,r,ql,qr);
	if(ql<=l&&r<=qr){
		T[tord]++; return;
	}
	T[(tord<<1)]+=T[tord];
	T[(tord<<1)|1]+=T[tord];
	T[tord]=0;
	if(ql<=mid) add((tord<<1),l,mid,ql,qr);
	if(qr>mid) add((tord<<1)|1,mid+1,r,ql,qr);
}
void lca(ll x,ll y){
	if(dth[zfa[x]]<dth[zfa[y]]) swap(x,y);
	while(zfa[x]!=zfa[y]){
		add(1,1,n,dfn[zfa[x]],dfn[x]);
		x=fa[zfa[x]];
		if(dth[zfa[x]]<dth[zfa[y]]) swap(x,y);
	}
	if(dth[x]<dth[y]) swap(x,y);
	if(x!=y)
	add(1,1,n,dfn[y]+1,dfn[x]);
	return;
}
ll que(ll tord,ll l,ll r,ll qord){
//	printf("%lld %lld %lld %lld\n",tord,l,r,qord);
	if(l==r) return T[tord];
	T[(tord<<1)]+=T[tord];
	T[(tord<<1)|1]+=T[tord];
	T[tord]=0;
	if(qord<=mid) return que((tord<<1),l,mid,qord);
	else return que((tord<<1)|1,mid+1,r,qord);
}
//
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Happy1041;
void usage() {
	ll time2=clock();
	cout<<(&Happy1041-&happy1041)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=gt(),m=gt();
	FOR(i,1,n-1){
		ll u=gt(),v=gt();
		side[u].push_back(v);
		side[v].push_back(u);
	}
	dfs1(1,1);
	zfa[1]=1; dfs2(1);
	FOR(i,1,m){
		string s; cin>>s; ll x=gt(),y=gt();
//		cout<<s; printf(" %lld %lld\n",x,y);
		if(s[0]=='P'){
			lca(x,y);
		}
		else{
			if(dth[x]<dth[y]) swap(x,y);
			wr(que(1,1,n,dfn[x]));
			puts("");
		}
	}
}
/*
LOOKING FOR:
Array limits
Special cases
file name
match by a brute force program
output(between "Yes" and "yes",)
*/



