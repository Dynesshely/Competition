/*Mlm:  Tlm:*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mid ((l+r)>>1)
#define FOR(i,a,b) for(long long i=(a); i<=(b); ++i)
#define ROF(i,a,b) for(long long i=(a); i>=(b); --i)
using namespace std;
bool happy1041;
ll time1=clock();
//
const ll N=1e3;
ll tot[2];
//
//
inline ll gt(){
	ll t=0,f=0;char v=getchar();
	while(!isdigit(v))f|=(v=='-'),v=getchar();
	while(isdigit(v))t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
inline void wr(ll x){
	if(x<0){x*=-1; putchar('-');}
	if(x>9) wr(x/10);
	putchar(x%10+'0');
	return;
}
bool Happy1041;
void usage() {
	ll time2=clock();
	cout<<(&Happy1041-&happy1041)/1024/1024<<" Mb, "<<time2-time1<<" Ms\n";
}
int main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	ll n=gt(),jz2; bool lb;
	if(n==0){
		printf("0"); return 0;
	} 
	else if(n>0){
		lb=1;
		tot[1]=jz2=1;
		while(n>tot[1]){
			jz2*=4;
			tot[1]+=jz2;
			tot[0]+=jz2/(-2);
		}
	}
	else if(n<0){
		lb=0;
		tot[0]=jz2=-2; tot[1]=1;
		while(n<tot[0]){
			jz2*=4;
			tot[0]+=jz2;
			tot[1]+=jz2/(-2);
		}
	} string ans;
	while(jz2!=0){
//		printf("%lld %lld %lld %lld\n",jz2,tot[0],tot[1],n);
		if(lb){
			if(n<0) ans+='0';
			else{
				if(n-jz2>=tot[lb^1]){
					ans+='1';
					n-=jz2;
				} 
				else ans+='0';
			}
		}
		else{
			if(n>0) ans+='0';
			else{
				if(n-jz2<=tot[lb^1]){
					ans+='1';
					n-=jz2;
				} 
				else ans+='0';
			}
		}
		tot[lb]-=jz2;
		jz2/=(-2);
		lb^=1;
	}
	cout<<ans;
}
/*
LOOKING FOR:
Array limits
Special cases
file name
match by a brute force program
output(between "Yes" and "yes",)
*/



