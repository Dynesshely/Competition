#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,a[34],b[34],ans[34];
signed main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	cin>>n,b[1]=a[1]=1;
	for(int i=2; i<=32; ++i) a[i]=a[i-1]*-2,b[i]=a[i]+b[i-2];
	while(n!=0) for(int i=1; i<=32; ++i) {
		if((n<0&&b[i]<=n)||(n>0&&b[i]>=n)) {
			ans[i]=1,n-=a[i];
			break;
		}
	}
	for(int i=32; i>=1; --i) if(ans[i]) for(i; i>=1; --i) cout<<ans[i];
	return 0;
}
/*
1 -2 4 -8 16 -32 64
1  0 1  0  1
*/
