#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10^48);
}
int n,k,l,r,mid,res,t;
int d[520][520];
int fx[4]= {-1,1,0,0},fy[4]= {0,0,1,-1};
bool vis[520][520];

bool ok(int w,int x,int y) {
	return x>=1&&x<=n&&y>=1&&y<=n&&!vis[x][y]&&w>=d[x][y];
}
void dfs(int w,int x,int y) {
	vis[x][y]=1,++t;
	for(int i=0; i<4; ++i) {
		int xt=x+fx[i],yt=y+fy[i];
		if(ok(w,xt,yt)) dfs(w,xt,yt);
	}
}
int check(int w) {
	int tot=0;
	for(int i=1; i<=n; ++i) for(int j=1; j<=n; ++j) vis[i][j]=0;
	for(int i=1; i<=n; ++i) for(int j=1; j<=n; ++j)
			if(!vis[i][j]) t=0,dfs(w,i,j),tot=max(tot,t);
	return tot;
}
signed main() {
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	n=read(),k=n*n+1>>1;
	for(int i=1; i<=n; ++i)
		for(int j=1; j<=n; ++j)
			d[i][j]=read(),r=max(r,d[i][j]);
	while(l<=r) {
		mid=(l+r)>>1;
		if(check(mid)>=k) res=mid,r=mid-1;
		else l=mid+1;
	}
	put(res);
	return 0;
}
/*
5
0 0 0 3 3
0 0 0 0 3
0 9 9 3 3
9 9 9 3 3
9 9 9 9 3
*/
