#include <Bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10^48);
}
int p,B1,B2,r;
int dd[9][9];

bool ok(int x,int y) {
	return x>=-4&&x<=4&&y>=-4&&y<=4;
}
void change(int x,int &k) {
	if(x>k) {
		if(B1>=k&&B1<x) k=B1+B1-k+1,change(x,k);
		else if(B2>=k&&B2<x) k=B2+B2-k+1,change(x,k);
	} else {
		if(B1<=k&&B1>x) k=B1+B1-k-1,change(x,k);
		else if(B2<=k&&B2>x) k=B2+B2-k-1,change(x,k);
	}
}
void solve(int x,int y,int t,int v) {
	int a=y-t,b=y+t,c=x-t,d=x+y;
	for(int i=1; i<t; ++i) {
		int xt1=x+i,xt2=x-i,yt1=a+i,yt2=a+i;
		change(y,yt1),change(y,yt2);
		if(ok(xt1,yt1)) dd[xt1+4][yt1+4]+=v;
		if(ok(xt2,yt2)) dd[xt2+4][yt2+4]+=v;
	}
	for(int i=1; i<t; ++i) {
		int xt1=x+i,xt2=x-i,yt1=b-i,yt2=b-i;
		change(y,yt1),change(y,yt2);
		if(ok(xt1,yt1)) dd[xt1+4][yt1+4]+=v;
		if(ok(xt2,yt2)) dd[xt2+4][yt2+4]+=v;
	}
	change(y,a),change(y,b);
	if(ok(x,a)) dd[x+4][a+4]+=v;
	if(ok(x,b)) dd[x+4][b+4]+=v;
	if(ok(c,y)) dd[c+4][y+4]+=v;
	if(ok(d,y)) dd[d+4][y+4]+=v;
}
signed main() {
	freopen("waves.in","r",stdin);
	freopen("waves.out","w",stdout);
	p=read(),B1=read(),B2=read(),r=read();
	if(B1>B2) swap(B1,B2);
	while(p--) {
		int x=read(),y=read(),t=read();
		if(r-t>=0) solve(x,y,r-t,1);
		if(r-t-2>=0) solve(x,y,r-t-2,-1);
	}
	for(int i=0; i<9; ++i) {
		for(int j=0; j<9; ++j) {
			if(j==B1+4||j==B2+4) putchar('X');
			else {
				if(dd[i][j]>0) putchar('*');
				if(dd[i][j]==0) putchar('-');
				if(dd[i][j]<0) putchar('o');
			}
		}
		putchar('\n');
	}
	return 0;
}
/*
1 second 2 seconds 3 seconds 4 seconds 5 seconds
X------  X------  X--*---  X-*-*--  X*---*-
X------  X--*---  X-*-*--  X*---*-  X*----*
X--*---  X-*-*--  X*---*-  X*----*  X-*----
X-*-*--  X*---*-  X*----*  X-*----  X--*---
X--*---  X-*-*--  X*---*-  X*----*  X-*----
X------  X--*---  X-*-*--  X*---*-  X*----*
X------  X------  X--*---  X-*-*--  X*---*-

                                         *
                              *         * *
X------  X------  X--*---  X-*-*--    X*---*-
X------  X--*---  X-*-*--  X*---*-    *-----*
X--*---  X-*-*--  X*---*-  *-----*   *X------*
X-*-*--  X*---*-  *-----* *X------* * X------ *
X--*---  X-*-*--  X*---*-  *-----*   *X------*
X------  X--*---  X-*-*--  X*---*-    *-----*
X------  X------  X--*---  X-*-*--    X*---*-
                              *         * *
                                         *
*/
