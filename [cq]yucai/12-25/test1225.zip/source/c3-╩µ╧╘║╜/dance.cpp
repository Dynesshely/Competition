#include <bits/stdc++.h>
#define int long long
#define pip pair<int, pair<int, int> >
#define mp make_pair 
#define fi first
#define se second
using namespace std;
int read() {
	int x=0,f=0; char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10^48);
}
int n,m,a[35][35];
int sx,sy,ex,ey;
int fx[8]={-2,-2,2,2,-1,1,-1,1};
int fy[8]={-1,1,-1,1,-2,-2,2,2};
bool vis[35][35];
int d[35][35],dp[35][35];
priority_queue<pip> pq;
queue<pip> q;

bool ok(int x,int y) {
	return x>=1&&x<=n&&y>=1&&y<=m&&a[x][y]!=2;
}
signed main() {
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i) {
		for(int j=1;j<=m;++j) {
			a[i][j]=read(),d[i][j]=1e9;
			if(a[i][j]==3) sx=i,sy=j;
			if(a[i][j]==4) ex=i,ey=j;
		}
	}
	d[sx][sy]=0;
	pq.push(mp(0,mp(sx,sy)));
	while(!pq.empty()) {
		int x=pq.top().se.fi,y=pq.top().se.se;
		pq.pop();
		if(vis[x][y]) continue;
		vis[x][y]=1;
		for(int i=0;i<8;++i) {
			int xt=x+fx[i],yt=y+fy[i];
			if(!ok(xt,yt)) continue;
			if(d[x][y]+(!a[xt][yt])<d[xt][yt]) {
				d[xt][yt]=d[x][y]+(!a[xt][yt]);
				pq.push(mp(-d[xt][yt],mp(xt,yt)));
			}
		}
	}
	put(d[ex][ey]),putchar('\n');
	memset(vis,0,sizeof vis);
	dp[sx][sy]=1;
	q.push(mp(0,mp(sx,sy)));
	while(!q.empty()) {
		int x=q.front().se.fi,y=q.front().se.se,w=q.front().fi;
		q.pop();
		if(vis[x][y]) continue;
		vis[x][y]=1;
		for(int i=0;i<8;++i) {
			int xt=x+fx[i],yt=y+fy[i];
			if(!ok(xt,yt)||vis[xt][yt]) continue;
			dp[xt][yt]+=dp[x][y];
			if(w+(!a[xt][yt])<=d[ex][ey])q.push(mp(w+(!a[xt][yt]),mp(xt,yt)));
		}
	}
	put(dp[ex][ey]),putchar('\n');
	return 0;
}
/*
4 5
1 0 0 0 0
3 0 0 0 0
0 0 2 0 0
0 0 0 4 0
*/
