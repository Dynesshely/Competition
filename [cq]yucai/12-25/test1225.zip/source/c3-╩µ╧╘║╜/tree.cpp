#include <bits/stdc++.h>
#define int long long
#define ls (x << 1)
#define rs (x << 1 | 1)
#define mid (l + r >> 1)
using namespace std;
int read() {
	int x=0,f=0;
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void put(int x) {
	if(x<0) putchar('-'),x=-x;
	if(x>=10) put(x/10);
	putchar(x%10^48);
}
const int Maxn=1e5+10;
int n,m;
vector<int> a[Maxn];
int dep[Maxn],fa[Maxn],siz[Maxn];
int dfn[Maxn],top[Maxn],son[Maxn],cnt;

struct SegmentTree {
	int a[Maxn],tree[Maxn<<2],tag[Maxn<<2],sz[Maxn<<2];
	void PushDown(int x,int l,int r) {
		tree[ls]=tree[ls]+sz[ls]*tag[x];
		tree[rs]=tree[rs]+sz[rs]*tag[x];
		tag[ls]=tag[ls]+tag[x];
		tag[rs]=tag[rs]+tag[x];
		tag[x]=0;
	}
	void Build(int x,int l,int r) {
		sz[x]=r-l+1;
		if(l==r) return;
		Build(ls,l,mid),Build(rs,mid+1,r);
	}
	void Change(int x,int l,int r,int L,int R,int v) {
		if(l>=L&&r<=R) {
			tree[x]=tree[x]+sz[x]*v;
			tag[x]=tag[x]+v;
			return;
		}
		PushDown(x,l,r);
		if(L<=mid) Change(ls,l,mid,L,R,v);
		if(R>mid) Change(rs,mid+1,r,L,R,v);
		tree[x]=tree[ls]+tree[rs];
	}
	int Ask(int x,int l,int r,int L,int R) {
		int res=0;
		if(l>=L&&r<=R) return tree[x];
		PushDown(x,l,r);
		if(L<=mid) res=res+Ask(ls,l,mid,L,R);
		if(R>mid) res=res+Ask(rs,mid+1,r,L,R);
		return res;
	}
} Seg;
void dfs1(int x) {
	siz[x]=1;
	for(int i=0; i<a[x].size(); i++) {
		int v=a[x][i];
		if(!dep[v]) {
			fa[v]=x,dep[v]=dep[x]+1;
			dfs1(v);
			siz[x]+=siz[v];
			if(siz[v]>siz[son[x]]) son[x]=v;
		}
	}
}
void dfs2(int x,int t) {
	dfn[x]=++cnt,top[x]=t;
	if(son[x]) dfs2(son[x],t);
	for(int i=0; i<a[x].size(); i++) {
		int v=a[x][i];
		if(v!=son[x]&&v!=fa[x]) dfs2(v,v);
	}
}
int Lca(int x,int y) {
	int fx=top[x],fy=top[y];
	while(fx!=fy) {
		if(dep[fx]<dep[fy]) swap(x,y),swap(fx,fy);
		x=fa[fx],fx=top[x];
	}
	return dep[x]<dep[y]?x:y;
}
void Add(int x,int y,int z) {
	int fx=top[x],fy=top[y];
	while(fx!=fy) {
		if(dep[fx]<dep[fy]) swap(x,y),swap(fx,fy);
		Seg.Change(1,1,cnt,dfn[fx],dfn[x],z);
		x=fa[fx],fx=top[x];
	}
	if(dfn[x]>dfn[y]) swap(x,y);
	Seg.Change(1,1,cnt,dfn[x],dfn[y],z);
}
int Ask(int x,int y) {
	int ans=0,fx=top[x],fy=top[y];
	while(fx!=fy) {
		if(dep[fx]<dep[fy]) swap(x,y),swap(fx,fy);
		ans=ans+Seg.Ask(1,1,cnt,dfn[fx],dfn[x]);
		x=fa[fx],fx=top[x];
	}
	if(dfn[x]>dfn[y]) swap(x,y);
	ans=ans+Seg.Ask(1,1,cnt,dfn[x],dfn[y]);
	return ans;
}

signed main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read(),m=read();
	for(int i=1; i<n; ++i) {
		int u=read(),v=read();
		a[u].push_back(v);
		a[v].push_back(u);
	}
	dep[1]=1;
	dfs1(1),dfs2(1,1);
	Seg.Build(1,1,n);
	while(m--) {
		char c;
		cin>>c;
		int l=read(),r=read(),k=Lca(l,r),res=0;
		if(c=='P') Add(l,r,1),Add(k,k,-1);
		if(c=='Q') {
			res=Ask(l,r)-Ask(k,k);
			put(res),putchar('\n');
		}
	}
	return 0;
}
/*
4 6
1 4
2 4
3 4
P 2 3
P 1 3
Q 3 4
P 1 4
Q 2 4
Q 1 4
*/
