#include<bits/stdc++.h> 
using namespace std;


int p, x[5], y[5], t[5], a, b, r;
int h[9] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };

int foo(int z, int a, int b)
{
    int i = (z - a - 1) % (2*b - 2*a - 2);
    if (i < 0) i += 2*b - 2*a - 2;
    if (i >= b - a - 1) i = 2*b - 2*a - 3 - i;
    i += a + 1;
    return i;
}

int main()
{  freopen("waves.in","r",stdin);
   freopen("waves.out","w",stdout);

    cin >> p >> a >> b >> r;
    for (int k = 0; k < p; ++k)
	cin >> x[k] >> y[k] >> t[k];
    if (a > b) a ^= b ^= a ^= b;
    for (int j = 4; j >= -4; --j)
    {
	for (int i = -4; i <= 4; ++i) h[i + 4] = 0;
	for (int k = 0; k < p; ++k)
	{
	    int aa = x[k] > b ? b : x[k] > a ? a : -500000000;
	    int bb = x[k] < a ? a : x[k] < b ? b : 500000000;
	    int i, z = r - t[k] - abs(j - y[k]);
	    if (z < 0) continue;
	    i = foo(x[k] + z, aa, bb); if (i >= -4 && i <= 4) ++h[i + 4];
	    if (z)
	    { i = foo(x[k] - z, aa, bb); if (i >= -4 && i <= 4) ++h[i + 4]; }
	    z -= 2;
	    if (z < 0) continue;
	    i = foo(x[k] + z, aa, bb); if (i >= -4 && i <= 4) --h[i + 4];
	    if (z)
	    { i = foo(x[k] - z, aa, bb); if (i >= -4 && i <= 4) --h[i + 4]; }
	}
	for (int i = -4; i <= 4; ++i)
	    cout << (i == a || i == b ? 'X' :
		     h[i + 4] > 0 ? '*' : h[i + 4] < 0 ? 'o' : '-');
	cout << endl;
    }
    return 0;
}
