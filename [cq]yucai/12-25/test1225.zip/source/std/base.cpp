#include<bits/stdc++.h> 
using namespace std;
long long  k,i,n;
int a[10000];
int main()
{  freopen("base.in","r",stdin);
   freopen("base.out","w",stdout);
    cin >>n;
    k=0;
    if(n==0) k++;
    for(;n;)
	{
		k++;
		a[k]=abs(n%-2);
		n=-(n-a[k])/2;
	}
	for (int i=k;i>=1;--i)
	    cout<<a[i];
	cout << endl;
    return 0;
}
