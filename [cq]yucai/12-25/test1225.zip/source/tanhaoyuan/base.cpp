#include<bits/stdc++.h>
using namespace std;
long long n,sp[10000],k,l,a,sum[1000],q=0,sp3[500];
void jb(int p) {
	if(p==k) {
		int ans=0;
		for(int i=0; i<k; i++) {
			ans=ans+sp[i]*sum[i];
		}
		if(ans==n) {
			for(int i=k-1; i>=0; i--) printf("%d",sum[i]);
			cout<<endl;
			q=1;
		}
		return;
	}
	sum[p]=1;
	jb(p+1);
	if(q==1) return;
	sum[p]=0;
	jb(p+1);
	return;
}

int main() {
	sp[0]=1;
	sp3[1]=1;
	scanf("%lld",&n);
	
	for(int i=1; i<=30; i++) sp[i]=sp[i-1]*(-2);
	for(int i=2; i<=40; i++) sp3[i]=sp3[i-1]*2;
	sp3[1]=2;
	if(n==0) {
		cout<<"0"<<endl;
		return 0;
	}
	if(n>0) {
		k=1;
		l=1;
		a=n;
	}
	if(n<0) {
		k=2;
		l=2;
		a=-n;
	//	n=-n;
	}
	while(a-l>=0) {
		a=a-l;
		if(a==0) break;
		l=l*4;
		k=k+2;
	}
//	cout<<k<<endl;
//	sum[k]=1;
		jb(0);
}
