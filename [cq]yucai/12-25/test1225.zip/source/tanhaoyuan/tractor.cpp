#include<bits/stdc++.h>
using namespace std;
int n,sp[1000][1000],maxn=0,lr=0,mid,sum=0,p=0,ans=0,asn=0;
int sp2[520][520];
void jb(int x,int y) {
	//cout<<x<<' '<<y<<endl;
	sum++;
	sp2[x][y]=1;
	if(x-1!=0)
		if(abs(sp[x][y]-sp[x-1][y])<=mid&&sp2[x-1][y]==0) jb(x-1,y);
	if(x+1!=n+1)
		if(abs(sp[x][y]-sp[x+1][y])<=mid&&sp2[x+1][y]==0) jb(x+1,y);
	if(y+1!=n+1)
		if(abs(sp[x][y]-sp[x][y+1])<=mid&&sp2[x][y+1]==0) jb(x,y+1);
	if(y-1!=0)
		if(abs(sp[x][y]-sp[x][y-1])<=mid&&sp2[x][y-1]==0) jb(x,y-1);
}
int main() {
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	scanf("%d",&n);
	p=n*n/2;
	if(n%2==1) p++;
	for(int i=1; i<=n; i++)
		for(int y=1; y<=n; y++)
			scanf("%d",&sp[i][y]);
	for(int i=2; i<n; i++)
		for(int y=2; y<n; y++)
			maxn=max(maxn,max(abs(sp[i][y]-sp[i-1][y]),max(abs(sp[i][y]-sp[i][y-1]),max(abs(sp[i][y]-sp[i+1][y]),abs(sp[i][y]-sp[i][y+1])))));
	while(lr<=maxn) {
		//cout<<lr<<" "<<maxn<<endl;
		ans=0;
		mid=(lr+maxn)/2;
		for(int i=1; i<=n; i++) {
			for(int y=1; y<=n; y++) {
				if(sp2[i][y]==0) {
					sum=0;
					//cout<<1;
					jb(i,y);
					//cout<<1;
					ans=max(ans,sum);
				}
			}
		}
		if(ans>=p){		
			asn=mid;
			maxn=mid-1;
		} 
		else lr=mid+1;
		memset(sp2,0,sizeof(sp2));
	}
	printf("%d\n",asn);
}
