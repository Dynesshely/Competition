#include<bits/stdc++.h>
using namespace std;
int n,m,sp[40][40],x,z,xd,zd,sp2[50][50],ans=1000000,sum=0;
long long p=0;
void jb(int w,int e) {
	sp2[w][e]=1;
	if(sp[w][e]==0) sum++;
	if(sp[w][e]==2) return;
	if(sp[w][e]==4) {
        //p++;
		ans=min(ans,sum);
		return;
	}
	if(w-2>=1&&e-1>=1&&sp2[w-2][e-1]==0) {
		jb(w-2,e-1);
		sp2[w-2][e-1]=0;
		if(sp[w-2][e-1]==0) sum--;
	}
	if(w+2<=n&&e-1>=1&&sp2[w+2][e-1]==0) {
		jb(w+2,e-1);
		sp2[w+2][e-1]=0;
		if(sp[w+2][e-1]==0) sum--;
	}
	if(w-2>=1&&e+1<=m&&sp2[w-2][e+1]==0) {
		jb(w-2,e+1);
		sp2[w-2][e+1]=0;
		if(sp[w-2][e+1]==0) sum--;
	}
	if(w+2<=n&&e+1<=m&&sp2[w+2][e+1]==0) {
		jb(w+2,e+1);
		sp2[w+2][e+1]=0;
		if(sp[w+2][e+1]==0) sum--;
	}
	if(w-1>=1&&e-2>=1&&sp2[w-1][e-2]==0) {
		jb(w-1,e-2);
		sp2[w-1][e-2]=0;
		if(sp[w-1][e-2]==0) sum--;
	}
	if(w+1<=n&&e-2>=1&&sp2[w+1][e-2]==0) {
		jb(w+1,e-2);
		sp2[w+1][e-2]=0;
		if(sp[w+1][e-2]==0) sum--;
	}
	if(w-1>=1&&e+2<=m&&sp2[w-1][e+2]==0) {
		jb(w-1,e+2);
		sp2[w-1][e+2]=0;
		if(sp[w-1][e+2]==0) sum--;
	}
	if(w+1<=n&&e+2<=m&&sp2[w+1][e+2]==0) {
		jb(w+1,e+2);
		sp2[w+1][e+2]=0;
		if(sp[w+1][e+2]==0) sum--;
	}
	return;
}
int main() {
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=n; i++) {
		for(int y=1; y<=m; y++) {
			scanf("%d",&sp[i][y]);
			if(sp[i][y]==3)  x=i,z=y;
		//	if(sp[i][y]==4)  xd=i,zd=y;
		}
	}
	jb(x,z);
	if(ans==1000000){
		cout<<"-1"<<endl;
		return 0;
	}
	cout<<ans<<endl<<"3"<<endl;
}
