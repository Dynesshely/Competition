#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int s=0,w=1;
	char ch=getchar();
	while('0'>ch || ch>'9')
	{
		if(ch=='-') w=0;
		ch=getchar();
	}
	while('0'<=ch && ch<='9')
	{
		s=(s<<3)+(s<<1)+ch-'0';
		ch=getchar();
	}
	return w?s:-s;
}
void out(long long x)
{
	if(x==0)
	{
		putchar('0');
		return ;
	}
	static int sta[21],top=0;
	while(x)
	{
		sta[++top]=x%10;
		x/=10;
	}
    while(top)
    {
    	putchar(sta[top--]+'0');
	}
}
int n,m,mp[35][35],sx,sy,ex,ey,tans=0;
long long cnt[1005];
int dir[8][2]={{1,2},{-1,2},{1,-2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-2}};
bitset<35> vis[35];
inline bool in(const int& x,const int& y)
{
	return 0<x && x<=n && 0<y && y<=n && !vis[x][y] && mp[x][y]!=2;
}
void dfs(int x,int y)
{
	if(mp[x][y]==4)
	{
		++cnt[tans];
		return ;
	}
	vis[x][y]=1;
	if(mp[x][y]==0) ++tans;
	int nx,ny;
	for(int i=0;i<8;++i)
	{
		nx=x+dir[i][0];
		ny=y+dir[i][1];
		if(in(nx,ny)) dfs(nx,ny);
	}
	vis[x][y]=0;
	if(mp[x][y]==0) --tans;
}
int main()
{
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=n;++j)
		{
			mp[i][j]=read();
			if(mp[i][j]==3) sx=i,sy=j;
			if(mp[i][j]==4) ex=i,ey=j;
		}
	}
	dfs(sx,sy);
	for(int i=0;i<=1000;++i)
	{
		if(cnt[i])
		{
			out(i);
			putchar('\n');
			out(cnt[i]);
			return 0;
		}
	}
	printf("-1");
	return 0;
}

