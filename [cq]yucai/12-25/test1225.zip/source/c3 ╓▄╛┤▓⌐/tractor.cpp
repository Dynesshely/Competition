#include<iostream>
#include<bitset>
#define max(x,y) (x>y?x:y)
#define min(x,y) (x<y?x:y)
inline int read()
{
	int s=0,w=1;
	char ch=getchar();
	while('0'>ch || ch>'9')
	{
		if(ch=='-') w=0;
		ch=getchar();
	}
	while('0'<=ch && ch<='9')
	{
		s=(s<<3)+(s<<1)+ch-'0';
		ch=getchar();
	}
	return w?s:-s;
}
void out(long long x)
{
	if(x==0)
	{
		putchar('0');
		return ;
	}
	static int sta[21],top=0;
	while(x)
	{
		sta[++top]=x%10;
		x/=10;
	}
    while(top)
    {
    	putchar(sta[top--]+'0');
	}
}
int n,mp[505][505],r=-1,l=1000001,mid,pur,tmp,tot;
int dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
std::bitset<105> vis[105];
inline int abs(const int x)
{
	return (x>0)?x:-x;
}
inline bool in(const int& x,const int& y)
{
	return 0<x && x<=n && 0<y && y<=n && !vis[x][y];
}
void dfs(const int& x,const int& y,const int& k)
{
	int nx,ny;
	vis[x][y]=1,++tmp;
	for(int i=0;i<4;++i)
	{
		nx=x+dir[i][0];
		ny=y+dir[i][1];
		if(in(nx,ny) && (abs(mp[x][y]-mp[nx][ny])<=k)) dfs(nx,ny,k);
	}
}
inline bool ok(const int& k)
{
	tot=0;
	for(int i=1;i<=n;++i) vis[i].reset();
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=n;++j)
		{
			if(!vis[i][j])
			{
				tmp=0;
				dfs(i,j,k);
				tot=max(tot,tmp);
			}
		}
	}
	return (tot>=pur);
}
int main()
{
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	n=read(),pur=n*n/2;
	if(n&1) ++pur;
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=n;++j)
		{
			mp[i][j]=read();
			r=max(mp[i][j],r);
			l=min(mp[i][j],l);
		}
	}
	while(l<r-1)
	{
		mid=(l+r)>>1;
		if(ok(mid)) r=mid;
		else l=mid;
	}
	out(ok(l)?l:r);
	return 0;
}

