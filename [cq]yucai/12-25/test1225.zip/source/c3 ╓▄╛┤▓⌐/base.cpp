#include<bits/stdc++.h>
using namespace std;
inline long long read()
{
	long long s=0;
	int w=1;
	char ch=getchar();
	while('0'>ch || ch>'9')
	{
		if(ch=='-') w=0;
		ch=getchar();
	}
	while('0'<=ch && ch<='9')
	{
		s=(s<<3)+(s<<1)+ch-'0';
		ch=getchar();
	}
	return w?s:-s;
}
long long n,base[115],mx[115],mn[115];
int i,flag=0;
int main()
{
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	n=read();
	if(n==0)
	{
		putchar('0');
		return 0;
	}
	if(n<0)
	{
		n=-n;
		base[0]=-1;
		mn[0]=-1,mx[0]=0;
	}
	else
	{
		base[0]=1;
		mn[0]=0,mx[0]=1;
	}
	for(i=1; i<=114; ++i)
	{
		base[i]=base[i-1]*-2;
		mx[i]=mx[i-1];
		mn[i]=mn[i-1];
		if(base[i]>0) mx[i]+=base[i];
		else mn[i]+=base[i];
		if(base[i]>n) break;
	}
	for(; i>=0; --i)
	{
		if(mn[i-1]<=(n-base[i]) && (n-base[i])<=mx[i-1])
		{
			n-=base[i];
			putchar('1');
			flag=1;
		}
		else if(flag) putchar('0');
	}
	return 0;
}

