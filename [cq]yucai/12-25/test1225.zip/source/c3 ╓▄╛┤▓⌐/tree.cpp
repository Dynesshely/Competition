#include<iostream>
#include<bitset>
#define l(x) tree[x].l
#define r(x) tree[x].r
#define ls(x) (x<<1)
#define rs(x) ((x<<1)|1)
#define wid(x) (tree[x].r-tree[x].l+1)
#define tag(x) tree[x].tag
#define dat(x) tree[x].dat
inline int read()
{
	int s=0,w=1;
	char ch=getchar();
	while('0'>ch || ch>'9')
	{
		if(ch=='-') w=0;
		ch=getchar();
	}
	while('0'<=ch && ch<='9')
	{
		s=(s<<3)+(s<<1)+ch-'0';
		ch=getchar();
	}
	return w?s:-s;
}
void out(long long x)
{
	if(x==0)
	{
		putchar('0');
		return ;
	}
	static int sta[21],top=0;
	while(x)
	{
		sta[++top]=x%10;
		x/=10;
	}
    while(top)
    {
    	putchar(sta[top--]+'0');
	}
}
struct sgt
{
	int dat,tag,l,r;
}tree[100005];
int n,m,u,v,ecnt=0,cnt=0,head[100005],nxt[100005],to[100005],tlca,lst;
int fa[100005],son[100005],siz[100005],dep[100005],dfn[100005],top[100005];
char op;
std::bitset<100005> vis;
inline void add(const int& x,const int& y)
{
	to[++ecnt]=y,nxt[ecnt]=head[x],head[x]=ecnt;
	to[++ecnt]=x,nxt[ecnt]=head[y],head[y]=ecnt;
}
void build(const int& p,const int& l,const int& r)
{
	l(p)=l,r(p)=r;
	if(l==r) return ;
	int mid=(l+r)>>1;
	build(ls(p),l,mid);
	build(rs(p),mid+1,r);
}
inline void pushdown(const int& p)
{
	if(tag(p))
	{
		tag(ls(p))+=tag(p);
		tag(rs(p))+=tag(p);
		dat(ls(p))+=(wid(ls(p))*tag(p));
		dat(rs(p))+=(wid(rs(p))*tag(p));
		tag(p)=0;
	}
}
void update(const int& p,const int& l,const int& r,const int& d)
{
	if(l<=l(p) && r(p)<=r)
	{
		tag(p)+=d;
		dat(p)+=(wid(p)*d);
		return ;
	}
	pushdown(p);
	int mid=(l(p)+r(p))>>1;
	if(l<=mid) update(ls(p),l,r,d);
	if(r>mid) update(rs(p),l,r,d);
	dat(p)=dat(ls(p))+dat(rs(p));
	return ;
}
long long getsum(const int& p,const int& l,const int& r)
{
	if(l<=l(p) && r(p)<=r)
		return dat(p);
	pushdown(p);
	int mid=(l(p)+r(p))>>1;
	long long ret=0;
	if(l<=mid) ret+=getsum(ls(p),l,r);
	if(r>mid) ret+=getsum(rs(p),l,r);
	return ret;
}
void uppoi(const int& p,const int& k,const int& d)
{
	if(k==l(p) && r(p)==k)
	{
		tag(p)=0;
		dat(p)=d;
		return ;
	}
	pushdown(p);
	int mid=(l(p)+r(p))>>1;
	if(k<=mid) uppoi(ls(p),k,d);
	else uppoi(rs(p),k,d);
	dat(p)=dat(ls(p))+dat(rs(p));
	return ;
}
int getpoi(const int& p,const int& k)
{
	if(k==l(p) && r(p)==k)
		return dat(p);
	pushdown(p);
	int mid=(l(p)+r(p))>>1;
	if(k<=mid) return getpoi(ls(p),k);
	return getpoi(rs(p),k);
}
void dfs1(const int& k)
{
	siz[k]=1,vis[k]=1,son[k]=0;
	for(int i=head[k];i;i=nxt[i])
	if(!vis[to[i]])
	{
		dep[to[i]]=dep[k]+1;
		fa[to[i]]=k;
		dfs1(to[i]);
		siz[k]+=siz[to[i]];
		if(siz[to[i]]>=siz[son[k]])
			son[k]=to[i];
	}
}
void dfs2(const int& k,const int& tp)
{
	vis[k]=1,top[k]=tp;
	dfn[k]=++cnt;
	if(son[k]==0)
		return;
	dfs2(son[k],tp);
	for(int i=head[k];i;i=nxt[i])
		if(!vis[to[i]]) dfs2(to[i],to[i]);
	return;
}
inline int lca(int x,int y)
{
	int fx=top[x],fy=top[y];
	while(fx!=fy)
	{
		
		if(dep[fx]>=dep[fy])
			x=fa[fx],fx=top[x];
		else
			y=fa[fy],fy=top[y];
	}
	return dep[x]<dep[y]?x:y;
}
inline long long query(int x,int y)
{
	long long ret=0;
	int fx=top[x],fy=top[y];
	while(fx!=fy)
	{
		if(dep[fx]>=dep[fy])
			ret+=getsum(1,dfn[fx],dfn[x]),x=fa[fx];
		else
			ret+=getsum(1,dfn[fy],dfn[y]),y=fa[fy];
		fx=top[x],fy=top[y];
	}
	if(dfn[x]<dfn[y])
		ret+=getsum(1,dfn[x],dfn[y]);
	else
		ret+=getsum(1,dfn[y],dfn[x]);
	return ret;
}
inline void plant(int x,int y)
{
	long long fx=top[x],fy=top[y];
	while(fx!=fy)
	{
		if(dep[fx]>=dep[fy])
			update(1,dfn[fx],dfn[x],1),x=fa[fx];
		else
			update(1,dfn[fy],dfn[y],1),y=fa[fy];
		fx=top[x],fy=top[y];
	}
	if(dfn[x]<dfn[y])
		update(1,dfn[x],dfn[y],1);
	else
		update(1,dfn[y],dfn[x],1);
	return;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read(),m=read(),++m;
	for(int i=1;i<n;++i)
	{
		u=read(),v=read();
		add(u,v);
	}
	add(0,1);
	vis.reset(),dfs1(1);
	vis.reset(),dfs2(1,1);
	build(1,1,n);
	while(--m)
	{
		scanf("%c ",&op);
		u=read(),v=read();
		tlca=lca(u,v);
		lst=getpoi(1,dfn[tlca]);
		if(op=='P') plant(u,v),uppoi(1,dfn[tlca],lst);
		else out(query(u,v)-lst),putchar('\n');
	}
	return 0;
}
