#include<bits/stdc++.h>
using namespace std;
const int maxn=36,maxs=1006;
int n,m,ch[maxn][maxn],sx,sy,tx,ty,f[8][2]={{1,2},{-1,2},{1,-2},{-1,-2},{2,1},{-2,1},{2,-1},{-2,-1}};
long long dp[maxn][maxn][maxs];
bool check(int x,int y){
	return ch[x][y]!=2&&x>=1&&x<=n&&y>=1&&y<=m;
}
int main(){
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&ch[i][j]);
			if(ch[i][j]==3)sx=i,sy=j;
			else if(ch[i][j]==4)tx=i,ty=j;
		}
	}
	memset(dp,0,sizeof(dp));
	dp[sx][sy][0]=1;
	int nx,ny;
	for(int k=0;k<=maxs-2;k++){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				for(int fx=0;fx<8;fx++){
					nx=i+f[fx][0],ny=j+f[fx][1];
					if(check(nx,ny)){
						if(ch[nx][ny]==1){
							dp[nx][ny][k]+=dp[i][j][k];
						}
						else {
							dp[nx][ny][k+1]+=dp[i][j][k];
						}
					}
				}
			}
		}
		if(dp[tx][ty][k]){
			printf("%d\n%d",k-1,dp[tx][ty][k]);
			return 0;
		}
	}
	printf("-1");
	return 0;
}
