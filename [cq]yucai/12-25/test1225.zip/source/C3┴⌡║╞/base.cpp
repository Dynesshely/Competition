#include<bits/stdc++.h>
using namespace std;
const int maxn=10000007;
int n,f,v[maxn*2];
int main(){
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	scanf("%d",&n);
	if(n==0){
		putchar('0');
		return 0;
	}
	f=(n>0)?1:-1;
	int absn=abs(n),lg=0;
	while(absn>0){
		if(absn&1){
			v[(1<<lg)*f+maxn]++;
		}
		lg++;
		absn/=2;
	}
//	for(int i=0;i<=20;i++){
//		if(v[(1<<i)*f+maxn])printf("%d ",(1<<i)*f);
//	}putchar('\n');
	int ma,bi;
	bool flag=1;
	while(flag){
		flag=0;
		for(int i=0;i<=20;++i){
			while(v[(1<<i)+maxn]>0&&v[-(1<<i)+maxn]>0){
				v[(1<<i)+maxn]--,v[-(1<<i)+maxn]--;
			}
			if(v[(1<<i)+maxn]>0)ma=(1<<i);
			else if(v[-(1<<i)+maxn]>0)ma=-(1<<i);
			else ma=0;
			bi=(1<<i)*((i&1)?-1:1);
			if(ma==bi){
				if(v[ma+maxn]>1)flag=1;
				v[2*ma+maxn]+=v[ma+maxn]/2;
				v[ma+maxn]%=2;
			}
			else if(ma==-bi){
//				cout<<ma<<' '<<bi<<' '<<"boom\n";
				flag=1;
				v[-ma+maxn]+=v[ma+maxn];
				v[2*ma+maxn]+=v[ma+maxn];
				v[ma+maxn]=0;
			}
		}
//		cout<<flag<<'\n';
	}
	flag=0;
	for(int i=20;i>=0;--i){
		bi=(1<<i)*((i&1)?-1:1);
		if(v[bi+maxn])flag=1,putchar('1');
		else if(flag)putchar('0');
	}
	return 0;
}
