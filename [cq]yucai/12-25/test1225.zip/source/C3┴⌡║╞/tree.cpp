#include<bits/stdc++.h>
using namespace std;
const int maxn=100007,maxm=200007;
const int logn=21;
int n,m,root,maxrtson=1e9,w[maxn],tmp[maxn],size[maxn],fa[logn][maxn],dep[maxn];
int cnt,hed[maxn],nxt[maxm],to[maxm],val[maxm];
void add(int u,int v){
	nxt[++cnt]=hed[u];
	hed[u]=cnt;
	to[cnt]=v;
	return ;
}
void getroot(int x,int f){
	size[x]=1;
	int v,maxson=0;
	for(int i=hed[x];i;i=nxt[i]){
		v=to[i];
		if(v==f)continue;
		getroot(v,x);
		size[x]+=size[v];
		maxson=max(maxson,size[v]);
	}
	maxson=max(maxson,n-size[x]);
	if(maxson<maxrtson){
		maxrtson=maxson;
		root=x;
	}
	return ;
}
void dfs(int x){
	int v;
	for(int i=hed[x];i;i=nxt[i]){
		v=to[i];
		if(v==fa[0][x])continue;
		fa[0][v]=x,dep[v]=dep[x]+1;
		tmp[v]=i;
		dfs(v);
	}
	return ;
}
void pre(){
	for(int i=1;i<logn;i++){
		for(int j=1;j<=n;j++){
			fa[i][j]=fa[i-1][fa[i-1][j]];
		}
	}
	return ;
}
int lca(int u,int v){
	if(dep[u]<dep[v])swap(u,v);
	for(int i=logn-1;i>=0;i--){
		if(dep[fa[i][u]]>=dep[v]){
			u=fa[i][u];
		}
	}
	if(u==v)return u;
	for(int i=logn-1;i>=0;i--){
		if(fa[i][u]!=fa[i][v]){
			u=fa[i][u],v=fa[i][v];
		}
	}
	return fa[0][u];
}
void modifycf(int u,int v){
	int lcauv=lca(u,v);
//	cout<<u<<' '<<v<<' '<<lcauv<<'\n';
	w[lcauv]-=2;
	w[u]++,w[v]++;
}
//int querycf(int u){
//	if(u==root)return 0;
//	return querycf(fa[0][u])+w[fa[0][u]];
//}
int querycf(int u){
	int v,sum=0;
	for(int i=hed[u];i;i=nxt[i]){
		v=to[i];
		if(v==fa[0][u])continue;
		sum+=querycf(v);
	}
	return sum+w[u];
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&n,&m);
	int u,v;
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	getroot(1,0);
	dfs(root);
	pre();
//	printf("root=%d\n",root);
	char ty;
	for(int i=1;i<=m;i++){
		cin>>ty;
		scanf("%d%d",&u,&v);
		if(ty=='P')modifycf(u,v);
		else {
			if(dep[u]<dep[v])swap(u,v);
			printf("%d\n",querycf(u));
		}
	}
	return 0;
}
