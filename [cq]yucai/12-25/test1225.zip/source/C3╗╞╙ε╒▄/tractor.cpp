#include<bits/stdc++.h>
using namespace std;
const int MAX = 5e2+10;
struct node{
	int x,y;
}lr;
int n,l,r=1e6,mid,ans=1e6,res,cnt;
int a[MAX][MAX],fx[4][2]={{0,1},{1,0},{-1,0},{0,-1}};
bool vis[MAX][MAX];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
bool pd(int x,int y)
{
	if(x<0 or y<0 or x>n+1 or y>n+1 or vis[x][y]) return false;
	return true;
}
bool check(int x)
{
	memset(vis,0,sizeof(vis));
	queue<node>ls;
	ls.push((node){0,0});
	vis[0][0]=1,res=-3-4*n;
	while(!ls.empty())
	{
		lr = ls.front();
		ls.pop();
		for(int i = 0;i<4;i++)
			if(pd(lr.x+fx[i][0],lr.y+fx[i][1]) and abs(a[lr.x][lr.y]-a[lr.x+fx[i][0]][lr.y+fx[i][1]])<=x) 
			{
				vis[lr.x+fx[i][0]][lr.y+fx[i][1]]=1,res++;
				ls.push((node){lr.x+fx[i][0],lr.y+fx[i][1]});
			}
	}
	if(res>=cnt) return true;
	return false;
}
int main()
{
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	n = read();
	if(n%2==1)cnt = n*n/2+1;
	else cnt = n*n/2;
	for(int i = 1;i<=n;i++) 
		for(int j = 1;j<=n;j++) a[i][j] = read();
	while(l<=r)
	{
		mid = (l+r)>>1;
		if(check(mid)) r = mid-1,ans = mid;
		else l = mid+1;
	}
	printf("%d",ans);
	return 0;
}
