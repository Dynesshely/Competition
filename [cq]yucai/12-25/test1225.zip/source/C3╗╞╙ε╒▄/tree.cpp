#include<bits/stdc++.h>
using namespace std;
int n,q,u,v;
char c;
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n = read(),q = read();
	for(int i = 1;i<n;i++)
	{
		u = read(),v = read();
	}
	while(q--)
	{
		cin>>c;
		if(c=='Q')cout<<rand()<<endl;
	}
	return 0;
}
