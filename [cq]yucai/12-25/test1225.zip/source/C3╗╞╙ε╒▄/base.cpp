#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 2e2;
int cnt,w=1,n,s,l;
int ans[MAX]; 
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=x*10+(ch^48),ch=getchar();
	return x*f;
}
void add(int x)
{
	if(x==0) return;
	if(x<0)
	{
		cnt=2,s=l=-2;
		while(s>x)l*=4,s+=l,cnt+=2;
		ans[cnt]=1;
		if(cnt>w)w=cnt;
		add(x-l);
	}
	else
	{
		cnt=1,s=l=1;
		while(s<x)l*=4,s+=l,cnt+=2;
		ans[cnt]=1;
		if(cnt>w)w=cnt;
		add(x-l);
	}
	return;
}
signed main()
{
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	n = read();
	add(n);
	for(int i = w;i>=1;i--)printf("%lld",ans[i]);
	return 0;
}
