#include<bits/stdc++.h>
#define int long long
using namespace std;
const int MAX = 50;
struct node{
	int x,y,s;
}l;
bool operator < (const node &xx, const node &yy){ 
	return xx.s>yy.s; 
}
int n,m,ans=-1;
int sx,sy,zx,zy;
int a[MAX][MAX],b[MAX][MAX];
int f[8][2]={{2,1},{2,-1},{-2,1},{-2,-1},{1,2},{1,-2},{-1,2},{-1,-2}};
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	return x*f;
}
bool pd(int x,int y,int s)
{
	s -= a[x][y];
	if(x<=0 or y<=0 or x>n or y>m or a[x][y]==2 or b[x][y]<=s) return false;
	return true;
}
void bfs()
{
	priority_queue<node>ls;
	ls.push((node){sx,sy,0});
	while(!ls.empty())
	{
		l = ls.top();
		ls.pop();
		if(b[l.x][l.y]<l.s) continue;	
		if(l.x==zx and l.y==zy)
		{
			ans = l.s;
			break;
		}
		for(int i = 0;i<8;i++) 
			if(pd(l.x+f[i][0],l.y+f[i][1],l.s+1)) 
			{
				ls.push((node){l.x+f[i][0],l.y+f[i][1],l.s+1-a[l.x+f[i][0]][l.y+f[i][1]]});
				b[l.x+f[i][0]][l.y+f[i][1]] = l.s+1-a[l.x+f[i][0]][l.y+f[i][1]];
			}
	}
	printf("%lld",ans);
	if(ans!=-1)printf("\n1"); 
}
signed main()
{
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	n = read(),m = read(); 
	for(int i = 1;i<=n;i++)
		for(int j = 1;j<=m;j++) 
		{
			a[i][j]=read(),b[i][j]=1e9;
			if(a[i][j]==4)zx=i,zy=j,a[i][j]=1;
			if(a[i][j]==3)sx=i,sy=j,a[i][j]=2;
		}
	bfs();
	return 0;
}
