#include<bits/stdc++.h>
using namespace std;
int n,k;
int ans[32],flag;
int main() {
	freopen("base.in","r",stdin);
	freopen("base.out","w",stdout);
	memset(ans,0,sizeof(ans));
	flag=0;
	scanf("%d",&n);
	if(n==0) {
		printf("0");
		return 0;
	} else {
		k=n,n=abs(n);
		while(n>0) {
			int tmp=log2(n);
			if(k>0) {
				if(tmp%2==0) ans[tmp]++;
				else ans[tmp]++,ans[tmp+1]++;
			} else {
				if(tmp%2==0) ans[tmp]++,ans[tmp+1]++;
				else ans[tmp]++;
			}
			n=n-(1<<tmp);
		}
	}
	for(int i=0; i<=30; i++) {
		if(ans[i]>1) {
			ans[i+1]+=(ans[i]/2);
			ans[i+2]+=(ans[i]/2);
			ans[i]=ans[i]%2;
		}
	}
	for(int i=30; i>=0; i--) {
		if(ans[i]!=0) flag=1;
		if(flag==1)	printf("%d",ans[i]);
	}
	return 0;
}
