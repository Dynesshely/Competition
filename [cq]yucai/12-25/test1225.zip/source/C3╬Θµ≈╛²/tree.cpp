#include<bits/stdc++.h>
using namespace std;
int n,m;
int head[100007],nex[200007],to[200007];
int s[100007],ad[100007],dep[100007],cnt,sum[100007];
int fa[100007][20];
void add(int a,int b) {
	to[++cnt]=b;
	nex[cnt]=head[a];
	head[a]=cnt;
}
void dfs(int id,int p) {
	for(int i=head[id]; i; i=nex[i]) {
		if(to[i]==p) continue;
		dep[to[i]]=dep[id]+1;
		fa[to[i]][0]=id;
		dfs(to[i],id);
	}
}
void f() {
	for(int j=1; j<20; j++) {
		for(int i=1; i<=n; i++) {
			fa[i][j]=fa[fa[i][j-1]][j-1];
		}
	}
}
int lca(int x,int y) {
	if(dep[x]>dep[y]) swap(x,y);//dep[x]<=dep[y]
	for(int i=19; i>=0; i--) {
		if(fa[y][i]!=0&&dep[fa[y][i]]>=dep[x]) y=fa[y][i];
	}
	for(int i=19; i>=0; i--) {
		if(fa[y][i]!=0&&fa[x][i]!=0&&dep[fa[y][i]]!=dep[fa[x][i]]) x=fa[x][i],y=fa[y][i];
	}
	if(x==y) return y;
	return fa[y][0];
}
void dfs2(int id,int p) {
	for(int i=head[id]; i; i=nex[i]) {
		if(to[i]==p) continue;
		dfs2(to[i],id);
		ad[id]+=ad[to[i]];
	}
}
void dfs3(int id,int p) {
	for(int i=head[id]; i; i=nex[i]) {
		if(to[i]==p) continue;
		sum[to[i]]+=sum[id];
		dfs3(to[i],id);
	}
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1; i<n; i++) {
		int u,v;
		scanf("%d %d",&u,&v);
		add(u,v);
		add(v,u);
	}
	dfs(1,-1);
	f();
	for(int i=1; i<=m; i++) {
		char ch;
		int A,B;
		cin>>ch;
		scanf("%d %d",&A,&B);
		int lc=lca(A,B);
		if(ch=='P') { //����
			ad[A]++,ad[B]++;
			ad[lc]-=2;
		} else { //����

			dfs2(1,-1);
			for(int j=1; j<=n; j++) {
				s[j]+=ad[j],ad[j]=0;
				sum[j]=s[j];
			}
			dfs3(1,-1);
			printf("%d\n",sum[A]+sum[B]-2*sum[lc]);
		}
	}
	return 0;
}
