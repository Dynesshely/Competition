#include<bits/stdc++.h>
using namespace std;
int n,l=0,r=1000000;
int cap[507][507],k,ans=1e6,flag=0;
int ad[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
int vis[507][507];
bool ok(int x,int y)
{
	if(x>=1&&x<=n&&y>=1&&y<=n&&vis[x][y]==0) return 1;
	return 0;
}
int cost(int x1,int y1,int x2,int y2)
{
	return abs(cap[x1][y1]-cap[x2][y2]);
}
void dfs(int x,int y,int nowans)
{
	flag++;
	for(int v=0;v<4;v++)
	{
		int dx=x+ad[v][0],dy=y+ad[v][1];
		if(ok(dx,dy)&&cost(x,y,dx,dy)<=nowans) 
		{
			vis[dx][dy]=1;
			dfs(dx,dy,nowans);
		}
	}
	
}
bool check(int nowans)
{
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{	flag=0;
			if(vis[i][j]==0)
			{
				vis[i][j]=1;
				dfs(i,j,nowans);
				if(flag>=k) return 1;
			}
		}
	}
	return 0;
}
int main()
{
	freopen("tractor.in","r",stdin);
	freopen("tractor.out","w",stdout);
	scanf("%d",&n);
	k=(n+1)/2;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			scanf("%d",&cap[i][j]);
		}
	}
	while(l<=r)
	{
		int mid=(l+r)>>1;
		if(check(mid)) ans=mid,r=mid-1;
		else l=mid+1;
	}
	printf("%d",ans);
	return 0;
 } 
