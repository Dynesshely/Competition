#include<bits/stdc++.h>
using namespace std;
int n,m,si,sj,ti,tj;
int cap[37][37],vis[37][37],num[37][37];
queue<pair<int,int> > q1,q2;
int ad[8][2]= {{1,2},{-1,2},{1,-2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
bool ok(int x,int y) {
	if(x>=1&&x<=n&&y>=1&&y<=m) return 1;
	return 0;
}
void bfs() {
	q1.push(make_pair(si,sj));
	vis[si][sj]=0;
	while(!q1.empty()) {
		int xi=q1.front().first,xj=q1.front().second;
		q1.pop(),q2.push(make_pair(xi,xj));
		for(int i=0; i<8; i++) {
			int dx=xi+ad[i][0],dy=xj+ad[i][1];
			if(ok(dx,dy)&&cap[dx][dy]==1&&vis[dx][dy]==-1) {
				vis[dx][dy]=0;
				q1.push(make_pair(dx,dy));
			}
		}
	}
	while(!q2.empty()) {
		int xi=q2.front().first,xj=q2.front().second;
		q2.pop();
		for(int i=0; i<8; i++) {
			int dx=xi+ad[i][0],dy=xj+ad[i][1];
			if(ok(dx,dy)&&cap[dx][dy]!=2) {
				if(cap[dx][dy]==0&&(vis[dx][dy]==-1||vis[dx][dy]>vis[xi][xj]+1)) {
					vis[dx][dy]=vis[xi][xj]+1;
					num[dx][dy]=0;
					q2.push(make_pair(dx,dy));
				} else if(cap[dx][dy]!=0&&(vis[dx][dy]==-1||vis[dx][dy]>vis[xi][xj])&&vis[xi][xj]!=0) {
					vis[dx][dy]=vis[xi][xj];
					num[dx][dy]=0;
					q2.push(make_pair(dx,dy));
				}
				if(cap[dx][dy]==0&&vis[dx][dy]==vis[xi][xj]+1) num[dx][dy]++;
				if(cap[dx][dy]!=0&&vis[dx][dy]==vis[xi][xj]) num[dx][dy]++;
			}
		}
	}
}
int main() {
	freopen("dance.in","r",stdin);
	freopen("dance.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=m; j++) {
			scanf("%d",&cap[i][j]);
			if(cap[i][j]==3) si=i,sj=j;
			if(cap[i][j]==4) ti=i,tj=j;
		}
	}
	memset(vis,-1,sizeof(vis));
	bfs();
	if(vis[ti][tj]==-1) printf("-1\n");
	else printf("%d\n%d",vis[ti][tj],num[ti][tj]);
	return 0;
}
